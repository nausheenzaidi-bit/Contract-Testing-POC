import { GraphQLResolveInfo, GraphQLScalarType, GraphQLScalarTypeConfig } from 'graphql';
import { TypedDocumentNode as DocumentNode } from '@graphql-typed-document-node/core';
export type Maybe<T> = T | null;
export type InputMaybe<T> = T | null;
export type Exact<T extends { [key: string]: unknown }> = { [K in keyof T]: T[K] };
export type MakeOptional<T, K extends keyof T> = Omit<T, K> & { [SubKey in K]?: Maybe<T[SubKey]> };
export type MakeMaybe<T, K extends keyof T> = Omit<T, K> & { [SubKey in K]: Maybe<T[SubKey]> };
export type MakeEmpty<T extends { [key: string]: unknown }, K extends keyof T> = { [_ in K]?: never };
export type Incremental<T> = T | { [P in keyof T]?: P extends ' $fragmentName' | '__typename' ? T[P] : never };
export type Omit<T, K extends keyof T> = Pick<T, Exclude<keyof T, K>>;
export type RequireFields<T, K extends keyof T> = Omit<T, K> & { [P in K]-?: NonNullable<T[P]> };
/** All built-in and custom scalars, mapped to their actual values */
export type Scalars = {
  ID: { input: string; output: string; }
  String: { input: string; output: string; }
  Boolean: { input: boolean; output: boolean; }
  Int: { input: number; output: number; }
  Float: { input: number; output: number; }
  /** The `ComponentCursor` scalar type is a base64 encoded string that represents an opaque and unique identifier for Page components. */
  ComponentCursor: { input: any; output: any; }
  /**
   * The `ContentCursor` scalar type is a base64 encoded string
   * that represents an opaque and unique identifier for Content Modules within a ChannelComponent.
   */
  ContentCursor: { input: any; output: any; }
  ContextFieldValue: { input: any; output: any; }
  Date: { input: any; output: any; }
  DateTime: { input: any; output: any; }
  /** A date-time string at UTC, such as 2007-12-03T10:15:30Z, compliant with the `date-time` format outlined in section 5.6 of the RFC 3339 profile of the ISO 8601 standard for representation of dates and times using the Gregorian calendar.This scalar is serialized to a string in ISO 8601 format and parsed from a string in ISO 8601 format. */
  DateTimeISO: { input: any; output: any; }
  /**
   * A string representing a duration conforming to the ISO8601 standard,
   * such as: P1W1DT13H23M34S
   * P is the duration designator (for period) placed at the start of the duration representation.
   * Y is the year designator that follows the value for the number of years.
   * M is the month designator that follows the value for the number of months.
   * W is the week designator that follows the value for the number of weeks.
   * D is the day designator that follows the value for the number of days.
   * T is the time designator that precedes the time components of the representation.
   * H is the hour designator that follows the value for the number of hours.
   * M is the minute designator that follows the value for the number of minutes.
   * S is the second designator that follows the value for the number of seconds.
   *
   * Note the time designator, T, that precedes the time value.
   *
   * Matches moment.js, Luxon and DateFns implementations
   * ,/. is valid for decimal places and +/- is a valid prefix
   */
  Duration: { input: any; output: any; }
  /** The `JSON` scalar type represents JSON values as specified by [ECMA-404](http://www.ecma-international.org/publications/files/ECMA-ST/ECMA-404.pdf). */
  JSON: { input: any; output: any; }
  /** The `JSONObject` scalar type represents JSON objects as specified by [ECMA-404](http://www.ecma-international.org/publications/files/ECMA-ST/ECMA-404.pdf). */
  JSONObject: { input: any; output: any; }
  /** A field whose value is a JSON Web Token (JWT): https://jwt.io/introduction. */
  JWT: { input: any; output: any; }
  /** The locale in the format of a BCP 47 (RFC 5646) standard string */
  Locale: { input: any; output: any; }
  /** The `ID` scalar type represents a unique MongoDB identifier in collection. MongoDB by default use 12-byte ObjectId value (https://docs.mongodb.com/manual/reference/bson-types/#objectid). But MongoDB also may accepts string or integer as correct values for _id field. */
  MongoID: { input: any; output: any; }
  /** A string that cannot be passed as an empty value */
  NonEmptyString: { input: any; output: any; }
  /** Floats that will have a value of 0 or more. */
  NonNegativeFloat: { input: any; output: any; }
  /** Integers that will have a value of 0 or more. */
  NonNegativeInt: { input: any; output: any; }
  /** Integers that will have a value greater than 0. */
  PositiveInt: { input: any; output: any; }
  /** A field whose value conforms to the standard URL format as specified in RFC3986: https://www.ietf.org/rfc/rfc3986.txt. */
  URL: { input: any; output: any; }
  /** A field whose value is a generic Universally Unique Identifier: https://en.wikipedia.org/wiki/Universally_unique_identifier. */
  UUID: { input: any; output: any; }
};

export type A2AResult = DsContentModelResult & {
  __typename?: 'A2AResult';
  article?: Maybe<StandaloneContentModule>;
  contentID: Scalars['String']['output'];
  score: Scalars['Float']['output'];
  type: ContentModuleType;
};

export type A2VResult = DsContentModelResult & {
  __typename?: 'A2VResult';
  contentID: Scalars['String']['output'];
  score: Scalars['Float']['output'];
  type: ContentModuleType;
  video?: Maybe<StandaloneContentModule>;
};

export type Action = {
  __typename?: 'Action';
  download?: Maybe<Allowed>;
  list?: Maybe<Allowed>;
  play?: Maybe<Allowed>;
};

export enum Actions {
  Created = 'CREATED',
  Deleted = 'DELETED',
  Updated = 'UPDATED'
}

export type AddAlertRankInput = {
  alertRanks?: InputMaybe<Array<AlertRankInput>>;
};

export type AddAlertRankResponse = {
  __typename?: 'AddAlertRankResponse';
  message?: Maybe<Scalars['String']['output']>;
  status: Scalars['String']['output'];
};

export type AdsAdSize = {
  __typename?: 'AdsAdSize';
  height?: Maybe<Scalars['Int']['output']>;
  width?: Maybe<Scalars['Int']['output']>;
};

/**
 * AdsChannelConfiguration | Ads API
 * ----------------------------------------------
 * Provides the ad registry and configuration for the Channel entity. This includes a registry for the
 * top-level view, as well as each section or grouping for the channel.
 */
export type AdsChannelConfiguration = {
  __typename?: 'AdsChannelConfiguration';
  adUnitPath: Scalars['String']['output'];
  configuration?: Maybe<AdsModuleConfiguration>;
  groupings?: Maybe<Array<Maybe<AdsChannelGroupingConfiguration>>>;
  registry: AdsDeployedState;
};

/**
 * AdsChannelGroupingConfiguration | Ads API
 * ----------------------------------------------
 * A mapping of ad slot registries for each grouping in a Channel. The id property maps to an id of
 * each of the groupings for the channel.
 */
export type AdsChannelGroupingConfiguration = {
  __typename?: 'AdsChannelGroupingConfiguration';
  adUnitPath: Scalars['String']['output'];
  id: Scalars['String']['output'];
  registry: AdsDeployedState;
};

/**
 *  AdsConfiguration | Ads API
 *  ----------------------------------------------
 * Configuration related to serving ads. Provides the ad slot registry as well as the configuration
 * for the web ad library, AdFuel.
 */
export type AdsConfiguration = {
  __typename?: 'AdsConfiguration';
  adUnitPath: Scalars['String']['output'];
  configuration?: Maybe<AdsModuleConfiguration>;
  registry: AdsDeployedState;
};

export type AdsDeployedState = {
  __typename?: 'AdsDeployedState';
  error?: Maybe<Scalars['String']['output']>;
  hasInViewRefresh?: Maybe<Scalars['Boolean']['output']>;
  hasRealTimeAdInsertion?: Maybe<Scalars['Boolean']['output']>;
  inViewRefreshCount?: Maybe<Scalars['Int']['output']>;
  inViewRefreshInterval?: Maybe<Scalars['Int']['output']>;
  isSingleton?: Maybe<Scalars['Boolean']['output']>;
  name?: Maybe<Scalars['String']['output']>;
  rtaiBuffer?: Maybe<Scalars['Int']['output']>;
  rtaiInitialPlacement?: Maybe<Scalars['Int']['output']>;
  rtaiMaxNoOfAds?: Maybe<Scalars['Int']['output']>;
  rtaiOffset?: Maybe<Scalars['Int']['output']>;
  rtaiParentSelector?: Maybe<Scalars['String']['output']>;
  safeFrameAllowPushExpansion?: Maybe<Scalars['Boolean']['output']>;
  safeFrameConfig?: Maybe<Scalars['Boolean']['output']>;
  safeFrameOverlayExpansion?: Maybe<Scalars['Boolean']['output']>;
  safeFrameSandboxMode?: Maybe<Scalars['Boolean']['output']>;
  slots?: Maybe<Array<Maybe<AdsSlot>>>;
  tagForChildDirectedTreatment?: Maybe<Scalars['Boolean']['output']>;
  targetings?: Maybe<Array<Maybe<AdsTargeting>>>;
  template?: Maybe<Scalars['String']['output']>;
};

export type AdsHistory = {
  __typename?: 'AdsHistory';
  area?: Maybe<Scalars['String']['output']>;
  modifiedBy?: Maybe<Scalars['String']['output']>;
  modifiedOn?: Maybe<Scalars['Float']['output']>;
  newValue?: Maybe<Scalars['String']['output']>;
  oldValue?: Maybe<Scalars['String']['output']>;
};

/**
 * AdsModuleConfiguration | Ads API
 * ----------------------------------------------
 * Provides an ad configuration JSON blob that can be parsed and passed to AdFuel when content is
 * rendered in a web view or in a web browser.
 */
export type AdsModuleConfiguration = {
  __typename?: 'AdsModuleConfiguration';
  /** Configuration for AdFuel in strigified JSON */
  jsonBlob: Scalars['String']['output'];
};

export type AdsRegistryDetailItem = {
  __typename?: 'AdsRegistryDetailItem';
  adUnitPath?: Maybe<Scalars['String']['output']>;
  description?: Maybe<Scalars['String']['output']>;
  error?: Maybe<Scalars['String']['output']>;
  lastDeployedOn?: Maybe<Scalars['Date']['output']>;
  name?: Maybe<Scalars['String']['output']>;
  nameLowered?: Maybe<Scalars['String']['output']>;
  slots?: Maybe<Array<Maybe<Scalars['String']['output']>>>;
};

export type AdsSlot = {
  __typename?: 'AdsSlot';
  adSizes?: Maybe<Array<Maybe<AdsAdSize>>>;
  adUnitPath?: Maybe<Scalars['String']['output']>;
  hasInViewRefresh?: Maybe<Scalars['Boolean']['output']>;
  inViewRefreshCount?: Maybe<Scalars['Int']['output']>;
  inViewRefreshInterval?: Maybe<Scalars['Int']['output']>;
  isFluid?: Maybe<Scalars['Boolean']['output']>;
  isInheritAdUnitFromRegistry?: Maybe<Scalars['Boolean']['output']>;
  isResponsive?: Maybe<Scalars['Boolean']['output']>;
  name?: Maybe<Scalars['String']['output']>;
  safeFrameAllowOverlayExpansion?: Maybe<Scalars['Boolean']['output']>;
  safeFrameAllowPushExpansion?: Maybe<Scalars['Boolean']['output']>;
  safeFrameConfig?: Maybe<Scalars['Boolean']['output']>;
  safeFrameSandboxMode?: Maybe<Scalars['Boolean']['output']>;
  targetings?: Maybe<Array<Maybe<AdsTargeting>>>;
  viewports?: Maybe<Array<Maybe<AdsViewport>>>;
};

export type AdsTargeting = {
  __typename?: 'AdsTargeting';
  key?: Maybe<Scalars['String']['output']>;
  value?: Maybe<Scalars['String']['output']>;
};

export type AdsViewport = {
  __typename?: 'AdsViewport';
  fluid?: Maybe<Scalars['Boolean']['output']>;
  height: Scalars['Int']['output'];
  name?: Maybe<Scalars['String']['output']>;
  sizes?: Maybe<Array<Maybe<Scalars['String']['output']>>>;
  width: Scalars['Int']['output'];
};

export type AlertAnalytics = {
  __typename?: 'AlertAnalytics';
  gamecastType?: Maybe<AlertGamecastType>;
  genres: Array<AlertGenre>;
};

export type AlertAnalyticsInput = {
  gamecastType?: InputMaybe<AlertGamecastType>;
  genres: Array<AlertGenre>;
};

export enum AlertCategory {
  Creators = 'creators',
  Highlights = 'highlights',
  News = 'news',
  Viral = 'viral'
}

export type AlertDestination = {
  __typename?: 'AlertDestination';
  contentModuleId?: Maybe<Scalars['String']['output']>;
  tagUUID: Scalars['String']['output'];
};

export type AlertDestinationInput = {
  contentModuleId?: InputMaybe<Scalars['String']['input']>;
  tagDisplayName?: InputMaybe<Scalars['String']['input']>;
  tagUUID: Scalars['String']['input'];
};

export enum AlertGamecastType {
  Halftime = 'halftime',
  Overtime = 'overtime',
  Postgame = 'postgame',
  Pregame = 'pregame'
}

export enum AlertGenre {
  Automated = 'automated',
  Betting = 'betting',
  CloseGame = 'closeGame',
  Highlights = 'highlights',
  News = 'news',
  Sensitive = 'sensitive',
  TuneIn = 'tuneIn',
  Viral = 'viral'
}

export type AlertInput = {
  type: AlertTypes;
  value: Scalars['Boolean']['input'];
};

export type AlertMediaAttachment = {
  __typename?: 'AlertMediaAttachment';
  /** Video reference to support video as media attachment */
  editId?: Maybe<Scalars['String']['output']>;
  height?: Maybe<Scalars['String']['output']>;
  /** This is the file extension of the media */
  mediaType: AlertMediaType;
  /** This is the url for the media */
  mediaUrl: Scalars['String']['output'];
  width?: Maybe<Scalars['String']['output']>;
};

export type AlertMediaAttachmentInput = {
  /** Video reference to support video as media attachment */
  editId?: InputMaybe<Scalars['String']['input']>;
  height?: InputMaybe<Scalars['String']['input']>;
  /** This is the file extension of the media */
  mediaType: AlertMediaType;
  /** This is the url for the media */
  mediaUrl: Scalars['String']['input'];
  width?: InputMaybe<Scalars['String']['input']>;
};

export enum AlertMediaType {
  Jpg = 'jpg',
  Png = 'png',
  Video = 'video'
}

export type AlertPreference = {
  __typename?: 'AlertPreference';
  enabled: Scalars['Boolean']['output'];
  type: AlertTypes;
};

export type AlertRank = {
  __typename?: 'AlertRank';
  pushNotification: PushNotification;
  rank: Scalars['Int']['output'];
};

export type AlertRankInput = {
  pushNotificationId: Scalars['ID']['input'];
  /** The values for the alert rank. E. g. [5, 10, 25, 50, 100] */
  rank?: InputMaybe<Scalars['Int']['input']>;
};

export enum AlertRegion {
  /** Andorra */
  Ad = 'AD',
  /** United Arab Emirates (the) */
  Ae = 'AE',
  /** Albania */
  Al = 'AL',
  /** Angola */
  Ao = 'AO',
  /** Argentina */
  Ar = 'AR',
  /** American Samoa */
  As = 'AS',
  /** Austria */
  At = 'AT',
  /** Australia */
  Au = 'AU',
  /** Bosnia and Herzegovina */
  Ba = 'BA',
  /** Barbados */
  Bb = 'BB',
  /** Belgium */
  Be = 'BE',
  /** Bulgaria */
  Bg = 'BG',
  /** Bahrain */
  Bh = 'BH',
  /** Bermuda */
  Bm = 'BM',
  /** Bolivia (Plurinational State of) */
  Bo = 'BO',
  /** Brazil */
  Br = 'BR',
  /** Bahamas (the) */
  Bs = 'BS',
  /** Belize */
  Bz = 'BZ',
  /** Canada */
  Ca = 'CA',
  /** Chile */
  Cl = 'CL',
  /** Cameroon */
  Cm = 'CM',
  /** Colombia */
  Co = 'CO',
  /** Costa Rica */
  Cr = 'CR',
  /** Curaçao */
  Cw = 'CW',
  /** Cyprus */
  Cy = 'CY',
  /** Czechia */
  Cz = 'CZ',
  /** Germany */
  De = 'DE',
  /** Denmark */
  Dk = 'DK',
  /** Dominican Republic (the) */
  Do = 'DO',
  /** Algeria */
  Dz = 'DZ',
  /** Ecuador */
  Ec = 'EC',
  /** Estonia */
  Ee = 'EE',
  /** Egypt */
  Eg = 'EG',
  /** Spain */
  Es = 'ES',
  /** Finland */
  Fi = 'FI',
  /** France */
  Fr = 'FR',
  /** United Kingdom of Great Britain and Northern Ireland (the) */
  Gb = 'GB',
  /** Georgia */
  Ge = 'GE',
  /** Ghana */
  Gh = 'GH',
  /** Greece */
  Gr = 'GR',
  /** Guatemala */
  Gt = 'GT',
  /** Guam */
  Gu = 'GU',
  /** Guyana */
  Gy = 'GY',
  /** Hong Kong */
  Hk = 'HK',
  /** Honduras */
  Hn = 'HN',
  /** Croatia */
  Hr = 'HR',
  /** Hungary */
  Hu = 'HU',
  /** Indonesia */
  Id = 'ID',
  /** Ireland */
  Ie = 'IE',
  /** Israel */
  Il = 'IL',
  /** India */
  In = 'IN',
  /** Italy */
  It = 'IT',
  /** Jamaica */
  Jm = 'JM',
  /** Jordan */
  Jo = 'JO',
  /** Kenya */
  Ke = 'KE',
  /** Kuwait */
  Kw = 'KW',
  /** Lebanon */
  Lb = 'LB',
  /** Lithuania */
  Lt = 'LT',
  /** Luxembourg */
  Lu = 'LU',
  /** Latvia */
  Lv = 'LV',
  /** Morocco */
  Ma = 'MA',
  /** Marshall Islands */
  Mh = 'MH',
  /** Republic of North Macedonia */
  Mk = 'MK',
  /** Mongolia */
  Mn = 'MN',
  /** Northern Mariana Islands (The) */
  Mp = 'MP',
  /** Mexico */
  Mx = 'MX',
  /** Malaysia */
  My = 'MY',
  /** Nicaragua */
  Ni = 'NI',
  /** Netherlands (the) */
  Nl = 'NL',
  /** Norway */
  No = 'NO',
  /** New Zealand */
  Nz = 'NZ',
  /** Panama */
  Pa = 'PA',
  /** Peru */
  Pe = 'PE',
  /** Philippines (the) */
  Ph = 'PH',
  /** Pakistan */
  Pk = 'PK',
  /** Poland */
  Pl = 'PL',
  /** Puerto Rico */
  Pr = 'PR',
  /** Portugal */
  Pt = 'PT',
  /** Palau */
  Pw = 'PW',
  /** Paraguay */
  Py = 'PY',
  /** Romania */
  Ro = 'RO',
  /** Serbia */
  Rs = 'RS',
  /** Saudi Arabia */
  Sa = 'SA',
  /** Sweden */
  Se = 'SE',
  /** Singapore */
  Sg = 'SG',
  /** Slovenia */
  Si = 'SI',
  /** Slovakia */
  Sk = 'SK',
  /** Senegal */
  Sn = 'SN',
  /** El Salvador */
  Sv = 'SV',
  /** Thailand */
  Th = 'TH',
  /** Trinidad and Tobago */
  Tt = 'TT',
  /** Taiwan (Province of China) */
  Tw = 'TW',
  /** Tanzania, United Republic of */
  Tz = 'TZ',
  /** Ukraine */
  Ua = 'UA',
  /** Uganda */
  Ug = 'UG',
  /** US Minor Outlying Islands */
  Um = 'UM',
  /** United States of America */
  Us = 'US',
  /** Uruguay */
  Uy = 'UY',
  /** Venezuela (Bolivarian Republic of) */
  Ve = 'VE',
  /** Virgin Islands (U.S.) */
  Vi = 'VI',
  /** Zambia */
  Zm = 'ZM',
  /** Zimbabwe */
  Zw = 'ZW'
}

export enum AlertTypes {
  Creators = 'creators',
  Highlights = 'highlights',
  News = 'news',
  /** @deprecated This alert type is deprecated and will be removed in a future version */
  Scores = 'scores',
  SocialAlertComments = 'social_alert_comments',
  SocialAlertFires = 'social_alert_fires',
  SocialAlertFollows = 'social_alert_follows',
  SocialAlertMentions = 'social_alert_mentions',
  SocialAlertPolls = 'social_alert_polls',
  Spoilers = 'spoilers',
  Viral = 'viral'
}

export type AllowAll = {
  __typename?: 'AllowAll';
  allowAll?: Maybe<Scalars['Boolean']['output']>;
};

export type Allowed = {
  __typename?: 'Allowed';
  allowed?: Maybe<Scalars['Boolean']['output']>;
};

export type Article = {
  __typename?: 'Article';
  _id: Scalars['MongoID']['output'];
  /** Ads Configuration | Ads API */
  adsConfig?: Maybe<AdsConfiguration>;
  ampUrl?: Maybe<Scalars['String']['output']>;
  author?: Maybe<ArticleAuthor>;
  betTags?: Maybe<Array<Maybe<TagV2>>>;
  /** @deprecated use field updatedAt which is a correctly typed Date */
  changed?: Maybe<Scalars['String']['output']>;
  cmsId: Scalars['String']['output'];
  containsGeoblockedContent?: Maybe<Scalars['Boolean']['output']>;
  contentSubtype?: Maybe<Scalars['String']['output']>;
  contentType: Scalars['String']['output'];
  /** @deprecated use field createdAt which is a correctly typed Date */
  created?: Maybe<Scalars['String']['output']>;
  createdAt?: Maybe<Scalars['Date']['output']>;
  description?: Maybe<Scalars['String']['output']>;
  displayId?: Maybe<Scalars['Int']['output']>;
  hash?: Maybe<Scalars['String']['output']>;
  hideBetModule?: Maybe<Scalars['Boolean']['output']>;
  image?: Maybe<Image>;
  isAdSensitive?: Maybe<Scalars['Boolean']['output']>;
  isEvergreen?: Maybe<Scalars['Boolean']['output']>;
  isPtScheduled?: Maybe<Scalars['Boolean']['output']>;
  isPublished: Scalars['Boolean']['output'];
  language?: Maybe<Scalars['String']['output']>;
  legacy?: Maybe<Scalars['Boolean']['output']>;
  metatags?: Maybe<Array<Maybe<PageMetatags>>>;
  primaryTag: TagV2;
  publishedDateTime?: Maybe<Scalars['Date']['output']>;
  recommendedArticles: Array<A2AResult>;
  recommendedVideos: Array<A2VResult>;
  schemaVersion?: Maybe<Scalars['String']['output']>;
  slides?: Maybe<Array<Maybe<Slide>>>;
  slug?: Maybe<Scalars['String']['output']>;
  statsBetOffers?: Maybe<StatsBetOffer>;
  tags?: Maybe<Array<Maybe<TagV2>>>;
  tenant?: Maybe<Scalars['String']['output']>;
  title: Scalars['String']['output'];
  /**
   * trendingRank | Data Services API
   *
   * Returns the Trending Rank from [1,100]. Returns null if not trending.
   */
  trendingRank?: Maybe<Scalars['Int']['output']>;
  updatedAt?: Maybe<Scalars['Date']['output']>;
  uuid: Scalars['String']['output'];
};


export type ArticleRecommendedArticlesArgs = {
  limit?: InputMaybe<Scalars['Int']['input']>;
  version?: InputMaybe<Scalars['Int']['input']>;
};


export type ArticleRecommendedVideosArgs = {
  aspectRatio?: InputMaybe<AspectRatio>;
  countryCode?: InputMaybe<Scalars['String']['input']>;
  limit?: InputMaybe<Scalars['Int']['input']>;
  version?: InputMaybe<Scalars['Int']['input']>;
};


export type ArticleStatsBetOffersArgs = {
  timezone?: InputMaybe<Scalars['Int']['input']>;
};

export type ArticleAuthor = {
  __typename?: 'ArticleAuthor';
  id?: Maybe<Scalars['String']['output']>;
  name?: Maybe<Scalars['String']['output']>;
  photoUrl?: Maybe<Scalars['String']['output']>;
  socialMediaHandles?: Maybe<Array<Maybe<SocialMediaHandle>>>;
  title?: Maybe<Scalars['String']['output']>;
};

export type ArticleConnection = {
  __typename?: 'ArticleConnection';
  edges: Array<ArticleEdge>;
  pageInfo: PageInfo;
  /** The total number of items *found* by the search */
  totalFound: Scalars['Int']['output'];
  /** The total number of items *returned* by the search */
  totalReturned: Scalars['Int']['output'];
};

export type ArticleEdge = {
  __typename?: 'ArticleEdge';
  cursor: Scalars['String']['output'];
  node: Article;
};

export type ArticleFindManyParametersInput = {
  /**
   * Filter search results by a date range of when the articles were created.
   *
   * The range is inclusive of the dates provided (ie. >= <=)
   */
  createdDateRange?: InputMaybe<DateRangeFilter>;
  /**
   * Filter search results by a date range of when the articles were published.
   *
   * The range is inclusive of the dates provided (ie. >= <=)
   */
  publishedDateRange?: InputMaybe<DateRangeFilter>;
  /**
   * The term to search for.
   *
   * Requires a minimum of 3 characters to start getting results.
   *
   * Supports passing (1) "OR/AND" boolean operator in queries.
   *
   * (example OR: "nba OR nfl") (example AND: "coach AND LeBron")
   */
  query?: InputMaybe<Scalars['String']['input']>;
  /** List of tag UUIDs to apply to the search. Multiple UUIDs will be treated as an *OR* operation */
  tagUUIDList?: InputMaybe<Array<Scalars['String']['input']>>;
  /** Filter search results to ARTICLE or SLIDESHOW types */
  type?: InputMaybe<ArticleType>;
  /**
   * Filter search results by a date range of when the articles were updated.
   *
   * The range is inclusive of the dates provided (ie. >= <=)
   */
  updatedDateRange?: InputMaybe<DateRangeFilter>;
};

export enum ArticleType {
  Article = 'ARTICLE',
  Slideshow = 'SLIDESHOW'
}

export enum AspectRatio {
  Any = 'Any',
  Horizontal = 'Horizontal',
  Vertical = 'Vertical'
}

export type AssetConnection = {
  __typename?: 'AssetConnection';
  edges?: Maybe<Array<Maybe<AssetEdge>>>;
  nodes?: Maybe<Array<Maybe<SearchResult>>>;
  pageInfo?: Maybe<PageInfo>;
  totalCount?: Maybe<Scalars['Int']['output']>;
};

export type AssetEdge = {
  __typename?: 'AssetEdge';
  cursor?: Maybe<Scalars['String']['output']>;
  node?: Maybe<SearchResult>;
};

export type Author = {
  __typename?: 'Author';
  /** The author name for internal articles */
  name?: Maybe<Scalars['String']['output']>;
};

export type Avatar = {
  __typename?: 'Avatar';
  file_name?: Maybe<Scalars['String']['output']>;
  url?: Maybe<Scalars['String']['output']>;
};

export type Badge = {
  __typename?: 'Badge';
  badge_icon_url?: Maybe<Scalars['String']['output']>;
  description?: Maybe<Scalars['String']['output']>;
  id?: Maybe<Scalars['String']['output']>;
  mimetype?: Maybe<Scalars['String']['output']>;
  name?: Maybe<Scalars['String']['output']>;
};

export type BadgeComponent = {
  __typename?: 'BadgeComponent';
  awarded_at?: Maybe<Scalars['String']['output']>;
  badge?: Maybe<Badge>;
};

export type BillingOrder = {
  __typename?: 'BillingOrder';
  scope?: Maybe<Scalars['String']['output']>;
  value?: Maybe<Scalars['Int']['output']>;
};

export type BlockedContent = {
  __typename?: 'BlockedContent';
  contentID: Scalars['String']['output'];
  insertedAt: Scalars['Date']['output'];
  type: ContentModuleType;
};

export type Brand = {
  __typename?: 'Brand';
  id?: Maybe<Identifier>;
  primary?: Maybe<Scalars['Boolean']['output']>;
};

export enum CacheControlScope {
  Private = 'PRIVATE',
  Public = 'PUBLIC'
}

export enum Category {
  Creators = 'creators',
  Highlights = 'highlights',
  News = 'news',
  Spoilers = 'spoilers',
  Viral = 'viral'
}

export enum CategoryType {
  Email = 'email',
  Push = 'push'
}

export type Channel = {
  __typename?: 'Channel';
  _id: Scalars['MongoID']['output'];
  /** Ads Channel Configuration | Ads API */
  adsConfig?: Maybe<AdsChannelConfiguration>;
  /** @deprecated use field updatedAt which is a correctly typed Date */
  changed?: Maybe<Scalars['String']['output']>;
  cmsId: Scalars['String']['output'];
  components: Array<Maybe<ChannelComponent>>;
  /** @deprecated use field createdAt which is a correctly typed Date */
  created?: Maybe<Scalars['String']['output']>;
  createdAt?: Maybe<Scalars['Date']['output']>;
  gameState?: Maybe<GameState>;
  groupingList?: Maybe<Array<Maybe<GroupingHeader>>>;
  groupings?: Maybe<Array<Maybe<Grouping>>>;
  headline?: Maybe<Scalars['String']['output']>;
  isPublished?: Maybe<Scalars['Boolean']['output']>;
  isTemplate?: Maybe<Scalars['Boolean']['output']>;
  language?: Maybe<Scalars['String']['output']>;
  metatags?: Maybe<Array<Maybe<PageMetatags>>>;
  pinnedContentModule?: Maybe<ContentModule>;
  schemaVersion?: Maybe<Scalars['String']['output']>;
  tag: TagV2;
  tenant?: Maybe<Scalars['String']['output']>;
  title?: Maybe<Scalars['String']['output']>;
  type?: Maybe<ChannelType>;
  updatedAt?: Maybe<Scalars['Date']['output']>;
  uuid: Scalars['String']['output'];
};


export type ChannelGroupingsArgs = {
  filter?: InputMaybe<Scalars['String']['input']>;
};

export type ChannelComponent = {
  __typename?: 'ChannelComponent';
  chat?: Maybe<ChatModule>;
  contents?: Maybe<Array<Maybe<ContentModule>>>;
  contentsConnection?: Maybe<ContentsConnection>;
  /**
   * dataServicesTagData | Data Services API
   *
   * Returns TagV2s according to the feature logic demanded by the given semanticID using data services.
   */
  dataServicesTagData: Array<TagV2>;
  description?: Maybe<Scalars['String']['output']>;
  headline?: Maybe<Scalars['String']['output']>;
  images?: Maybe<Array<Maybe<ImageWithStyle>>>;
  interlacingInterval?: Maybe<Scalars['Int']['output']>;
  isDomesticOnly?: Maybe<Scalars['Boolean']['output']>;
  link?: Maybe<Link>;
  semanticID?: Maybe<SemanticId>;
  semanticType?: Maybe<SemanticType>;
  statsGamecast?: Maybe<StatsGamecast>;
  statsSchedule?: Maybe<StatsSchedule>;
  statsScores?: Maybe<Scores>;
  statsStandings?: Maybe<StatsStanding>;
  subheadline?: Maybe<Scalars['String']['output']>;
  tagData?: Maybe<Array<Maybe<TagV2>>>;
  tagSlug?: Maybe<Scalars['String']['output']>;
  tagType?: Maybe<Scalars['String']['output']>;
  tagUUID?: Maybe<Scalars['String']['output']>;
  userAlerts?: Maybe<Array<PushNotification>>;
  userContents?: Maybe<Array<Maybe<StandaloneContentModule>>>;
  userInfo?: Maybe<User>;
  /** userSocialAlerts | Mock-only */
  userSocialAlerts?: Maybe<Array<UserSocialAlert>>;
  userTags?: Maybe<Array<Maybe<TagV2>>>;
  uuid: Scalars['String']['output'];
  watchInfo?: Maybe<Array<Maybe<WatchInfo>>>;
  weight?: Maybe<Scalars['Int']['output']>;
};


export type ChannelComponentContentsArgs = {
  contentType?: InputMaybe<Array<InputMaybe<ContentModuleType>>>;
  limit?: InputMaybe<Scalars['Int']['input']>;
  state?: InputMaybe<Array<InputMaybe<ModuleState>>>;
};


export type ChannelComponentContentsConnectionArgs = {
  after?: InputMaybe<Scalars['ContentCursor']['input']>;
  before?: InputMaybe<Scalars['ContentCursor']['input']>;
  first?: InputMaybe<Scalars['Int']['input']>;
  last?: InputMaybe<Scalars['Int']['input']>;
  paginationControl?: InputMaybe<Array<InputMaybe<PaginationControl>>>;
  state?: InputMaybe<Array<InputMaybe<ModuleState>>>;
};


export type ChannelComponentDataServicesTagDataArgs = {
  limit?: InputMaybe<Scalars['Int']['input']>;
};


export type ChannelComponentStatsScheduleArgs = {
  season?: InputMaybe<Scalars['Int']['input']>;
  timezone?: InputMaybe<Scalars['Int']['input']>;
};


export type ChannelComponentStatsScoresArgs = {
  context?: InputMaybe<Scalars['String']['input']>;
  date?: InputMaybe<Scalars['String']['input']>;
  league?: InputMaybe<Scalars['String']['input']>;
  locale?: InputMaybe<Scalars['String']['input']>;
  timezone?: InputMaybe<Scalars['Int']['input']>;
};


export type ChannelComponentStatsStandingsArgs = {
  filter?: InputMaybe<Scalars['String']['input']>;
  season?: InputMaybe<Scalars['Int']['input']>;
};


export type ChannelComponentUserAlertsArgs = {
  limit?: InputMaybe<Scalars['Int']['input']>;
  tenant: Tenant;
};


export type ChannelComponentUserContentsArgs = {
  limit?: InputMaybe<Scalars['Int']['input']>;
  offset?: InputMaybe<Scalars['Int']['input']>;
  profileID?: InputMaybe<Scalars['String']['input']>;
};


export type ChannelComponentUserInfoArgs = {
  profileId?: InputMaybe<Scalars['String']['input']>;
  tenant: Tenant;
};


export type ChannelComponentUserSocialAlertsArgs = {
  limit?: InputMaybe<Scalars['Int']['input']>;
  tenant: Tenant;
};


export type ChannelComponentUserTagsArgs = {
  tenant: Tenant;
};


export type ChannelComponentWatchInfoArgs = {
  providerName?: InputMaybe<Scalars['String']['input']>;
};

/**
 * ChannelRecommenderResult | Data Services API
 * Encapsulates all data related to the BR Channel Recommender Data Science Model.
 */
export type ChannelRecommenderResult = {
  __typename?: 'ChannelRecommenderResult';
  score: Scalars['Float']['output'];
  tagV2: TagV2;
};

export type ChannelStreamMetaData = {
  __typename?: 'ChannelStreamMetaData';
  _id?: Maybe<Scalars['MongoID']['output']>;
  contents?: Maybe<Array<Maybe<ContentModule>>>;
  id?: Maybe<Scalars['String']['output']>;
  semanticID?: Maybe<SemanticId>;
  tagUUID?: Maybe<Scalars['String']['output']>;
  weight?: Maybe<Scalars['Float']['output']>;
};


export type ChannelStreamMetaDataContentsArgs = {
  contentType?: InputMaybe<Array<InputMaybe<ContentModuleType>>>;
  limit?: InputMaybe<Scalars['Int']['input']>;
  state?: InputMaybe<Array<InputMaybe<ModuleState>>>;
};

export enum ChannelType {
  Alerts = 'Alerts',
  Creator = 'Creator',
  Discovery = 'Discovery',
  Following = 'Following',
  FollowingAddTags = 'FollowingAddTags',
  GameCast = 'GameCast',
  Home = 'Home',
  Interest = 'Interest',
  League = 'League',
  Onboarding = 'Onboarding',
  OnboardingAddTags = 'OnboardingAddTags',
  PopularTeam = 'PopularTeam',
  Scores = 'Scores',
  SmallTeam = 'SmallTeam',
  User = 'User'
}

export type ChatModule = {
  __typename?: 'ChatModule';
  chatroom?: Maybe<Scalars['String']['output']>;
};

export type Clock = {
  __typename?: 'Clock';
  hours?: Maybe<Scalars['String']['output']>;
  milliseconds?: Maybe<Scalars['String']['output']>;
  minutes?: Maybe<Scalars['String']['output']>;
  seconds?: Maybe<Scalars['String']['output']>;
  stoppage?: Maybe<Scalars['String']['output']>;
};

export type Competitor = {
  __typename?: 'Competitor';
  description?: Maybe<Scalars['String']['output']>;
  display_name_1?: Maybe<Scalars['String']['output']>;
  display_name_2?: Maybe<Scalars['String']['output']>;
  draws?: Maybe<Scalars['String']['output']>;
  hash?: Maybe<Scalars['String']['output']>;
  header_image_bucket?: Maybe<Scalars['String']['output']>;
  id?: Maybe<Scalars['ID']['output']>;
  league?: Maybe<League>;
  leagues?: Maybe<Array<Maybe<League>>>;
  logo_dark?: Maybe<Scalars['String']['output']>;
  logo_light?: Maybe<Scalars['String']['output']>;
  logo_split?: Maybe<Scalars['String']['output']>;
  losses?: Maybe<Scalars['String']['output']>;
  market?: Maybe<Scalars['String']['output']>;
  name?: Maybe<Scalars['String']['output']>;
  overtime_losses?: Maybe<Scalars['String']['output']>;
  rank?: Maybe<Scalars['String']['output']>;
  sport?: Maybe<Sport>;
  sportradar_id?: Maybe<Scalars['String']['output']>;
  team_abbr?: Maybe<Scalars['String']['output']>;
  team_alias?: Maybe<Scalars['String']['output']>;
  tournaments?: Maybe<Array<Maybe<Tournament>>>;
  wins?: Maybe<Scalars['String']['output']>;
};


export type CompetitorLeaguesArgs = {
  id?: InputMaybe<Scalars['ID']['input']>;
};


export type CompetitorTournamentsArgs = {
  id?: InputMaybe<Scalars['ID']['input']>;
};

export type Competitors = {
  __typename?: 'Competitors';
  competitors?: Maybe<Array<Maybe<Competitor>>>;
  index_end?: Maybe<Scalars['Int']['output']>;
  index_start?: Maybe<Scalars['Int']['output']>;
  total?: Maybe<Scalars['Int']['output']>;
};

export type Component = {
  __typename?: 'Component';
  _id?: Maybe<Scalars['MongoID']['output']>;
  content?: Maybe<Array<Maybe<Content>>>;
  description?: Maybe<Scalars['String']['output']>;
  endTime?: Maybe<Scalars['Date']['output']>;
  format?: Maybe<Scalars['String']['output']>;
  headline?: Maybe<Scalars['String']['output']>;
  id?: Maybe<Scalars['String']['output']>;
  image?: Maybe<Image>;
  images?: Maybe<Array<Maybe<ImageWithStyle>>>;
  isFavoriteTeam?: Maybe<Scalars['Boolean']['output']>;
  link?: Maybe<Link>;
  orientation?: Maybe<Scalars['String']['output']>;
  /** The reference stream */
  referenceStream?: Maybe<ReferenceStream>;
  startTime?: Maybe<Scalars['Date']['output']>;
  subheadline?: Maybe<Scalars['String']['output']>;
  type?: Maybe<Scalars['String']['output']>;
  uuid: Scalars['String']['output'];
  weight?: Maybe<Scalars['Float']['output']>;
};

export type ComponentEdge = {
  __typename?: 'ComponentEdge';
  cursor: Scalars['ComponentCursor']['output'];
  node: Component;
};

export type ComponentModule = {
  __typename?: 'ComponentModule';
  /** Hashed string used for sharing information with other graphs */
  hash?: Maybe<Scalars['String']['output']>;
  /** Date and time that the Content Modules was programmed into the Channel */
  insertedAt?: Maybe<Scalars['Date']['output']>;
  isPinned?: Maybe<Scalars['Boolean']['output']>;
  isPositionLocked?: Maybe<Scalars['Boolean']['output']>;
  position: Scalars['Int']['output'];
  positionLockExpiresAt?: Maybe<Scalars['Date']['output']>;
  semanticID?: Maybe<SemanticId>;
  tag?: Maybe<TagV2>;
  widgets?: Maybe<Array<Maybe<UgcWidget>>>;
};


export type ComponentModuleTagArgs = {
  tenant: Tenant;
};

export type ComponentsConnection = {
  __typename?: 'ComponentsConnection';
  edges: Array<ComponentEdge>;
  pageInfo: PageInfo;
  totalCount: Scalars['Int']['output'];
};

export type Conference = {
  __typename?: 'Conference';
  divisions?: Maybe<Array<Maybe<Division>>>;
  id?: Maybe<Scalars['ID']['output']>;
  league?: Maybe<League>;
  name?: Maybe<Scalars['String']['output']>;
  sport?: Maybe<Sport>;
  sportradar_id?: Maybe<Scalars['String']['output']>;
  teams?: Maybe<Array<Maybe<Competitor>>>;
};


export type ConferenceDivisionsArgs = {
  id?: InputMaybe<Scalars['ID']['input']>;
};


export type ConferenceTeamsArgs = {
  id?: InputMaybe<Scalars['ID']['input']>;
};

export type Conferences = {
  __typename?: 'Conferences';
  conferences?: Maybe<Array<Maybe<Conference>>>;
  index_end?: Maybe<Scalars['Int']['output']>;
  index_start?: Maybe<Scalars['Int']['output']>;
  total?: Maybe<Scalars['Int']['output']>;
};

export type ConfigJson = {
  __typename?: 'ConfigJson';
  _id: Scalars['MongoID']['output'];
  changed?: Maybe<Scalars['String']['output']>;
  cmsId: Scalars['String']['output'];
  created?: Maybe<Scalars['String']['output']>;
  isPublished?: Maybe<Scalars['Boolean']['output']>;
  jsonBlob?: Maybe<Scalars['String']['output']>;
  language?: Maybe<Scalars['String']['output']>;
  schemaVersion?: Maybe<Scalars['String']['output']>;
  tenant?: Maybe<Scalars['String']['output']>;
  title?: Maybe<Scalars['String']['output']>;
  uri: Scalars['String']['output'];
  uuid: Scalars['String']['output'];
};

export type Content = {
  __typename?: 'Content';
  _id?: Maybe<Scalars['MongoID']['output']>;
  allowedTypes?: Maybe<Array<Maybe<Scalars['String']['output']>>>;
  channelStream?: Maybe<ChannelStreamMetaData>;
  /** @deprecated This field will be removed. Please use the "clips" (plural) field to get Video entity data */
  clip?: Maybe<Scalars['String']['output']>;
  clips?: Maybe<Array<Maybe<Video>>>;
  contentModules?: Maybe<Array<Maybe<ContentModule>>>;
  episodes?: Maybe<Array<Maybe<Show>>>;
  /** @deprecated This field is deprecated. Please use the "events" (plural) field to get the full Event entity */
  event?: Maybe<Scalars['String']['output']>;
  events?: Maybe<Array<Maybe<Event>>>;
  filters?: Maybe<ContentFilters>;
  form?: Maybe<ContentForm>;
  hash?: Maybe<Scalars['String']['output']>;
  image?: Maybe<Image>;
  item?: Maybe<Item>;
  league?: Maybe<Scalars['String']['output']>;
  liveStream?: Maybe<Scalars['String']['output']>;
  product?: Maybe<Array<Maybe<Product>>>;
  series?: Maybe<Array<Maybe<Series>>>;
  show?: Maybe<ContentShow>;
  sort?: Maybe<ContentSort>;
  stream?: Maybe<StreamMetaData>;
  /** @deprecated This field is deprecated. Please use the "teams" (plural) field to get the full Competitor entity */
  team?: Maybe<Scalars['String']['output']>;
  teams?: Maybe<Array<Maybe<Competitor>>>;
  /** @deprecated This field is deprecated. Please use the "tournaments" (plural) field to get the full Tournament entity */
  tournament?: Maybe<Scalars['String']['output']>;
  tournaments?: Maybe<Array<Maybe<Tournament>>>;
  weight?: Maybe<Scalars['Float']['output']>;
};

/** The Brand or Source for content. Primarily for External Articles */
export type ContentBrand = {
  __typename?: 'ContentBrand';
  brandSourceUrls?: Maybe<Array<Maybe<Scalars['String']['output']>>>;
  cmsId: Scalars['String']['output'];
  isDeleted?: Maybe<Scalars['Boolean']['output']>;
  isPartner?: Maybe<Scalars['Boolean']['output']>;
  isPublished?: Maybe<Scalars['Boolean']['output']>;
  language?: Maybe<Scalars['String']['output']>;
  logos?: Maybe<Array<Maybe<ImageWithStyle>>>;
  name: Scalars['String']['output'];
  source: Scalars['String']['output'];
  tenant?: Maybe<Scalars['String']['output']>;
  uuid: Scalars['String']['output'];
};

export type ContentEdge = {
  __typename?: 'ContentEdge';
  cursor: Scalars['ContentCursor']['output'];
  node: ContentModule;
};

export type ContentFilters = {
  __typename?: 'ContentFilters';
  _id?: Maybe<Scalars['MongoID']['output']>;
  collections?: Maybe<Array<Maybe<Scalars['String']['output']>>>;
  isFavoriteTeam?: Maybe<Scalars['Boolean']['output']>;
  maxItems?: Maybe<Scalars['Float']['output']>;
  shows?: Maybe<Array<Maybe<Scalars['String']['output']>>>;
  status?: Maybe<Array<Maybe<Scalars['String']['output']>>>;
  tags?: Maybe<Array<Maybe<Scalars['String']['output']>>>;
  timeWindow?: Maybe<Array<Maybe<Scalars['Float']['output']>>>;
};

export type ContentForm = {
  __typename?: 'ContentForm';
  element?: Maybe<FormElement>;
};

export type ContentLibrarySearchParametersInput = {
  /** Filter search results to specific content types */
  contentTypeFilter?: InputMaybe<Array<ContentSearchType>>;
  /**
   * Filter search results by a date range of when the content was created.
   *
   * The range is inclusive of the dates provided (ie. >= <=)
   */
  createdDateRange?: InputMaybe<DateRangeFilter>;
  /** Whether or not the content should be scheduled in the Programming Tool */
  isPtScheduled?: InputMaybe<Scalars['Boolean']['input']>;
  /**
   * The term to search for.
   *
   * Requires a minimum of 3 characters to start getting results.
   *
   * Supports passing (1) "OR/AND" boolean operator in queries.
   *
   * (example OR: "nba OR nfl") (example AND: "coach AND LeBron")
   */
  query?: InputMaybe<Scalars['String']['input']>;
  /** Provides the ability to search on specific source fields. */
  sourceType?: InputMaybe<SearchSource>;
  /** List of tag UUIDs to apply to the search. Multiple UUIDs will be treated as an *OR* operation */
  tagUUIDList?: InputMaybe<Array<Scalars['String']['input']>>;
  /**
   * Toggle using either parital-text match (ie. autocomplete) or full-text match.
   * A different search algorithm will be run depending on this flag.
   * Partial-Text match (ie. autocomplete) is the default.
   */
  useFullTextSearch?: InputMaybe<Scalars['Boolean']['input']>;
  /** Filter VideoV2 search results by whether or not a video is full length or a clip */
  videoContentTypeFilter?: InputMaybe<VideoContentTypeFilter>;
};

export type ContentLibrarySearchResult = Article | Tweet | VideoV2;

export enum ContentLibrarySortDirection {
  Asc = 'ASC',
  Desc = 'DESC'
}

export type ContentLibrarySortParametersInput = {
  /** sort by the date the content was last updated. (sorts on field updatedAt) */
  changed?: InputMaybe<ContentLibrarySortDirection>;
  /** sort by the date the content was created. (sorts on field createdAt) */
  created?: InputMaybe<ContentLibrarySortDirection>;
  /** sort by the title of content */
  title?: InputMaybe<ContentLibrarySortDirection>;
};

export type ContentMetadata = {
  __typename?: 'ContentMetadata';
  video?: Maybe<VideoV2Metadata>;
};

export type ContentModule = {
  /** Indicates to what tagUUID the content module was alerted to. */
  alertedChannelTagUUID?: Maybe<Scalars['String']['output']>;
  /** List of countries that a content module will be visible. */
  allowedCountries?: Maybe<Array<Maybe<Scalars['String']['output']>>>;
  commentsEnabled?: Maybe<Scalars['Boolean']['output']>;
  /** List of Channels/Components (tag + semanticID) a content module is programmed to. */
  components?: Maybe<Array<Maybe<ComponentModule>>>;
  /** Also known as Commentary, short description of the content of a content module. */
  description: Scalars['String']['output'];
  /** Date and Time when a content module will not be visible anymore for end users. The state will be `UNPROGRAMMED`. */
  expiresAt?: Maybe<Scalars['Date']['output']>;
  hidden?: Maybe<Scalars['Boolean']['output']>;
  /** Date and Time when a hidden content module will automatically become visible again. */
  hiddenExpiresAt?: Maybe<Scalars['Date']['output']>;
  id: Scalars['ID']['output'];
  /** Date and time that the Content Modules was created. */
  insertedAt?: Maybe<Scalars['Date']['output']>;
  /** Indicates if a push notification was sent to the content module. */
  isAlerted?: Maybe<Scalars['Boolean']['output']>;
  /** Metadata containing community tag, author, and brand information for logos and display. */
  metaData?: Maybe<ModuleMetaData>;
  /** Date and Time when a content module will start to be visible for end users. The state will be `SCHEDULED`. */
  scheduledDate?: Maybe<Scalars['Date']['output']>;
  /** List of possible states of content module. One of `SCHEDULED`, `PROGRAMMED` or `UNPROGRAMMED`. */
  state?: Maybe<ModuleState>;
  /** Also known as Headline, that's the heading text of a content module. */
  title: Scalars['String']['output'];
  /** Date and time that a content module was last updated. */
  updatedAt?: Maybe<Scalars['Date']['output']>;
};

export type ContentModuleInput = {
  allowedCountries?: InputMaybe<Array<InputMaybe<Scalars['String']['input']>>>;
  channels: Array<TagComponent>;
  commentsEnabled?: InputMaybe<Scalars['Boolean']['input']>;
  contentId: Scalars['ID']['input'];
  contentType: ContentModuleType;
  description: Scalars['String']['input'];
  expiresAt?: InputMaybe<Scalars['Date']['input']>;
  hidden?: InputMaybe<Scalars['Boolean']['input']>;
  hiddenExpiresAt?: InputMaybe<Scalars['Date']['input']>;
  id?: InputMaybe<Scalars['ID']['input']>;
  lastModifiedBy: Scalars['String']['input'];
  orientation?: InputMaybe<ModuleOrientation>;
  scheduledDate?: InputMaybe<Scalars['Date']['input']>;
  thumbnail: Scalars['String']['input'];
  thumbnailAccreditation?: InputMaybe<Scalars['String']['input']>;
  thumbnailCopyright?: InputMaybe<Scalars['String']['input']>;
  title: Scalars['String']['input'];
  updateProgrammingTimestamp?: InputMaybe<Scalars['Boolean']['input']>;
};

export enum ContentModuleType {
  Article = 'Article',
  ExternalArticle = 'ExternalArticle',
  Mixed = 'Mixed',
  StatsBetting = 'StatsBetting',
  StatsGamecast = 'StatsGamecast',
  Tweet = 'Tweet',
  UgcImagePoll = 'UGCImagePoll',
  UgcPost = 'UGCPost',
  UgcTextPoll = 'UGCTextPoll',
  VideoV2 = 'VideoV2'
}

export enum ContentSearchType {
  Article = 'Article',
  Tweet = 'Tweet',
  VideoV2 = 'VideoV2'
}

export type ContentShow = {
  __typename?: 'ContentShow';
  _id?: Maybe<Scalars['MongoID']['output']>;
  id?: Maybe<Scalars['String']['output']>;
  image?: Maybe<Image>;
  title?: Maybe<Scalars['String']['output']>;
  weight?: Maybe<Scalars['Float']['output']>;
};

export type ContentSort = {
  __typename?: 'ContentSort';
  field?: Maybe<Scalars['String']['output']>;
  order?: Maybe<Scalars['String']['output']>;
};

export enum ContentType {
  Article = 'ARTICLE',
  Channel = 'CHANNEL',
  User = 'USER',
  Video = 'VIDEO'
}

export type ContentsConnection = {
  __typename?: 'ContentsConnection';
  edges: Array<ContentEdge>;
  pageInfo: PageInfo;
  totalCount: Scalars['Int']['output'];
};

export type CreatePollResponse = {
  __typename?: 'CreatePollResponse';
  created: Scalars['Boolean']['output'];
  errorMsg?: Maybe<Scalars['String']['output']>;
  poll?: Maybe<Poll>;
  status: Scalars['String']['output'];
};

export type CreatePostResponse = {
  __typename?: 'CreatePostResponse';
  created: Scalars['Boolean']['output'];
  errorMsg?: Maybe<Scalars['String']['output']>;
  post?: Maybe<Post>;
  status: Scalars['String']['output'];
};

export type CreateProgramResponse = {
  __typename?: 'CreateProgramResponse';
  created: Scalars['Boolean']['output'];
  errorMsg?: Maybe<Scalars['String']['output']>;
  program?: Maybe<Scalars['String']['output']>;
};

export enum CreatorTier {
  Bronze = 'Bronze',
  Gold = 'Gold',
  Platinum = 'Platinum',
  Silver = 'Silver'
}

export type Credit = {
  __typename?: 'Credit';
  billingOrders?: Maybe<Array<Maybe<BillingOrder>>>;
  id?: Maybe<Scalars['String']['output']>;
  personId?: Maybe<Scalars['ID']['output']>;
  role?: Maybe<Scalars['String']['output']>;
};

export type CustomLiveLikeUserReaction = {
  __typename?: 'CustomLiveLikeUserReaction';
  clientId: Scalars['String']['output'];
  createdAt: Scalars['String']['output'];
  customData?: Maybe<Scalars['String']['output']>;
  id: Scalars['String']['output'];
  reactedById: Scalars['String']['output'];
  reactionId: Scalars['String']['output'];
  reactionSpaceId: Scalars['String']['output'];
  targetId: Scalars['String']['output'];
};

export type DateRangeFilter = {
  /**
   * Upper value of the createdDateRange.
   *
   * Must be an ISODate. The format is YYYY-MM-DD HH:MM.SS.millis (ex. 2024-07-01T00:00:00.000Z)
   */
  high?: InputMaybe<Scalars['Date']['input']>;
  /**
   * Lower value of the createdDateRange.
   *
   * Must be an ISODate. The format is YYYY-MM-DD HH:MM.SS.millis (ex. 2024-04-01T00:00:00.000Z)
   */
  low?: InputMaybe<Scalars['Date']['input']>;
};

export type DeleteVideoContentModulesResult = {
  __typename?: 'DeleteVideoContentModulesResult';
  contentId: Scalars['String']['output'];
  deletedCount: Scalars['Int']['output'];
  deletedModuleIds: Array<Scalars['String']['output']>;
};

export type Device = {
  __typename?: 'Device';
  appVersion: Scalars['String']['output'];
  id: Scalars['Int']['output'];
  osVersion: Scalars['String']['output'];
  token: Scalars['String']['output'];
  type: Scalars['String']['output'];
};

export type DeviceInput = {
  appVersion: Scalars['String']['input'];
  osVersion: Scalars['String']['input'];
  token: Scalars['String']['input'];
  type: DeviceType;
};

export enum DeviceType {
  Android = 'ANDROID',
  Ipad = 'IPAD',
  Iphone = 'IPHONE'
}

export type Division = {
  __typename?: 'Division';
  conference?: Maybe<Conference>;
  division_alias?: Maybe<Scalars['String']['output']>;
  id?: Maybe<Scalars['ID']['output']>;
  league?: Maybe<League>;
  name?: Maybe<Scalars['String']['output']>;
  sport?: Maybe<Sport>;
  sportradar_id?: Maybe<Scalars['String']['output']>;
  teams?: Maybe<Array<Maybe<Competitor>>>;
};


export type DivisionTeamsArgs = {
  id?: InputMaybe<Scalars['ID']['input']>;
};

export type Divisions = {
  __typename?: 'Divisions';
  divisions?: Maybe<Array<Maybe<Division>>>;
  index_end?: Maybe<Scalars['Int']['output']>;
  index_start?: Maybe<Scalars['Int']['output']>;
  total?: Maybe<Scalars['Int']['output']>;
};

export type DsContentModelResult = {
  contentID: Scalars['String']['output'];
  type: ContentModuleType;
};

export type DsModel = {
  __typename?: 'DsModel';
  defaultVersion: Scalars['Int']['output'];
  name: Scalars['String']['output'];
};

export type Element = {
  __typename?: 'Element';
  content?: Maybe<ElementContent>;
  contentType?: Maybe<Scalars['String']['output']>;
  order?: Maybe<Scalars['Int']['output']>;
};

export type ElementContent = {
  __typename?: 'ElementContent';
  html?: Maybe<Scalars['String']['output']>;
  image?: Maybe<Image>;
  media?: Maybe<VideoV2>;
  url?: Maybe<Scalars['String']['output']>;
  wordCount?: Maybe<Scalars['Float']['output']>;
};

export enum EnumTagGroupType {
  League = 'League',
  Location = 'Location',
  Programming = 'Programming',
  Suggested = 'Suggested'
}

export enum EnumTagV2ChannelState {
  LiveGame = 'LiveGame',
  PostGame = 'PostGame',
  PreGame = 'PreGame',
  Standard = 'Standard'
}

export type Event = {
  __typename?: 'Event';
  away?: Maybe<Competitor>;
  away_team_points?: Maybe<Scalars['String']['output']>;
  card_type?: Maybe<Scalars['String']['output']>;
  color_1?: Maybe<Scalars['String']['output']>;
  color_2?: Maybe<Scalars['String']['output']>;
  derived_status?: Maybe<Scalars['String']['output']>;
  event_image?: Maybe<Scalars['String']['output']>;
  event_image_bucket?: Maybe<Scalars['String']['output']>;
  free_event?: Maybe<Scalars['Boolean']['output']>;
  free_preview?: Maybe<Scalars['Boolean']['output']>;
  game?: Maybe<Game>;
  has_media?: Maybe<Scalars['Boolean']['output']>;
  hash?: Maybe<Scalars['String']['output']>;
  header_image_bucket?: Maybe<Scalars['String']['output']>;
  hidden?: Maybe<Scalars['Boolean']['output']>;
  home?: Maybe<Competitor>;
  home_team_points?: Maybe<Scalars['String']['output']>;
  id?: Maybe<Scalars['ID']['output']>;
  is_live?: Maybe<Scalars['Boolean']['output']>;
  league?: Maybe<League>;
  logo_dark?: Maybe<Scalars['String']['output']>;
  logo_light?: Maybe<Scalars['String']['output']>;
  media_asset_id_live?: Maybe<Scalars['String']['output']>;
  media_asset_id_vod?: Maybe<Scalars['String']['output']>;
  medium_vod?: Maybe<Scalars['Boolean']['output']>;
  period?: Maybe<Scalars['String']['output']>;
  recommended?: Maybe<Scalars['Boolean']['output']>;
  scheduled_utc?: Maybe<Scalars['String']['output']>;
  season?: Maybe<Scalars['String']['output']>;
  season_type?: Maybe<Scalars['String']['output']>;
  series_id?: Maybe<Scalars['Int']['output']>;
  series_name?: Maybe<Scalars['String']['output']>;
  sponsor_text?: Maybe<Scalars['String']['output']>;
  sport?: Maybe<Sport>;
  sportradar_id?: Maybe<Scalars['String']['output']>;
  status?: Maybe<Scalars['String']['output']>;
  territories_available?: Maybe<Array<Maybe<Territories>>>;
  time_zone?: Maybe<Scalars['String']['output']>;
  title?: Maybe<Scalars['String']['output']>;
  tournament?: Maybe<Tournament>;
  trending?: Maybe<Scalars['Boolean']['output']>;
  type?: Maybe<Scalars['String']['output']>;
  updated_at?: Maybe<Scalars['String']['output']>;
  venue?: Maybe<Venue>;
  week?: Maybe<Scalars['String']['output']>;
};

export type EventFilterInput = {
  count_end?: InputMaybe<Scalars['String']['input']>;
  count_start?: InputMaybe<Scalars['String']['input']>;
  end_date?: InputMaybe<Scalars['String']['input']>;
  filterId?: InputMaybe<Array<InputMaybe<EventFilterType>>>;
  has_media?: InputMaybe<Scalars['Boolean']['input']>;
  media_filter?: InputMaybe<Scalars['String']['input']>;
  order?: InputMaybe<SortDirections>;
  season?: InputMaybe<Scalars['Int']['input']>;
  sort?: InputMaybe<EventSort>;
  start_date?: InputMaybe<Scalars['String']['input']>;
  territories?: InputMaybe<Territories>;
  type?: InputMaybe<EventTypes>;
};

export enum EventFilterNames {
  League = 'league',
  Series = 'series',
  Sport = 'sport',
  SportRadar = 'sportRadar',
  Team = 'team',
  Tournament = 'tournament'
}

export type EventFilterType = {
  id: Scalars['String']['input'];
  name: EventFilterNames;
};

export enum EventSort {
  Date = 'date',
  Rating = 'rating'
}

export enum EventTypes {
  Manual = 'manual',
  Match = 'match'
}

export type Events = {
  __typename?: 'Events';
  events?: Maybe<Array<Maybe<Event>>>;
  index_end?: Maybe<Scalars['Int']['output']>;
  index_start?: Maybe<Scalars['Int']['output']>;
  total?: Maybe<Scalars['Int']['output']>;
};

export type ExternalArticle = {
  __typename?: 'ExternalArticle';
  brand?: Maybe<ContentBrand>;
  created: Scalars['Date']['output'];
  id: Scalars['ID']['output'];
  providerName: Scalars['String']['output'];
  source: Scalars['String']['output'];
  url: Scalars['String']['output'];
};


export type ExternalArticleBrandArgs = {
  tenant: Tenant;
};

export type FacetRequest = {
  field: Scalars['String']['input'];
  first?: InputMaybe<Scalars['Int']['input']>;
};

export type FacetResponse = {
  __typename?: 'FacetResponse';
  facetResults?: Maybe<Array<FacetResult>>;
  field: Scalars['String']['output'];
};

export type FacetResult = {
  __typename?: 'FacetResult';
  count: Scalars['Int']['output'];
  value: Scalars['String']['output'];
};

export type Feed = {
  __typename?: 'Feed';
  code?: Maybe<Scalars['String']['output']>;
  description?: Maybe<Scalars['String']['output']>;
  link?: Maybe<Scalars['String']['output']>;
  logo?: Maybe<Scalars['String']['output']>;
  shows?: Maybe<Array<Maybe<Show>>>;
};

export enum Feeds {
  CdfhCl = 'CDFH_CL',
  TntspoAr = 'TNTSPO_AR'
}

export type Filter = {
  field: Scalars['String']['input'];
  values?: InputMaybe<Array<Scalars['String']['input']>>;
};

export type FollowingMetadata = {
  __typename?: 'FollowingMetadata';
  categoryLogo?: Maybe<Image>;
  chipLabel?: Maybe<Scalars['String']['output']>;
  primaryLabel?: Maybe<Scalars['String']['output']>;
  secondaryLabel?: Maybe<Scalars['String']['output']>;
  uuid?: Maybe<Scalars['String']['output']>;
  weight?: Maybe<Scalars['Float']['output']>;
};

export type FormElement = {
  __typename?: 'FormElement';
  _id?: Maybe<Scalars['MongoID']['output']>;
  headline?: Maybe<Scalars['String']['output']>;
  options?: Maybe<Scalars['JSON']['output']>;
  type?: Maybe<Scalars['String']['output']>;
  weight?: Maybe<Scalars['Float']['output']>;
};

export type Game = {
  __typename?: 'Game';
  away?: Maybe<Team>;
  gameDate?: Maybe<GameDate>;
  gameProgress?: Maybe<GameProgress>;
  home?: Maybe<Team>;
  id?: Maybe<Scalars['String']['output']>;
  name?: Maybe<Scalars['String']['output']>;
  score?: Maybe<Score>;
  sourceGameId?: Maybe<Scalars['String']['output']>;
  sport?: Maybe<SportMetaData>;
  sportradar_id?: Maybe<Scalars['String']['output']>;
  stateStatus?: Maybe<StateStatus>;
  status?: Maybe<Scalars['String']['output']>;
  weekId?: Maybe<Scalars['String']['output']>;
};

export type GameDate = {
  __typename?: 'GameDate';
  epoch?: Maybe<Scalars['Int']['output']>;
  iso8501?: Maybe<Scalars['String']['output']>;
};

export type GameGroup = {
  __typename?: 'GameGroup';
  current?: Maybe<Scalars['Boolean']['output']>;
  events?: Maybe<Array<Maybe<ScoresEvent>>>;
  games?: Maybe<Array<Maybe<ScoresGame>>>;
  name?: Maybe<Scalars['String']['output']>;
};

export type GameProgress = {
  __typename?: 'GameProgress';
  clock?: Maybe<Clock>;
  currentPeriod?: Maybe<Scalars['String']['output']>;
  displayPrimary?: Maybe<Scalars['String']['output']>;
  displaySecondary?: Maybe<Scalars['String']['output']>;
  totalPeriods?: Maybe<Scalars['String']['output']>;
};

export enum GameState {
  LiveGame = 'LiveGame',
  PostGame = 'PostGame',
  PreGame = 'PreGame',
  Standard = 'Standard'
}

export type GamecastAnalytics = {
  __typename?: 'GamecastAnalytics';
  awayTeamTag?: Maybe<Tag>;
  coverageType?: Maybe<Scalars['String']['output']>;
  gamePeriod?: Maybe<Scalars['Int']['output']>;
  gamePermalinkTag?: Maybe<Tag>;
  gameStart?: Maybe<Scalars['String']['output']>;
  headlineTitle?: Maybe<Scalars['String']['output']>;
  headlineTitleAbbreviated?: Maybe<Scalars['String']['output']>;
  homeTeamTag?: Maybe<Tag>;
  seasonType?: Maybe<Scalars['String']['output']>;
  tournamentName?: Maybe<Scalars['String']['output']>;
};

export type GamecastMetadata = {
  __typename?: 'GamecastMetadata';
  analytics?: Maybe<GamecastAnalytics>;
  gamePermalink?: Maybe<Scalars['String']['output']>;
  scoreBoard?: Maybe<GamecastScoreboard>;
};

export type GamecastProgress = {
  __typename?: 'GamecastProgress';
  footer?: Maybe<Scalars['String']['output']>;
  header?: Maybe<Scalars['String']['output']>;
  primary?: Maybe<Scalars['String']['output']>;
};

export type GamecastScoreboard = {
  __typename?: 'GamecastScoreboard';
  gameDate?: Maybe<Scalars['String']['output']>;
  id?: Maybe<Scalars['String']['output']>;
  league?: Maybe<Scalars['String']['output']>;
  progress?: Maybe<GamecastProgress>;
  sport?: Maybe<Scalars['String']['output']>;
  status?: Maybe<Scalars['String']['output']>;
  teamOne?: Maybe<GamecastTeam>;
  teamTwo?: Maybe<GamecastTeam>;
};

export type GamecastTeam = {
  __typename?: 'GamecastTeam';
  abbrev?: Maybe<Scalars['String']['output']>;
  hasPossession: Scalars['Boolean']['output'];
  isWinner: Scalars['Boolean']['output'];
  logo?: Maybe<Scalars['String']['output']>;
  name?: Maybe<Scalars['String']['output']>;
  permalink?: Maybe<Scalars['String']['output']>;
  score?: Maybe<Scalars['String']['output']>;
  shortName?: Maybe<Scalars['String']['output']>;
};

export type Grouping = {
  __typename?: 'Grouping';
  components?: Maybe<Array<Maybe<ChannelComponent>>>;
  header?: Maybe<GroupingHeader>;
};

export type GroupingHeader = {
  __typename?: 'GroupingHeader';
  applicableGameStates?: Maybe<Array<Maybe<GameState>>>;
  /** GameCast end time for this GroupingHeader */
  gameEndTime?: Maybe<Scalars['Date']['output']>;
  /** GameCast start time for this GroupingHeader */
  gameStartTime?: Maybe<Scalars['Date']['output']>;
  id?: Maybe<Scalars['String']['output']>;
  image?: Maybe<Image>;
  isDefault?: Maybe<Scalars['Boolean']['output']>;
  isDomesticOnly?: Maybe<Scalars['Boolean']['output']>;
  /** GameCast slug for this GroupingHeader */
  slug?: Maybe<Scalars['String']['output']>;
  title?: Maybe<Scalars['String']['output']>;
  visible: Scalars['Boolean']['output'];
  visibleReason?: Maybe<VisibilityReason>;
};

export type Identifier = {
  __typename?: 'Identifier';
  id?: Maybe<Scalars['String']['output']>;
  namespace?: Maybe<Scalars['String']['output']>;
};

export type Image = {
  __typename?: 'Image';
  _id?: Maybe<Scalars['MongoID']['output']>;
  accreditation?: Maybe<Scalars['String']['output']>;
  alt?: Maybe<Scalars['String']['output']>;
  caption?: Maybe<Scalars['String']['output']>;
  copyright?: Maybe<Scalars['String']['output']>;
  focalPointX?: Maybe<Scalars['Float']['output']>;
  focalPointY?: Maybe<Scalars['Float']['output']>;
  height?: Maybe<Scalars['String']['output']>;
  url: Scalars['String']['output'];
  width?: Maybe<Scalars['String']['output']>;
};

export type ImagePollInput = {
  contentId?: InputMaybe<Scalars['ID']['input']>;
  interactiveUntil?: InputMaybe<Scalars['String']['input']>;
  options?: InputMaybe<Array<ImagePollOptionInput>>;
  question: Scalars['String']['input'];
  tagUUIDs: Array<Scalars['String']['input']>;
  timeout?: InputMaybe<Scalars['String']['input']>;
  uploadId: Scalars['ID']['input'];
  userAuth: Scalars['String']['input'];
};

export type ImagePollOptionInput = {
  description: Scalars['String']['input'];
  imageUrl: Scalars['String']['input'];
};

export enum ImageTypes {
  Jpg = 'jpg',
  Png = 'png'
}

export type ImageWithStyle = {
  __typename?: 'ImageWithStyle';
  _id?: Maybe<Scalars['MongoID']['output']>;
  image?: Maybe<Image>;
  style?: Maybe<Scalars['String']['output']>;
  type?: Maybe<Scalars['String']['output']>;
};

export type Item = {
  __typename?: 'Item';
  _id?: Maybe<Scalars['MongoID']['output']>;
  description?: Maybe<Scalars['String']['output']>;
  endTime?: Maybe<Scalars['Date']['output']>;
  headline?: Maybe<Scalars['String']['output']>;
  images?: Maybe<Array<Maybe<ImageWithStyle>>>;
  link?: Maybe<Link>;
  startTime?: Maybe<Scalars['Date']['output']>;
  style?: Maybe<Scalars['String']['output']>;
  subheadline?: Maybe<Scalars['String']['output']>;
};

export type League = {
  __typename?: 'League';
  alias?: Maybe<Scalars['String']['output']>;
  current_season?: Maybe<Scalars['String']['output']>;
  display_name?: Maybe<Scalars['String']['output']>;
  display_name_short?: Maybe<Scalars['String']['output']>;
  id?: Maybe<Scalars['ID']['output']>;
  name?: Maybe<Scalars['String']['output']>;
  season_end?: Maybe<Scalars['String']['output']>;
  season_start?: Maybe<Scalars['String']['output']>;
  sport?: Maybe<Sport>;
  type?: Maybe<Scalars['String']['output']>;
};

export type Leagues = {
  __typename?: 'Leagues';
  index_end?: Maybe<Scalars['Int']['output']>;
  index_start?: Maybe<Scalars['Int']['output']>;
  leagues?: Maybe<Array<Maybe<League>>>;
  total?: Maybe<Scalars['Int']['output']>;
};

export type Legacy = {
  __typename?: 'Legacy';
  league_id?: Maybe<Scalars['Int']['output']>;
  sport_id?: Maybe<Scalars['Int']['output']>;
};

export type Limitation = {
  __typename?: 'Limitation';
  adPlacement?: Maybe<AllowAll>;
  audioLanguage?: Maybe<AllowAll>;
  technicalQuality?: Maybe<AllowAll>;
  textLanguage?: Maybe<AllowAll>;
};

export type Link = {
  __typename?: 'Link';
  _id?: Maybe<Scalars['MongoID']['output']>;
  text?: Maybe<Scalars['String']['output']>;
  uri?: Maybe<Scalars['String']['output']>;
};

export type LiveLikeAlert = LiveLikeNode & LiveLikeWidgetBase & {
  __typename?: 'LiveLikeAlert';
  /** Client identifier associated with this alert */
  clientId: Scalars['NonEmptyString']['output'];
  /** Timestamp when the widget was created */
  createdAt: Scalars['DateTimeISO']['output'];
  /** Information about the user that created the widget */
  createdBy: LiveLikeWidgetCreator;
  /** Optional custom metadata for the widget */
  customData?: Maybe<Scalars['String']['output']>;
  /** Unique identifier of the alert */
  id: Scalars['UUID']['output'];
  /** url of the body image */
  imageUrl?: Maybe<Scalars['URL']['output']>;
  /** ISO8601 DateTime when the widget stops accepting interactions */
  interactiveUntil?: Maybe<Scalars['DateTimeISO']['output']>;
  /** Kind of widget */
  kind: LiveLikeWidgetKindEnum;
  /** label describing the link */
  linkLabel?: Maybe<Scalars['NonEmptyString']['output']>;
  /** url of the link */
  linkUrl?: Maybe<Scalars['URL']['output']>;
  /** Video playback time at which the widget appears, in milliseconds */
  playbackTimeMs?: Maybe<Scalars['NonNegativeInt']['output']>;
  /** Program-scheduled datetime when the alert is expected to appear */
  programDateTime?: Maybe<Scalars['DateTimeISO']['output']>;
  /** Program identifier associated with this alert */
  programId: Scalars['UUID']['output'];
  /** Delay (ISO8601) before the widget is published after scheduling */
  publishDelay: Scalars['Duration']['output'];
  /** Datetime when the widget was actually published */
  publishedAt?: Maybe<Scalars['DateTimeISO']['output']>;
  /** Whether pubnub is enabled. */
  pubnubEnabled: Scalars['Boolean']['output'];
  /** Contains count-based metrics such as interactions */
  reportCount?: Maybe<LiveLikeWidgetReportCount>;
  /** Scheduled datetime for the widget */
  scheduledAt?: Maybe<Scalars['DateTimeISO']['output']>;
  /** List of sponsor IDs associated with this Alert */
  sponsorIds?: Maybe<Array<Scalars['UUID']['output']>>;
  /** Current status of the widget (e.g.,  PENDING, SCHEDULED, PUBLISHED, INFLIGHT etc). */
  status: LiveLikeWidgetStatusEnum;
  /** text of the alert */
  text?: Maybe<Scalars['NonEmptyString']['output']>;
  /** Duration (ISO8601) for which the widget remains interactive */
  timeout: Scalars['Duration']['output'];
  /** title of the alert */
  title?: Maybe<Scalars['NonEmptyString']['output']>;
  /** Total number of unique users who interacted with the widget */
  uniqueImpressionCount?: Maybe<Scalars['NonNegativeInt']['output']>;
  /** Additional widget attributes in key-value format */
  widgetAttributes?: Maybe<Array<LiveLikeKeyValuePair>>;
};

export type LiveLikeAlertCreateInput = {
  /** free-form field used for custom behaviors */
  customData?: InputMaybe<Scalars['String']['input']>;
  /** url of the body image */
  imageUrl?: InputMaybe<Scalars['URL']['input']>;
  /** ISO8601 DateTime that the widget will stop accepting interactions */
  interactiveUntil?: InputMaybe<Scalars['DateTimeISO']['input']>;
  /** label describing the link */
  linkLabel?: InputMaybe<Scalars['NonEmptyString']['input']>;
  /** url of the link */
  linkUrl?: InputMaybe<Scalars['URL']['input']>;
  /** Alert localized data */
  localizedData?: InputMaybe<Array<LiveLikeAlertLocalizedInput>>;
  /** Video playback time in milliseconds */
  playbackTimeMs?: InputMaybe<Scalars['NonNegativeInt']['input']>;
  /**  ID of the program to create the alert */
  programId: Scalars['UUID']['input'];
  /**
   * Links the sponsors with this Alert.
   * Note only valid sponsor ids will be linked to Alert.
   */
  sponsorIds?: InputMaybe<Array<Scalars['UUID']['input']>>;
  /** text of the alert */
  text?: InputMaybe<Scalars['NonEmptyString']['input']>;
  /** ISO8601 duration hint for when a Widget should be timed out */
  timeout?: InputMaybe<Scalars['Duration']['input']>;
  /** title of the alert */
  title?: InputMaybe<Scalars['NonEmptyString']['input']>;
  /** An array of key value pairs used for custom behaviors */
  widgetAttributes?: InputMaybe<Array<LiveLikeKeyValuePairInput>>;
};

export type LiveLikeAlertLocalizedInput = {
  /** Localized language a string that conforms to the BCP-47 (RFC 5646) standard  */
  language: Scalars['Locale']['input'];
  /** label describing the link */
  linkLabel?: InputMaybe<Scalars['NonEmptyString']['input']>;
  /** text of the alert */
  text?: InputMaybe<Scalars['NonEmptyString']['input']>;
  /** title of the alert */
  title?: InputMaybe<Scalars['NonEmptyString']['input']>;
};

export type LiveLikeApplication = {
  __typename?: 'LiveLikeApplication';
  apiPollingInterval: Scalars['PositiveInt']['output'];
  clientId: Scalars['NonEmptyString']['output'];
  imageUrl: Scalars['URL']['output'];
  mediaUrl: Scalars['URL']['output'];
  name: Scalars['String']['output'];
  organizationId: Scalars['UUID']['output'];
  organizationName: Scalars['NonEmptyString']['output'];
  pubnubHeartbeatInterval?: Maybe<Scalars['NonNegativeInt']['output']>;
  pubnubOrigin?: Maybe<Scalars['NonEmptyString']['output']>;
  pubnubPresenceTimeout?: Maybe<Scalars['NonNegativeInt']['output']>;
  pubnubPublishKey?: Maybe<Scalars['NonEmptyString']['output']>;
  pubnubSubscribeKey?: Maybe<Scalars['NonEmptyString']['output']>;
};

export type LiveLikeAwardBadgeInput = {
  badgeId: Scalars['UUID']['input'];
  profileId: Scalars['UUID']['input'];
};

export type LiveLikeBadge = LiveLikeNode & {
  __typename?: 'LiveLikeBadge';
  attributes?: Maybe<Array<LiveLikeKeyValuePair>>;
  badgeIconUrl: Scalars['URL']['output'];
  clientId: Scalars['NonEmptyString']['output'];
  description?: Maybe<Scalars['NonEmptyString']['output']>;
  file: Scalars['URL']['output'];
  id: Scalars['UUID']['output'];
  mimetype: Scalars['NonEmptyString']['output'];
  name: Scalars['NonEmptyString']['output'];
};

export type LiveLikeBadgeCollection = LiveLikeConnection & {
  __typename?: 'LiveLikeBadgeCollection';
  edges?: Maybe<Array<LiveLikeBadgeEdge>>;
  page: LiveLikePage;
};

export type LiveLikeBadgeEdge = LiveLikeEdge & {
  __typename?: 'LiveLikeBadgeEdge';
  cursor?: Maybe<Scalars['String']['output']>;
  node: LiveLikeBadge;
};

export type LiveLikeBadgeProfile = {
  __typename?: 'LiveLikeBadgeProfile';
  awardedAt: Scalars['DateTimeISO']['output'];
  badgeId: Scalars['UUID']['output'];
  profile: LiveLikeProfile;
};

export type LiveLikeBadgeProfileCollection = {
  __typename?: 'LiveLikeBadgeProfileCollection';
  edges?: Maybe<Array<LiveLikeBadgeProfileEdge>>;
  page: LiveLikePage;
};

export type LiveLikeBadgeProfileEdge = {
  __typename?: 'LiveLikeBadgeProfileEdge';
  cursor?: Maybe<Scalars['String']['output']>;
  node: LiveLikeBadgeProfile;
};

/** Represents the progress of reward item associated with a badge. */
export type LiveLikeBadgeRewardProgress = {
  __typename?: 'LiveLikeBadgeRewardProgress';
  /** Current amount the badge has accumulated toward this reward item. */
  currentRewardAmount: Scalars['NonNegativeInt']['output'];
  /** Unique identifier of the reward item. */
  rewardItemId: Scalars['UUID']['output'];
  /** Name of the reward item. */
  rewardItemName: Scalars['NonEmptyString']['output'];
  /** Threshold amount required to earn this reward item. */
  rewardItemThreshold: Scalars['NonNegativeInt']['output'];
};

/** Represents the reward progress tracking for a specific badge, including associated reward items and their progress. */
export type LiveLikeBadgeRewardProgressCollection = {
  __typename?: 'LiveLikeBadgeRewardProgressCollection';
  /** The badge for which the reward progress is being tracked. */
  badge: LiveLikeBadge;
  /** A list of reward progress entries for each reward item under the badge. */
  badgeProgress?: Maybe<Array<LiveLikeBadgeRewardProgress>>;
};

export type LiveLikeBlockProfile = LiveLikeNode & {
  __typename?: 'LiveLikeBlockProfile';
  blockedByProfile: LiveLikeProfile;
  blockedByProfileId: Scalars['UUID']['output'];
  blockedProfile: LiveLikeProfile;
  blockedProfileId: Scalars['UUID']['output'];
  id: Scalars['UUID']['output'];
};

export type LiveLikeChatRoom = LiveLikeNode & {
  __typename?: 'LiveLikeChatRoom';
  channels: LiveLikeChatRoomChannel;
  contentFilter: LiveLikeChatRoomContentFilterEnum;
  createdAt: Scalars['DateTimeISO']['output'];
  id: Scalars['UUID']['output'];
  reactionPackIds?: Maybe<Array<Scalars['UUID']['output']>>;
  reactionSpaceId: Scalars['UUID']['output'];
  sponsorIds?: Maybe<Array<Scalars['UUID']['output']>>;
  title?: Maybe<Scalars['String']['output']>;
  tokenGates?: Maybe<Array<LiveLikeTokenGate>>;
  visibility: LiveLikeChatRoomVisibilityEnum;
};

export type LiveLikeChatRoomChannel = {
  __typename?: 'LiveLikeChatRoomChannel';
  chat: Scalars['NonEmptyString']['output'];
  control: Scalars['NonEmptyString']['output'];
  reactions: Scalars['NonEmptyString']['output'];
};

export type LiveLikeChatRoomCollection = LiveLikeConnection & {
  __typename?: 'LiveLikeChatRoomCollection';
  edges?: Maybe<Array<Maybe<LiveLikeChatRoomEdge>>>;
  page: LiveLikePage;
};

export enum LiveLikeChatRoomContentFilterEnum {
  Filtered = 'FILTERED',
  None = 'NONE',
  Producer = 'PRODUCER'
}

export type LiveLikeChatRoomCreateInput = {
  contentFilter?: InputMaybe<LiveLikeChatRoomContentFilterEnum>;
  reactionPackIds?: InputMaybe<Array<Scalars['UUID']['input']>>;
  sponsorIds?: InputMaybe<Array<Scalars['UUID']['input']>>;
  title?: InputMaybe<Scalars['NonEmptyString']['input']>;
  tokenGates?: InputMaybe<Array<LiveLikeTokenGateInput>>;
  visibility?: InputMaybe<LiveLikeChatRoomVisibilityEnum>;
};

export type LiveLikeChatRoomEdge = LiveLikeEdge & {
  __typename?: 'LiveLikeChatRoomEdge';
  cursor?: Maybe<Scalars['String']['output']>;
  node: LiveLikeChatRoom;
};

export type LiveLikeChatRoomUpdateInput = {
  contentFilter?: InputMaybe<LiveLikeChatRoomContentFilterEnum>;
  id: Scalars['UUID']['input'];
  reactionPackIds?: InputMaybe<Array<Scalars['UUID']['input']>>;
  sponsorIds?: InputMaybe<Array<Scalars['UUID']['input']>>;
  title?: InputMaybe<Scalars['NonEmptyString']['input']>;
  tokenGates?: InputMaybe<Array<LiveLikeTokenGateInput>>;
  visibility?: InputMaybe<LiveLikeChatRoomVisibilityEnum>;
};

export enum LiveLikeChatRoomVisibilityEnum {
  Everyone = 'EVERYONE',
  Members = 'MEMBERS'
}

export type LiveLikeChatRoomsGetInput = {
  clientId: Scalars['NonEmptyString']['input'];
  page?: InputMaybe<Scalars['PositiveInt']['input']>;
};

export type LiveLikeComment = LiveLikeNode & {
  __typename?: 'LiveLikeComment';
  author: LiveLikeProfile;
  authorId: Scalars['UUID']['output'];
  commentBoardId: Scalars['UUID']['output'];
  commentDepth: Scalars['NonNegativeInt']['output'];
  commentReportsCount: Scalars['NonNegativeInt']['output'];
  createdAt: Scalars['DateTimeISO']['output'];
  customData?: Maybe<Scalars['NonEmptyString']['output']>;
  deletedAt?: Maybe<Scalars['DateTimeISO']['output']>;
  deletedBy?: Maybe<Scalars['UUID']['output']>;
  id: Scalars['UUID']['output'];
  isDeleted: Scalars['Boolean']['output'];
  isReported: Scalars['Boolean']['output'];
  parentCommentId?: Maybe<Scalars['UUID']['output']>;
  repliesCount: Scalars['NonNegativeInt']['output'];
  text?: Maybe<Scalars['String']['output']>;
};

export type LiveLikeCommentBoard = LiveLikeNode & {
  __typename?: 'LiveLikeCommentBoard';
  allowComments: Scalars['Boolean']['output'];
  clientId: Scalars['NonEmptyString']['output'];
  commentsCount: Scalars['NonNegativeInt']['output'];
  contentFilter: LiveLikeContentFilterEnum;
  createdAt: Scalars['DateTimeISO']['output'];
  createdById: Scalars['UUID']['output'];
  customData?: Maybe<Scalars['String']['output']>;
  customId?: Maybe<Scalars['String']['output']>;
  description?: Maybe<Scalars['String']['output']>;
  id: Scalars['UUID']['output'];
  repliesDepth: Scalars['PositiveInt']['output'];
  title?: Maybe<Scalars['String']['output']>;
};

export type LiveLikeCommentBoardBan = LiveLikeNode & {
  __typename?: 'LiveLikeCommentBoardBan';
  bannedById: Scalars['UUID']['output'];
  clientId: Scalars['NonEmptyString']['output'];
  commentBoardId?: Maybe<Scalars['UUID']['output']>;
  createdAt: Scalars['DateTimeISO']['output'];
  description?: Maybe<Scalars['String']['output']>;
  id: Scalars['UUID']['output'];
  profileId: Scalars['UUID']['output'];
};

export type LiveLikeCommentBoardBanCollection = LiveLikeConnection & {
  __typename?: 'LiveLikeCommentBoardBanCollection';
  edges?: Maybe<Array<LiveLikeCommentBoardBanEdge>>;
  page: LiveLikePage;
};

export type LiveLikeCommentBoardBanEdge = LiveLikeEdge & {
  __typename?: 'LiveLikeCommentBoardBanEdge';
  cursor?: Maybe<Scalars['String']['output']>;
  node: LiveLikeCommentBoardBan;
};

export type LiveLikeCommentBoardBanInput = {
  commentBoardId?: InputMaybe<Scalars['UUID']['input']>;
  description?: InputMaybe<Scalars['String']['input']>;
  profileId: Scalars['UUID']['input'];
};

export type LiveLikeCommentBoardBansInput = {
  clientId?: InputMaybe<Scalars['NonEmptyString']['input']>;
  commentBoardId?: InputMaybe<Scalars['UUID']['input']>;
  profileId?: InputMaybe<Scalars['UUID']['input']>;
};

export type LiveLikeCommentBoardCollection = LiveLikeConnection & {
  __typename?: 'LiveLikeCommentBoardCollection';
  edges?: Maybe<Array<Maybe<LiveLikeCommentBoardEdge>>>;
  page: LiveLikePage;
};

export type LiveLikeCommentBoardCount = LiveLikeNode & {
  __typename?: 'LiveLikeCommentBoardCount';
  commentsCount: Scalars['NonNegativeInt']['output'];
  id: Scalars['UUID']['output'];
  topLevelCommentsCount: Scalars['NonNegativeInt']['output'];
};

export type LiveLikeCommentBoardCreateInput = {
  allowComments?: InputMaybe<Scalars['Boolean']['input']>;
  contentFilter?: InputMaybe<LiveLikeContentFilterEnum>;
  customData?: InputMaybe<Scalars['NonEmptyString']['input']>;
  customId?: InputMaybe<Scalars['NonEmptyString']['input']>;
  description?: InputMaybe<Scalars['NonEmptyString']['input']>;
  repliesDepth?: InputMaybe<Scalars['PositiveInt']['input']>;
  title?: InputMaybe<Scalars['NonEmptyString']['input']>;
};

export type LiveLikeCommentBoardEdge = LiveLikeEdge & {
  __typename?: 'LiveLikeCommentBoardEdge';
  cursor?: Maybe<Scalars['String']['output']>;
  node: LiveLikeCommentBoard;
};

export type LiveLikeCommentBoardUpdateInput = {
  allowComments?: InputMaybe<Scalars['Boolean']['input']>;
  contentFilter?: InputMaybe<LiveLikeContentFilterEnum>;
  customData?: InputMaybe<Scalars['NonEmptyString']['input']>;
  customId?: InputMaybe<Scalars['NonEmptyString']['input']>;
  description?: InputMaybe<Scalars['NonEmptyString']['input']>;
  id: Scalars['UUID']['input'];
  repliesDepth?: InputMaybe<Scalars['PositiveInt']['input']>;
  title?: InputMaybe<Scalars['NonEmptyString']['input']>;
};

export type LiveLikeCommentBoardsCountGetInput = {
  commentBoardIds: Array<Scalars['UUID']['input']>;
};

export type LiveLikeCommentBoardsGetInput = {
  clientId: Scalars['NonEmptyString']['input'];
  commentBoardIds?: InputMaybe<Array<Scalars['UUID']['input']>>;
  customId?: InputMaybe<Scalars['NonEmptyString']['input']>;
  page?: InputMaybe<Scalars['PositiveInt']['input']>;
};

export type LiveLikeCommentCollection = LiveLikeConnection & {
  __typename?: 'LiveLikeCommentCollection';
  edges?: Maybe<Array<Maybe<LiveLikeCommentEdge>>>;
  page: LiveLikePage;
};

export type LiveLikeCommentCreateInput = {
  commentBoardId: Scalars['UUID']['input'];
  customData?: InputMaybe<Scalars['NonEmptyString']['input']>;
  text: Scalars['NonEmptyString']['input'];
};

export type LiveLikeCommentEdge = LiveLikeEdge & {
  __typename?: 'LiveLikeCommentEdge';
  cursor?: Maybe<Scalars['String']['output']>;
  node: LiveLikeComment;
};

export type LiveLikeCommentRepliesGetInput = {
  commentBoardId: Scalars['UUID']['input'];
  page?: InputMaybe<Scalars['PositiveInt']['input']>;
  parentCommentId: Scalars['UUID']['input'];
  withoutDeletedThread?: InputMaybe<Scalars['Boolean']['input']>;
};

export type LiveLikeCommentReplyCreateInput = {
  commentBoardId: Scalars['UUID']['input'];
  customData?: InputMaybe<Scalars['NonEmptyString']['input']>;
  parentCommentId: Scalars['UUID']['input'];
  text: Scalars['NonEmptyString']['input'];
};

export type LiveLikeCommentReport = LiveLikeNode & {
  __typename?: 'LiveLikeCommentReport';
  comment: LiveLikeComment;
  commentBoardId: Scalars['UUID']['output'];
  commentId: Scalars['UUID']['output'];
  description?: Maybe<Scalars['String']['output']>;
  id: Scalars['UUID']['output'];
  reportStatus: LiveLikeCommentReportStatusEnum;
  reportedAt: Scalars['DateTimeISO']['output'];
  reportedById: Scalars['UUID']['output'];
};

export type LiveLikeCommentReportCollection = LiveLikeConnection & {
  __typename?: 'LiveLikeCommentReportCollection';
  edges?: Maybe<Array<Maybe<LiveLikeCommentReportEdge>>>;
  page: LiveLikePage;
};

export type LiveLikeCommentReportCreateInput = {
  commentId: Scalars['UUID']['input'];
  description?: InputMaybe<Scalars['NonEmptyString']['input']>;
};

export type LiveLikeCommentReportEdge = LiveLikeEdge & {
  __typename?: 'LiveLikeCommentReportEdge';
  cursor?: Maybe<Scalars['String']['output']>;
  node: LiveLikeCommentReport;
};

export enum LiveLikeCommentReportStatusEnum {
  Dismissed = 'DISMISSED',
  Pending = 'PENDING'
}

export type LiveLikeCommentsGetInput = {
  commentBoardId: Scalars['UUID']['input'];
  page?: InputMaybe<Scalars['PositiveInt']['input']>;
};

export type LiveLikeCommentsReportsGetInput = {
  clientId: Scalars['NonEmptyString']['input'];
  commentBoardId?: InputMaybe<Scalars['UUID']['input']>;
  commentId?: InputMaybe<Scalars['UUID']['input']>;
  page?: InputMaybe<Scalars['PositiveInt']['input']>;
};

export type LiveLikeConnection = {
  edges?: Maybe<Array<Maybe<LiveLikeEdge>>>;
  page?: Maybe<LiveLikePage>;
};

export enum LiveLikeContentFilterEnum {
  Filtered = 'FILTERED',
  None = 'NONE'
}

export type LiveLikeEarnedBadge = {
  __typename?: 'LiveLikeEarnedBadge';
  awardedAt: Scalars['DateTimeISO']['output'];
  badge: LiveLikeBadge;
  id: Scalars['UUID']['output'];
};

export type LiveLikeEarnedBadgeCollection = {
  __typename?: 'LiveLikeEarnedBadgeCollection';
  edges?: Maybe<Array<LiveLikeEarnedBadgeEdge>>;
  page: LiveLikePage;
};

export type LiveLikeEarnedBadgeEdge = {
  __typename?: 'LiveLikeEarnedBadgeEdge';
  cursor?: Maybe<Scalars['String']['output']>;
  node: LiveLikeEarnedBadge;
};

export type LiveLikeEdge = {
  cursor?: Maybe<Scalars['String']['output']>;
  node?: Maybe<LiveLikeNode>;
};

export type LiveLikeEmoji = LiveLikeNode & {
  __typename?: 'LiveLikeEmoji';
  file: Scalars['URL']['output'];
  id: Scalars['UUID']['output'];
  mimeType: Scalars['NonEmptyString']['output'];
  name: Scalars['NonEmptyString']['output'];
};

export type LiveLikeEmojiCount = LiveLikeNode & {
  __typename?: 'LiveLikeEmojiCount';
  id: Scalars['UUID']['output'];
  reactionsCount: Scalars['NonNegativeInt']['output'];
};

export type LiveLikeImagePoll = LiveLikeNode & LiveLikeWidgetBase & {
  __typename?: 'LiveLikeImagePoll';
  clientId: Scalars['NonEmptyString']['output'];
  contentFilter?: Maybe<Array<Scalars['String']['output']>>;
  createdAt: Scalars['DateTimeISO']['output'];
  createdBy: LiveLikeWidgetCreator;
  customData?: Maybe<Scalars['String']['output']>;
  filteredQuestion?: Maybe<Scalars['String']['output']>;
  id: Scalars['UUID']['output'];
  /** The ISO8601 Date that the widget will stop accepting interactions */
  interactiveUntil?: Maybe<Scalars['DateTimeISO']['output']>;
  kind: LiveLikeWidgetKindEnum;
  /** List of options for this prediction */
  options: Array<LiveLikeImagePollOption>;
  /** Video playback time in milliseconds */
  playbackTimeMs?: Maybe<Scalars['NonNegativeInt']['output']>;
  /** Program-scheduled datetime when the widget is expected to appear (if applicable). */
  programDateTime?: Maybe<Scalars['DateTimeISO']['output']>;
  programId: Scalars['UUID']['output'];
  /** Delay (ISO8601) before the widget is published after scheduling (if applicable). */
  publishDelay: Scalars['Duration']['output'];
  publishedAt?: Maybe<Scalars['DateTimeISO']['output']>;
  pubnubEnabled: Scalars['Boolean']['output'];
  /** The prompt or question for the prediction to be made */
  question: Scalars['NonEmptyString']['output'];
  /** Report count information */
  reportCount?: Maybe<LiveLikeWidgetReportCount>;
  scheduledAt?: Maybe<Scalars['DateTimeISO']['output']>;
  /** List the sponsors ids with this Image Poll. */
  sponsorIds?: Maybe<Array<Scalars['UUID']['output']>>;
  status: LiveLikeWidgetStatusEnum;
  timeout: Scalars['Duration']['output'];
  uniqueImpressionCount?: Maybe<Scalars['NonNegativeInt']['output']>;
  /** @deprecated Introduces cyclic dependency and ImagePoll cache issue */
  userVote?: Maybe<LiveLikeWidgetInteraction>;
  /** An array of key value pairs used for custom behaviors */
  widgetAttributes?: Maybe<Array<LiveLikeKeyValuePair>>;
};

export type LiveLikeImagePollCreateInput = {
  /** A free-form field used for custom behaviors */
  customData?: InputMaybe<Scalars['String']['input']>;
  /** The ISO8601 DateTime that the widget will stop accepting interactions */
  interactiveUntil?: InputMaybe<Scalars['DateTimeISO']['input']>;
  /** ImagePoll localized data */
  localizedData?: InputMaybe<Array<LiveLikeImagePollLocalizedInput>>;
  /** List of options for this prediction, min 2 and max 4 */
  options: Array<LiveLikeImagePollCreateOptionInput>;
  /** Video playback time in milliseconds */
  playbackTimeMs?: InputMaybe<Scalars['NonNegativeInt']['input']>;
  /** ID of the program to create the prediction for */
  programId: Scalars['UUID']['input'];
  /** The prompt or question for the prediction to be made */
  question: Scalars['NonEmptyString']['input'];
  /** Links the sponsors with this Image Poll. Note that only valid sponsor_ids will be linked to a Image Poll. */
  sponsorIds?: InputMaybe<Array<Scalars['UUID']['input']>>;
  /** A iso8601 duration hint for when a Widget should be timed out */
  timeout?: InputMaybe<Scalars['Duration']['input']>;
  /** An array of key value pairs used for custom behaviors */
  widgetAttributes?: InputMaybe<Array<LiveLikeKeyValuePairInput>>;
};

export type LiveLikeImagePollCreateOptionInput = {
  /** Description of a poll option */
  description: Scalars['NonEmptyString']['input'];
  /** Image URL of a poll option */
  imageURL: Scalars['URL']['input'];
  /** ImagePoll option localized data */
  localizedData?: InputMaybe<Array<LiveLikeImagePollOptionLocalizedInput>>;
};

export type LiveLikeImagePollLocalizedInput = {
  /** Localized language a string that conforms to the BCP-47 (RFC 5646) standard. */
  language: Scalars['Locale']['input'];
  /** The prompt or question for the prediction to be made */
  question: Scalars['NonEmptyString']['input'];
};

export type LiveLikeImagePollOption = LiveLikeNode & {
  __typename?: 'LiveLikeImagePollOption';
  contentFilter?: Maybe<Array<Scalars['String']['output']>>;
  description: Scalars['String']['output'];
  filteredDescription?: Maybe<Scalars['String']['output']>;
  id: Scalars['UUID']['output'];
  imageUrl: Scalars['URL']['output'];
  translatableFields?: Maybe<Array<Scalars['String']['output']>>;
  voteCount?: Maybe<Scalars['Int']['output']>;
};

export type LiveLikeImagePollOptionLocalizedInput = {
  /** Description of a poll option */
  description: Scalars['NonEmptyString']['input'];
  /** Localized language a string that conforms to the BCP-47 (RFC 5646) standard. */
  language: Scalars['Locale']['input'];
};

export type LiveLikeImagePollVote = LiveLikeWidgetInteractionBase & {
  __typename?: 'LiveLikeImagePollVote';
  createdAt: Scalars['String']['output'];
  id: Scalars['UUID']['output'];
  /** Leaderboard rewards associated with the image poll vote */
  leaderboardRewards?: Maybe<Array<LiveLikeLeaderboardReward>>;
  /** Vote option associated with the image poll vote */
  optionId: Scalars['UUID']['output'];
  /** ID of the profile associated with the image poll vote */
  profileId: Scalars['UUID']['output'];
  /** Rewards associated with the image poll vote */
  rewards?: Maybe<Array<LiveLikeReward>>;
  /** Image poll widget associated with the image poll vote */
  widget: LiveLikeImagePoll;
  /** ID of the widget associated with the image poll vote */
  widgetId: Scalars['UUID']['output'];
  widgetKind: LiveLikeWidgetInteractionEnum;
};

export type LiveLikeImagePollVoteCreateInput = {
  optionId: Scalars['UUID']['input'];
  widgetId: Scalars['UUID']['input'];
};

export type LiveLikeImagePollVoteUpdateInput = {
  id: Scalars['UUID']['input'];
  optionId: Scalars['UUID']['input'];
  widgetId: Scalars['UUID']['input'];
};

/** Represents an image prediction widget. */
export type LiveLikeImagePrediction = LiveLikeNode & LiveLikeWidgetBase & {
  __typename?: 'LiveLikeImagePrediction';
  /** Client identifier associated with this prediction. */
  clientId: Scalars['NonEmptyString']['output'];
  /** Optional confirmation message for the widget. */
  confirmationMessage?: Maybe<Scalars['String']['output']>;
  /** Timestamp when the widget was created. */
  createdAt: Scalars['DateTimeISO']['output'];
  /** Information about the user that created the widget. */
  createdBy: LiveLikeWidgetCreator;
  /** Optional custom metadata for the widget. */
  customData?: Maybe<Scalars['String']['output']>;
  /** List of all follow ups available for this prediction. */
  followUps: Array<LiveLikeImagePredictionFollowUp>;
  /** Unique identifier of the image prediction. */
  id: Scalars['UUID']['output'];
  /** The ISO8601 DateTime when the widget stops accepting interactions. */
  interactiveUntil?: Maybe<Scalars['DateTimeISO']['output']>;
  /** Kind of widget */
  kind: LiveLikeWidgetKindEnum;
  /** List of options available for this prediction. */
  options: Array<LiveLikeImagePredictionOption>;
  /** Video playback time at which the widget appears, in milliseconds. */
  playbackTimeMs?: Maybe<Scalars['NonNegativeInt']['output']>;
  /** Program-scheduled datetime when the prediction is expected to appear. */
  programDateTime?: Maybe<Scalars['DateTimeISO']['output']>;
  /** Program identifier associated with this prediction. */
  programId: Scalars['UUID']['output'];
  /** Delay (ISO8601) before the widget is published after scheduling. */
  publishDelay: Scalars['Duration']['output'];
  /** Datetime when the widget was actually published. */
  publishedAt?: Maybe<Scalars['DateTimeISO']['output']>;
  /** Whether pubnub is enabled. */
  pubnubEnabled: Scalars['Boolean']['output'];
  /** The question for the prediction to be made */
  question: Scalars['NonEmptyString']['output'];
  /** Contains count-based metrics such as interactions. */
  reportCount?: Maybe<LiveLikeWidgetReportCount>;
  /** Scheduled datetime for the widget. */
  scheduledAt?: Maybe<Scalars['DateTimeISO']['output']>;
  /** List of sponsor IDs associated with this Image Prediction. */
  sponsorIds?: Maybe<Array<Scalars['UUID']['output']>>;
  /** Current status of the widget (e.g.,  PENDING, SCHEDULED, PUBLISHED, INFLIGHT etc). */
  status: LiveLikeWidgetStatusEnum;
  /** Duration (ISO8601) for which the widget remains interactive. */
  timeout: Scalars['Duration']['output'];
  /** Total number of unique users who interacted with the widget. */
  uniqueImpressionCount?: Maybe<Scalars['NonNegativeInt']['output']>;
  /** Additional widget attributes in key-value format. */
  widgetAttributes?: Maybe<Array<LiveLikeKeyValuePair>>;
};

export type LiveLikeImagePredictionCreateInput = {
  /** Optional confirmation message for the widget. */
  confirmationMessage?: InputMaybe<Scalars['String']['input']>;
  /** A free-form field used for custom behaviors */
  customData?: InputMaybe<Scalars['NonEmptyString']['input']>;
  /**  The ISO8601 DateTime that the widget will stop accepting interactions  */
  interactiveUntil?: InputMaybe<Scalars['DateTimeISO']['input']>;
  /** Image Prediction localized data */
  localizedData?: InputMaybe<Array<LiveLikeImagePredictionLocalizedInput>>;
  /**  List of options for this prediction */
  options: Array<LiveLikeImagePredictionCreateOptionInput>;
  /**  Video playback time in milliseconds  */
  playbackTimeMs?: InputMaybe<Scalars['NonNegativeInt']['input']>;
  /** ID of the program to create the prediction for */
  programId: Scalars['UUID']['input'];
  /**  The prompt or question for the prediction to be made  */
  question: Scalars['NonEmptyString']['input'];
  /**  Links the sponsors with this Image Prediction. Note that only valid sponsor_ids will be linked to a Image Prediction. */
  sponsorIds?: InputMaybe<Array<Scalars['UUID']['input']>>;
  /** A iso8601 duration hint for when a Widget should be timed out  */
  timeout?: InputMaybe<Scalars['Duration']['input']>;
  /**  An array of key value pairs used for custom behaviors */
  widgetAttributes?: InputMaybe<Array<LiveLikeKeyValuePairInput>>;
};

/** Represents a option for a image prediction. */
export type LiveLikeImagePredictionCreateOptionInput = {
  /** Description of the option. */
  description: Scalars['NonEmptyString']['input'];
  /** URL of the image associated with this option */
  imageUrl: Scalars['URL']['input'];
  /** Indicates whether this option is the correct answer */
  isCorrect?: InputMaybe<Scalars['Boolean']['input']>;
  /** ImagePrediction option localized data */
  localizedData?: InputMaybe<Array<LiveLikeImagePredictionOptionLocalizedInput>>;
  /** Reward amount for the prediction option . */
  rewardItemAmount?: InputMaybe<Scalars['NonNegativeInt']['input']>;
  /** Unique identifier for the reward Item Id. */
  rewardItemId?: InputMaybe<Scalars['UUID']['input']>;
};

/** Represents an image prediction followup widget. */
export type LiveLikeImagePredictionFollowUp = LiveLikeNode & LiveLikeWidgetBase & {
  __typename?: 'LiveLikeImagePredictionFollowUp';
  /** Client identifier associated with this prediction. */
  clientId: Scalars['NonEmptyString']['output'];
  /** Optional Correct option id of the prediction. */
  correctOptionId?: Maybe<Scalars['UUID']['output']>;
  /** Timestamp when the widget was created. */
  createdAt: Scalars['DateTimeISO']['output'];
  /** Information about the user that created the widget. */
  createdBy: LiveLikeWidgetCreator;
  /** Optional custom metadata for the widget. */
  customData?: Maybe<Scalars['String']['output']>;
  /** Unique identifier of the image prediction. */
  id: Scalars['UUID']['output'];
  /** Image Prediction identifier associated with this prediction followup. */
  imagePredictionId: Scalars['UUID']['output'];
  /** The ISO8601 DateTime when the widget stops accepting interactions. */
  interactiveUntil?: Maybe<Scalars['DateTimeISO']['output']>;
  /** Kind of widget */
  kind: LiveLikeWidgetKindEnum;
  /** List of options available for this prediction. */
  options: Array<LiveLikeImagePredictionOption>;
  /** Video playback time at which the widget appears, in milliseconds. */
  playbackTimeMs?: Maybe<Scalars['NonNegativeInt']['output']>;
  /** Program-scheduled datetime when the prediction is expected to appear. */
  programDateTime?: Maybe<Scalars['DateTimeISO']['output']>;
  /** Program identifier associated with this prediction. */
  programId: Scalars['UUID']['output'];
  /** Delay (ISO8601) before the widget is published after scheduling. */
  publishDelay: Scalars['Duration']['output'];
  /** Datetime when the widget was actually published. */
  publishedAt?: Maybe<Scalars['DateTimeISO']['output']>;
  /** Whether pubnub is enabled. */
  pubnubEnabled: Scalars['Boolean']['output'];
  /** The question for the prediction to be made */
  question: Scalars['NonEmptyString']['output'];
  /** Contains count-based metrics such as interactions. */
  reportCount?: Maybe<LiveLikeWidgetReportCount>;
  /** Scheduled datetime for the widget. */
  scheduledAt?: Maybe<Scalars['DateTimeISO']['output']>;
  /** List of sponsor IDs associated with this Image Prediction. */
  sponsorIds?: Maybe<Array<Scalars['UUID']['output']>>;
  /** Current status of the widget (e.g.,  PENDING, SCHEDULED, PUBLISHED, INFLIGHT etc). */
  status: LiveLikeWidgetStatusEnum;
  /** Duration (ISO8601) for which the widget remains interactive. */
  timeout: Scalars['Duration']['output'];
  /** Total number of unique users who interacted with the widget. */
  uniqueImpressionCount?: Maybe<Scalars['NonNegativeInt']['output']>;
  /** Additional widget attributes in key-value format. */
  widgetAttributes?: Maybe<Array<LiveLikeKeyValuePair>>;
};

export type LiveLikeImagePredictionFollowUpCreateInput = {
  /** ID of the correct text prediction option to create the followup prediction. */
  correctOptionId?: InputMaybe<Scalars['NonEmptyString']['input']>;
  /** ID of the text prediction to create the follow up prediction. */
  imagePredictionId: Scalars['UUID']['input'];
  /** Links the sponsors with this Text Prediction. Note that only valid sponsor_ids will be linked to a Text Prediction. */
  sponsorIds?: InputMaybe<Array<Scalars['UUID']['input']>>;
};

export type LiveLikeImagePredictionLocalizedInput = {
  /** Localized language a string that conforms to the BCP-47  (RFC 5646 ) standard. */
  language: Scalars['Locale']['input'];
  /** The prompt or question for the prediction to be made */
  question: Scalars['NonEmptyString']['input'];
};

/**  Represents a option in a image prediction. Includes correctness, user response count, and localization metadata. */
export type LiveLikeImagePredictionOption = LiveLikeNode & {
  __typename?: 'LiveLikeImagePredictionOption';
  /** Description of the image prediction option. */
  description: Scalars['String']['output'];
  /** List of all earned rewards */
  earnableRewards?: Maybe<Array<LiveLikeReward>>;
  /** Unique identifier for the image option. */
  id: Scalars['UUID']['output'];
  /** URL of the image associated with this option */
  imageUrl: Scalars['URL']['output'];
  /** Indicates whether this option is the correct answer */
  isCorrect: Scalars['Boolean']['output'];
  /** Reward amount for the prediction option . */
  rewardItemAmount?: Maybe<Scalars['NonNegativeInt']['output']>;
  /** Unique identifier for the reward Item Id. */
  rewardItemId?: Maybe<Scalars['UUID']['output']>;
  /** List of fields in this object that support translation */
  translatableFields?: Maybe<Array<Scalars['String']['output']>>;
  /** Number of users who selected this option. */
  voteCount: Scalars['NonNegativeInt']['output'];
};

export type LiveLikeImagePredictionOptionLocalizedInput = {
  /** Description of the option */
  description: Scalars['NonEmptyString']['input'];
  /** Localized language a string that conforms to the BCP-47  (RFC 5646 ) standard. */
  language: Scalars['Locale']['input'];
};

export type LiveLikeImagePredictionVote = LiveLikeWidgetInteractionBase & {
  __typename?: 'LiveLikeImagePredictionVote';
  /** Claim token for the image prediction Vote */
  claimToken: Scalars['JWT']['output'];
  /** Timestamp when the widget was created. */
  createdAt: Scalars['String']['output'];
  /** Unique ID of the image prediction vote */
  id: Scalars['UUID']['output'];
  /** Leaderboard rewards associated with the image prediction vote */
  leaderboardRewards?: Maybe<Array<LiveLikeLeaderboardReward>>;
  /** Vote option associated with the image prediction vote */
  optionId: Scalars['UUID']['output'];
  /** ID of the profile associated with the image prediction vote */
  profileId: Scalars['UUID']['output'];
  /** Rewards associated with the image prediction vote */
  rewards?: Maybe<Array<LiveLikeReward>>;
  /** Image Prediction widget associated with the image prediction vote */
  widget: LiveLikeImagePrediction;
  /** ID of the widget associated with the image prediction vote */
  widgetId: Scalars['UUID']['output'];
  /** Kind of the widget Interaction */
  widgetKind: LiveLikeWidgetInteractionEnum;
};

export type LiveLikeImagePredictionVoteCreateInput = {
  optionId: Scalars['UUID']['input'];
  widgetId: Scalars['UUID']['input'];
};

export type LiveLikeImagePredictionVoteUpdateInput = {
  id: Scalars['UUID']['input'];
  optionId: Scalars['UUID']['input'];
  widgetId: Scalars['UUID']['input'];
};

/** Represents an image quiz widget. */
export type LiveLikeImageQuiz = LiveLikeNode & LiveLikeWidgetBase & {
  __typename?: 'LiveLikeImageQuiz';
  /** List of choices available for this quiz. */
  choices: Array<LiveLikeImageQuizChoice>;
  /** Client identifier associated with this quiz. */
  clientId: Scalars['NonEmptyString']['output'];
  /** Timestamp when the widget was created. */
  createdAt: Scalars['DateTimeISO']['output'];
  /** Information about the user that created the widget. */
  createdBy: LiveLikeWidgetCreator;
  /** Optional custom metadata for the widget. */
  customData?: Maybe<Scalars['String']['output']>;
  /** Unique identifier of the image quiz. */
  id: Scalars['UUID']['output'];
  /** The ISO8601 DateTime when the widget stops accepting interactions. */
  interactiveUntil?: Maybe<Scalars['DateTimeISO']['output']>;
  /** Kind of widget */
  kind: LiveLikeWidgetKindEnum;
  /** Video playback time at which the widget appears, in milliseconds. */
  playbackTimeMs?: Maybe<Scalars['NonNegativeInt']['output']>;
  /** Program-scheduled datetime when the quiz is expected to appear. */
  programDateTime?: Maybe<Scalars['DateTimeISO']['output']>;
  /** Program identifier associated with this quiz. */
  programId: Scalars['UUID']['output'];
  /** Delay (ISO8601) before the widget is published after scheduling. */
  publishDelay: Scalars['Duration']['output'];
  /** Datetime when the widget was actually published. */
  publishedAt?: Maybe<Scalars['DateTimeISO']['output']>;
  /** Whether pubnub is enabled. */
  pubnubEnabled: Scalars['Boolean']['output'];
  /** The question for the quiz to be made */
  question: Scalars['NonEmptyString']['output'];
  /** Contains count-based metrics such as interactions. */
  reportCount?: Maybe<LiveLikeWidgetReportCount>;
  /** Scheduled datetime for the widget. */
  scheduledAt?: Maybe<Scalars['DateTimeISO']['output']>;
  /** List of sponsor IDs associated with this Image Quiz. */
  sponsorIds?: Maybe<Array<Scalars['UUID']['output']>>;
  /** Current status of the widget (e.g.,  PENDING, SCHEDULED, PUBLISHED, INFLIGHT etc). */
  status: LiveLikeWidgetStatusEnum;
  /** Duration (ISO8601) for which the widget remains interactive. */
  timeout: Scalars['Duration']['output'];
  /** Total number of unique users who interacted with the widget. */
  uniqueImpressionCount?: Maybe<Scalars['NonNegativeInt']['output']>;
  /** Additional widget attributes in key-value format. */
  widgetAttributes?: Maybe<Array<LiveLikeKeyValuePair>>;
};

export type LiveLikeImageQuizAnswer = LiveLikeWidgetInteractionBase & {
  __typename?: 'LiveLikeImageQuizAnswer';
  /** Identifier of the choice selected by the user. */
  choiceId: Scalars['UUID']['output'];
  /** Timestamp when the answer was created. */
  createdAt: Scalars['String']['output'];
  /** Unique identifier of the image quiz answer. */
  id: Scalars['UUID']['output'];
  /** List of leaderboard rewards associated with this answer. */
  leaderboardRewards?: Maybe<Array<LiveLikeLeaderboardReward>>;
  /** ID of the profile who submitted the answer. */
  profileId: Scalars['UUID']['output'];
  /** List of rewards granted for this answer. */
  rewards?: Maybe<Array<LiveLikeReward>>;
  /** The image quiz widget associated with this answer. */
  widget: LiveLikeImageQuiz;
  /** ID of the widget instance this answer belongs to. */
  widgetId: Scalars['UUID']['output'];
  /** Type of widget interaction. */
  widgetKind: LiveLikeWidgetInteractionEnum;
};

export type LiveLikeImageQuizAnswerCreateInput = {
  /** ID of the choice selected by the user. */
  choiceId: Scalars['UUID']['input'];
  /** ID of the widget instance for which the answer is submitted. */
  widgetId: Scalars['UUID']['input'];
};

export type LiveLikeImageQuizAnswerUpdateInput = {
  /** ID of the choice selected by the user. */
  choiceId: Scalars['UUID']['input'];
  /** ID identifier of the image quiz answer to update. */
  id: Scalars['UUID']['input'];
  /** ID of the widget instance for which the answer is submitted. */
  widgetId: Scalars['UUID']['input'];
};

/**  Represents a choice in a image quiz. Includes correctness, user response count, and localization metadata. */
export type LiveLikeImageQuizChoice = LiveLikeNode & {
  __typename?: 'LiveLikeImageQuizChoice';
  /** Number of users who selected this choice. */
  answerCount: Scalars['NonNegativeInt']['output'];
  /** Description of the choice. */
  description: Scalars['String']['output'];
  /** Unique identifier for the choice. */
  id: Scalars['UUID']['output'];
  /** URL of the image associated with this choice */
  imageUrl: Scalars['URL']['output'];
  /** Indicates whether this choice is the correct answer */
  isCorrect: Scalars['Boolean']['output'];
  /** List of fields in this object that support translation */
  translatableFields?: Maybe<Array<Scalars['String']['output']>>;
};

export type LiveLikeImageQuizChoiceLocalizedInput = {
  /** Description of the choice */
  description: Scalars['NonEmptyString']['input'];
  /** Localized language a string that conforms to the BCP-47  (RFC 5646 ) standard. */
  language: Scalars['Locale']['input'];
};

/** Represents a choice option for a image quiz. */
export type LiveLikeImageQuizCreateChoiceInput = {
  /** Description of the choice. */
  description: Scalars['NonEmptyString']['input'];
  /** URL of the image associated with this choice */
  imageUrl: Scalars['URL']['input'];
  /** Indicates whether this choice is the correct answer */
  isCorrect: Scalars['Boolean']['input'];
  /** ImageQuiz choice localized data */
  localizedData?: InputMaybe<Array<LiveLikeImageQuizChoiceLocalizedInput>>;
};

export type LiveLikeImageQuizCreateInput = {
  /**  List of choices for this quiz */
  choices: Array<LiveLikeImageQuizCreateChoiceInput>;
  /** A free-form field used for custom behaviors */
  customData?: InputMaybe<Scalars['NonEmptyString']['input']>;
  /**  The ISO8601 DateTime that the widget will stop accepting interactions  */
  interactiveUntil?: InputMaybe<Scalars['DateTimeISO']['input']>;
  /** ImageQuiz localized data */
  localizedData?: InputMaybe<Array<LiveLikeImageQuizLocalizedInput>>;
  /**  Video playback time in milliseconds  */
  playbackTimeMs?: InputMaybe<Scalars['NonNegativeInt']['input']>;
  /** ID of the program to create the prediction for */
  programId: Scalars['UUID']['input'];
  /**  The prompt or question for the prediction to be made  */
  question: Scalars['NonEmptyString']['input'];
  /**  Links the sponsors with this Image Quiz. Note that only valid sponsor_ids will be linked to a Image Quiz. */
  sponsorIds?: InputMaybe<Array<Scalars['UUID']['input']>>;
  /** A iso8601 duration hint for when a Widget should be timed out  */
  timeout?: InputMaybe<Scalars['Duration']['input']>;
  /**  An array of key value pairs used for custom behaviors */
  widgetAttributes?: InputMaybe<Array<LiveLikeKeyValuePairInput>>;
};

export type LiveLikeImageQuizLocalizedInput = {
  /** Localized language a string that conforms to the BCP-47  (RFC 5646 ) standard. */
  language: Scalars['Locale']['input'];
  /** The prompt or question for the prediction to be made */
  question: Scalars['NonEmptyString']['input'];
};

export type LiveLikeIncomingProfileRelationshipInput = {
  fromProfileId?: InputMaybe<Scalars['UUID']['input']>;
  relationshipTypeKey?: InputMaybe<Scalars['NonEmptyString']['input']>;
  since?: InputMaybe<Scalars['DateTimeISO']['input']>;
  until?: InputMaybe<Scalars['DateTimeISO']['input']>;
};

export type LiveLikeKeyValuePair = {
  __typename?: 'LiveLikeKeyValuePair';
  key: Scalars['String']['output'];
  value: Scalars['String']['output'];
};

export type LiveLikeKeyValuePairInput = {
  key: Scalars['String']['input'];
  value: Scalars['String']['input'];
};

export type LiveLikeLeaderboard = LiveLikeNode & {
  __typename?: 'LiveLikeLeaderboard';
  clientId: Scalars['NonEmptyString']['output'];
  id: Scalars['UUID']['output'];
  isLocked: Scalars['Boolean']['output'];
  name: Scalars['NonEmptyString']['output'];
  rewardItem?: Maybe<LiveLikeRewardItem>;
  rewardItemId: Scalars['UUID']['output'];
};

export type LiveLikeLeaderboardCollection = LiveLikeConnection & {
  __typename?: 'LiveLikeLeaderboardCollection';
  edges?: Maybe<Array<LiveLikeLeaderboardEdge>>;
  page: LiveLikePage;
};

export type LiveLikeLeaderboardCreateInput = {
  attributes?: InputMaybe<Array<LiveLikeKeyValuePairInput>>;
  clientId: Scalars['NonEmptyString']['input'];
  isLocked?: InputMaybe<Scalars['Boolean']['input']>;
  name: Scalars['NonEmptyString']['input'];
  rewardItemId: Scalars['UUID']['input'];
};

export type LiveLikeLeaderboardEdge = LiveLikeEdge & {
  __typename?: 'LiveLikeLeaderboardEdge';
  cursor?: Maybe<Scalars['String']['output']>;
  node: LiveLikeLeaderboard;
};

export type LiveLikeLeaderboardEntriesGetInput = {
  leaderboardId: Scalars['UUID']['input'];
  page?: InputMaybe<LiveLikePaginationOffsetInput>;
};

export type LiveLikeLeaderboardEntry = {
  __typename?: 'LiveLikeLeaderboardEntry';
  percentileRank: Scalars['NonNegativeFloat']['output'];
  profileId: Scalars['UUID']['output'];
  profileNickname: Scalars['NonEmptyString']['output'];
  rank: Scalars['PositiveInt']['output'];
  score: Scalars['PositiveInt']['output'];
};

export type LiveLikeLeaderboardEntryCollection = {
  __typename?: 'LiveLikeLeaderboardEntryCollection';
  edges?: Maybe<Array<LiveLikeLeaderboardEntryEdge>>;
  page: LiveLikePageOffset;
};

export type LiveLikeLeaderboardEntryEdge = {
  __typename?: 'LiveLikeLeaderboardEntryEdge';
  cursor?: Maybe<Scalars['String']['output']>;
  node: LiveLikeLeaderboardEntry;
};

export type LiveLikeLeaderboardEntryGetInput = {
  leaderboardId: Scalars['UUID']['input'];
  profileId: Scalars['UUID']['input'];
};

export type LiveLikeLeaderboardProgramLinkInput = {
  leaderboardId: Scalars['UUID']['input'];
  programId: Scalars['UUID']['input'];
};

export type LiveLikeLeaderboardReward = {
  __typename?: 'LiveLikeLeaderboardReward';
  leaderboardId: Scalars['UUID']['output'];
  leaderboardName: Scalars['NonEmptyString']['output'];
  newPercentileRank: Scalars['NonEmptyString']['output'];
  newRank: Scalars['NonNegativeInt']['output'];
  newScore: Scalars['NonNegativeFloat']['output'];
  rewardAction: LiveLikeRewardActionEnum;
  rewardItemAmount: Scalars['PositiveInt']['output'];
  rewardItemId: Scalars['UUID']['output'];
  rewardItemName: Scalars['NonEmptyString']['output'];
};

export type LiveLikeLeaderboardUpdateInput = {
  attributes?: InputMaybe<Array<LiveLikeKeyValuePairInput>>;
  id: Scalars['UUID']['input'];
  isLocked?: InputMaybe<Scalars['Boolean']['input']>;
  name?: InputMaybe<Scalars['NonEmptyString']['input']>;
};

export type LiveLikeLeaderboardsGetInput = {
  clientId: Scalars['NonEmptyString']['input'];
  page?: InputMaybe<Scalars['PositiveInt']['input']>;
  programIds?: InputMaybe<Array<Scalars['UUID']['input']>>;
};

export type LiveLikeLinkRewardTableWithProgramInput = {
  programId: Scalars['UUID']['input'];
  rewardTableId: Scalars['UUID']['input'];
};

export type LiveLikeNode = {
  id: Scalars['UUID']['output'];
};

export enum LiveLikeOrderEnum {
  Asc = 'ASC',
  Desc = 'DESC'
}

export type LiveLikeOutgoingProfileRelationshipInput = {
  relationshipTypeKey?: InputMaybe<Scalars['NonEmptyString']['input']>;
  since?: InputMaybe<Scalars['DateTimeISO']['input']>;
  toProfileId?: InputMaybe<Scalars['UUID']['input']>;
  until?: InputMaybe<Scalars['DateTimeISO']['input']>;
};

export type LiveLikePage = {
  __typename?: 'LiveLikePage';
  count?: Maybe<Scalars['NonNegativeInt']['output']>;
  endCursor?: Maybe<Scalars['String']['output']>;
  next?: Maybe<Scalars['PositiveInt']['output']>;
  previous?: Maybe<Scalars['PositiveInt']['output']>;
  startCursor?: Maybe<Scalars['String']['output']>;
};

export type LiveLikePageOffset = {
  __typename?: 'LiveLikePageOffset';
  count?: Maybe<Scalars['NonNegativeInt']['output']>;
  next?: Maybe<LiveLikePaginationOffset>;
  previous?: Maybe<LiveLikePaginationOffset>;
};

export type LiveLikePaginationOffset = {
  __typename?: 'LiveLikePaginationOffset';
  limit?: Maybe<Scalars['NonNegativeInt']['output']>;
  offset?: Maybe<Scalars['NonNegativeInt']['output']>;
};

export type LiveLikePaginationOffsetInput = {
  limit?: InputMaybe<Scalars['NonNegativeInt']['input']>;
  offset?: InputMaybe<Scalars['NonNegativeInt']['input']>;
};

export type LiveLikePermission = LiveLikeNode & {
  __typename?: 'LiveLikePermission';
  createdAt: Scalars['DateTimeISO']['output'];
  description: Scalars['String']['output'];
  id: Scalars['UUID']['output'];
  key: Scalars['NonEmptyString']['output'];
  name: Scalars['NonEmptyString']['output'];
};

export type LiveLikePermissionEdge = LiveLikeEdge & {
  __typename?: 'LiveLikePermissionEdge';
  cursor?: Maybe<Scalars['String']['output']>;
  node: LiveLikePermission;
};

export type LiveLikePermissions = LiveLikeConnection & {
  __typename?: 'LiveLikePermissions';
  edges?: Maybe<Array<Maybe<LiveLikePermissionEdge>>>;
  page: LiveLikePage;
};

export enum LiveLikePollInteractionEnum {
  ImagePoll = 'IMAGE_POLL',
  TextPoll = 'TEXT_POLL'
}

/**
 * DEPRECATED: Use widget specific one
 * (TextPollVoteCreateInput, ImagePollVoteCreateInput)
 */
export type LiveLikePollVoteCreateInput = {
  kind: LiveLikePollInteractionEnum;
  optionId: Scalars['UUID']['input'];
  widgetId: Scalars['UUID']['input'];
};

/**
 * DEPRECATED: Use widget specific one
 * (TextPollVoteUpdateInput, ImagePollVoteUpdateInput)
 */
export type LiveLikePollVoteUpdateInput = {
  id: Scalars['UUID']['input'];
  kind: LiveLikePollInteractionEnum;
  optionId: Scalars['UUID']['input'];
  widgetId: Scalars['UUID']['input'];
};

export type LiveLikeProfile = LiveLikeNode & {
  __typename?: 'LiveLikeProfile';
  badgeProgress?: Maybe<Array<LiveLikeBadgeRewardProgressCollection>>;
  badges?: Maybe<LiveLikeEarnedBadgeCollection>;
  clientId?: Maybe<Scalars['NonEmptyString']['output']>;
  createdAt: Scalars['NonEmptyString']['output'];
  customData?: Maybe<Scalars['String']['output']>;
  customId?: Maybe<Scalars['NonEmptyString']['output']>;
  id: Scalars['UUID']['output'];
  incomingProfileRelationships?: Maybe<LiveLikeProfileRelationshipCollection>;
  nickname: Scalars['NonEmptyString']['output'];
  outgoingProfileRelationships?: Maybe<LiveLikeProfileRelationshipCollection>;
  quests?: Maybe<LiveLikeUserQuestCollection>;
  rewardBalance?: Maybe<LiveLikeRewardItemBalance>;
  rewardBalances?: Maybe<LiveLikeRewardItemBalanceCollection>;
  widgetsInteractions?: Maybe<Array<LiveLikeWidgetInteractions>>;
};


export type LiveLikeProfileBadgeProgressArgs = {
  badgeId: Scalars['UUID']['input'];
};


export type LiveLikeProfileIncomingProfileRelationshipsArgs = {
  input?: InputMaybe<LiveLikeIncomingProfileRelationshipInput>;
  order?: InputMaybe<LiveLikeProfileRelationshipOrderInput>;
};


export type LiveLikeProfileOutgoingProfileRelationshipsArgs = {
  input?: InputMaybe<LiveLikeOutgoingProfileRelationshipInput>;
  order?: InputMaybe<LiveLikeProfileRelationshipOrderInput>;
};


export type LiveLikeProfileQuestsArgs = {
  input?: InputMaybe<LiveLikeUserQuestsInput>;
};


export type LiveLikeProfileRewardBalanceArgs = {
  input: LiveLikeRewardBalanceGetInput;
};


export type LiveLikeProfileRewardBalancesArgs = {
  input?: InputMaybe<LiveLikeRewardBalancesGetInput>;
};


export type LiveLikeProfileWidgetsInteractionsArgs = {
  input: Array<LiveLikeWidgetInteractionsInput>;
};

export type LiveLikeProfileAuth = LiveLikeNode & {
  __typename?: 'LiveLikeProfileAuth';
  accessToken: Scalars['JWT']['output'];
  clientId: Scalars['NonEmptyString']['output'];
  createdAt: Scalars['NonEmptyString']['output'];
  customId?: Maybe<Scalars['NonEmptyString']['output']>;
  id: Scalars['UUID']['output'];
  nickname: Scalars['NonEmptyString']['output'];
};

export type LiveLikeProfileByCustomIdCreateInput = {
  clientId: Scalars['NonEmptyString']['input'];
  customId: Scalars['NonEmptyString']['input'];
  nickname?: InputMaybe<Scalars['NonEmptyString']['input']>;
};

export type LiveLikeProfileCreateInput = {
  clientId: Scalars['NonEmptyString']['input'];
  nickname?: InputMaybe<Scalars['NonEmptyString']['input']>;
};

export type LiveLikeProfileGetByCustomIdInput = {
  clientId: Scalars['NonEmptyString']['input'];
  customId: Scalars['NonEmptyString']['input'];
};

export type LiveLikeProfileRelationship = LiveLikeNode & {
  __typename?: 'LiveLikeProfileRelationship';
  createdAt: Scalars['DateTimeISO']['output'];
  fromProfile: LiveLikeProfile;
  id: Scalars['UUID']['output'];
  relationshipType: LiveLikeProfileRelationshipType;
  toProfile: LiveLikeProfile;
};

export type LiveLikeProfileRelationshipCollection = LiveLikeConnection & {
  __typename?: 'LiveLikeProfileRelationshipCollection';
  edges?: Maybe<Array<LiveLikeProfileRelationshipEdge>>;
  page: LiveLikePage;
};

export type LiveLikeProfileRelationshipCreateInput = {
  fromProfileId: Scalars['UUID']['input'];
  relationshipTypeKey: Scalars['NonEmptyString']['input'];
  toProfileId: Scalars['UUID']['input'];
};

export type LiveLikeProfileRelationshipEdge = LiveLikeEdge & {
  __typename?: 'LiveLikeProfileRelationshipEdge';
  cursor?: Maybe<Scalars['String']['output']>;
  node: LiveLikeProfileRelationship;
};

export type LiveLikeProfileRelationshipInput = {
  clientId: Scalars['NonEmptyString']['input'];
  fromProfileId?: InputMaybe<Scalars['UUID']['input']>;
  relationshipTypeKey?: InputMaybe<Scalars['NonEmptyString']['input']>;
  since?: InputMaybe<Scalars['DateTimeISO']['input']>;
  toProfileId?: InputMaybe<Scalars['UUID']['input']>;
  until?: InputMaybe<Scalars['DateTimeISO']['input']>;
};

export enum LiveLikeProfileRelationshipOrderField {
  CreatedAt = 'CREATED_AT'
}

export type LiveLikeProfileRelationshipOrderInput = {
  field: LiveLikeProfileRelationshipOrderField;
  order?: InputMaybe<LiveLikeOrderEnum>;
};

export type LiveLikeProfileRelationshipType = LiveLikeNode & {
  __typename?: 'LiveLikeProfileRelationshipType';
  clientId: Scalars['NonEmptyString']['output'];
  createdAt: Scalars['DateTimeISO']['output'];
  id: Scalars['UUID']['output'];
  key: Scalars['NonEmptyString']['output'];
  name: Scalars['NonEmptyString']['output'];
};

export type LiveLikeProfileRelationshipTypeCollection = LiveLikeConnection & {
  __typename?: 'LiveLikeProfileRelationshipTypeCollection';
  edges?: Maybe<Array<LiveLikeProfileRelationshipTypeEdge>>;
  page: LiveLikePage;
};

export type LiveLikeProfileRelationshipTypeCreateInput = {
  clientId: Scalars['NonEmptyString']['input'];
  key: Scalars['NonEmptyString']['input'];
  name: Scalars['NonEmptyString']['input'];
};

export type LiveLikeProfileRelationshipTypeEdge = LiveLikeEdge & {
  __typename?: 'LiveLikeProfileRelationshipTypeEdge';
  cursor?: Maybe<Scalars['String']['output']>;
  node: LiveLikeProfileRelationshipType;
};

export type LiveLikeProfileRelationshipTypesInput = {
  clientId: Scalars['NonEmptyString']['input'];
  key?: InputMaybe<Scalars['NonEmptyString']['input']>;
};

export type LiveLikeProfileUpdateInput = {
  customData?: InputMaybe<Scalars['NonEmptyString']['input']>;
  id: Scalars['UUID']['input'];
  nickname?: InputMaybe<Scalars['NonEmptyString']['input']>;
};

export type LiveLikeProgram = LiveLikeNode & {
  __typename?: 'LiveLikeProgram';
  /** The unique identifier of the app to create the program in */
  clientId: Scalars['NonEmptyString']['output'];
  /** The date and time the program was created in ISO format */
  createdAt: Scalars['NonEmptyString']['output'];
  /** Associate this Program with an ID in another system */
  customId?: Maybe<Scalars['NonEmptyString']['output']>;
  id: Scalars['UUID']['output'];
  /** The date and time the program is scheduled to begin in ISO format compliant with RFC 3339 */
  scheduledAt: Scalars['DateTimeISO']['output'];
  /** List of sponsors to link with the program. Note that only valid sponsor_ids will be linked to a program. */
  sponsorIds?: Maybe<Array<Scalars['UUID']['output']>>;
  /** The date and time the program started in ISO format compliant with RFC 3339 */
  startedAt?: Maybe<Scalars['DateTimeISO']['output']>;
  status: LiveLikeProgramStatusEnum;
  /** The date and time the program stopped in ISO format compliant with RFC 3339 */
  stoppedAt?: Maybe<Scalars['DateTimeISO']['output']>;
  /** The human-readable title of the program */
  title: Scalars['NonEmptyString']['output'];
  widgets?: Maybe<LiveLikeWidgetCollection>;
  widgetsEnabled: Scalars['Boolean']['output'];
};


export type LiveLikeProgramWidgetsArgs = {
  input?: InputMaybe<LiveLikeWidgetGetInput>;
  order?: InputMaybe<LiveLikeWidgetOrderInput>;
};

export type LiveLikeProgramBan = LiveLikeNode & {
  __typename?: 'LiveLikeProgramBan';
  bannedByProfile: LiveLikeProfile;
  bannedProfile: LiveLikeProfile;
  clientId: Scalars['NonEmptyString']['output'];
  comment: Scalars['NonEmptyString']['output'];
  createdAt: Scalars['DateTimeISO']['output'];
  expiringAt?: Maybe<Scalars['DateTimeISO']['output']>;
  id: Scalars['UUID']['output'];
  programId: Scalars['UUID']['output'];
};

export type LiveLikeProgramBanCollection = {
  __typename?: 'LiveLikeProgramBanCollection';
  edges?: Maybe<Array<LiveLikeProgramBanEdge>>;
  page: LiveLikePage;
};

export type LiveLikeProgramBanEdge = {
  __typename?: 'LiveLikeProgramBanEdge';
  cursor?: Maybe<Scalars['String']['output']>;
  node: LiveLikeProgramBan;
};

export type LiveLikeProgramBanInput = {
  bannedProfileId: Scalars['UUID']['input'];
  comment: Scalars['NonEmptyString']['input'];
  expiringAt?: InputMaybe<Scalars['DateTimeISO']['input']>;
  programId: Scalars['UUID']['input'];
};

export type LiveLikeProgramBansInput = {
  bannedByProfileId?: InputMaybe<Scalars['UUID']['input']>;
  bannedProfileId?: InputMaybe<Scalars['UUID']['input']>;
  page?: InputMaybe<Scalars['PositiveInt']['input']>;
  programId?: InputMaybe<Scalars['UUID']['input']>;
};

export type LiveLikeProgramConnection = LiveLikeConnection & {
  __typename?: 'LiveLikeProgramConnection';
  edges?: Maybe<Array<Maybe<LiveLikeProgramEdge>>>;
  page: LiveLikePage;
};

export type LiveLikeProgramCreateInput = {
  clientId: Scalars['NonEmptyString']['input'];
  /** Associate this Program with an ID in another system */
  customId?: InputMaybe<Scalars['NonEmptyString']['input']>;
  /** Program localized data */
  localizedData?: InputMaybe<Array<LiveLikeProgramLocalizedInput>>;
  /** The date and time the program is scheduled to begin in ISO format compliant with RFC 3339 */
  scheduledAt: Scalars['DateTimeISO']['input'];
  /** List of sponsors to link with the program. Note that only valid sponsorId's will be linked to a program. */
  sponsorIds?: InputMaybe<Array<Scalars['UUID']['input']>>;
  /** The human-readable title of the program */
  title: Scalars['NonEmptyString']['input'];
};

export type LiveLikeProgramDeleteByCustomIdInput = {
  clientId: Scalars['NonEmptyString']['input'];
  /** Associates this Program with an ID in another system */
  customId: Scalars['NonEmptyString']['input'];
};

export type LiveLikeProgramEdge = LiveLikeEdge & {
  __typename?: 'LiveLikeProgramEdge';
  cursor?: Maybe<Scalars['String']['output']>;
  node: LiveLikeProgram;
};

export type LiveLikeProgramGetByCustomIdInput = {
  clientId: Scalars['NonEmptyString']['input'];
  /** Associates this Program with an ID in another system */
  customId: Scalars['NonEmptyString']['input'];
};

export type LiveLikeProgramLocalizedInput = {
  /** Localized language a string that conforms to the BCP-47  (RFC 5646 ) standard. */
  language: Scalars['Locale']['input'];
  /** Localized title of the program */
  title: Scalars['NonEmptyString']['input'];
};

export type LiveLikeProgramSchedule = LiveLikeNode & {
  __typename?: 'LiveLikeProgramSchedule';
  id: Scalars['UUID']['output'];
  startedAt?: Maybe<Scalars['DateTimeISO']['output']>;
  status: LiveLikeProgramStatusEnum;
  stoppedAt?: Maybe<Scalars['DateTimeISO']['output']>;
};

export enum LiveLikeProgramStatusEnum {
  Future = 'FUTURE',
  Live = 'LIVE',
  Past = 'PAST'
}

export type LiveLikeProgramUpdateByCustomIdInput = {
  clientId: Scalars['NonEmptyString']['input'];
  /** Associate this Program with an ID in another system */
  customId: Scalars['NonEmptyString']['input'];
  /** Program localized data */
  localizedData?: InputMaybe<Array<LiveLikeProgramLocalizedInput>>;
  /** The date and time the program is scheduled to begin in ISO format compliant with RFC 3339 */
  scheduledAt?: InputMaybe<Scalars['DateTimeISO']['input']>;
  /** List of sponsors to link with the program. Note that only valid sponsorId's will be linked to a program. */
  sponsorIds?: InputMaybe<Array<Scalars['UUID']['input']>>;
  /** The human-readable title of the program */
  title?: InputMaybe<Scalars['NonEmptyString']['input']>;
};

export type LiveLikeProgramUpdateInput = {
  /** Associate this Program with an ID in another system */
  customId?: InputMaybe<Scalars['NonEmptyString']['input']>;
  id: Scalars['UUID']['input'];
  /** Program localized data */
  localizedData?: InputMaybe<Array<LiveLikeProgramLocalizedInput>>;
  /** The date and time the program is scheduled to begin in ISO format compliant with RFC 3339 */
  scheduledAt?: InputMaybe<Scalars['DateTimeISO']['input']>;
  /** List of sponsors to link with the program. Note that only valid sponsorId's will be linked to a program. */
  sponsorIds?: InputMaybe<Array<Scalars['UUID']['input']>>;
  /** The human-readable title of the program */
  title?: InputMaybe<Scalars['NonEmptyString']['input']>;
};

export type LiveLikeProgramsGetInput = {
  clientId: Scalars['NonEmptyString']['input'];
  page?: InputMaybe<Scalars['PositiveInt']['input']>;
};

export type LiveLikeQuest = LiveLikeNode & {
  __typename?: 'LiveLikeQuest';
  attributes?: Maybe<Array<LiveLikeKeyValuePair>>;
  clientId: Scalars['NonEmptyString']['output'];
  createdAt: Scalars['DateTimeISO']['output'];
  description: Scalars['String']['output'];
  id: Scalars['UUID']['output'];
  name: Scalars['NonEmptyString']['output'];
  questRewards?: Maybe<Array<LiveLikeQuestReward>>;
  questTasks?: Maybe<Array<LiveLikeQuestTask>>;
  startedAt?: Maybe<Scalars['DateTimeISO']['output']>;
  status: LiveLikeQuestStatusEnum;
  stoppedAt?: Maybe<Scalars['DateTimeISO']['output']>;
  timeout?: Maybe<Scalars['String']['output']>;
};

export type LiveLikeQuestCollection = LiveLikeConnection & {
  __typename?: 'LiveLikeQuestCollection';
  edges?: Maybe<Array<LiveLikeQuestEdge>>;
  page: LiveLikePage;
};

export type LiveLikeQuestEdge = LiveLikeEdge & {
  __typename?: 'LiveLikeQuestEdge';
  cursor?: Maybe<Scalars['String']['output']>;
  node: LiveLikeQuest;
};

export type LiveLikeQuestInput = {
  clientId: Scalars['NonEmptyString']['input'];
  description: Scalars['String']['input'];
  name: Scalars['NonEmptyString']['input'];
  startedAt?: InputMaybe<Scalars['DateTimeISO']['input']>;
  stoppedAt?: InputMaybe<Scalars['DateTimeISO']['input']>;
  timeout?: InputMaybe<Scalars['String']['input']>;
};

export type LiveLikeQuestReward = LiveLikeNode & {
  __typename?: 'LiveLikeQuestReward';
  id: Scalars['UUID']['output'];
  questId: Scalars['UUID']['output'];
  rewardItemAmount: Scalars['PositiveInt']['output'];
  rewardItemId: Scalars['UUID']['output'];
  rewardItemName: Scalars['NonEmptyString']['output'];
};

export enum LiveLikeQuestStatusEnum {
  Active = 'ACTIVE',
  Expired = 'EXPIRED',
  NotStarted = 'NOT_STARTED'
}

export type LiveLikeQuestTask = LiveLikeNode & {
  __typename?: 'LiveLikeQuestTask';
  attributes?: Maybe<Array<LiveLikeKeyValuePair>>;
  createdAt: Scalars['DateTimeISO']['output'];
  defaultProgressIncrement: Scalars['NonNegativeInt']['output'];
  description: Scalars['String']['output'];
  id: Scalars['UUID']['output'];
  name: Scalars['NonEmptyString']['output'];
  questId: Scalars['UUID']['output'];
  targetValue: Scalars['PositiveInt']['output'];
};

export type LiveLikeReaction = LiveLikeNode & {
  __typename?: 'LiveLikeReaction';
  count: Scalars['NonNegativeInt']['output'];
  id: Scalars['UUID']['output'];
  userReactionId: Scalars['UUID']['output'];
};

export type LiveLikeReactionPack = LiveLikeNode & {
  __typename?: 'LiveLikeReactionPack';
  emojis?: Maybe<Array<Maybe<LiveLikeEmoji>>>;
  id: Scalars['UUID']['output'];
  name: Scalars['NonEmptyString']['output'];
};

export type LiveLikeReactionPackCollection = LiveLikeConnection & {
  __typename?: 'LiveLikeReactionPackCollection';
  edges?: Maybe<Array<Maybe<LiveLikeReactionPackEdge>>>;
  page: LiveLikePage;
};

export type LiveLikeReactionPackEdge = LiveLikeEdge & {
  __typename?: 'LiveLikeReactionPackEdge';
  cursor?: Maybe<Scalars['String']['output']>;
  node: LiveLikeReactionPack;
};

export type LiveLikeReactionPacksGetInput = {
  clientId: Scalars['NonEmptyString']['input'];
  page?: InputMaybe<Scalars['PositiveInt']['input']>;
};

export type LiveLikeReactionSpace = LiveLikeNode & {
  __typename?: 'LiveLikeReactionSpace';
  clientId: Scalars['NonEmptyString']['output'];
  createdBy: Scalars['UUID']['output'];
  id: Scalars['UUID']['output'];
  name?: Maybe<Scalars['NonEmptyString']['output']>;
  reactionPackIds?: Maybe<Array<Scalars['UUID']['output']>>;
  reactionSpaceChannel?: Maybe<Scalars['NonEmptyString']['output']>;
  targetGroupId: Scalars['NonEmptyString']['output'];
};

export type LiveLikeReactionSpaceCollection = LiveLikeConnection & {
  __typename?: 'LiveLikeReactionSpaceCollection';
  edges?: Maybe<Array<Maybe<LiveLikeReactionSpaceEdge>>>;
  page: LiveLikePage;
};

export type LiveLikeReactionSpaceCount = {
  __typename?: 'LiveLikeReactionSpaceCount';
  emojiCounts?: Maybe<Array<LiveLikeEmojiCount>>;
  reactionSpaceId: Scalars['UUID']['output'];
  reactionsCount: Scalars['NonNegativeInt']['output'];
  targetGroupId: Scalars['NonEmptyString']['output'];
};

export type LiveLikeReactionSpaceCreateInput = {
  clientId: Scalars['NonEmptyString']['input'];
  name?: InputMaybe<Scalars['NonEmptyString']['input']>;
  reactionPackIds?: InputMaybe<Array<Scalars['UUID']['input']>>;
  targetGroupId: Scalars['NonEmptyString']['input'];
};

export type LiveLikeReactionSpaceDeleteInput = {
  clientId: Scalars['NonEmptyString']['input'];
  id: Scalars['UUID']['input'];
};

export type LiveLikeReactionSpaceEdge = LiveLikeEdge & {
  __typename?: 'LiveLikeReactionSpaceEdge';
  cursor?: Maybe<Scalars['String']['output']>;
  node: LiveLikeReactionSpace;
};

export type LiveLikeReactionSpaceGetInput = {
  clientId: Scalars['NonEmptyString']['input'];
  page?: InputMaybe<Scalars['PositiveInt']['input']>;
  reactionSpaceId?: InputMaybe<Scalars['UUID']['input']>;
  targetGroupId?: InputMaybe<Scalars['NonEmptyString']['input']>;
};

export type LiveLikeReactionSpacePatch = {
  __typename?: 'LiveLikeReactionSpacePatch';
  name?: Maybe<Scalars['NonEmptyString']['output']>;
  reactionPackIds: Array<Scalars['UUID']['output']>;
};

export type LiveLikeReactionSpaceUpdateInput = {
  id: Scalars['UUID']['input'];
  name?: InputMaybe<Scalars['NonEmptyString']['input']>;
  reactionPackIds: Array<Scalars['UUID']['input']>;
};

export type LiveLikeReactionSpacesCountInput = {
  clientId: Scalars['NonEmptyString']['input'];
  reactionSpaceIds: Array<Scalars['UUID']['input']>;
};

export type LiveLikeReactions = {
  __typename?: 'LiveLikeReactions';
  reactions?: Maybe<Array<LiveLikeReaction>>;
  targetId: Scalars['NonEmptyString']['output'];
};

export type LiveLikeResource = LiveLikeNode & {
  __typename?: 'LiveLikeResource';
  createdAt: Scalars['DateTimeISO']['output'];
  description: Scalars['NonEmptyString']['output'];
  id: Scalars['UUID']['output'];
  kind: LiveLikeResourceKindEnum;
  name: Scalars['NonEmptyString']['output'];
};

export enum LiveLikeResourceKindEnum {
  Alert = 'ALERT',
  Application = 'APPLICATION',
  ChatRoom = 'CHAT_ROOM',
  CheerMeter = 'CHEER_METER',
  CommentBoard = 'COMMENT_BOARD',
  EmojiPoll = 'EMOJI_POLL',
  EmojiSlider = 'EMOJI_SLIDER',
  ImageNumberPrediction = 'IMAGE_NUMBER_PREDICTION',
  ImageNumberPredictionFollowUp = 'IMAGE_NUMBER_PREDICTION_FOLLOW_UP',
  ImagePoll = 'IMAGE_POLL',
  ImagePrediction = 'IMAGE_PREDICTION',
  ImagePredictionFollowUp = 'IMAGE_PREDICTION_FOLLOW_UP',
  ImageQuiz = 'IMAGE_QUIZ',
  Profile = 'PROFILE',
  Program = 'PROGRAM',
  RichPost = 'RICH_POST',
  SocialEmbed = 'SOCIAL_EMBED',
  TextAsk = 'TEXT_ASK',
  TextPoll = 'TEXT_POLL',
  TextPrediction = 'TEXT_PREDICTION',
  TextPredictionFollowUp = 'TEXT_PREDICTION_FOLLOW_UP',
  TextQuiz = 'TEXT_QUIZ',
  TwitterSpotlight = 'TWITTER_SPOTLIGHT',
  VideoAlert = 'VIDEO_ALERT'
}

/** Represents a reward earned by a user for performing a specific action. */
export type LiveLikeReward = {
  __typename?: 'LiveLikeReward';
  /** The action for which this reward is given. */
  rewardAction: LiveLikeRewardActionEnum;
  /** The amount or value associated with the reward item. */
  rewardItemAmount: Scalars['NonNegativeInt']['output'];
  /** Unique identifier of the reward item. */
  rewardItemId: Scalars['UUID']['output'];
  /** The name or label of the reward item. */
  rewardItemName: Scalars['NonEmptyString']['output'];
};

export type LiveLikeRewardATableActionChoice = {
  __typename?: 'LiveLikeRewardATableActionChoice';
  action: Scalars['String']['output'];
  actionDisplay: Scalars['NonEmptyString']['output'];
};

export type LiveLikeRewardAction = LiveLikeNode & {
  __typename?: 'LiveLikeRewardAction';
  attributes?: Maybe<Array<LiveLikeKeyValuePair>>;
  clientId: Scalars['NonEmptyString']['output'];
  code?: Maybe<Scalars['NonEmptyString']['output']>;
  createdAt: Scalars['NonEmptyString']['output'];
  id: Scalars['UUID']['output'];
  profileId: Scalars['UUID']['output'];
  profileNickname: Scalars['NonEmptyString']['output'];
  programId: Scalars['UUID']['output'];
  rewardActionKey: Scalars['NonEmptyString']['output'];
  rewards?: Maybe<Array<LiveLikeRewardActionItem>>;
};

export type LiveLikeRewardActionCreateInput = {
  code?: InputMaybe<Scalars['NonEmptyString']['input']>;
  profileId: Scalars['UUID']['input'];
  programId: Scalars['UUID']['input'];
  rewardActionKey: Scalars['NonEmptyString']['input'];
};

export enum LiveLikeRewardActionEnum {
  AskReplied = 'ASK_REPLIED',
  PollVoted = 'POLL_VOTED',
  PredictionCorrect = 'PREDICTION_CORRECT',
  PredictionMade = 'PREDICTION_MADE',
  QuizAnswered = 'QUIZ_ANSWERED',
  QuizCorrect = 'QUIZ_CORRECT'
}

export type LiveLikeRewardActionItem = LiveLikeNode & {
  __typename?: 'LiveLikeRewardActionItem';
  amount: Scalars['NonNegativeInt']['output'];
  id: Scalars['UUID']['output'];
  name: Scalars['NonEmptyString']['output'];
};

export type LiveLikeRewardBalanceGetInput = {
  rewardItemId: Scalars['UUID']['input'];
};

export type LiveLikeRewardBalancesGetInput = {
  rewardItemIds: Array<Scalars['UUID']['input']>;
};

export type LiveLikeRewardItem = LiveLikeNode & {
  __typename?: 'LiveLikeRewardItem';
  attributes?: Maybe<Array<LiveLikeKeyValuePair>>;
  clientId?: Maybe<Scalars['NonEmptyString']['output']>;
  id: Scalars['UUID']['output'];
  images?: Maybe<Array<LiveLikeRewardItemImage>>;
  name: Scalars['NonEmptyString']['output'];
  prizeoutConversionRate?: Maybe<Scalars['NonNegativeInt']['output']>;
  prizeoutPoints?: Maybe<Scalars['NonNegativeInt']['output']>;
  prizeoutStatus?: Maybe<Scalars['Boolean']['output']>;
  rewardItemPoints?: Maybe<Scalars['NonNegativeInt']['output']>;
};

export type LiveLikeRewardItemBalance = {
  __typename?: 'LiveLikeRewardItemBalance';
  profileId: Scalars['UUID']['output'];
  rewardItemBalance: Scalars['NonNegativeInt']['output'];
  rewardItemId: Scalars['UUID']['output'];
  rewardItemName: Scalars['NonEmptyString']['output'];
};

export type LiveLikeRewardItemBalanceCollection = {
  __typename?: 'LiveLikeRewardItemBalanceCollection';
  edges?: Maybe<Array<LiveLikeRewardItemBalanceEdge>>;
  page: LiveLikePage;
};

export type LiveLikeRewardItemBalanceEdge = {
  __typename?: 'LiveLikeRewardItemBalanceEdge';
  cursor?: Maybe<Scalars['String']['output']>;
  node: LiveLikeRewardItemBalance;
};

export type LiveLikeRewardItemCollection = LiveLikeConnection & {
  __typename?: 'LiveLikeRewardItemCollection';
  edges?: Maybe<Array<LiveLikeRewardItemEdge>>;
  page: LiveLikePage;
};

export type LiveLikeRewardItemCreateInput = {
  attributes?: InputMaybe<Array<LiveLikeKeyValuePairInput>>;
  clientId: Scalars['NonEmptyString']['input'];
  name: Scalars['NonEmptyString']['input'];
};

export type LiveLikeRewardItemEdge = LiveLikeEdge & {
  __typename?: 'LiveLikeRewardItemEdge';
  cursor?: Maybe<Scalars['String']['output']>;
  node: LiveLikeRewardItem;
};

export type LiveLikeRewardItemImage = LiveLikeNode & {
  __typename?: 'LiveLikeRewardItemImage';
  id: Scalars['UUID']['output'];
  imageUrl: Scalars['URL']['output'];
  mimeType?: Maybe<Scalars['String']['output']>;
  name?: Maybe<Scalars['String']['output']>;
};

/** Represents a transaction made on a RewardItem, such as credits or debits applied to a user's reward item balance. */
export type LiveLikeRewardItemTransaction = LiveLikeNode & {
  __typename?: 'LiveLikeRewardItemTransaction';
  /** Additional attributes stored as key-value pairs. */
  attributes?: Maybe<Array<LiveLikeKeyValuePair>>;
  /** Timestamp when the transaction was created, in ISO 8601 format. */
  createdAt: Scalars['NonEmptyString']['output'];
  /** Optional custom metadata for the reward item transaction. */
  customData?: Maybe<Scalars['NonEmptyString']['output']>;
  /** Optional description for the reward item transaction. */
  description?: Maybe<Scalars['NonEmptyString']['output']>;
  /** Unique identifier of the reward item transaction */
  id: Scalars['UUID']['output'];
  /** The new balance of the reward item transaction */
  newBalance: Scalars['NonNegativeInt']['output'];
  /** The user's prizeout balance of reward item */
  prizeoutBalance?: Maybe<Scalars['NonNegativeInt']['output']>;
  /** The reason of transaction  */
  reason: Scalars['NonEmptyString']['output'];
  /** UUID of the user that performed this transaction. */
  transactedById: Scalars['UUID']['output'];
  /** Nickname or label of the user who performed this transaction */
  transactedByNickname: Scalars['NonEmptyString']['output'];
};

/** Input type for crediting or debiting a RewardItem. */
export type LiveLikeRewardItemTransactionInput = {
  /** Optional additional attributes as key-value pairs */
  attributes?: InputMaybe<Array<LiveLikeKeyValuePairInput>>;
  /** Optional custom metadata related to the transaction, in string format */
  customData?: InputMaybe<Scalars['NonEmptyString']['input']>;
  /** Optional description providing the context of the transaction */
  description?: InputMaybe<Scalars['NonEmptyString']['input']>;
  /** ID of the profile associated with the transaction */
  profileId: Scalars['UUID']['input'];
  /** Optional reason for the transaction */
  reason?: InputMaybe<Scalars['NonEmptyString']['input']>;
  /** Amount to credit or debit. Must be a positive integer. */
  rewardItemAmount: Scalars['PositiveInt']['input'];
  /** ID of the reward item being credited or debited */
  rewardItemId: Scalars['UUID']['input'];
};

export type LiveLikeRewardTable = LiveLikeNode & {
  __typename?: 'LiveLikeRewardTable';
  actionChoices: Array<LiveLikeRewardATableActionChoice>;
  clientId: Scalars['NonEmptyString']['output'];
  entries: Array<LiveLikeRewardTableEntry>;
  id: Scalars['UUID']['output'];
  name: Scalars['NonEmptyString']['output'];
};

export type LiveLikeRewardTableCollection = LiveLikeConnection & {
  __typename?: 'LiveLikeRewardTableCollection';
  edges?: Maybe<Array<LiveLikeRewardTableEdge>>;
  page: LiveLikePage;
};

export type LiveLikeRewardTableCreateInput = {
  clientId: Scalars['NonEmptyString']['input'];
  entries: Array<LiveLikeRewardTableEntryInput>;
  name: Scalars['NonEmptyString']['input'];
};

export type LiveLikeRewardTableEdge = LiveLikeEdge & {
  __typename?: 'LiveLikeRewardTableEdge';
  cursor?: Maybe<Scalars['String']['output']>;
  node: LiveLikeRewardTable;
};

export type LiveLikeRewardTableEntry = {
  __typename?: 'LiveLikeRewardTableEntry';
  action: Scalars['NonEmptyString']['output'];
  actionDisplay: Scalars['NonEmptyString']['output'];
  id: Scalars['UUID']['output'];
  rewardItem: LiveLikeRewardItem;
  rewardItemAmount: Scalars['PositiveInt']['output'];
};

export type LiveLikeRewardTableEntryCreateInput = {
  action: Scalars['NonEmptyString']['input'];
  rewardItemAmount: Scalars['PositiveInt']['input'];
  rewardItemId: Scalars['UUID']['input'];
  rewardTableId: Scalars['UUID']['input'];
};

export type LiveLikeRewardTableEntryDeleteInput = {
  entryId: Scalars['UUID']['input'];
  id: Scalars['UUID']['input'];
};

export type LiveLikeRewardTableEntryGetInput = {
  entryId: Scalars['UUID']['input'];
  id: Scalars['UUID']['input'];
};

export type LiveLikeRewardTableEntryInput = {
  action: Scalars['NonEmptyString']['input'];
  rewardItemAmount: Scalars['PositiveInt']['input'];
  rewardItemId: Scalars['UUID']['input'];
};

export type LiveLikeRewardTableUpdateInput = {
  entries?: InputMaybe<Array<LiveLikeRewardTableEntryInput>>;
  id: Scalars['UUID']['input'];
  name?: InputMaybe<Scalars['NonEmptyString']['input']>;
};

export type LiveLikeRewardTablesGetInput = {
  clientId: Scalars['NonEmptyString']['input'];
  page?: InputMaybe<Scalars['PositiveInt']['input']>;
};

export type LiveLikeRichPost = LiveLikeNode & LiveLikeWidgetBase & {
  __typename?: 'LiveLikeRichPost';
  clientId: Scalars['NonEmptyString']['output'];
  /** HTML content of the post */
  content?: Maybe<Scalars['String']['output']>;
  contentFilter?: Maybe<Array<Scalars['String']['output']>>;
  createdAt: Scalars['DateTimeISO']['output'];
  createdBy: LiveLikeWidgetCreator;
  customData?: Maybe<Scalars['String']['output']>;
  filteredContent?: Maybe<Scalars['String']['output']>;
  filteredTitle?: Maybe<Scalars['String']['output']>;
  id: Scalars['UUID']['output'];
  /** The ISO8601 Date that the widget will stop accepting interactions */
  interactiveUntil?: Maybe<Scalars['DateTimeISO']['output']>;
  kind: LiveLikeWidgetKindEnum;
  /** Video playback time in milliseconds */
  playbackTimeMs?: Maybe<Scalars['NonNegativeInt']['output']>;
  /** Program-scheduled datetime when the widget is expected to appear (if applicable). */
  programDateTime?: Maybe<Scalars['DateTimeISO']['output']>;
  /** Rich Post related program id */
  programId: Scalars['UUID']['output'];
  /** Delay (ISO8601) before the widget is published after scheduling (if applicable). */
  publishDelay: Scalars['Duration']['output'];
  publishedAt?: Maybe<Scalars['DateTimeISO']['output']>;
  /** Whether pubnub is enabled (if applicable). */
  pubnubEnabled: Scalars['Boolean']['output'];
  /** Report count information */
  reportCount?: Maybe<LiveLikeWidgetReportCount>;
  scheduledAt?: Maybe<Scalars['DateTimeISO']['output']>;
  /** List the sponsors ids with this RichPost. */
  sponsorIds?: Maybe<Array<Scalars['UUID']['output']>>;
  status: LiveLikeWidgetStatusEnum;
  timeout: Scalars['Duration']['output'];
  /** Title of the post */
  title?: Maybe<Scalars['String']['output']>;
  uniqueImpressionCount?: Maybe<Scalars['NonNegativeInt']['output']>;
  /** An array of key value pairs used for custom behaviors */
  widgetAttributes?: Maybe<Array<LiveLikeKeyValuePair>>;
};

export type LiveLikeRichPostCreateInput = {
  /** HTML content of the post */
  content: Scalars['NonEmptyString']['input'];
  /** A free-form field used for custom behaviors */
  customData?: InputMaybe<Scalars['String']['input']>;
  /** The ISO8601 Date that the widget will stop accepting interactions */
  interactiveUntil?: InputMaybe<Scalars['DateTimeISO']['input']>;
  /** RichPost localized data */
  localizedData?: InputMaybe<Array<LiveLikeRichPostLocalizedInput>>;
  /** Video playback time in milliseconds */
  playbackTimeMs?: InputMaybe<Scalars['NonNegativeInt']['input']>;
  /** The program to create the rich post inside of */
  programId: Scalars['UUID']['input'];
  /** Links the sponsors with this Text Poll. Note that only valid sponsor_ids will be linked to a Text Poll. */
  sponsorIds?: InputMaybe<Array<Scalars['UUID']['input']>>;
  /** A iso8601 duration hint for when a Widget should be timed out */
  timeout?: InputMaybe<Scalars['Duration']['input']>;
  /** Title of the post */
  title?: InputMaybe<Scalars['NonEmptyString']['input']>;
  /** An array of key value pairs used for custom behaviors */
  widgetAttributes?: InputMaybe<Array<LiveLikeKeyValuePairInput>>;
};

export type LiveLikeRichPostLocalizedInput = {
  /** HTML content of the post */
  content: Scalars['NonEmptyString']['input'];
  /** Localized language a string that conforms to the BCP-47  (RFC 5646 ) standard. */
  language: Scalars['Locale']['input'];
  /** Title of the post */
  title?: InputMaybe<Scalars['NonEmptyString']['input']>;
};

export type LiveLikeRole = LiveLikeNode & {
  __typename?: 'LiveLikeRole';
  clientId: Scalars['NonEmptyString']['output'];
  createdAt: Scalars['DateTimeISO']['output'];
  description: Scalars['String']['output'];
  id: Scalars['UUID']['output'];
  isActive: Scalars['Boolean']['output'];
  key: Scalars['NonEmptyString']['output'];
  name: Scalars['NonEmptyString']['output'];
  permissions: Array<LiveLikePermission>;
};

export type LiveLikeRoleAssignment = LiveLikeNode & {
  __typename?: 'LiveLikeRoleAssignment';
  createdAt: Scalars['DateTimeISO']['output'];
  id: Scalars['UUID']['output'];
  profile?: Maybe<LiveLikeProfile>;
  role?: Maybe<LiveLikeRole>;
  scope?: Maybe<LiveLikeScope>;
};

export type LiveLikeRoleAssignmentConnection = LiveLikeConnection & {
  __typename?: 'LiveLikeRoleAssignmentConnection';
  edges?: Maybe<Array<LiveLikeRoleAssignmentEdge>>;
  page: LiveLikePage;
};

export type LiveLikeRoleAssignmentCreateInput = {
  /** id of the profile to assign the role to */
  profileId: Scalars['UUID']['input'];
  /** key of the scope to assign the role to */
  resourceKey: Scalars['NonEmptyString']['input'];
  /** kind of the scope to assign the role to */
  resourceKind: LiveLikeResourceKindEnum;
  /** key of the role to assign to the profile */
  roleKey: Scalars['NonEmptyString']['input'];
};

export type LiveLikeRoleAssignmentEdge = LiveLikeEdge & {
  __typename?: 'LiveLikeRoleAssignmentEdge';
  cursor?: Maybe<Scalars['String']['output']>;
  node: LiveLikeRoleAssignment;
};

export type LiveLikeRoleAssignmentsGetInput = {
  page?: InputMaybe<Scalars['PositiveInt']['input']>;
  profileCustomId?: InputMaybe<Scalars['NonEmptyString']['input']>;
  profileId?: InputMaybe<Scalars['NonEmptyString']['input']>;
};

export type LiveLikeRoleConnection = LiveLikeConnection & {
  __typename?: 'LiveLikeRoleConnection';
  edges?: Maybe<Array<LiveLikeRoleEdge>>;
  page: LiveLikePage;
};

export type LiveLikeRoleCreateInput = {
  /** key of the role to be created */
  key: Scalars['NonEmptyString']['input'];
  /** name of the role to be created */
  name: Scalars['NonEmptyString']['input'];
  /** Array of permissionIds to add to the role */
  permissionIds?: InputMaybe<Array<Scalars['UUID']['input']>>;
  /** Array of permissionKeys to add to the role */
  permissionKeys?: InputMaybe<Array<Scalars['NonEmptyString']['input']>>;
  /** key of the role template to add permissions from */
  roleTemplateKey?: InputMaybe<Scalars['NonEmptyString']['input']>;
};

export type LiveLikeRoleEdge = LiveLikeEdge & {
  __typename?: 'LiveLikeRoleEdge';
  cursor?: Maybe<Scalars['String']['output']>;
  node: LiveLikeRole;
};

export type LiveLikeRolesGetInput = {
  clientId: Scalars['NonEmptyString']['input'];
  page?: InputMaybe<Scalars['PositiveInt']['input']>;
};

export type LiveLikeScope = LiveLikeNode & {
  __typename?: 'LiveLikeScope';
  clientId: Scalars['NonEmptyString']['output'];
  createdAt: Scalars['DateTimeISO']['output'];
  id: Scalars['UUID']['output'];
  resource: LiveLikeResource;
  resourceKey: Scalars['NonEmptyString']['output'];
};

export type LiveLikeSocialEmbed = LiveLikeNode & LiveLikeWidgetBase & {
  __typename?: 'LiveLikeSocialEmbed';
  /** Client identifier associated with this widget */
  clientId: Scalars['NonEmptyString']['output'];
  /** comment of the social embed widget */
  comment?: Maybe<Scalars['NonEmptyString']['output']>;
  /** Timestamp when the widget was created */
  createdAt: Scalars['DateTimeISO']['output'];
  /** Information about the user that created the widget */
  createdBy: LiveLikeWidgetCreator;
  /** Optional custom metadata for the widget */
  customData?: Maybe<Scalars['String']['output']>;
  /** Unique identifier of the widget */
  id: Scalars['UUID']['output'];
  /** ISO8601 DateTime when the widget stops accepting interactions */
  interactiveUntil?: Maybe<Scalars['DateTimeISO']['output']>;
  /** Kind of widget */
  kind: LiveLikeWidgetKindEnum;
  /** social oEmbed item */
  oEmbedItem?: Maybe<LiveLikeSocialEmbedItem>;
  /** Video playback time at which the widget appears, in milliseconds */
  playbackTimeMs?: Maybe<Scalars['NonNegativeInt']['output']>;
  /** Program-scheduled datetime when the widget is expected to appear */
  programDateTime?: Maybe<Scalars['DateTimeISO']['output']>;
  /** Program identifier associated with this widget */
  programId: Scalars['UUID']['output'];
  /** Delay (ISO8601) before the widget is published after scheduling */
  publishDelay: Scalars['Duration']['output'];
  /** Datetime when the widget was actually published */
  publishedAt?: Maybe<Scalars['DateTimeISO']['output']>;
  /** Whether pubnub is enabled. */
  pubnubEnabled: Scalars['Boolean']['output'];
  /** Contains count-based metrics such as interactions */
  reportCount?: Maybe<LiveLikeWidgetReportCount>;
  /** Scheduled datetime for the widget */
  scheduledAt?: Maybe<Scalars['DateTimeISO']['output']>;
  /** List of sponsor IDs associated with this widget */
  sponsorIds?: Maybe<Array<Scalars['UUID']['output']>>;
  /** Current status of the widget (e.g.,  PENDING, SCHEDULED, PUBLISHED, INFLIGHT etc). */
  status: LiveLikeWidgetStatusEnum;
  /** Duration (ISO8601) for which the widget remains interactive */
  timeout: Scalars['Duration']['output'];
  /** Total number of unique users who interacted with the widget */
  uniqueImpressionCount?: Maybe<Scalars['NonNegativeInt']['output']>;
  /** Additional widget attributes in key-value format */
  widgetAttributes?: Maybe<Array<LiveLikeKeyValuePair>>;
};

export type LiveLikeSocialEmbedCreateInput = {
  /** comment of the social embed widget */
  comment?: InputMaybe<Scalars['NonEmptyString']['input']>;
  /** free-form field used for custom behaviors */
  customData?: InputMaybe<Scalars['String']['input']>;
  /** ISO8601 DateTime that the widget will stop accepting interactions */
  interactiveUntil?: InputMaybe<Scalars['DateTimeISO']['input']>;
  /** Social embed localized data */
  localizedData?: InputMaybe<Array<LiveLikeSocialEmbedLocalizedInput>>;
  /** oEmbed url of social embed item https://oembed.com/ */
  oEmbedUrl: Scalars['URL']['input'];
  /** Video playback time in milliseconds */
  playbackTimeMs?: InputMaybe<Scalars['NonNegativeInt']['input']>;
  /** ID of the program to create the widget */
  programId: Scalars['UUID']['input'];
  /**
   * Links the sponsors with this widget.
   * Note only valid sponsor ids will be linked to widget.
   */
  sponsorIds?: InputMaybe<Array<Scalars['UUID']['input']>>;
  /** ISO8601 duration hint for when a widget should be timed out */
  timeout?: InputMaybe<Scalars['Duration']['input']>;
  /** An array of key value pairs used for custom behaviors */
  widgetAttributes?: InputMaybe<Array<LiveLikeKeyValuePairInput>>;
};

export type LiveLikeSocialEmbedItem = LiveLikeNode & {
  __typename?: 'LiveLikeSocialEmbedItem';
  /** Unique identifier of the social embed item */
  id: Scalars['UUID']['output'];
  /** oEmbed meta of social embed item https://oembed.com/ */
  oEmbedMeta?: Maybe<Scalars['JSONObject']['output']>;
  /** oEmbed url of social embed item https://oembed.com/ */
  oEmbedUrl?: Maybe<Scalars['URL']['output']>;
};

export type LiveLikeSocialEmbedLocalizedInput = {
  /** comment of the social embed widget */
  comment: Scalars['NonEmptyString']['input'];
  /** Localized language a string that conforms to the BCP-47 (RFC 5646) standard  */
  language: Scalars['Locale']['input'];
};

export type LiveLikeTextPoll = LiveLikeNode & LiveLikeWidgetBase & {
  __typename?: 'LiveLikeTextPoll';
  clientId: Scalars['NonEmptyString']['output'];
  contentFilter?: Maybe<Array<Scalars['String']['output']>>;
  createdAt: Scalars['DateTimeISO']['output'];
  createdBy: LiveLikeWidgetCreator;
  customData?: Maybe<Scalars['String']['output']>;
  filteredQuestion?: Maybe<Scalars['String']['output']>;
  id: Scalars['UUID']['output'];
  /** The ISO8601 Date that the widget will stop accepting interactions */
  interactiveUntil?: Maybe<Scalars['DateTimeISO']['output']>;
  kind: LiveLikeWidgetKindEnum;
  /** List of options for this prediction */
  options: Array<LiveLikeTextPollOption>;
  /** Video playback time in milliseconds */
  playbackTimeMs?: Maybe<Scalars['NonNegativeInt']['output']>;
  /** Program-scheduled datetime when the widget is expected to appear (if applicable). */
  programDateTime?: Maybe<Scalars['DateTimeISO']['output']>;
  programId: Scalars['UUID']['output'];
  /** Delay (ISO8601) before the widget is published after scheduling (if applicable). */
  publishDelay: Scalars['Duration']['output'];
  publishedAt?: Maybe<Scalars['DateTimeISO']['output']>;
  pubnubEnabled: Scalars['Boolean']['output'];
  /** The prompt or question for the prediction to be made */
  question: Scalars['NonEmptyString']['output'];
  /** Report count information */
  reportCount?: Maybe<LiveLikeWidgetReportCount>;
  scheduledAt?: Maybe<Scalars['DateTimeISO']['output']>;
  /** List the sponsors ids with this Text Poll. */
  sponsorIds?: Maybe<Array<Scalars['UUID']['output']>>;
  status: LiveLikeWidgetStatusEnum;
  timeout: Scalars['Duration']['output'];
  uniqueImpressionCount?: Maybe<Scalars['NonNegativeInt']['output']>;
  /** @deprecated Introduces cyclic dependency and TextPoll cache issue */
  userVote?: Maybe<LiveLikeWidgetInteraction>;
  /** An array of key value pairs used for custom behaviors */
  widgetAttributes?: Maybe<Array<LiveLikeKeyValuePair>>;
};

export type LiveLikeTextPollCreateInput = {
  /** A free-form field used for custom behaviors */
  customData?: InputMaybe<Scalars['String']['input']>;
  /** The ISO8601 DateTime that the widget will stop accepting interactions */
  interactiveUntil?: InputMaybe<Scalars['DateTimeISO']['input']>;
  /** TextPoll localized data */
  localizedData?: InputMaybe<Array<LiveLikeTextPollLocalizedInput>>;
  /** List of options for this prediction, min 2 and max 4 */
  options: Array<LiveLikeTextPollCreateOptionInput>;
  /** Video playback time in milliseconds */
  playbackTimeMs?: InputMaybe<Scalars['NonNegativeInt']['input']>;
  /** ID of the program to create the prediction for */
  programId: Scalars['UUID']['input'];
  /** The prompt or question for the prediction to be made */
  question: Scalars['NonEmptyString']['input'];
  /** Links the sponsors with this Text Poll. Note that only valid sponsor_ids will be linked to a Text Poll. */
  sponsorIds?: InputMaybe<Array<Scalars['UUID']['input']>>;
  /** A iso8601 duration hint for when a Widget should be timed out */
  timeout?: InputMaybe<Scalars['Duration']['input']>;
  /** An array of key value pairs used for custom behaviors */
  widgetAttributes?: InputMaybe<Array<LiveLikeKeyValuePairInput>>;
};

export type LiveLikeTextPollCreateOptionInput = {
  /** Description of a poll option */
  description: Scalars['NonEmptyString']['input'];
  /** TextPoll option localized data */
  localizedData?: InputMaybe<Array<LiveLikeTextPollOptionLocalizedInput>>;
};

export type LiveLikeTextPollLocalizedInput = {
  /** Localized language a string that conforms to the BCP-47 (RFC 5646) standard. */
  language: Scalars['Locale']['input'];
  /** The prompt or question for the prediction to be made */
  question: Scalars['NonEmptyString']['input'];
};

export type LiveLikeTextPollOption = LiveLikeNode & {
  __typename?: 'LiveLikeTextPollOption';
  contentFilter?: Maybe<Array<Scalars['String']['output']>>;
  description: Scalars['String']['output'];
  filteredDescription?: Maybe<Scalars['String']['output']>;
  id: Scalars['UUID']['output'];
  translatableFields?: Maybe<Array<Scalars['String']['output']>>;
  voteCount?: Maybe<Scalars['Int']['output']>;
};

export type LiveLikeTextPollOptionLocalizedInput = {
  /** Description of a poll option */
  description: Scalars['NonEmptyString']['input'];
  /** Localized language a string that conforms to the BCP-47 (RFC 5646) standard. */
  language: Scalars['Locale']['input'];
};

export type LiveLikeTextPollVote = LiveLikeWidgetInteractionBase & {
  __typename?: 'LiveLikeTextPollVote';
  createdAt: Scalars['String']['output'];
  id: Scalars['UUID']['output'];
  /** Leaderboard rewards associated with the text poll vote */
  leaderboardRewards?: Maybe<Array<LiveLikeLeaderboardReward>>;
  /** Vote option associated with the text poll vote */
  optionId: Scalars['UUID']['output'];
  /** ID of the profile associated with the text poll vote */
  profileId: Scalars['UUID']['output'];
  /** Rewards associated with the text poll vote */
  rewards?: Maybe<Array<LiveLikeReward>>;
  /** Text poll widget associated with the text poll vote */
  widget: LiveLikeTextPoll;
  /** ID of the widget associated with the text poll vote */
  widgetId: Scalars['UUID']['output'];
  widgetKind: LiveLikeWidgetInteractionEnum;
};

export type LiveLikeTextPollVoteCreateInput = {
  optionId: Scalars['UUID']['input'];
  widgetId: Scalars['UUID']['input'];
};

export type LiveLikeTextPollVoteUpdateInput = {
  id: Scalars['UUID']['input'];
  optionId: Scalars['UUID']['input'];
  widgetId: Scalars['UUID']['input'];
};

/** Represents an text prediction widget. */
export type LiveLikeTextPrediction = LiveLikeNode & LiveLikeWidgetBase & {
  __typename?: 'LiveLikeTextPrediction';
  /** Client identifier associated with this prediction. */
  clientId: Scalars['NonEmptyString']['output'];
  /** Optional confirmation message for the widget. */
  confirmationMessage?: Maybe<Scalars['String']['output']>;
  /** Timestamp when the widget was created. */
  createdAt: Scalars['DateTimeISO']['output'];
  /** Information about the user that created the widget. */
  createdBy: LiveLikeWidgetCreator;
  /** Optional custom metadata for the widget. */
  customData?: Maybe<Scalars['String']['output']>;
  /** List of all follow ups available for this prediction. */
  followUps: Array<LiveLikeTextPredictionFollowUp>;
  /** Unique identifier of the text prediction. */
  id: Scalars['UUID']['output'];
  /** The ISO8601 DateTime when the widget stops accepting interactions. */
  interactiveUntil?: Maybe<Scalars['DateTimeISO']['output']>;
  /** Kind of widget */
  kind: LiveLikeWidgetKindEnum;
  /** List of options available for this prediction. */
  options: Array<LiveLikeTextPredictionOption>;
  /** Video playback time at which the widget appears, in milliseconds. */
  playbackTimeMs?: Maybe<Scalars['NonNegativeInt']['output']>;
  /** Program-scheduled datetime when the prediction is expected to appear. */
  programDateTime?: Maybe<Scalars['DateTimeISO']['output']>;
  /** Program identifier associated with this prediction. */
  programId: Scalars['UUID']['output'];
  /** Delay (ISO8601) before the widget is published after scheduling. */
  publishDelay: Scalars['Duration']['output'];
  /** Datetime when the widget was actually published. */
  publishedAt?: Maybe<Scalars['DateTimeISO']['output']>;
  /** Whether pubnub is enabled. */
  pubnubEnabled: Scalars['Boolean']['output'];
  /** The question for the prediction to be made */
  question: Scalars['NonEmptyString']['output'];
  /** Contains count-based metrics such as interactions. */
  reportCount?: Maybe<LiveLikeWidgetReportCount>;
  /** Scheduled datetime for the widget. */
  scheduledAt?: Maybe<Scalars['DateTimeISO']['output']>;
  /** List of sponsor IDs associated with this Text Prediction. */
  sponsorIds?: Maybe<Array<Scalars['UUID']['output']>>;
  /** Current status of the widget (e.g.,  PENDING, SCHEDULED, PUBLISHED, INFLIGHT etc). */
  status: LiveLikeWidgetStatusEnum;
  /** Duration (ISO8601) for which the widget remains interactive. */
  timeout: Scalars['Duration']['output'];
  /** Total number of unique users who interacted with the widget. */
  uniqueImpressionCount?: Maybe<Scalars['NonNegativeInt']['output']>;
  /** Additional widget attributes in key-value format. */
  widgetAttributes?: Maybe<Array<LiveLikeKeyValuePair>>;
};

export type LiveLikeTextPredictionCreateInput = {
  /** Optional confirmation message for the widget. */
  confirmationMessage?: InputMaybe<Scalars['String']['input']>;
  /** A free-form field used for custom behaviors */
  customData?: InputMaybe<Scalars['NonEmptyString']['input']>;
  /** The ISO8601 DateTime that the widget will stop accepting interactions */
  interactiveUntil?: InputMaybe<Scalars['DateTimeISO']['input']>;
  /** TextPrediction localized data */
  localizedData?: InputMaybe<Array<LiveLikeTextPredictionLocalizedInput>>;
  /** List of options for this prediction, min 2 and max 4 */
  options: Array<LiveLikeTextPredictionCreateOptionInput>;
  /** Video playback time in milliseconds */
  playbackTimeMs?: InputMaybe<Scalars['NonNegativeInt']['input']>;
  /** ID of the program to create the prediction for */
  programId: Scalars['UUID']['input'];
  /** The prompt or question for the prediction to be made */
  question: Scalars['NonEmptyString']['input'];
  /** Links the sponsors with this Text Prediction. Note that only valid sponsor_ids will be linked to a Text Prediction. */
  sponsorIds?: InputMaybe<Array<Scalars['UUID']['input']>>;
  /** A iso8601 duration hint for when a Widget should be timed out */
  timeout?: InputMaybe<Scalars['Duration']['input']>;
  /** An array of key value pairs used for custom behaviors */
  widgetAttributes?: InputMaybe<Array<LiveLikeKeyValuePairInput>>;
};

/** Represents a option for a text prediction. */
export type LiveLikeTextPredictionCreateOptionInput = {
  /** Description of the prediction. */
  description: Scalars['NonEmptyString']['input'];
  /** Indicates whether this option is the correct option. */
  isCorrect?: InputMaybe<Scalars['Boolean']['input']>;
  /** TextPrediction option localized data */
  localizedData?: InputMaybe<Array<LiveLikeTextPredictionOptionLocalizedInput>>;
  /** Reward amount for the prediction option . */
  rewardItemAmount?: InputMaybe<Scalars['NonNegativeInt']['input']>;
  /** Unique identifier for the reward Item Id. */
  rewardItemId?: InputMaybe<Scalars['UUID']['input']>;
};

/** Represents an text prediction followup. */
export type LiveLikeTextPredictionFollowUp = LiveLikeNode & LiveLikeWidgetBase & {
  __typename?: 'LiveLikeTextPredictionFollowUp';
  /** Client identifier associated with this prediction followup. */
  clientId: Scalars['NonEmptyString']['output'];
  /** Optional Correct option id of the prediction. */
  correctOptionId?: Maybe<Scalars['UUID']['output']>;
  /** Timestamp when the widget was created. */
  createdAt: Scalars['DateTimeISO']['output'];
  /** Information about the user that created the widget. */
  createdBy: LiveLikeWidgetCreator;
  /** Optional custom metadata for the widget. */
  customData?: Maybe<Scalars['String']['output']>;
  /** Unique identifier of the text prediction followup. */
  id: Scalars['UUID']['output'];
  /** The ISO8601 DateTime when the widget stops accepting interactions. */
  interactiveUntil?: Maybe<Scalars['DateTimeISO']['output']>;
  /** Kind of widget */
  kind: LiveLikeWidgetKindEnum;
  /** List of options available for this prediction. */
  options: Array<LiveLikeTextPredictionOption>;
  /** Video playback time at which the widget appears, in milliseconds. */
  playbackTimeMs?: Maybe<Scalars['NonNegativeInt']['output']>;
  /** Program-scheduled datetime when the prediction is expected to appear. */
  programDateTime?: Maybe<Scalars['DateTimeISO']['output']>;
  /** Program identifier associated with this prediction. */
  programId: Scalars['UUID']['output'];
  /** Delay (ISO8601) before the widget is published after scheduling. */
  publishDelay: Scalars['Duration']['output'];
  /** Datetime when the widget was actually published. */
  publishedAt?: Maybe<Scalars['DateTimeISO']['output']>;
  /** Whether pubnub is enabled. */
  pubnubEnabled: Scalars['Boolean']['output'];
  /** The question for the prediction to be made */
  question: Scalars['NonEmptyString']['output'];
  /** Contains count-based metrics such as interactions. */
  reportCount?: Maybe<LiveLikeWidgetReportCount>;
  /** Scheduled datetime for the widget. */
  scheduledAt?: Maybe<Scalars['DateTimeISO']['output']>;
  /** List of sponsor IDs associated with this Text Prediction. */
  sponsorIds?: Maybe<Array<Scalars['UUID']['output']>>;
  /** Current status of the widget (e.g.,  PENDING, SCHEDULED, PUBLISHED, INFLIGHT etc). */
  status: LiveLikeWidgetStatusEnum;
  /** Text Prediction identifier associated with this prediction followup. */
  textPredictionId: Scalars['UUID']['output'];
  /** Duration (ISO8601) for which the widget remains interactive. */
  timeout: Scalars['Duration']['output'];
  /** Total number of unique users who interacted with the widget. */
  uniqueImpressionCount?: Maybe<Scalars['NonNegativeInt']['output']>;
  /** Additional widget attributes in key-value format. */
  widgetAttributes?: Maybe<Array<LiveLikeKeyValuePair>>;
};

export type LiveLikeTextPredictionFollowUpCreateInput = {
  /** ID of the correct text prediction option to create the followup prediction for */
  correctOptionId?: InputMaybe<Scalars['NonEmptyString']['input']>;
  /** Links the sponsors with this Text Prediction. Note that only valid sponsor_ids will be linked to a Text Prediction. */
  sponsorIds?: InputMaybe<Array<Scalars['UUID']['input']>>;
  /** ID of the text prediction to create the followup prediction for */
  textPredictionId: Scalars['UUID']['input'];
};

export type LiveLikeTextPredictionLocalizedInput = {
  /** Localized language a string that conforms to the BCP-47  (RFC 5646 ) standard. */
  language: Scalars['Locale']['input'];
  /** The prompt or question for the prediction to be made */
  question: Scalars['NonEmptyString']['input'];
};

/**  Represents a option in a text prediction. Includes correctness. */
export type LiveLikeTextPredictionOption = LiveLikeNode & {
  __typename?: 'LiveLikeTextPredictionOption';
  /** Description of the option. */
  description: Scalars['String']['output'];
  /** List of all earned rewards */
  earnableRewards?: Maybe<Array<LiveLikeReward>>;
  /** Unique identifier for the option. */
  id: Scalars['UUID']['output'];
  /** Indicates whether this option is the correct */
  isCorrect: Scalars['Boolean']['output'];
  /** Reward amount for the prediction option . */
  rewardItemAmount?: Maybe<Scalars['NonNegativeInt']['output']>;
  /** Unique identifier for the reward Item Id. */
  rewardItemId?: Maybe<Scalars['UUID']['output']>;
  /** List of fields in this object that support translation */
  translatableFields?: Maybe<Array<Scalars['String']['output']>>;
  /** Number of users who selected this option. */
  voteCount: Scalars['NonNegativeInt']['output'];
};

export type LiveLikeTextPredictionOptionLocalizedInput = {
  /** Description of the option */
  description: Scalars['NonEmptyString']['input'];
  /** Localized language a string that conforms to the BCP-47  (RFC 5646 ) standard. */
  language: Scalars['Locale']['input'];
};

export type LiveLikeTextPredictionVote = LiveLikeWidgetInteractionBase & {
  __typename?: 'LiveLikeTextPredictionVote';
  /** Claim token for the text prediction Vote */
  claimToken: Scalars['JWT']['output'];
  /** Timestamp when the widget was created. */
  createdAt: Scalars['String']['output'];
  /** Unique ID of the text prediction vote */
  id: Scalars['UUID']['output'];
  /** Leaderboard rewards associated with the text prediction vote */
  leaderboardRewards?: Maybe<Array<LiveLikeLeaderboardReward>>;
  /** Vote option associated with the text prediction vote */
  optionId: Scalars['UUID']['output'];
  /** ID of the profile associated with the text prediction vote */
  profileId: Scalars['UUID']['output'];
  /** List of rewards granted for this answer. */
  rewards?: Maybe<Array<LiveLikeReward>>;
  /** Text prediction widget associated with the text prediction vote */
  widget: LiveLikeTextPrediction;
  /** ID of the widget associated with the text prediction vote */
  widgetId: Scalars['UUID']['output'];
  /** Kind of the widget Interaction */
  widgetKind: LiveLikeWidgetInteractionEnum;
};

export type LiveLikeTextPredictionVoteCreateInput = {
  optionId: Scalars['UUID']['input'];
  widgetId: Scalars['UUID']['input'];
};

export type LiveLikeTextPredictionVoteUpdateInput = {
  id: Scalars['UUID']['input'];
  optionId: Scalars['UUID']['input'];
  widgetId: Scalars['UUID']['input'];
};

/** Represents an text quiz widget. */
export type LiveLikeTextQuiz = LiveLikeNode & LiveLikeWidgetBase & {
  __typename?: 'LiveLikeTextQuiz';
  /** List of choices available for this quiz. */
  choices: Array<LiveLikeTextQuizChoice>;
  /** Client identifier associated with this quiz. */
  clientId: Scalars['NonEmptyString']['output'];
  /** Timestamp when the widget was created. */
  createdAt: Scalars['DateTimeISO']['output'];
  /** Information about the user that created the widget. */
  createdBy: LiveLikeWidgetCreator;
  /** Optional custom metadata for the widget. */
  customData?: Maybe<Scalars['String']['output']>;
  /** Unique identifier of the text quiz. */
  id: Scalars['UUID']['output'];
  /** The ISO8601 DateTime when the widget stops accepting interactions. */
  interactiveUntil?: Maybe<Scalars['DateTimeISO']['output']>;
  /** Kind of widget */
  kind: LiveLikeWidgetKindEnum;
  /** Video playback time at which the widget appears, in milliseconds. */
  playbackTimeMs?: Maybe<Scalars['NonNegativeInt']['output']>;
  /** Program-scheduled datetime when the quiz is expected to appear. */
  programDateTime?: Maybe<Scalars['DateTimeISO']['output']>;
  /** Program identifier associated with this quiz. */
  programId: Scalars['UUID']['output'];
  /** Delay (ISO8601) before the widget is published after scheduling. */
  publishDelay: Scalars['Duration']['output'];
  /** Datetime when the widget was actually published. */
  publishedAt?: Maybe<Scalars['DateTimeISO']['output']>;
  /** Whether pubnub is enabled. */
  pubnubEnabled: Scalars['Boolean']['output'];
  /** The question for the quiz to be made */
  question: Scalars['NonEmptyString']['output'];
  /** Contains count-based metrics such as interactions. */
  reportCount?: Maybe<LiveLikeWidgetReportCount>;
  /** Scheduled datetime for the widget. */
  scheduledAt?: Maybe<Scalars['DateTimeISO']['output']>;
  /** List of sponsor IDs associated with this Text Quiz. */
  sponsorIds?: Maybe<Array<Scalars['UUID']['output']>>;
  /** Current status of the widget (e.g.,  PENDING, SCHEDULED, PUBLISHED, INFLIGHT etc). */
  status: LiveLikeWidgetStatusEnum;
  /** Duration (ISO8601) for which the widget remains interactive. */
  timeout: Scalars['Duration']['output'];
  /** Total number of unique users who interacted with the widget. */
  uniqueImpressionCount?: Maybe<Scalars['NonNegativeInt']['output']>;
  /** Additional widget attributes in key-value format. */
  widgetAttributes?: Maybe<Array<LiveLikeKeyValuePair>>;
};

export type LiveLikeTextQuizAnswer = LiveLikeWidgetInteractionBase & {
  __typename?: 'LiveLikeTextQuizAnswer';
  /** Identifier of the choice selected by the user. */
  choiceId: Scalars['UUID']['output'];
  /** Timestamp when the answer was created. */
  createdAt: Scalars['String']['output'];
  /** Unique identifier of the text quiz answer. */
  id: Scalars['UUID']['output'];
  /** List of leaderboard rewards associated with this answer. */
  leaderboardRewards?: Maybe<Array<LiveLikeLeaderboardReward>>;
  /** ID of the profile who submitted the answer. */
  profileId: Scalars['UUID']['output'];
  /** List of rewards granted for this answer. */
  rewards?: Maybe<Array<LiveLikeReward>>;
  /** The text quiz widget associated with this answer. */
  widget: LiveLikeTextQuiz;
  /** ID of the widget this answer belongs to. */
  widgetId: Scalars['UUID']['output'];
  /** Type of widget interaction. */
  widgetKind: LiveLikeWidgetInteractionEnum;
};

export type LiveLikeTextQuizAnswerCreateInput = {
  /** ID of the choice selected by the user. */
  choiceId: Scalars['UUID']['input'];
  /** ID of the widget instance for which the answer is submitted. */
  widgetId: Scalars['UUID']['input'];
};

export type LiveLikeTextQuizAnswerUpdateInput = {
  /** ID of the choice selected by the user. */
  choiceId: Scalars['UUID']['input'];
  /** ID of the text quiz answer to update. */
  id: Scalars['UUID']['input'];
  /** ID of the widget instance for which the answer is submitted. */
  widgetId: Scalars['UUID']['input'];
};

/**  Represents a choice in a text quiz. Includes correctness, user response count, and localization metadata. */
export type LiveLikeTextQuizChoice = LiveLikeNode & {
  __typename?: 'LiveLikeTextQuizChoice';
  /** Number of users who selected this choice. */
  answerCount: Scalars['NonNegativeInt']['output'];
  /** Description of the choice. */
  description: Scalars['String']['output'];
  /** Unique identifier for the choice. */
  id: Scalars['UUID']['output'];
  /** Indicates whether this choice is the correct answer */
  isCorrect: Scalars['Boolean']['output'];
  /** List of fields in this object that support translation */
  translatableFields?: Maybe<Array<Scalars['String']['output']>>;
};

export type LiveLikeTextQuizChoiceLocalizedInput = {
  /** Description of the choice */
  description: Scalars['NonEmptyString']['input'];
  /** Localized language a string that conforms to the BCP-47  (RFC 5646 ) standard. */
  language: Scalars['Locale']['input'];
};

/** Represents a choice option for a text quiz. */
export type LiveLikeTextQuizCreateChoiceInput = {
  /** Description of the choice. */
  description: Scalars['NonEmptyString']['input'];
  /** Indicates whether this choice is the correct answer. */
  isCorrect: Scalars['Boolean']['input'];
  /** TextQuiz choice localized data */
  localizedData?: InputMaybe<Array<LiveLikeTextQuizChoiceLocalizedInput>>;
};

export type LiveLikeTextQuizCreateInput = {
  /** List of choices for this prediction, min 2 and max 4 */
  choices: Array<LiveLikeTextQuizCreateChoiceInput>;
  /** A free-form field used for custom behaviors */
  customData?: InputMaybe<Scalars['NonEmptyString']['input']>;
  /** The ISO8601 DateTime that the widget will stop accepting interactions */
  interactiveUntil?: InputMaybe<Scalars['DateTimeISO']['input']>;
  /** TextQuiz localized data */
  localizedData?: InputMaybe<Array<LiveLikeTextQuizLocalizedInput>>;
  /** Video playback time in milliseconds */
  playbackTimeMs?: InputMaybe<Scalars['NonNegativeInt']['input']>;
  /** ID of the program to create the prediction for */
  programId: Scalars['UUID']['input'];
  /** The prompt or question for the prediction to be made */
  question: Scalars['NonEmptyString']['input'];
  /** Links the sponsors with this Text Quiz. Note that only valid sponsor_ids will be linked to a Text Quiz. */
  sponsorIds?: InputMaybe<Array<Scalars['UUID']['input']>>;
  /** A iso8601 duration hint for when a Widget should be timed out */
  timeout?: InputMaybe<Scalars['Duration']['input']>;
  /** An array of key value pairs used for custom behaviors */
  widgetAttributes?: InputMaybe<Array<LiveLikeKeyValuePairInput>>;
};

export type LiveLikeTextQuizLocalizedInput = {
  /** Localized language a string that conforms to the BCP-47  (RFC 5646 ) standard. */
  language: Scalars['Locale']['input'];
  /** The prompt or question for the prediction to be made */
  question: Scalars['NonEmptyString']['input'];
};

export type LiveLikeTokenGate = {
  __typename?: 'LiveLikeTokenGate';
  attributes?: Maybe<Array<LiveLikeTokenGateAttribute>>;
  contractAddress: Scalars['NonEmptyString']['output'];
  networkType: LiveLikeTokenGateNetworkTypeEnum;
  tokenType: LiveLikeTokenGateTokenTypeEnum;
};

export type LiveLikeTokenGateAttribute = {
  __typename?: 'LiveLikeTokenGateAttribute';
  trainType: Scalars['NonEmptyString']['output'];
  value: Scalars['NonEmptyString']['output'];
};

export type LiveLikeTokenGateAttributesInput = {
  trainType: Scalars['NonEmptyString']['input'];
  value: Scalars['NonEmptyString']['input'];
};

export type LiveLikeTokenGateInput = {
  attributes?: InputMaybe<Array<LiveLikeTokenGateAttributesInput>>;
  contractAddress: Scalars['NonEmptyString']['input'];
  networkType: LiveLikeTokenGateNetworkTypeEnum;
  tokenType: LiveLikeTokenGateTokenTypeEnum;
};

export enum LiveLikeTokenGateNetworkTypeEnum {
  Chiliz = 'CHILIZ',
  Ethereum = 'ETHEREUM',
  Hedera = 'HEDERA',
  Polygon = 'POLYGON'
}

export enum LiveLikeTokenGateTokenTypeEnum {
  Fungible = 'FUNGIBLE',
  NonFungible = 'NON_FUNGIBLE'
}

export type LiveLikeUnlinkRewardTableWithProgramInput = {
  programId: Scalars['UUID']['input'];
  rewardTableId: Scalars['UUID']['input'];
};

export type LiveLikeUserBadge = LiveLikeNode & {
  __typename?: 'LiveLikeUserBadge';
  awardedAt: Scalars['DateTimeISO']['output'];
  badge: LiveLikeBadge;
  badgeId: Scalars['UUID']['output'];
  id: Scalars['UUID']['output'];
  profile: LiveLikeProfile;
};

export type LiveLikeUserBadgeCollection = {
  __typename?: 'LiveLikeUserBadgeCollection';
  edges?: Maybe<Array<LiveLikeUserBadgeEdge>>;
  page: LiveLikePage;
};

export type LiveLikeUserBadgeEdge = {
  __typename?: 'LiveLikeUserBadgeEdge';
  cursor?: Maybe<Scalars['String']['output']>;
  node: LiveLikeUserBadge;
};

export type LiveLikeUserQuest = LiveLikeNode & {
  __typename?: 'LiveLikeUserQuest';
  activeUntil?: Maybe<Scalars['DateTimeISO']['output']>;
  completedAt?: Maybe<Scalars['NonEmptyString']['output']>;
  createdAt: Scalars['NonEmptyString']['output'];
  id: Scalars['UUID']['output'];
  profileId: Scalars['UUID']['output'];
  quest: LiveLikeQuest;
  questId: Scalars['UUID']['output'];
  rewardsClaimedAt?: Maybe<Scalars['NonEmptyString']['output']>;
  rewardsStatus: LiveLikeUserQuestRewardStatus;
  status: LiveLikeUserQuestStatusEnum;
  timerExpired?: Maybe<Scalars['Boolean']['output']>;
  userQuestTasks?: Maybe<Array<LiveLikeUserQuestTask>>;
};

export type LiveLikeUserQuestCollection = LiveLikeConnection & {
  __typename?: 'LiveLikeUserQuestCollection';
  edges?: Maybe<Array<LiveLikeUserQuestEdge>>;
  page: LiveLikePage;
};

export type LiveLikeUserQuestEdge = LiveLikeEdge & {
  __typename?: 'LiveLikeUserQuestEdge';
  cursor?: Maybe<Scalars['String']['output']>;
  node: LiveLikeUserQuest;
};

export type LiveLikeUserQuestInput = {
  profileId: Scalars['UUID']['input'];
  questId: Scalars['UUID']['input'];
};

export type LiveLikeUserQuestReward = LiveLikeNode & {
  __typename?: 'LiveLikeUserQuestReward';
  id: Scalars['UUID']['output'];
  questReward: LiveLikeQuestReward;
  rewardStatus: LiveLikeUserQuestRewardStatus;
  userQuestId: Scalars['UUID']['output'];
};

export enum LiveLikeUserQuestRewardStatus {
  Claimed = 'CLAIMED',
  Unclaimed = 'UNCLAIMED'
}

export type LiveLikeUserQuestRewardsConnection = LiveLikeConnection & {
  __typename?: 'LiveLikeUserQuestRewardsConnection';
  edges?: Maybe<Array<Maybe<LiveLikeUserQuestRewardsEdge>>>;
  page: LiveLikePage;
};

export type LiveLikeUserQuestRewardsEdge = LiveLikeEdge & {
  __typename?: 'LiveLikeUserQuestRewardsEdge';
  cursor?: Maybe<Scalars['String']['output']>;
  node: LiveLikeUserQuestReward;
};

export type LiveLikeUserQuestRewardsInput = {
  rewardStatus?: InputMaybe<LiveLikeUserQuestRewardStatus>;
  userQuestId: Scalars['UUID']['input'];
};

export enum LiveLikeUserQuestStatusEnum {
  Cancelled = 'CANCELLED',
  Completed = 'COMPLETED',
  Incomplete = 'INCOMPLETE'
}

export type LiveLikeUserQuestTask = LiveLikeNode & {
  __typename?: 'LiveLikeUserQuestTask';
  completedAt?: Maybe<Scalars['DateTimeISO']['output']>;
  createdAt: Scalars['NonEmptyString']['output'];
  id: Scalars['UUID']['output'];
  progress?: Maybe<Scalars['NonNegativeInt']['output']>;
  questTask: LiveLikeQuestTask;
  status: LiveLikeUserQuestTaskStatusEnum;
  userQuestId: Scalars['UUID']['output'];
};

export type LiveLikeUserQuestTaskProgress = {
  __typename?: 'LiveLikeUserQuestTaskProgress';
  customIncrement?: Maybe<Scalars['NonNegativeInt']['output']>;
  customProgress?: Maybe<Scalars['NonNegativeInt']['output']>;
  id: Scalars['UUID']['output'];
  userQuest: LiveLikeUserQuest;
  userQuestTaskId: Scalars['UUID']['output'];
};

export enum LiveLikeUserQuestTaskStatusEnum {
  Completed = 'COMPLETED',
  Incomplete = 'INCOMPLETE'
}

export type LiveLikeUserQuestsInput = {
  clientId?: InputMaybe<Scalars['NonEmptyString']['input']>;
  questId?: InputMaybe<Scalars['UUID']['input']>;
  rewardsStatus?: InputMaybe<LiveLikeUserQuestRewardStatus>;
  status?: InputMaybe<LiveLikeUserQuestStatusEnum>;
};

export type LiveLikeUserQuestsTaskProgressInput = {
  customIncrement?: InputMaybe<Scalars['NonNegativeInt']['input']>;
  customProgress?: InputMaybe<Scalars['NonNegativeInt']['input']>;
  userQuestTaskId: Scalars['UUID']['input'];
};

export type LiveLikeUserReaction = LiveLikeNode & {
  __typename?: 'LiveLikeUserReaction';
  clientId: Scalars['NonEmptyString']['output'];
  createdAt: Scalars['NonEmptyString']['output'];
  customData?: Maybe<Scalars['NonEmptyString']['output']>;
  id: Scalars['UUID']['output'];
  reactedById: Scalars['UUID']['output'];
  reactionId: Scalars['UUID']['output'];
  reactionSpaceId: Scalars['UUID']['output'];
  targetId: Scalars['NonEmptyString']['output'];
};

export type LiveLikeUserReactionCollection = LiveLikeConnection & {
  __typename?: 'LiveLikeUserReactionCollection';
  edges?: Maybe<Array<LiveLikeUserReactionEdge>>;
  page: LiveLikePage;
};

export type LiveLikeUserReactionCountCollection = {
  __typename?: 'LiveLikeUserReactionCountCollection';
  edges?: Maybe<Array<LiveLikeUserReactionCountEdge>>;
  page: LiveLikePage;
};

export type LiveLikeUserReactionCountEdge = {
  __typename?: 'LiveLikeUserReactionCountEdge';
  cursor?: Maybe<Scalars['String']['output']>;
  node: LiveLikeReactions;
};

export type LiveLikeUserReactionCountsGetInput = {
  page?: InputMaybe<Scalars['PositiveInt']['input']>;
  reactionSpaceId: Scalars['UUID']['input'];
  targetId?: InputMaybe<Array<Scalars['NonEmptyString']['input']>>;
};

export type LiveLikeUserReactionCreateInput = {
  customData?: InputMaybe<Scalars['NonEmptyString']['input']>;
  reactionId: Scalars['UUID']['input'];
  reactionSpaceId: Scalars['UUID']['input'];
  targetId: Scalars['NonEmptyString']['input'];
};

export type LiveLikeUserReactionEdge = LiveLikeEdge & {
  __typename?: 'LiveLikeUserReactionEdge';
  cursor?: Maybe<Scalars['String']['output']>;
  node: LiveLikeUserReaction;
};

export type LiveLikeUserReactionsGetInput = {
  clientId: Scalars['NonEmptyString']['input'];
  page?: InputMaybe<Scalars['PositiveInt']['input']>;
  pageSize?: InputMaybe<Scalars['PositiveInt']['input']>;
  reactedById?: InputMaybe<Scalars['UUID']['input']>;
  reactionId?: InputMaybe<Scalars['UUID']['input']>;
  reactionSpaceIds?: InputMaybe<Array<Scalars['UUID']['input']>>;
  targetGroupId?: InputMaybe<Scalars['NonEmptyString']['input']>;
  targetId?: InputMaybe<Array<Scalars['NonEmptyString']['input']>>;
};

export type LiveLikeVideoAlert = LiveLikeNode & LiveLikeWidgetBase & {
  __typename?: 'LiveLikeVideoAlert';
  /** Client identifier associated with this video alert */
  clientId: Scalars['NonEmptyString']['output'];
  /** Timestamp when the widget was created */
  createdAt: Scalars['DateTimeISO']['output'];
  /** Information about the user that created the widget */
  createdBy: LiveLikeWidgetCreator;
  /** Optional custom metadata for the widget */
  customData?: Maybe<Scalars['String']['output']>;
  /** Unique identifier of the video alert */
  id: Scalars['UUID']['output'];
  /** ISO8601 DateTime when the widget stops accepting interactions */
  interactiveUntil?: Maybe<Scalars['DateTimeISO']['output']>;
  /** Kind of widget */
  kind: LiveLikeWidgetKindEnum;
  /** label describing the link */
  linkLabel?: Maybe<Scalars['NonEmptyString']['output']>;
  /** url of the link */
  linkUrl?: Maybe<Scalars['URL']['output']>;
  /** Video playback time at which the widget appears, in milliseconds */
  playbackTimeMs?: Maybe<Scalars['NonNegativeInt']['output']>;
  /** Program-scheduled datetime when the video alert is expected to appear */
  programDateTime?: Maybe<Scalars['DateTimeISO']['output']>;
  /** Program identifier associated with this video alert */
  programId: Scalars['UUID']['output'];
  /** Delay (ISO8601) before the widget is published after scheduling */
  publishDelay: Scalars['Duration']['output'];
  /** Datetime when the widget was actually published */
  publishedAt?: Maybe<Scalars['DateTimeISO']['output']>;
  /** Whether pubnub is enabled. */
  pubnubEnabled: Scalars['Boolean']['output'];
  /** Contains count-based metrics such as interactions */
  reportCount?: Maybe<LiveLikeWidgetReportCount>;
  /** Scheduled datetime for the widget */
  scheduledAt?: Maybe<Scalars['DateTimeISO']['output']>;
  /** List of sponsor IDs associated with this video alert */
  sponsorIds?: Maybe<Array<Scalars['UUID']['output']>>;
  /** Current status of the widget (e.g.,  PENDING, SCHEDULED, PUBLISHED, INFLIGHT etc). */
  status: LiveLikeWidgetStatusEnum;
  /** text of the video alert */
  text?: Maybe<Scalars['NonEmptyString']['output']>;
  /** Duration (ISO8601) for which the widget remains interactive */
  timeout: Scalars['Duration']['output'];
  /** title of the video alert */
  title?: Maybe<Scalars['NonEmptyString']['output']>;
  /** Total number of unique users who interacted with the widget */
  uniqueImpressionCount?: Maybe<Scalars['NonNegativeInt']['output']>;
  /** url of the video file  */
  videoUrl: Scalars['URL']['output'];
  /** Additional widget attributes in key-value format */
  widgetAttributes?: Maybe<Array<LiveLikeKeyValuePair>>;
};

export type LiveLikeVideoAlertCreateInput = {
  /** free-form field used for custom behaviors */
  customData?: InputMaybe<Scalars['String']['input']>;
  /** ISO8601 DateTime that the widget will stop accepting interactions */
  interactiveUntil?: InputMaybe<Scalars['DateTimeISO']['input']>;
  /** label describing the link */
  linkLabel?: InputMaybe<Scalars['NonEmptyString']['input']>;
  /** url of the link */
  linkUrl?: InputMaybe<Scalars['URL']['input']>;
  /** Video Alert localized data */
  localizedData?: InputMaybe<Array<LiveLikeVideoAlertLocalizedInput>>;
  /** Video playback time in milliseconds */
  playbackTimeMs?: InputMaybe<Scalars['NonNegativeInt']['input']>;
  /**  ID of the program to create the video alert */
  programId: Scalars['UUID']['input'];
  /**
   * Links the sponsors with this Alert.
   * Note only valid sponsor ids will be linked to video alert.
   */
  sponsorIds?: InputMaybe<Array<Scalars['UUID']['input']>>;
  /** text of the video alert */
  text?: InputMaybe<Scalars['NonEmptyString']['input']>;
  /** ISO8601 duration hint for when a Widget should be timed out */
  timeout?: InputMaybe<Scalars['Duration']['input']>;
  /** title of the video alert */
  title?: InputMaybe<Scalars['NonEmptyString']['input']>;
  /** url of the video file  */
  videoUrl: Scalars['URL']['input'];
  /** An array of key value pairs used for custom behaviors */
  widgetAttributes?: InputMaybe<Array<LiveLikeKeyValuePairInput>>;
};

export type LiveLikeVideoAlertLocalizedInput = {
  /** Localized language a string that conforms to the BCP-47 (RFC 5646) standard  */
  language: Scalars['Locale']['input'];
  /** label describing the link */
  linkLabel?: InputMaybe<Scalars['NonEmptyString']['input']>;
  /** text of the video alert */
  text?: InputMaybe<Scalars['NonEmptyString']['input']>;
  /** title of the video alert */
  title?: InputMaybe<Scalars['NonEmptyString']['input']>;
};

export type LiveLikeWidget = LiveLikeAlert | LiveLikeImagePoll | LiveLikeImagePrediction | LiveLikeImagePredictionFollowUp | LiveLikeImageQuiz | LiveLikeRichPost | LiveLikeSocialEmbed | LiveLikeTextPoll | LiveLikeTextPrediction | LiveLikeTextPredictionFollowUp | LiveLikeTextQuiz | LiveLikeVideoAlert;

/** Base widget type containing common fields shared across */
export type LiveLikeWidgetBase = {
  /** Client identifier associated with this widget. */
  clientId: Scalars['NonEmptyString']['output'];
  /** Timestamp when the widget was created. */
  createdAt: Scalars['DateTimeISO']['output'];
  /** Information about the user that created the widget. */
  createdBy: LiveLikeWidgetCreator;
  /** Optional custom metadata for the widget. */
  customData?: Maybe<Scalars['String']['output']>;
  /** Unique identifier of the widget. */
  id: Scalars['UUID']['output'];
  /** The ISO8601 DateTime when the widget stops accepting interactions. */
  interactiveUntil?: Maybe<Scalars['DateTimeISO']['output']>;
  /** Kind of widget (e.g., POST, POLL, PREDICTION, ALERT). */
  kind: LiveLikeWidgetKindEnum;
  /** Video playback time at which the widget appears, in milliseconds. */
  playbackTimeMs?: Maybe<Scalars['NonNegativeInt']['output']>;
  /** Program-scheduled datetime when the widget is expected to appear (if applicable). */
  programDateTime?: Maybe<Scalars['DateTimeISO']['output']>;
  /** Program identifier associated with this widget. */
  programId: Scalars['UUID']['output'];
  /** Delay (ISO8601) before the widget is published after scheduling (if applicable). */
  publishDelay: Scalars['Duration']['output'];
  /** Datetime when the widget was actually published. */
  publishedAt?: Maybe<Scalars['DateTimeISO']['output']>;
  /** Whether pubnub is enabled (if applicable). */
  pubnubEnabled: Scalars['Boolean']['output'];
  /** Contains count-based metrics such as interactions and reports. */
  reportCount?: Maybe<LiveLikeWidgetReportCount>;
  /** Scheduled datetime for the widget. */
  scheduledAt?: Maybe<Scalars['DateTimeISO']['output']>;
  /** List of sponsor IDs associated with this widget. */
  sponsorIds?: Maybe<Array<Scalars['UUID']['output']>>;
  /** Current status of the widget (e.g., PENDING, SCHEDULED, PUBLISHED, INFLIGHT). */
  status: LiveLikeWidgetStatusEnum;
  /** Duration (ISO8601) for which the widget remains interactive. */
  timeout: Scalars['Duration']['output'];
  /** Total number of unique users who interacted with the widget. */
  uniqueImpressionCount?: Maybe<Scalars['NonNegativeInt']['output']>;
  /** Additional widget attributes in key-value format. */
  widgetAttributes?: Maybe<Array<LiveLikeKeyValuePair>>;
};

export type LiveLikeWidgetCollection = {
  __typename?: 'LiveLikeWidgetCollection';
  edges?: Maybe<Array<Maybe<LiveLikeWidgetEdge>>>;
  order?: Maybe<LiveLikeWidgetOrder>;
  page: LiveLikePage;
};

export type LiveLikeWidgetCreator = {
  __typename?: 'LiveLikeWidgetCreator';
  avatar?: Maybe<Avatar>;
  customId?: Maybe<Scalars['NonEmptyString']['output']>;
  id: Scalars['UUID']['output'];
  name: Scalars['NonEmptyString']['output'];
};

export type LiveLikeWidgetDeleteInput = {
  id: Scalars['UUID']['input'];
  kind: LiveLikeWidgetKindEnum;
};

export type LiveLikeWidgetEdge = {
  __typename?: 'LiveLikeWidgetEdge';
  cursor?: Maybe<Scalars['String']['output']>;
  node: LiveLikeWidget;
};

export type LiveLikeWidgetGetInput = {
  kinds?: InputMaybe<Array<LiveLikeWidgetKindEnum>>;
  page?: InputMaybe<Scalars['PositiveInt']['input']>;
  since?: InputMaybe<Scalars['NonEmptyString']['input']>;
  status?: InputMaybe<LiveLikeWidgetStatusEnum>;
  until?: InputMaybe<Scalars['NonEmptyString']['input']>;
};

/**
 * DEPRECATED: Use widget specific one
 * (TextPollVote, ImagePollVote)
 */
export type LiveLikeWidgetInteraction = {
  __typename?: 'LiveLikeWidgetInteraction';
  createdAt: Scalars['String']['output'];
  id: Scalars['UUID']['output'];
  leaderboardRewards?: Maybe<Array<LiveLikeLeaderboardReward>>;
  optionId: Scalars['UUID']['output'];
  profileId: Scalars['UUID']['output'];
  rewards?: Maybe<Array<LiveLikeReward>>;
  widget?: Maybe<LiveLikeWidget>;
  widgetId: Scalars['UUID']['output'];
  widgetKind: LiveLikeWidgetInteractionEnum;
};

export type LiveLikeWidgetInteractionBase = {
  createdAt: Scalars['String']['output'];
  id: Scalars['UUID']['output'];
  leaderboardRewards?: Maybe<Array<LiveLikeLeaderboardReward>>;
  profileId: Scalars['UUID']['output'];
  rewards?: Maybe<Array<LiveLikeReward>>;
  widgetId: Scalars['UUID']['output'];
  widgetKind: LiveLikeWidgetInteractionEnum;
};

export type LiveLikeWidgetInteractionBaseCreateInput = {
  widgetId: Scalars['UUID']['output'];
};

/** Remove not used in scehma used in resolver */
export type LiveLikeWidgetInteractionCreateInput = {
  kind: LiveLikeWidgetInteractionEnum;
  optionId: Scalars['UUID']['input'];
  widgetId: Scalars['UUID']['input'];
};

export enum LiveLikeWidgetInteractionEnum {
  ImagePoll = 'IMAGE_POLL',
  ImagePrediction = 'IMAGE_PREDICTION',
  ImageQuiz = 'IMAGE_QUIZ',
  TextPoll = 'TEXT_POLL',
  TextPrediction = 'TEXT_PREDICTION',
  TextQuiz = 'TEXT_QUIZ'
}

export type LiveLikeWidgetInteractionUnion = LiveLikeImagePollVote | LiveLikeImagePredictionVote | LiveLikeImageQuizAnswer | LiveLikeTextPollVote | LiveLikeTextPredictionVote | LiveLikeTextQuizAnswer;

/** Remove not used in scehma used in resolver */
export type LiveLikeWidgetInteractionUpdateInput = {
  id: Scalars['UUID']['input'];
  kind: LiveLikeWidgetInteractionEnum;
  optionId: Scalars['UUID']['input'];
  widgetId: Scalars['UUID']['input'];
};

export type LiveLikeWidgetInteractions = {
  __typename?: 'LiveLikeWidgetInteractions';
  interactions?: Maybe<Array<LiveLikeWidgetInteractionUnion>>;
  kind: LiveLikeWidgetInteractionEnum;
};

export type LiveLikeWidgetInteractionsInput = {
  ids: Array<Scalars['UUID']['input']>;
  kind: LiveLikeWidgetInteractionEnum;
};

export enum LiveLikeWidgetKindEnum {
  Alert = 'ALERT',
  ImagePoll = 'IMAGE_POLL',
  ImagePrediction = 'IMAGE_PREDICTION',
  ImagePredictionFollowUp = 'IMAGE_PREDICTION_FOLLOW_UP',
  ImageQuiz = 'IMAGE_QUIZ',
  RichPost = 'RICH_POST',
  SocialEmbed = 'SOCIAL_EMBED',
  TextPoll = 'TEXT_POLL',
  TextPrediction = 'TEXT_PREDICTION',
  TextPredictionFollowUp = 'TEXT_PREDICTION_FOLLOW_UP',
  TextQuiz = 'TEXT_QUIZ',
  VideoAlert = 'VIDEO_ALERT'
}

export type LiveLikeWidgetOrder = {
  __typename?: 'LiveLikeWidgetOrder';
  field?: Maybe<LiveLikeWidgetOrderField>;
  order?: Maybe<LiveLikeOrderEnum>;
};

export enum LiveLikeWidgetOrderField {
  CreatedAt = 'CREATED_AT',
  PublishedAt = 'PUBLISHED_AT',
  Recent = 'RECENT',
  ScheduledAt = 'SCHEDULED_AT'
}

export type LiveLikeWidgetOrderInput = {
  field: LiveLikeWidgetOrderField;
  order?: InputMaybe<LiveLikeOrderEnum>;
};

export type LiveLikeWidgetPublish = {
  __typename?: 'LiveLikeWidgetPublish';
  /** An ISO8601 date hint to sync widget to video */
  programDateTime?: Maybe<Scalars['DateTimeISO']['output']>;
  /** An ISO8601 duration to delay publishing */
  publishDelay?: Maybe<Scalars['String']['output']>;
  publishedAt?: Maybe<Scalars['DateTimeISO']['output']>;
  scheduledAt?: Maybe<Scalars['DateTimeISO']['output']>;
  status: LiveLikeWidgetStatusEnum;
};

export type LiveLikeWidgetPublishInput = {
  /**  An ISO8601 date hint to sync widget to video  */
  programDateTime?: InputMaybe<Scalars['DateTimeISO']['input']>;
  /**  An ISO8601 duration to delay publishing  */
  publishDelay?: InputMaybe<Scalars['String']['input']>;
  /**  Widget unique ID  */
  widgetId: Scalars['UUID']['input'];
};

export type LiveLikeWidgetReport = LiveLikeNode & {
  __typename?: 'LiveLikeWidgetReport';
  clientId: Scalars['NonEmptyString']['output'];
  comment?: Maybe<Scalars['String']['output']>;
  createdAt: Scalars['DateTimeISO']['output'];
  id: Scalars['UUID']['output'];
  moderatedAt?: Maybe<Scalars['DateTimeISO']['output']>;
  moderatedBy?: Maybe<Scalars['UUID']['output']>;
  moderatorComment?: Maybe<Scalars['String']['output']>;
  programId: Scalars['UUID']['output'];
  status: LiveLikeWidgetReportStatusEnum;
  widgetId: Scalars['UUID']['output'];
  widgetKind: LiveLikeWidgetKindEnum;
};

export type LiveLikeWidgetReportCollection = LiveLikeConnection & {
  __typename?: 'LiveLikeWidgetReportCollection';
  edges?: Maybe<Array<Maybe<LiveLikeWidgetReportEdge>>>;
  page: LiveLikePage;
};

export type LiveLikeWidgetReportCount = {
  __typename?: 'LiveLikeWidgetReportCount';
  accepted: Scalars['NonNegativeInt']['output'];
  dismissed: Scalars['NonNegativeInt']['output'];
  pending: Scalars['NonNegativeInt']['output'];
  total: Scalars['NonNegativeInt']['output'];
};

export type LiveLikeWidgetReportEdge = LiveLikeEdge & {
  __typename?: 'LiveLikeWidgetReportEdge';
  cursor?: Maybe<Scalars['String']['output']>;
  node: LiveLikeWidgetReport;
};

export type LiveLikeWidgetReportInput = {
  comment?: InputMaybe<Scalars['NonEmptyString']['input']>;
  widgetId: Scalars['UUID']['input'];
  widgetKind: LiveLikeWidgetKindEnum;
};

export enum LiveLikeWidgetReportStatusEnum {
  Accepted = 'ACCEPTED',
  Dismissed = 'DISMISSED',
  Pending = 'PENDING'
}

export type LiveLikeWidgetReportsInput = {
  clientId?: InputMaybe<Scalars['NonEmptyString']['input']>;
  createdById?: InputMaybe<Scalars['UUID']['input']>;
  createdSince?: InputMaybe<Scalars['DateTimeISO']['input']>;
  createdUntil?: InputMaybe<Scalars['DateTimeISO']['input']>;
  moderatedById?: InputMaybe<Scalars['UUID']['input']>;
  moderatedSince?: InputMaybe<Scalars['DateTimeISO']['input']>;
  moderatedUntil?: InputMaybe<Scalars['DateTimeISO']['input']>;
  page?: InputMaybe<Scalars['PositiveInt']['input']>;
  programId?: InputMaybe<Scalars['UUID']['input']>;
  status?: InputMaybe<LiveLikeWidgetReportStatusEnum>;
  widgetId?: InputMaybe<Scalars['UUID']['input']>;
  widgetKind?: InputMaybe<LiveLikeWidgetKindEnum>;
};

export enum LiveLikeWidgetStatusEnum {
  Inflight = 'INFLIGHT',
  Pending = 'PENDING',
  Published = 'PUBLISHED',
  Scheduled = 'SCHEDULED'
}

export type LiveLikeclaimUserQuestRewardInput = {
  rewardsStatus: LiveLikeUserQuestRewardStatus;
  userQuestId: Scalars['UUID']['input'];
};

export type Localization = {
  __typename?: 'Localization';
  language?: Maybe<Scalars['String']['output']>;
  value?: Maybe<Scalars['String']['output']>;
};

export type Media = {
  __typename?: 'Media';
  _id?: Maybe<Scalars['MongoID']['output']>;
  clip?: Maybe<Scalars['String']['output']>;
  image?: Maybe<Image>;
};

export type Menu = {
  __typename?: 'Menu';
  _id: Scalars['MongoID']['output'];
  cmsId?: Maybe<Scalars['String']['output']>;
  id: Scalars['String']['output'];
  isPublished?: Maybe<Scalars['Boolean']['output']>;
  language: Scalars['String']['output'];
  links?: Maybe<Array<Maybe<MenuLinks>>>;
  schemaVersion: Scalars['String']['output'];
  tenant: Scalars['String']['output'];
  title: Scalars['String']['output'];
  uuid?: Maybe<Scalars['String']['output']>;
};

export type MenuLinks = {
  __typename?: 'MenuLinks';
  _id?: Maybe<Scalars['MongoID']['output']>;
  children?: Maybe<Array<Maybe<MenuLinks>>>;
  options?: Maybe<MenuOptions>;
  tagGroups?: Maybe<Array<Maybe<TagGroup>>>;
  tags?: Maybe<Array<Maybe<TagV2>>>;
  text: Scalars['String']['output'];
  url?: Maybe<Scalars['String']['output']>;
  weight: Scalars['String']['output'];
};

export type MenuOptions = {
  __typename?: 'MenuOptions';
  _id?: Maybe<Scalars['MongoID']['output']>;
  attributes?: Maybe<MenuOptionsAttributes>;
  expanded?: Maybe<Scalars['Boolean']['output']>;
  images?: Maybe<Array<Maybe<ImageWithStyle>>>;
  routes?: Maybe<Array<Maybe<MenuRoutes>>>;
  target?: Maybe<Scalars['String']['output']>;
};

export type MenuOptionsAttributes = {
  __typename?: 'MenuOptionsAttributes';
  class?: Maybe<Array<Maybe<Scalars['String']['output']>>>;
  title?: Maybe<Scalars['String']['output']>;
};

export type MenuRoutes = {
  __typename?: 'MenuRoutes';
  _id?: Maybe<Scalars['MongoID']['output']>;
  id?: Maybe<Scalars['String']['output']>;
  path?: Maybe<Scalars['String']['output']>;
  title?: Maybe<Scalars['String']['output']>;
};

export type Metadata = {
  __typename?: 'Metadata';
  cdn?: Maybe<Scalars['String']['output']>;
};

export type ModuleMetaData = {
  __typename?: 'ModuleMetaData';
  /** Represents author of the content within a Content Module. In most cases this would be Creators (creator tags). */
  author?: Maybe<TagV2>;
  brand?: Maybe<ContentBrand>;
  /**
   * Represents the community this content module belongs to (ex. NFL, NBA, BR).
   * In other words, the chosen Tag/Channel we want to display, and often but
   * not always the destination the user would tap through to.
   */
  communityTag?: Maybe<TagV2>;
  hash: Scalars['String']['output'];
  /** Represents the tenant. */
  tenant?: Maybe<Tenant>;
  /** Represents the contentId for video. */
  videoContentId?: Maybe<Scalars['String']['output']>;
};

export enum ModuleOrientation {
  Landscape = 'Landscape',
  Portrait = 'Portrait'
}

export enum ModuleState {
  Programmed = 'PROGRAMMED',
  Scheduled = 'SCHEDULED',
  Unprogrammed = 'UNPROGRAMMED'
}

/** TEST Mutate the Hydration Station Social Entities */
export type Mutation = {
  __typename?: 'Mutation';
  addAlertRank?: Maybe<AddAlertRankResponse>;
  addContentToPackage: ContentModule;
  /** Add new Device for specific tenant */
  addDevice?: Maybe<Device>;
  addPushNotificationsAlertRank?: Maybe<PushNotificationAlertRankResponse>;
  addUserTags?: Maybe<Array<Maybe<TagV2>>>;
  awardLiveLikeBadge?: Maybe<LiveLikeEarnedBadge>;
  blockLiveLikeProfile?: Maybe<LiveLikeBlockProfile>;
  blockProfile?: Maybe<BlockProfileResponse>;
  claimLiveLikeUserQuestReward?: Maybe<LiveLikeUserQuest>;
  createExternalArticle: ExternalArticle;
  createImagePollByTenant?: Maybe<CreatePollResponse>;
  /** Create a Alert widget */
  createLiveLikeAlert?: Maybe<LiveLikeAlert>;
  createLiveLikeChatRoom?: Maybe<LiveLikeChatRoom>;
  createLiveLikeComment?: Maybe<LiveLikeComment>;
  createLiveLikeCommentBoard?: Maybe<LiveLikeCommentBoard>;
  createLiveLikeCommentBoardBan?: Maybe<LiveLikeCommentBoardBan>;
  createLiveLikeCommentReply?: Maybe<LiveLikeComment>;
  createLiveLikeCommentReport?: Maybe<LiveLikeCommentReport>;
  createLiveLikeImagePoll?: Maybe<LiveLikeImagePoll>;
  /**  Vote on a image poll  */
  createLiveLikeImagePollVote?: Maybe<LiveLikeImagePollVote>;
  /**
   * Creates a new image prediction widget with the provided input.
   * Returns the created ImagePrediction object.
   */
  createLiveLikeImagePrediction?: Maybe<LiveLikeImagePrediction>;
  /**
   * Creates a new image prediction follow up widget with the provided input.
   * Returns the created ImagePredictionFollowUp object.
   */
  createLiveLikeImagePredictionFollowUp?: Maybe<LiveLikeImagePredictionFollowUp>;
  /**  Vote on a image prediction  */
  createLiveLikeImagePredictionVote?: Maybe<LiveLikeImagePredictionVote>;
  /**
   * Creates a new image quiz widget with the provided input.
   * Returns the created ImageQuiz object.
   */
  createLiveLikeImageQuiz?: Maybe<LiveLikeImageQuiz>;
  /**  Answer on a image quiz  */
  createLiveLikeImageQuizAnswer?: Maybe<LiveLikeImageQuizAnswer>;
  createLiveLikeLeaderboard?: Maybe<LiveLikeLeaderboard>;
  /** @deprecated Use widget specific one (createTextPollVote, createImagePollVote) */
  createLiveLikePollVote?: Maybe<LiveLikeWidgetInteraction>;
  createLiveLikeProfile?: Maybe<LiveLikeProfileAuth>;
  createLiveLikeProfileByCustomId?: Maybe<LiveLikeProfileAuth>;
  createLiveLikeProfileRelationship?: Maybe<LiveLikeProfileRelationship>;
  createLiveLikeProfileRelationshipType?: Maybe<LiveLikeProfileRelationshipType>;
  createLiveLikeProgram?: Maybe<LiveLikeProgram>;
  createLiveLikeProgramBan?: Maybe<LiveLikeProgramBan>;
  createLiveLikeQuest?: Maybe<LiveLikeQuest>;
  createLiveLikeReactionSpace?: Maybe<LiveLikeReactionSpace>;
  createLiveLikeRewardItem?: Maybe<LiveLikeRewardItem>;
  createLiveLikeRewardTable?: Maybe<LiveLikeRewardTable>;
  createLiveLikeRewardTableEntry?: Maybe<LiveLikeRewardTableEntry>;
  /** Create a Rich Post widget */
  createLiveLikeRichPost?: Maybe<LiveLikeRichPost>;
  createLiveLikeRole?: Maybe<LiveLikeRole>;
  createLiveLikeRoleAssignment?: Maybe<LiveLikeRoleAssignment>;
  /** Create a SocialEmbed widget */
  createLiveLikeSocialEmbed?: Maybe<LiveLikeSocialEmbed>;
  createLiveLikeTextPoll?: Maybe<LiveLikeTextPoll>;
  /**  Vote on a text poll  */
  createLiveLikeTextPollVote?: Maybe<LiveLikeTextPollVote>;
  /**
   * Creates a new text prediction widget with the provided input.
   * Returns the created TextPrediction object.
   */
  createLiveLikeTextPrediction?: Maybe<LiveLikeTextPrediction>;
  /**
   * Creates a new text prediction follow up widget with the provided input.
   * Returns the created TextPredictionFollowUp object.
   */
  createLiveLikeTextPredictionFollowUp?: Maybe<LiveLikeTextPredictionFollowUp>;
  /**  Vote on a text prediction  */
  createLiveLikeTextPredictionVote?: Maybe<LiveLikeTextPredictionVote>;
  /**
   * Creates a new text quiz widget with the provided input.
   * Returns the created TextQuiz object.
   */
  createLiveLikeTextQuiz?: Maybe<LiveLikeTextQuiz>;
  /**  Answer on a text quiz  */
  createLiveLikeTextQuizAnswer?: Maybe<LiveLikeTextQuizAnswer>;
  createLiveLikeUserQuest?: Maybe<LiveLikeUserQuest>;
  createLiveLikeUserReaction?: Maybe<LiveLikeUserReaction>;
  /** Create a Video Alert widget */
  createLiveLikeVideoAlert?: Maybe<LiveLikeVideoAlert>;
  createPackageContentModule: ContentModule;
  createPostByTenant?: Maybe<CreatePostResponse>;
  createProgramForTaxonomy?: Maybe<CreateProgramResponse>;
  createStandaloneContentModule: StandaloneContentModule;
  createStaticPackages: Array<Maybe<ContentModule>>;
  createTextPollByTenant?: Maybe<CreatePollResponse>;
  /** TEST Mutation for Tweets from Hydration Station no used in Production Clients ONLY DEV */
  createTweetById: Tweet;
  /**
   * Credit reward item points to a user profile.
   * Returns the resulting RewardItemTransaction.
   */
  creditLiveLikeRewardItem?: Maybe<LiveLikeRewardItemTransaction>;
  /**
   * Debit reward item points from a user profile.
   * Returns the resulting RewardItemTransaction.
   */
  debitLiveLikeRewardItem?: Maybe<LiveLikeRewardItemTransaction>;
  deleteContentFromPackage?: Maybe<Scalars['Boolean']['output']>;
  deleteContentModule: Scalars['String']['output'];
  deleteContentModuleByContentId: DeleteVideoContentModulesResult;
  deleteDuplicateScheduledHighlightsPackages?: Maybe<Scalars['String']['output']>;
  /** Delete a Alert widget */
  deleteLiveLikeAlert?: Maybe<Scalars['Boolean']['output']>;
  deleteLiveLikeChatRoom?: Maybe<Scalars['Boolean']['output']>;
  deleteLiveLikeComment?: Maybe<Scalars['Boolean']['output']>;
  deleteLiveLikeCommentBoard?: Maybe<Scalars['Boolean']['output']>;
  deleteLiveLikeCommentBoardBan?: Maybe<Scalars['Boolean']['output']>;
  /** Delete a Image Poll widget */
  deleteLiveLikeImagePoll?: Maybe<Scalars['Boolean']['output']>;
  /** Delete a Image Prediction widget */
  deleteLiveLikeImagePrediction?: Maybe<Scalars['Boolean']['output']>;
  /** Delete a Image Prediction Follow up widget */
  deleteLiveLikeImagePredictionFollowUp?: Maybe<Scalars['Boolean']['output']>;
  /** Delete a Image Quiz widget */
  deleteLiveLikeImageQuiz?: Maybe<Scalars['Boolean']['output']>;
  deleteLiveLikeLeaderboard?: Maybe<Scalars['Boolean']['output']>;
  deleteLiveLikeProfile?: Maybe<Scalars['Boolean']['output']>;
  deleteLiveLikeProfileBlock?: Maybe<Scalars['Boolean']['output']>;
  deleteLiveLikeProfileRelationship?: Maybe<Scalars['Boolean']['output']>;
  deleteLiveLikeProfileRelationshipType?: Maybe<Scalars['Boolean']['output']>;
  deleteLiveLikeProgram?: Maybe<Scalars['Boolean']['output']>;
  deleteLiveLikeProgramBan?: Maybe<Scalars['Boolean']['output']>;
  deleteLiveLikeProgramByCustomId?: Maybe<Scalars['Boolean']['output']>;
  deleteLiveLikeReactionSpace?: Maybe<Scalars['Boolean']['output']>;
  deleteLiveLikeRewardItem?: Maybe<Scalars['Boolean']['output']>;
  deleteLiveLikeRewardTable?: Maybe<Scalars['Boolean']['output']>;
  deleteLiveLikeRewardTableEntry?: Maybe<Scalars['Boolean']['output']>;
  /** Delete a Rich Post widget */
  deleteLiveLikeRichPost?: Maybe<Scalars['Boolean']['output']>;
  /** Delete a SocialEmbed widget */
  deleteLiveLikeSocialEmbed?: Maybe<Scalars['Boolean']['output']>;
  /** Delete a Text Poll widget */
  deleteLiveLikeTextPoll?: Maybe<Scalars['Boolean']['output']>;
  /** Delete a Text Prediction widget */
  deleteLiveLikeTextPrediction?: Maybe<Scalars['Boolean']['output']>;
  /** Delete a Text Prediction Follow up widget */
  deleteLiveLikeTextPredictionFollowUp?: Maybe<Scalars['Boolean']['output']>;
  /** Delete a Text Quiz widget */
  deleteLiveLikeTextQuiz?: Maybe<Scalars['Boolean']['output']>;
  deleteLiveLikeUserReaction?: Maybe<Scalars['Boolean']['output']>;
  /** Delete a Video Alert widget */
  deleteLiveLikeVideoAlert?: Maybe<Scalars['Boolean']['output']>;
  deleteLiveLikeWidget?: Maybe<Scalars['Boolean']['output']>;
  dismissLiveLikeCommentReport?: Maybe<LiveLikeCommentReport>;
  /** @deprecated use deleteContentModule instead */
  expireContentModules: Array<Scalars['Int']['output']>;
  /**
   * flushAdRegistryCache | Ads API
   * ----------------------------------------------
   * Flushes the cache for ads registries and metadata based on the operationName
   * Returns the number of entries deleted
   */
  flushAdRegistryCache?: Maybe<Scalars['Int']['output']>;
  /**
   * flushAdSiteCache | Ads API
   * ----------------------------------------------
   * Flushes the cache for ads site configurations
   * Returns the number of entries deleted
   */
  flushAdSiteCache?: Maybe<Scalars['Boolean']['output']>;
  invokeLiveLikeRewardAction?: Maybe<LiveLikeRewardAction>;
  linkLiveLikeLeaderboardWithProgram?: Maybe<Scalars['Boolean']['output']>;
  linkLiveLikeRewardTableWithProgram?: Maybe<Scalars['Boolean']['output']>;
  login?: Maybe<Scalars['String']['output']>;
  prepareImage?: Maybe<PrepareImageResponse>;
  /** Publish a Alert widget */
  publishLiveLikeAlert?: Maybe<LiveLikeWidgetPublish>;
  /** Publish a Image Poll widget */
  publishLiveLikeImagePoll?: Maybe<LiveLikeWidgetPublish>;
  /** Publish a Image Prediction widget */
  publishLiveLikeImagePrediction?: Maybe<LiveLikeWidgetPublish>;
  /** Publish a Image Prediction Follow Up widget */
  publishLiveLikeImagePredictionFollowUp?: Maybe<LiveLikeWidgetPublish>;
  /** Publish a Image Quiz widget */
  publishLiveLikeImageQuiz?: Maybe<LiveLikeWidgetPublish>;
  /** Publish a Rich Post widget */
  publishLiveLikeRichPost?: Maybe<LiveLikeWidgetPublish>;
  /** Publish a SocialEmbed widget */
  publishLiveLikeSocialEmbed?: Maybe<LiveLikeWidgetPublish>;
  /** Publish a Text Poll widget */
  publishLiveLikeTextPoll?: Maybe<LiveLikeWidgetPublish>;
  /** Publish a Text Prediction widget */
  publishLiveLikeTextPrediction?: Maybe<LiveLikeWidgetPublish>;
  /** Publish a Text Prediction Follow Up widget */
  publishLiveLikeTextPredictionFollowUp?: Maybe<LiveLikeWidgetPublish>;
  /** Publish a Text Quiz widget */
  publishLiveLikeTextQuiz?: Maybe<LiveLikeWidgetPublish>;
  /** Publish a Video Alert widget */
  publishLiveLikeVideoAlert?: Maybe<LiveLikeWidgetPublish>;
  publishLiveLikeWidget?: Maybe<LiveLikeWidgetPublish>;
  removeUserTags?: Maybe<Array<Maybe<TagV2>>>;
  reportLiveLikeWidget?: Maybe<LiveLikeWidgetReport>;
  revokeLiveLikeEarnedBadge?: Maybe<Scalars['Boolean']['output']>;
  /** Send Push Notification for specific tenant to provided tag ids */
  sendPushNotification?: Maybe<PushNotification>;
  setGlobalAlerts?: Maybe<Settings>;
  /** @deprecated Use setGlobalAlerts with spoilers alerts instead */
  setGlobalSpoilerSettings?: Maybe<Settings>;
  setUserFavoriteTeams?: Maybe<User>;
  /** @deprecated Use updateUserTags with spoilers in the notifications array instead */
  setUserSpoilers?: Maybe<TagV2>;
  startLiveLikeProgram?: Maybe<LiveLikeProgramSchedule>;
  stopLiveLikeProgram?: Maybe<LiveLikeProgramSchedule>;
  unblockProfile?: Maybe<Scalars['Boolean']['output']>;
  unlinkLiveLikeLeaderboardFromProgram?: Maybe<Scalars['Boolean']['output']>;
  unlinkLiveLikeRewardTableWithProgram?: Maybe<Scalars['Boolean']['output']>;
  updateLiveLikeChatRoom?: Maybe<LiveLikeChatRoom>;
  updateLiveLikeCommentBoard?: Maybe<LiveLikeCommentBoard>;
  /**  Update Vote on a voted image poll  */
  updateLiveLikeImagePollVote?: Maybe<LiveLikeImagePollVote>;
  /**  Update Vote on a voted image prediction  */
  updateLiveLikeImagePredictionVote?: Maybe<LiveLikeImagePredictionVote>;
  /**  Update answer on a answered image quiz  */
  updateLiveLikeImageQuizAnswer?: Maybe<LiveLikeImageQuizAnswer>;
  updateLiveLikeLeaderboard?: Maybe<LiveLikeLeaderboard>;
  /** @deprecated Use widget specific one (updateTextPollVote, updateImagePollVote) */
  updateLiveLikePollVote?: Maybe<LiveLikeWidgetInteraction>;
  updateLiveLikeProfile?: Maybe<LiveLikeProfile>;
  updateLiveLikeProgram?: Maybe<LiveLikeProgram>;
  updateLiveLikeProgramByCustomId?: Maybe<LiveLikeProgram>;
  updateLiveLikeReactionSpace?: Maybe<LiveLikeReactionSpacePatch>;
  updateLiveLikeRewardTable?: Maybe<LiveLikeRewardTable>;
  /**  Update Vote on a voted text poll  */
  updateLiveLikeTextPollVote?: Maybe<LiveLikeTextPollVote>;
  /**  Update Vote on a voted text prediction  */
  updateLiveLikeTextPredictionVote?: Maybe<LiveLikeTextPredictionVote>;
  /**  Update answer on a answered text quiz  */
  updateLiveLikeTextQuizAnswer?: Maybe<LiveLikeTextQuizAnswer>;
  updateLiveLikeUserQuestTaskProgress?: Maybe<LiveLikeUserQuestTaskProgress>;
  updatePackageContentModule: ContentModule;
  updatePostByTenant?: Maybe<CreatePostResponse>;
  updateStandaloneContentModule: ContentModule;
  updateTextPollByTenant?: Maybe<CreatePollResponse>;
  updateUserTags?: Maybe<Array<Maybe<TagV2>>>;
  upsertPackageContentModules?: Maybe<Array<Maybe<PackageContentModule>>>;
  upsertStandaloneContentModules: Array<ContentModule>;
  upsertVideoState?: Maybe<VideoV2Metadata>;
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationAddAlertRankArgs = {
  alertRankInput?: InputMaybe<AddAlertRankInput>;
  tenant: Tenant;
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationAddContentToPackageArgs = {
  allowedCountries?: InputMaybe<Array<InputMaybe<Scalars['String']['input']>>>;
  commentsEnabled?: InputMaybe<Scalars['Boolean']['input']>;
  contentId?: InputMaybe<Scalars['ID']['input']>;
  contentModuleId?: InputMaybe<Scalars['ID']['input']>;
  contentType?: InputMaybe<ContentModuleType>;
  description: Scalars['String']['input'];
  hidden?: InputMaybe<Scalars['Boolean']['input']>;
  hiddenExpiresAt?: InputMaybe<Scalars['Date']['input']>;
  lastModifiedBy: Scalars['String']['input'];
  packageModuleId: Scalars['String']['input'];
  position: Scalars['Int']['input'];
  scheduledDate?: InputMaybe<Scalars['Date']['input']>;
  thumbnail: Scalars['String']['input'];
  thumbnailAccreditation?: InputMaybe<Scalars['String']['input']>;
  thumbnailCopyright?: InputMaybe<Scalars['String']['input']>;
  title: Scalars['String']['input'];
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationAddDeviceArgs = {
  device: DeviceInput;
  tenant: Tenant;
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationAddPushNotificationsAlertRankArgs = {
  alertRankInput?: InputMaybe<PushNotificationAlertRankInput>;
  tenant: Tenant;
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationAddUserTagsArgs = {
  inputs: Array<InputMaybe<UserTagInput>>;
  tenant: Tenant;
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationAwardLiveLikeBadgeArgs = {
  input: LiveLikeAwardBadgeInput;
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationBlockLiveLikeProfileArgs = {
  profileId: Scalars['UUID']['input'];
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationBlockProfileArgs = {
  blockedProfileID: Scalars['String']['input'];
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationClaimLiveLikeUserQuestRewardArgs = {
  input: LiveLikeclaimUserQuestRewardInput;
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationCreateExternalArticleArgs = {
  created?: InputMaybe<Scalars['Date']['input']>;
  providerName: Scalars['String']['input'];
  source: Scalars['String']['input'];
  url: Scalars['String']['input'];
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationCreateImagePollByTenantArgs = {
  poll: ImagePollInput;
  tenant: Tenant;
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationCreateLiveLikeAlertArgs = {
  input: LiveLikeAlertCreateInput;
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationCreateLiveLikeChatRoomArgs = {
  input: LiveLikeChatRoomCreateInput;
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationCreateLiveLikeCommentArgs = {
  input: LiveLikeCommentCreateInput;
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationCreateLiveLikeCommentBoardArgs = {
  input: LiveLikeCommentBoardCreateInput;
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationCreateLiveLikeCommentBoardBanArgs = {
  input: LiveLikeCommentBoardBanInput;
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationCreateLiveLikeCommentReplyArgs = {
  input: LiveLikeCommentReplyCreateInput;
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationCreateLiveLikeCommentReportArgs = {
  input: LiveLikeCommentReportCreateInput;
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationCreateLiveLikeImagePollArgs = {
  input: LiveLikeImagePollCreateInput;
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationCreateLiveLikeImagePollVoteArgs = {
  input: LiveLikeImagePollVoteCreateInput;
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationCreateLiveLikeImagePredictionArgs = {
  input: LiveLikeImagePredictionCreateInput;
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationCreateLiveLikeImagePredictionFollowUpArgs = {
  input: LiveLikeImagePredictionFollowUpCreateInput;
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationCreateLiveLikeImagePredictionVoteArgs = {
  input: LiveLikeImagePredictionVoteCreateInput;
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationCreateLiveLikeImageQuizArgs = {
  input: LiveLikeImageQuizCreateInput;
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationCreateLiveLikeImageQuizAnswerArgs = {
  input: LiveLikeImageQuizAnswerCreateInput;
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationCreateLiveLikeLeaderboardArgs = {
  input: LiveLikeLeaderboardCreateInput;
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationCreateLiveLikePollVoteArgs = {
  input: LiveLikePollVoteCreateInput;
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationCreateLiveLikeProfileArgs = {
  input: LiveLikeProfileCreateInput;
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationCreateLiveLikeProfileByCustomIdArgs = {
  input: LiveLikeProfileByCustomIdCreateInput;
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationCreateLiveLikeProfileRelationshipArgs = {
  input: LiveLikeProfileRelationshipCreateInput;
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationCreateLiveLikeProfileRelationshipTypeArgs = {
  input: LiveLikeProfileRelationshipTypeCreateInput;
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationCreateLiveLikeProgramArgs = {
  input: LiveLikeProgramCreateInput;
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationCreateLiveLikeProgramBanArgs = {
  input: LiveLikeProgramBanInput;
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationCreateLiveLikeQuestArgs = {
  input: LiveLikeQuestInput;
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationCreateLiveLikeReactionSpaceArgs = {
  input: LiveLikeReactionSpaceCreateInput;
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationCreateLiveLikeRewardItemArgs = {
  input: LiveLikeRewardItemCreateInput;
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationCreateLiveLikeRewardTableArgs = {
  input: LiveLikeRewardTableCreateInput;
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationCreateLiveLikeRewardTableEntryArgs = {
  input: LiveLikeRewardTableEntryCreateInput;
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationCreateLiveLikeRichPostArgs = {
  input: LiveLikeRichPostCreateInput;
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationCreateLiveLikeRoleArgs = {
  input: LiveLikeRoleCreateInput;
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationCreateLiveLikeRoleAssignmentArgs = {
  input: LiveLikeRoleAssignmentCreateInput;
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationCreateLiveLikeSocialEmbedArgs = {
  input: LiveLikeSocialEmbedCreateInput;
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationCreateLiveLikeTextPollArgs = {
  input: LiveLikeTextPollCreateInput;
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationCreateLiveLikeTextPollVoteArgs = {
  input: LiveLikeTextPollVoteCreateInput;
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationCreateLiveLikeTextPredictionArgs = {
  input: LiveLikeTextPredictionCreateInput;
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationCreateLiveLikeTextPredictionFollowUpArgs = {
  input: LiveLikeTextPredictionFollowUpCreateInput;
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationCreateLiveLikeTextPredictionVoteArgs = {
  input: LiveLikeTextPredictionVoteCreateInput;
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationCreateLiveLikeTextQuizArgs = {
  input: LiveLikeTextQuizCreateInput;
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationCreateLiveLikeTextQuizAnswerArgs = {
  input: LiveLikeTextQuizAnswerCreateInput;
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationCreateLiveLikeUserQuestArgs = {
  input: LiveLikeUserQuestInput;
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationCreateLiveLikeUserReactionArgs = {
  input: LiveLikeUserReactionCreateInput;
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationCreateLiveLikeVideoAlertArgs = {
  input: LiveLikeVideoAlertCreateInput;
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationCreatePackageContentModuleArgs = {
  allowedCountries?: InputMaybe<Array<InputMaybe<Scalars['String']['input']>>>;
  channels: Array<TagComponent>;
  commentsEnabled?: InputMaybe<Scalars['Boolean']['input']>;
  contentId?: InputMaybe<Scalars['ID']['input']>;
  contentType: ContentModuleType;
  description?: InputMaybe<Scalars['String']['input']>;
  expiresAt?: InputMaybe<Scalars['Date']['input']>;
  hidden?: InputMaybe<Scalars['Boolean']['input']>;
  hiddenExpiresAt?: InputMaybe<Scalars['Date']['input']>;
  lastModifiedBy: Scalars['String']['input'];
  orientation?: InputMaybe<ModuleOrientation>;
  packageTag?: InputMaybe<Scalars['String']['input']>;
  packageType?: InputMaybe<PackageType>;
  scheduledDate?: InputMaybe<Scalars['Date']['input']>;
  title: Scalars['String']['input'];
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationCreatePostByTenantArgs = {
  post: PostInput;
  tenant: Tenant;
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationCreateProgramForTaxonomyArgs = {
  taxonomyId: Scalars['String']['input'];
  tenant: Tenant;
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationCreateStandaloneContentModuleArgs = {
  allowedCountries?: InputMaybe<Array<InputMaybe<Scalars['String']['input']>>>;
  channels: Array<TagComponent>;
  commentsEnabled?: InputMaybe<Scalars['Boolean']['input']>;
  contentId: Scalars['ID']['input'];
  contentType: ContentModuleType;
  description: Scalars['String']['input'];
  expiresAt?: InputMaybe<Scalars['Date']['input']>;
  hidden?: InputMaybe<Scalars['Boolean']['input']>;
  hiddenExpiresAt?: InputMaybe<Scalars['Date']['input']>;
  lastModifiedBy: Scalars['String']['input'];
  orientation?: InputMaybe<ModuleOrientation>;
  scheduledDate?: InputMaybe<Scalars['Date']['input']>;
  thumbnail: Scalars['String']['input'];
  thumbnailAccreditation?: InputMaybe<Scalars['String']['input']>;
  thumbnailCopyright?: InputMaybe<Scalars['String']['input']>;
  title: Scalars['String']['input'];
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationCreateStaticPackagesArgs = {
  allowedCountries?: InputMaybe<Array<InputMaybe<Scalars['String']['input']>>>;
  channels?: InputMaybe<Array<TagComponent>>;
  commentsEnabled?: InputMaybe<Scalars['Boolean']['input']>;
  contentType: ContentModuleType;
  lastModifiedBy: Scalars['String']['input'];
  packageTypes: Array<PackageType>;
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationCreateTextPollByTenantArgs = {
  poll: TextPollInput;
  tenant: Tenant;
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationCreateTweetByIdArgs = {
  id: Scalars['ID']['input'];
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationCreditLiveLikeRewardItemArgs = {
  input: LiveLikeRewardItemTransactionInput;
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationDebitLiveLikeRewardItemArgs = {
  input: LiveLikeRewardItemTransactionInput;
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationDeleteContentFromPackageArgs = {
  contentModuleId: Scalars['String']['input'];
  packageContentModuleId: Scalars['String']['input'];
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationDeleteContentModuleArgs = {
  id: Scalars['ID']['input'];
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationDeleteContentModuleByContentIdArgs = {
  contentId: Scalars['String']['input'];
  contentType?: InputMaybe<ContentModuleType>;
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationDeleteLiveLikeAlertArgs = {
  id: Scalars['UUID']['input'];
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationDeleteLiveLikeChatRoomArgs = {
  id: Scalars['UUID']['input'];
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationDeleteLiveLikeCommentArgs = {
  id: Scalars['UUID']['input'];
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationDeleteLiveLikeCommentBoardArgs = {
  id: Scalars['UUID']['input'];
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationDeleteLiveLikeCommentBoardBanArgs = {
  id: Scalars['UUID']['input'];
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationDeleteLiveLikeImagePollArgs = {
  id: Scalars['UUID']['input'];
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationDeleteLiveLikeImagePredictionArgs = {
  id: Scalars['UUID']['input'];
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationDeleteLiveLikeImagePredictionFollowUpArgs = {
  id: Scalars['UUID']['input'];
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationDeleteLiveLikeImageQuizArgs = {
  id: Scalars['UUID']['input'];
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationDeleteLiveLikeLeaderboardArgs = {
  id: Scalars['UUID']['input'];
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationDeleteLiveLikeProfileArgs = {
  id: Scalars['UUID']['input'];
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationDeleteLiveLikeProfileBlockArgs = {
  id: Scalars['UUID']['input'];
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationDeleteLiveLikeProfileRelationshipArgs = {
  id: Scalars['UUID']['input'];
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationDeleteLiveLikeProfileRelationshipTypeArgs = {
  id: Scalars['UUID']['input'];
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationDeleteLiveLikeProgramArgs = {
  id: Scalars['UUID']['input'];
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationDeleteLiveLikeProgramBanArgs = {
  id: Scalars['UUID']['input'];
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationDeleteLiveLikeProgramByCustomIdArgs = {
  input: LiveLikeProgramDeleteByCustomIdInput;
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationDeleteLiveLikeReactionSpaceArgs = {
  input: LiveLikeReactionSpaceDeleteInput;
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationDeleteLiveLikeRewardItemArgs = {
  id: Scalars['UUID']['input'];
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationDeleteLiveLikeRewardTableArgs = {
  id: Scalars['UUID']['input'];
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationDeleteLiveLikeRewardTableEntryArgs = {
  input: LiveLikeRewardTableEntryDeleteInput;
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationDeleteLiveLikeRichPostArgs = {
  id: Scalars['UUID']['input'];
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationDeleteLiveLikeSocialEmbedArgs = {
  id: Scalars['UUID']['input'];
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationDeleteLiveLikeTextPollArgs = {
  id: Scalars['UUID']['input'];
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationDeleteLiveLikeTextPredictionArgs = {
  id: Scalars['UUID']['input'];
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationDeleteLiveLikeTextPredictionFollowUpArgs = {
  id: Scalars['UUID']['input'];
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationDeleteLiveLikeTextQuizArgs = {
  id: Scalars['UUID']['input'];
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationDeleteLiveLikeUserReactionArgs = {
  id: Scalars['UUID']['input'];
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationDeleteLiveLikeVideoAlertArgs = {
  id: Scalars['UUID']['input'];
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationDeleteLiveLikeWidgetArgs = {
  input: LiveLikeWidgetDeleteInput;
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationDismissLiveLikeCommentReportArgs = {
  id: Scalars['UUID']['input'];
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationFlushAdRegistryCacheArgs = {
  operationName: Scalars['String']['input'];
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationFlushAdSiteCacheArgs = {
  siteCache?: InputMaybe<Scalars['String']['input']>;
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationInvokeLiveLikeRewardActionArgs = {
  input: LiveLikeRewardActionCreateInput;
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationLinkLiveLikeLeaderboardWithProgramArgs = {
  input: LiveLikeLeaderboardProgramLinkInput;
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationLinkLiveLikeRewardTableWithProgramArgs = {
  input: LiveLikeLinkRewardTableWithProgramInput;
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationLoginArgs = {
  email: Scalars['String']['input'];
  password: Scalars['String']['input'];
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationPrepareImageArgs = {
  imageCount: Scalars['Int']['input'];
  imageTypes: ImageTypes;
  tenant: Tenant;
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationPublishLiveLikeAlertArgs = {
  input: LiveLikeWidgetPublishInput;
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationPublishLiveLikeImagePollArgs = {
  input: LiveLikeWidgetPublishInput;
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationPublishLiveLikeImagePredictionArgs = {
  input: LiveLikeWidgetPublishInput;
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationPublishLiveLikeImagePredictionFollowUpArgs = {
  input: LiveLikeWidgetPublishInput;
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationPublishLiveLikeImageQuizArgs = {
  input: LiveLikeWidgetPublishInput;
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationPublishLiveLikeRichPostArgs = {
  input: LiveLikeWidgetPublishInput;
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationPublishLiveLikeSocialEmbedArgs = {
  input: LiveLikeWidgetPublishInput;
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationPublishLiveLikeTextPollArgs = {
  input: LiveLikeWidgetPublishInput;
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationPublishLiveLikeTextPredictionArgs = {
  input: LiveLikeWidgetPublishInput;
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationPublishLiveLikeTextPredictionFollowUpArgs = {
  input: LiveLikeWidgetPublishInput;
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationPublishLiveLikeTextQuizArgs = {
  input: LiveLikeWidgetPublishInput;
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationPublishLiveLikeVideoAlertArgs = {
  input: LiveLikeWidgetPublishInput;
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationPublishLiveLikeWidgetArgs = {
  input: LiveLikeWidgetPublishInput;
  kind: LiveLikeWidgetKindEnum;
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationRemoveUserTagsArgs = {
  tagUUIDS: Array<InputMaybe<Scalars['String']['input']>>;
  tenant: Tenant;
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationReportLiveLikeWidgetArgs = {
  input: LiveLikeWidgetReportInput;
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationRevokeLiveLikeEarnedBadgeArgs = {
  earnedBadgeId: Scalars['UUID']['input'];
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationSendPushNotificationArgs = {
  notification: NewPushNotification;
  tenant: Tenant;
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationSetGlobalAlertsArgs = {
  input: Array<InputMaybe<AlertInput>>;
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationSetGlobalSpoilerSettingsArgs = {
  spoilersEnabled: Scalars['Boolean']['input'];
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationSetUserFavoriteTeamsArgs = {
  tagUUIDS: Array<InputMaybe<Scalars['String']['input']>>;
  tenant: Tenant;
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationSetUserSpoilersArgs = {
  spoilers: Scalars['Boolean']['input'];
  tagUUID: Scalars['String']['input'];
  tenant: Tenant;
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationStartLiveLikeProgramArgs = {
  id: Scalars['UUID']['input'];
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationStopLiveLikeProgramArgs = {
  id: Scalars['UUID']['input'];
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationUnblockProfileArgs = {
  blockedProfileID: Scalars['String']['input'];
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationUnlinkLiveLikeLeaderboardFromProgramArgs = {
  input: LiveLikeLeaderboardProgramLinkInput;
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationUnlinkLiveLikeRewardTableWithProgramArgs = {
  input: LiveLikeUnlinkRewardTableWithProgramInput;
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationUpdateLiveLikeChatRoomArgs = {
  input: LiveLikeChatRoomUpdateInput;
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationUpdateLiveLikeCommentBoardArgs = {
  input: LiveLikeCommentBoardUpdateInput;
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationUpdateLiveLikeImagePollVoteArgs = {
  input: LiveLikeImagePollVoteUpdateInput;
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationUpdateLiveLikeImagePredictionVoteArgs = {
  input: LiveLikeImagePredictionVoteUpdateInput;
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationUpdateLiveLikeImageQuizAnswerArgs = {
  input: LiveLikeImageQuizAnswerUpdateInput;
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationUpdateLiveLikeLeaderboardArgs = {
  input: LiveLikeLeaderboardUpdateInput;
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationUpdateLiveLikePollVoteArgs = {
  input: LiveLikePollVoteUpdateInput;
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationUpdateLiveLikeProfileArgs = {
  input: LiveLikeProfileUpdateInput;
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationUpdateLiveLikeProgramArgs = {
  input: LiveLikeProgramUpdateInput;
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationUpdateLiveLikeProgramByCustomIdArgs = {
  input: LiveLikeProgramUpdateByCustomIdInput;
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationUpdateLiveLikeReactionSpaceArgs = {
  input: LiveLikeReactionSpaceUpdateInput;
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationUpdateLiveLikeRewardTableArgs = {
  input: LiveLikeRewardTableUpdateInput;
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationUpdateLiveLikeTextPollVoteArgs = {
  input: LiveLikeTextPollVoteUpdateInput;
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationUpdateLiveLikeTextPredictionVoteArgs = {
  input: LiveLikeTextPredictionVoteUpdateInput;
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationUpdateLiveLikeTextQuizAnswerArgs = {
  input: LiveLikeTextQuizAnswerUpdateInput;
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationUpdateLiveLikeUserQuestTaskProgressArgs = {
  input: LiveLikeUserQuestsTaskProgressInput;
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationUpdatePackageContentModuleArgs = {
  allowedCountries?: InputMaybe<Array<InputMaybe<Scalars['String']['input']>>>;
  channels?: InputMaybe<Array<InputMaybe<TagComponent>>>;
  commentsEnabled?: InputMaybe<Scalars['Boolean']['input']>;
  contentModuleId: Scalars['ID']['input'];
  description?: InputMaybe<Scalars['String']['input']>;
  expiresAt?: InputMaybe<Scalars['Date']['input']>;
  hidden?: InputMaybe<Scalars['Boolean']['input']>;
  hiddenExpiresAt?: InputMaybe<Scalars['Date']['input']>;
  isAlerted?: InputMaybe<Scalars['Boolean']['input']>;
  lastModifiedBy?: InputMaybe<Scalars['String']['input']>;
  packageTag?: InputMaybe<Scalars['String']['input']>;
  scheduledDate?: InputMaybe<Scalars['Date']['input']>;
  title?: InputMaybe<Scalars['String']['input']>;
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationUpdatePostByTenantArgs = {
  post: UpdatePostInput;
  tenant: Tenant;
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationUpdateStandaloneContentModuleArgs = {
  allowedCountries?: InputMaybe<Array<InputMaybe<Scalars['String']['input']>>>;
  channels?: InputMaybe<Array<InputMaybe<TagComponent>>>;
  commentsEnabled?: InputMaybe<Scalars['Boolean']['input']>;
  contentId?: InputMaybe<Scalars['ID']['input']>;
  contentType?: InputMaybe<ContentModuleType>;
  description?: InputMaybe<Scalars['String']['input']>;
  expiresAt?: InputMaybe<Scalars['Date']['input']>;
  hidden?: InputMaybe<Scalars['Boolean']['input']>;
  hiddenExpiresAt?: InputMaybe<Scalars['Date']['input']>;
  id: Scalars['ID']['input'];
  isAlerted?: InputMaybe<Scalars['Boolean']['input']>;
  lastModifiedBy?: InputMaybe<Scalars['String']['input']>;
  scheduledDate?: InputMaybe<Scalars['Date']['input']>;
  thumbnail?: InputMaybe<Scalars['String']['input']>;
  thumbnailAccreditation?: InputMaybe<Scalars['String']['input']>;
  thumbnailCopyright?: InputMaybe<Scalars['String']['input']>;
  title?: InputMaybe<Scalars['String']['input']>;
  updateProgrammingTimestamp?: InputMaybe<Scalars['Boolean']['input']>;
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationUpdateTextPollByTenantArgs = {
  poll: UpdateTextPollInput;
  tenant: Tenant;
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationUpdateUserTagsArgs = {
  inputs: Array<InputMaybe<UserTagInput>>;
  tenant: Tenant;
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationUpsertPackageContentModulesArgs = {
  contents?: InputMaybe<Array<InputMaybe<PackageContent>>>;
  delete?: InputMaybe<Array<Scalars['ID']['input']>>;
  packages?: InputMaybe<Array<InputMaybe<PackageInput>>>;
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationUpsertStandaloneContentModulesArgs = {
  data: Array<ContentModuleInput>;
  delete?: InputMaybe<Array<Scalars['ID']['input']>>;
};


/** TEST Mutate the Hydration Station Social Entities */
export type MutationUpsertVideoStateArgs = {
  data: VideoMetadataInput;
};

export type Name = {
  __typename?: 'Name';
  display_name?: Maybe<Scalars['String']['output']>;
  first?: Maybe<Scalars['String']['output']>;
  last?: Maybe<Scalars['String']['output']>;
};

export type NavigationElement = {
  __typename?: 'NavigationElement';
  /** @deprecated Use queryParameters instead */
  href?: Maybe<Scalars['String']['output']>;
  name?: Maybe<Scalars['String']['output']>;
  queryParameters?: Maybe<NavigationQueryParameters>;
};

export type NavigationQueryParameters = {
  __typename?: 'NavigationQueryParameters';
  date?: Maybe<Scalars['String']['output']>;
  league?: Maybe<StatsLeagues>;
};

export type NewPushNotification = {
  /** Add ad parameters */
  adParameters?: InputMaybe<Scalars['String']['input']>;
  /** This is the alert type to know which category it falls into */
  alertCategories: Array<InputMaybe<AlertCategory>>;
  /** This would be a list of the allowed regions the alert can be sent to */
  allowInRegions: Array<AlertRegion>;
  /** Provides a list of genres for Analytics, cannot be null, needs at least one */
  analytics: AlertAnalyticsInput;
  /** These are the list of the attachments related to the alert */
  attachments: Array<AlertMediaAttachmentInput>;
  /** This is the ID of the user that created the alert */
  createdBy: Scalars['ID']['input'];
  /**
   * This would be an override destination. If provided, all users will receive this common destination.
   * Otherwise, the users will receive the destination included with the tagId they are subscribed to which
   * is included in the destinations list above. The String is the contentModule ID.
   */
  destinationOverride?: InputMaybe<Scalars['String']['input']>;
  /** This would keep track of the places the alert will be going to */
  destinations: Array<AlertDestinationInput>;
  /** Mobile uses to show alert card */
  showAlertCard?: InputMaybe<Scalars['Boolean']['input']>;
  /** This will let us know if it is a spoiler or not */
  spoiler?: InputMaybe<Scalars['Boolean']['input']>;
  /** Push Notification's text message */
  text?: InputMaybe<Scalars['String']['input']>;
  /** Push Notification's title message */
  title?: InputMaybe<Scalars['String']['input']>;
  /** Url of content, could be null */
  url?: InputMaybe<Scalars['String']['input']>;
};

export type NotificationInput = {
  id: Category;
  notificationMethods?: InputMaybe<Array<InputMaybe<NotificationMethodInput>>>;
};

export type NotificationMethod = {
  __typename?: 'NotificationMethod';
  enabled?: Maybe<Scalars['Boolean']['output']>;
  type?: Maybe<CategoryType>;
};

export type NotificationMethodInput = {
  enabled: Scalars['Boolean']['input'];
  type: CategoryType;
};

export type Notifications = {
  __typename?: 'Notifications';
  enabled?: Maybe<Scalars['Boolean']['output']>;
  id?: Maybe<Category>;
  notificationMethods?: Maybe<Array<Maybe<NotificationMethod>>>;
};

export type Offering = {
  __typename?: 'Offering';
  actions?: Maybe<Action>;
  alternateIds?: Maybe<Array<Maybe<Identifier>>>;
  appNames?: Maybe<VideoAppName>;
  brands?: Maybe<Array<Maybe<Brand>>>;
  contentClass?: Maybe<Scalars['String']['output']>;
  contentId?: Maybe<Scalars['String']['output']>;
  createdDateTime?: Maybe<Scalars['String']['output']>;
  editId?: Maybe<Scalars['String']['output']>;
  endDate?: Maybe<Scalars['String']['output']>;
  firstAvailableDate?: Maybe<Scalars['String']['output']>;
  id?: Maybe<Scalars['String']['output']>;
  lastModifiedDateTime?: Maybe<Scalars['String']['output']>;
  limitations?: Maybe<Limitation>;
  packages?: Maybe<Array<Maybe<Scalars['String']['output']>>>;
  platforms?: Maybe<AllowAll>;
  productLines?: Maybe<Array<Maybe<ProductLine>>>;
  startDate?: Maybe<Scalars['String']['output']>;
  territories?: Maybe<Array<Maybe<Scalars['String']['output']>>>;
};

export type PackageContent = {
  allowedCountries?: InputMaybe<Array<InputMaybe<Scalars['String']['input']>>>;
  contentId?: InputMaybe<Scalars['ID']['input']>;
  contentModuleId?: InputMaybe<Scalars['ID']['input']>;
  contentType?: InputMaybe<ContentModuleType>;
  description: Scalars['String']['input'];
  expiresAt?: InputMaybe<Scalars['Date']['input']>;
  hidden?: InputMaybe<Scalars['Boolean']['input']>;
  hiddenExpiresAt?: InputMaybe<Scalars['Date']['input']>;
  isPositionLocked?: InputMaybe<Scalars['Boolean']['input']>;
  orientation?: InputMaybe<ModuleOrientation>;
  position?: InputMaybe<Scalars['Int']['input']>;
  positionLockExpiresAt?: InputMaybe<Scalars['Date']['input']>;
  scheduledDate?: InputMaybe<Scalars['Date']['input']>;
  thumbnail: Scalars['String']['input'];
  thumbnailAccreditation?: InputMaybe<Scalars['String']['input']>;
  thumbnailCopyright?: InputMaybe<Scalars['String']['input']>;
  title: Scalars['String']['input'];
  updateProgrammingTimestamp?: InputMaybe<Scalars['Boolean']['input']>;
};

export type PackageContentModule = ContentModule & {
  __typename?: 'PackageContentModule';
  /** Ads Configuration | Ads API */
  adsConfig?: Maybe<AdsConfiguration>;
  alertRanks: Array<Maybe<AlertRank>>;
  /** Indicates to what tagUUID the content module was alerted to. */
  alertedChannelTagUUID?: Maybe<Scalars['String']['output']>;
  /** List of countries that a content module will be visible. */
  allowedCountries?: Maybe<Array<Maybe<Scalars['String']['output']>>>;
  commentsEnabled?: Maybe<Scalars['Boolean']['output']>;
  /** List of Channels/Components (tag + semanticID) a content module is programmed to. */
  components?: Maybe<Array<Maybe<ComponentModule>>>;
  /** Type of the content that will be accepted by the package. */
  contentType?: Maybe<ContentModuleType>;
  /** List of contents of the package. */
  contents?: Maybe<Array<Maybe<StandaloneContentModule>>>;
  /** Also known as Commentary, short description of the content of a content module. */
  description: Scalars['String']['output'];
  /** Date and Time when a content module will not be visible anymore for end users. The state will be `UNPROGRAMMED`. */
  expiresAt?: Maybe<Scalars['Date']['output']>;
  hidden?: Maybe<Scalars['Boolean']['output']>;
  /** Date and Time when a hidden content module will automatically become visible again. */
  hiddenExpiresAt?: Maybe<Scalars['Date']['output']>;
  id: Scalars['ID']['output'];
  /** Date and time that the Content Modules was created */
  insertedAt?: Maybe<Scalars['Date']['output']>;
  /** Indicates if a push notification was sent to the content module. */
  isAlerted?: Maybe<Scalars['Boolean']['output']>;
  /** Metadata containing community tag, author, and brand information for logos and display. */
  metaData?: Maybe<ModuleMetaData>;
  /** Content module orientation, one of: Landscape or Portrait */
  orientation: ModuleOrientation;
  /** Package headline for the content module */
  packageHeadline?: Maybe<Scalars['String']['output']>;
  /** packageTag of composite data */
  packageTag?: Maybe<Scalars['String']['output']>;
  /** Type of the package, defines if a package is one of the static package or ad hoc. */
  packageType?: Maybe<PackageType>;
  /** Date and Time when a content module will start to be visible for end users. The state will be `SCHEDULED`. */
  scheduledDate?: Maybe<Scalars['Date']['output']>;
  /** List of possible states of content module. One of `SCHEDULED`, `PROGRAMMED` or `UNPROGRAMMED`. */
  state?: Maybe<ModuleState>;
  /** Also known as Headline, that's the heading text of a content module. */
  title: Scalars['String']['output'];
  /** Unique title for the package content module */
  uniqueTitle?: Maybe<Scalars['String']['output']>;
  /** Date and time that a content module was last updated. */
  updatedAt?: Maybe<Scalars['Date']['output']>;
};


export type PackageContentModuleAlertRanksArgs = {
  limit?: InputMaybe<Scalars['Int']['input']>;
};

export type PackageInput = {
  allowedCountries?: InputMaybe<Array<InputMaybe<Scalars['String']['input']>>>;
  channels: Array<TagComponent>;
  commentsEnabled?: InputMaybe<Scalars['Boolean']['input']>;
  contentModuleId?: InputMaybe<Scalars['ID']['input']>;
  contentType: ContentModuleType;
  description?: InputMaybe<Scalars['String']['input']>;
  expiresAt?: InputMaybe<Scalars['Date']['input']>;
  hidden?: InputMaybe<Scalars['Boolean']['input']>;
  hiddenExpiresAt?: InputMaybe<Scalars['Date']['input']>;
  lastModifiedBy: Scalars['String']['input'];
  packageHeadline?: InputMaybe<Scalars['String']['input']>;
  packageTag?: InputMaybe<Scalars['String']['input']>;
  packageType?: InputMaybe<PackageType>;
  scheduledDate?: InputMaybe<Scalars['Date']['input']>;
  title: Scalars['String']['input'];
  uniqueTitle?: InputMaybe<Scalars['String']['input']>;
};

export enum PackageType {
  AdHoc = 'AdHoc',
  CreatorShows = 'CreatorShows',
  FromTheFans = 'FromTheFans',
  Highlights = 'Highlights',
  HomeLandscape = 'HomeLandscape',
  HomePortrait = 'HomePortrait',
  TopHeadlines = 'TopHeadlines',
  TrendingBets = 'TrendingBets',
  TrendingVideos = 'TrendingVideos',
  WhatsBuzzing = 'WhatsBuzzing'
}

export type Page = {
  __typename?: 'Page';
  _id: Scalars['MongoID']['output'];
  /** Ads Configuration | Ads API */
  adsConfig?: Maybe<AdsConfiguration>;
  body?: Maybe<PageBody>;
  changed?: Maybe<Scalars['String']['output']>;
  cmsId: Scalars['String']['output'];
  /** @deprecated This field will be removed. Please use the "componentsConnection" field which provides support for component pagination */
  components?: Maybe<Array<Maybe<Component>>>;
  componentsConnection: ComponentsConnection;
  created?: Maybe<Scalars['String']['output']>;
  headline?: Maybe<Scalars['String']['output']>;
  isPublished?: Maybe<Scalars['Boolean']['output']>;
  language?: Maybe<Scalars['String']['output']>;
  metatags?: Maybe<Array<Maybe<PageMetatags>>>;
  schemaVersion?: Maybe<Scalars['String']['output']>;
  tenant?: Maybe<Scalars['String']['output']>;
  title?: Maybe<Scalars['String']['output']>;
  type?: Maybe<Scalars['String']['output']>;
  uri: Scalars['String']['output'];
  uuid: Scalars['String']['output'];
};


export type PageComponentsConnectionArgs = {
  after?: InputMaybe<Scalars['ComponentCursor']['input']>;
  before?: InputMaybe<Scalars['ComponentCursor']['input']>;
  first?: InputMaybe<Scalars['Int']['input']>;
  last?: InputMaybe<Scalars['Int']['input']>;
};

export type PageBody = {
  __typename?: 'PageBody';
  _id?: Maybe<Scalars['MongoID']['output']>;
  format?: Maybe<Scalars['String']['output']>;
  summary?: Maybe<Scalars['String']['output']>;
  value?: Maybe<Scalars['String']['output']>;
};

export type PageComponentFiltersInput = {
  /** Filter Page Components by a User's favorite Team. Value passed should be **sportradar_id** (ex. `sr:competitor:1234`) */
  team?: InputMaybe<Scalars['String']['input']>;
};

/**   PageInfo in this context provides metadata for **pagination** It is not related to the Page type. */
export type PageInfo = {
  __typename?: 'PageInfo';
  endCursor?: Maybe<Scalars['String']['output']>;
  hasNextPage?: Maybe<Scalars['Boolean']['output']>;
  hasPreviousPage?: Maybe<Scalars['Boolean']['output']>;
  startCursor?: Maybe<Scalars['String']['output']>;
};

export type PageMetatags = {
  __typename?: 'PageMetatags';
  _id?: Maybe<Scalars['MongoID']['output']>;
  content?: Maybe<Scalars['String']['output']>;
  key?: Maybe<Scalars['String']['output']>;
  type?: Maybe<Scalars['String']['output']>;
};

export type PaginationControl = {
  after?: InputMaybe<Scalars['ContentCursor']['input']>;
  before?: InputMaybe<Scalars['ContentCursor']['input']>;
  first?: InputMaybe<Scalars['Int']['input']>;
  last?: InputMaybe<Scalars['Int']['input']>;
  semanticId: Scalars['String']['input'];
};

export type PaginationControlInput = {
  after?: InputMaybe<Scalars['ComponentCursor']['input']>;
  before?: InputMaybe<Scalars['ComponentCursor']['input']>;
  first?: InputMaybe<Scalars['Int']['input']>;
  last?: InputMaybe<Scalars['Int']['input']>;
};

export type PeriodScore = {
  __typename?: 'PeriodScore';
  /** Number of the period - potentially used in conjunction with `type` for constructing a column header ("Set 1") */
  number?: Maybe<Scalars['Int']['output']>;
  /** Primary Score Value */
  score?: Maybe<Scalars['String']['output']>;
  /** Secondary Score Value (example: tiebreaks in tennis) */
  subscore?: Maybe<Scalars['String']['output']>;
  /** Type of period - will vary by sport */
  type?: Maybe<PeriodScoreType>;
};

export enum PeriodScoreType {
  TennisSet = 'TennisSet'
}

export type Playlist = {
  __typename?: 'Playlist';
  _id: Scalars['MongoID']['output'];
  changed?: Maybe<Scalars['String']['output']>;
  cmsId: Scalars['String']['output'];
  created?: Maybe<Scalars['String']['output']>;
  headline?: Maybe<Scalars['String']['output']>;
  isPublished?: Maybe<Scalars['Boolean']['output']>;
  language?: Maybe<Scalars['String']['output']>;
  media?: Maybe<Array<Maybe<Media>>>;
  schemaVersion?: Maybe<Scalars['String']['output']>;
  tagging?: Maybe<Tagging>;
  tenant?: Maybe<Scalars['String']['output']>;
  title?: Maybe<Scalars['String']['output']>;
  type?: Maybe<Scalars['String']['output']>;
  uuid: Scalars['String']['output'];
};

export type Poll = {
  __typename?: 'Poll';
  contentId: Scalars['ID']['output'];
  id: Scalars['ID']['output'];
};

export type Post = {
  __typename?: 'Post';
  content: Scalars['String']['output'];
  contentId?: Maybe<Scalars['ID']['output']>;
  id: Scalars['ID']['output'];
};

export type PostInput = {
  content: Scalars['String']['input'];
  tagUUIDs: Array<Scalars['String']['input']>;
  uploadId?: InputMaybe<Scalars['ID']['input']>;
};

export type PrepareImageResponse = {
  __typename?: 'PrepareImageResponse';
  errorMsg?: Maybe<Scalars['String']['output']>;
  uploadId: Scalars['ID']['output'];
  urlMappings: Array<UrlMapping>;
};

export type Product = {
  __typename?: 'Product';
  _id?: Maybe<Scalars['MongoID']['output']>;
  cta?: Maybe<Scalars['String']['output']>;
  disclaimer?: Maybe<Scalars['String']['output']>;
  headline?: Maybe<Scalars['String']['output']>;
  isPayPalEnabled?: Maybe<Scalars['Boolean']['output']>;
  price?: Maybe<Scalars['String']['output']>;
  productId?: Maybe<Scalars['String']['output']>;
  subHeadline?: Maybe<Scalars['String']['output']>;
  weight?: Maybe<Scalars['Float']['output']>;
};

export type ProductLine = {
  __typename?: 'ProductLine';
  id?: Maybe<Identifier>;
  label?: Maybe<Scalars['String']['output']>;
};

export type Program = {
  __typename?: 'Program';
  alternateIds?: Maybe<Array<Maybe<Identifier>>>;
  createdDateTime?: Maybe<Scalars['String']['output']>;
  credits?: Maybe<Array<Maybe<Credit>>>;
  entityClass?: Maybe<Scalars['String']['output']>;
  entityType?: Maybe<Scalars['String']['output']>;
  id?: Maybe<Scalars['String']['output']>;
  lastModifiedDateTime?: Maybe<Scalars['String']['output']>;
  ratings?: Maybe<Array<Maybe<Rating>>>;
  taxonomyReferenceGroups?: Maybe<Array<Maybe<TaxonomyReferenceGroup>>>;
  titles?: Maybe<Array<Maybe<VideoTitle>>>;
};

export type ProgrammedContent = Article | ExternalArticle | StatsBetting | StatsGamecast | Tweet | UgcImagePoll | UgcPost | UgcTextPoll | VideoV2;

export type PushNotification = {
  __typename?: 'PushNotification';
  /** Add ad parameters */
  adParameters?: Maybe<Scalars['String']['output']>;
  /** This is the alert type to know which category it falls into */
  alertCategories: Array<AlertCategory>;
  /** This would be a list of the allowed regions the alert can be sent to */
  allowInRegions: Array<AlertRegion>;
  /** Provides a list of genres for Analytics, cannot be null, needs at least one */
  analytics?: Maybe<AlertAnalytics>;
  /** These are the list of the attachments related to the alert */
  attachments: Array<AlertMediaAttachment>;
  /** When Push Notification was created at */
  createdAt: Scalars['DateTime']['output'];
  /** This is the ID of the user that created the alert */
  createdBy: Scalars['ID']['output'];
  /**
   * This would be an override destination. If provided, all users will receive this common destination.
   * Otherwise, the users will receive the destination included with the tagId they are subscribed to which
   * is included in the destinations list above. The String is the contentModule ID.
   */
  destinationOverride?: Maybe<Scalars['String']['output']>;
  /** This would keep track of the places the alert will be going to */
  destinations: Array<AlertDestination>;
  /** Push Notification ID */
  id: Scalars['ID']['output'];
  /** Mobile uses to show alert card */
  showAlertCard?: Maybe<Scalars['Boolean']['output']>;
  /** This will let us know if it is a spoiler or not */
  spoiler?: Maybe<Scalars['Boolean']['output']>;
  /** The tag ids that will receive the Push Notification */
  tags: Array<TagV2>;
  /** Push Notification's text message */
  text: Scalars['String']['output'];
  /** Push Notification's title */
  title: Scalars['String']['output'];
  url: Scalars['String']['output'];
  /** The resolved destination for an individual alert instance sent to a specific user */
  userDestination?: Maybe<UserDestination>;
};

export type PushNotificationAlertRankInput = {
  alertRanks?: InputMaybe<Array<AlertRankInput>>;
};

export type PushNotificationAlertRankResponse = {
  __typename?: 'PushNotificationAlertRankResponse';
  message?: Maybe<Scalars['String']['output']>;
  status: Scalars['String']['output'];
};

/** TEST Query the Hydration Station Social Entities */
export type Query = {
  __typename?: 'Query';
  a2a: Array<A2AResult>;
  a2v: Array<A2VResult>;
  alertRanks: Array<AlertRank>;
  articleBlocklist: Array<BlockedContent>;
  contentModules?: Maybe<Array<Maybe<ContentModule>>>;
  dsModel?: Maybe<DsModel>;
  fetchContentModuleByContentIdAndContentType: Array<Maybe<ContentModule>>;
  fetchContentModuleById?: Maybe<ContentModule>;
  fetchPackageByTypeAndTag?: Maybe<Array<Maybe<PackageContentModule>>>;
  fetchScheduledModules?: Maybe<Array<Maybe<ContentModule>>>;
  /** findContentBrandBySourceUrl | CMS API */
  findContentBrandBySourceUrl?: Maybe<ContentBrand>;
  findContentModulesBySemanticIdAndTag?: Maybe<Array<Maybe<ContentModule>>>;
  findPackageByTitle?: Maybe<Array<Maybe<PackageContentModule>>>;
  /** search for a tag by name or fragment. it is recommended (but not enforced) to provide at least 3 characters */
  findTagByMatchTerm: Array<Tag>;
  /** getAllArticles | CMS API */
  getAllArticles?: Maybe<ArticleConnection>;
  /** getAllCompetitors | Will be deprecated February 01, 2023 | Use getCompetitorList */
  getAllCompetitors?: Maybe<Array<Maybe<Competitor>>>;
  /** getAllConferences | Will be deprecated February 01, 2023 | Use getConferenceList */
  getAllConferences?: Maybe<Array<Maybe<Conference>>>;
  /** getAllDivisions | Will be deprecated February 01, 2023 | Use getDivisionList */
  getAllDivisions?: Maybe<Array<Maybe<Division>>>;
  /** getAllEvents | Will be deprecated February 01, 2023 | Use getEventList */
  getAllEvents?: Maybe<Array<Maybe<Event>>>;
  /** getAllLeagues | Will be deprecated February 01, 2023 | Use getLeagueList */
  getAllLeagues?: Maybe<Array<Maybe<League>>>;
  /** getAllMenus | CMS API */
  getAllMenus?: Maybe<Array<Maybe<Menu>>>;
  /** Get all push notifications. */
  getAllNotifications: Array<PushNotification>;
  /** getAllPlaylists | CMS API */
  getAllPlaylists?: Maybe<Array<Maybe<Playlist>>>;
  /** getAllSeries | Will be deprecated February 01, 2023 | Use getSeriesList */
  getAllSeries?: Maybe<Array<Maybe<Series>>>;
  /** getAllSports | Will be deprecated February 01, 2023 | Use getSportList */
  getAllSports?: Maybe<Array<Maybe<Sport>>>;
  getAllTeamsByPermalink: Array<Tag>;
  /** getAllTournaments | Will be deprecated February 01, 2023 | Use getTournamentList */
  getAllTournaments?: Maybe<Array<Maybe<Tournament>>>;
  /** getAllVenues | To be deprecated December, 2022 */
  getAllVenues?: Maybe<Array<Maybe<Venue>>>;
  /** getAllVideos | CMS API */
  getAllVideos?: Maybe<Array<Maybe<Video>>>;
  /** getAllVideosV2 | CMS API */
  getAllVideosV2?: Maybe<Array<Maybe<VideoV2>>>;
  /** getArticleByCmsId | CMS API */
  getArticleByCmsId?: Maybe<Article>;
  /** getArticleByDisplayId | CMS API */
  getArticleByDisplayId?: Maybe<Article>;
  /** getArticleBySlug | CMS API */
  getArticleBySlug?: Maybe<Article>;
  /** getArticleByUUID | CMS API */
  getArticleByUUID?: Maybe<Article>;
  getBlockedUsers?: Maybe<Array<Maybe<User>>>;
  /** getChannelByCmsId | CMS API */
  getChannelByCmsId?: Maybe<Channel>;
  /** getChannelBySlug | CMS API */
  getChannelBySlug?: Maybe<Channel>;
  /** getChannelByTagUUID | CMS API */
  getChannelByTagUUID?: Maybe<Channel>;
  /** getChannelByUUID | CMS API */
  getChannelByUUID?: Maybe<Channel>;
  /** getCompetitorById | Event API | LET API */
  getCompetitorById?: Maybe<Competitor>;
  /** getCompetitorList | Event API | LET API */
  getCompetitorList?: Maybe<Competitors>;
  /** getConferenceById | Event API | LET API */
  getConferenceById?: Maybe<Conference>;
  /** getConferenceList | Event API | LET API */
  getConferenceList?: Maybe<Conferences>;
  /** getConfigJsonByUri | CMS API */
  getConfigJsonByUri?: Maybe<ConfigJson>;
  /** Returns contentModuleIds that have been push notifications associated with them. */
  getContentModuleIdsWithPushNotificationIds?: Maybe<Array<Scalars['Int']['output']>>;
  /** getDivisionById | Event API | LET API */
  getDivisionById?: Maybe<Division>;
  /** getDivisionList | Event API | LET API */
  getDivisionList?: Maybe<Divisions>;
  /** getEventById | Event API | LET API */
  getEventById?: Maybe<Event>;
  /** getEventList | Event API | LET API */
  getEventList?: Maybe<Events>;
  /** getGameCastByTagUUID | Stats API | Statmilk API */
  getGameCastByTagUUID?: Maybe<StatsGamecast>;
  /** getGameCastBySlug | Stats API | Statmilk API */
  getGamecastBySlug?: Maybe<StatsGamecast>;
  /** getGamesByGameDate | Stat API | Statmilk API */
  getGamesByGameDate?: Maybe<Array<Maybe<Game>>>;
  /** getGamesByGameIds | Stat API | Statmilk API */
  getGamesByGameIds?: Maybe<Array<Maybe<Game>>>;
  /** getGamesBySportRadarIds | Stat API | Statmilk API */
  getGamesBySportRadarIds?: Maybe<Array<Maybe<Game>>>;
  /** @deprecated No longer needed */
  getHelloWorld?: Maybe<Scalars['String']['output']>;
  /** getLeagueById | Event API | LET API */
  getLeagueById?: Maybe<League>;
  /** getLeagueList | Event API | LET API */
  getLeagueList?: Maybe<Leagues>;
  getMediaId?: Maybe<Scalars['String']['output']>;
  /** getMenuById | CMS API */
  getMenuById?: Maybe<Menu>;
  getMetadata?: Maybe<Metadata>;
  /** getPageByUri | CMS API */
  getPageByUri?: Maybe<Page>;
  /** getPlaylistByCmsId | CMS API */
  getPlaylistByCmsId?: Maybe<Playlist>;
  /** getPlaylistByEventId | CMS API */
  getPlaylistByEventId?: Maybe<Playlist>;
  /** getPlaylistById | CMS API */
  getPlaylistById?: Maybe<Playlist>;
  /** Get one push notification by id. */
  getPushNotificationById?: Maybe<PushNotification>;
  /** Grab reference stream by name with optional limit */
  getReferenceStreamByComponentId?: Maybe<ReferenceStream>;
  /**
   * Grab references by name with optional limit
   * @deprecated Use `getReferenceStreamByComponentId` instead.
   */
  getReferenceStreamByName?: Maybe<Array<Reference>>;
  /** getSchedule | Stats API | Statmilk API */
  getSchedule?: Maybe<StatsSchedule>;
  /** getScheduleByFeeds | Episode API | EPG API */
  getScheduleByFeeds?: Maybe<Schedule>;
  /** getScores | Stat API | Statmilk API */
  getScores?: Maybe<Scores>;
  /** getSeriesById | Event API | LET API */
  getSeriesById?: Maybe<Series>;
  /** getSeriesList | Event API | LET API */
  getSeriesList?: Maybe<Serieses>;
  getSiteMap: Tag;
  /** getSportById | Event API | LET API */
  getSportById?: Maybe<Sport>;
  /** getSportList | Event API | LET API */
  getSportList?: Maybe<Sports>;
  /** getStandings | Stats API | Statmilk API */
  getStandings?: Maybe<StatsStanding>;
  /** getTagByForeignId | CMS API */
  getTagByForeignId?: Maybe<TagV2>;
  /** getTagByForeignIds | CMS API */
  getTagByForeignIds?: Maybe<Array<Maybe<TagV2>>>;
  getTagById: Tag;
  /** getTagBySlugs | CMS API */
  getTagBySlugs?: Maybe<Array<Maybe<TagV2>>>;
  /** getTagByUUID | CMS API */
  getTagByUUID?: Maybe<TagV2>;
  /** getTagGroupByUUID | CMS API */
  getTagGroupByUUID?: Maybe<TagGroup>;
  /** getTagGroupsBySlugs | CMS API */
  getTagGroupsBySlugs?: Maybe<Array<Maybe<TagGroup>>>;
  getTagsByPermalinks?: Maybe<Array<Maybe<Tag>>>;
  /** getTaxonomyByIdAndType | CMS API */
  getTaxonomyByIdAndType?: Maybe<TaxonomyTerm>;
  /** getTournamentById | Event API | LET API */
  getTournamentById?: Maybe<Tournament>;
  /** getTournamentList | Event API | LET API */
  getTournamentList?: Maybe<Tournaments>;
  /** TEST Query for fetching Tweets from Hydration Station no used in Production Clients ONLY DEV */
  getTweetsByIds: Array<Tweet>;
  getUser?: Maybe<User>;
  /** Get the User's Push Notifications */
  getUserPushNotifications: Array<PushNotification>;
  /** getVenueById | Event API | LET API */
  getVenueById?: Maybe<Venue>;
  /** getVenueList | Event API | LET API | Includes Pagination (Use instead of getAllVenues) */
  getVenueList?: Maybe<Venues>;
  /** getVideoByCmsId | CMS API */
  getVideoByCmsId?: Maybe<Video>;
  /** getVideoById | CMS API */
  getVideoById?: Maybe<Video>;
  /** getVideoV2ByCmsId | CMS API */
  getVideoV2ByCmsId?: Maybe<VideoV2>;
  /** getVideoV2ByEditId | CMS API */
  getVideoV2ByEditId?: Maybe<VideoV2>;
  /** getVideoV2ById | CMS API */
  getVideoV2ById?: Maybe<VideoV2>;
  /**
   * getVideoV2TagIdsFromEventIds | CMS API
   * @deprecated No longer in use
   */
  getVideoV2TagIdsFromEventIds?: Maybe<Array<VideoV2TagIds>>;
  /** getVideosByEventId | CMS API */
  getVideosByEventId?: Maybe<Array<Maybe<Video>>>;
  /** getVideosByTeamId | CMS API */
  getVideosByTeamId?: Maybe<Array<Maybe<Video>>>;
  getWbdContext?: Maybe<Scalars['String']['output']>;
  /**  Get a Alert widget by ID  */
  liveLikeAlert?: Maybe<LiveLikeAlert>;
  liveLikeApplication?: Maybe<LiveLikeApplication>;
  liveLikeBadge?: Maybe<LiveLikeBadge>;
  liveLikeBadgeProfiles?: Maybe<LiveLikeBadgeProfileCollection>;
  liveLikeBadgeProgress?: Maybe<Array<LiveLikeBadgeRewardProgressCollection>>;
  liveLikeBadges?: Maybe<LiveLikeBadgeCollection>;
  liveLikeBlockedProfileIds?: Maybe<Array<Scalars['UUID']['output']>>;
  liveLikeChatRoom?: Maybe<LiveLikeChatRoom>;
  liveLikeChatRooms?: Maybe<LiveLikeChatRoomCollection>;
  liveLikeComment?: Maybe<LiveLikeComment>;
  liveLikeCommentBoard?: Maybe<LiveLikeCommentBoard>;
  liveLikeCommentBoardBan?: Maybe<LiveLikeCommentBoardBan>;
  liveLikeCommentBoardBans?: Maybe<LiveLikeCommentBoardBanCollection>;
  liveLikeCommentBoards?: Maybe<LiveLikeCommentBoardCollection>;
  liveLikeCommentBoardsCount?: Maybe<Array<LiveLikeCommentBoardCount>>;
  liveLikeCommentReplies?: Maybe<LiveLikeCommentCollection>;
  liveLikeCommentReport?: Maybe<LiveLikeCommentReport>;
  liveLikeComments?: Maybe<LiveLikeCommentCollection>;
  liveLikeCommentsReports?: Maybe<LiveLikeCommentReportCollection>;
  liveLikeEarnedBadges?: Maybe<LiveLikeEarnedBadgeCollection>;
  liveLikeImagePoll?: Maybe<LiveLikeImagePoll>;
  /**
   * Fetch the image prediction widget with the id.
   * Returns the ImagePrediction object.
   */
  liveLikeImagePrediction?: Maybe<LiveLikeImagePrediction>;
  /**
   * Fetch the image prediction follow up widget with the id.
   * Returns the ImagePredictionFollowUp object.
   */
  liveLikeImagePredictionFollowUp?: Maybe<LiveLikeImagePredictionFollowUp>;
  /**
   * Fetch the image quiz widget with the id.
   * Returns the ImageQuiz object.
   */
  liveLikeImageQuiz?: Maybe<LiveLikeImageQuiz>;
  liveLikeLeaderboard?: Maybe<LiveLikeLeaderboard>;
  liveLikeLeaderboardEntries?: Maybe<LiveLikeLeaderboardEntryCollection>;
  liveLikeLeaderboardEntry?: Maybe<LiveLikeLeaderboardEntry>;
  liveLikeLeaderboards?: Maybe<LiveLikeLeaderboardCollection>;
  liveLikeMe?: Maybe<LiveLikeProfile>;
  liveLikePermissions?: Maybe<LiveLikePermissions>;
  liveLikeProfile?: Maybe<LiveLikeProfile>;
  liveLikeProfileByCustomId?: Maybe<LiveLikeProfile>;
  liveLikeProfileRelationshipType?: Maybe<LiveLikeProfileRelationshipType>;
  liveLikeProfileRelationshipTypes?: Maybe<LiveLikeProfileRelationshipTypeCollection>;
  liveLikeProfileRelationships?: Maybe<LiveLikeProfileRelationshipCollection>;
  liveLikeProgram?: Maybe<LiveLikeProgram>;
  liveLikeProgramBans?: Maybe<LiveLikeProgramBanCollection>;
  liveLikeProgramByCustomId?: Maybe<LiveLikeProgram>;
  liveLikePrograms?: Maybe<LiveLikeProgramConnection>;
  liveLikeQuests?: Maybe<LiveLikeQuestCollection>;
  liveLikeReactionPack?: Maybe<LiveLikeReactionPack>;
  liveLikeReactionPacks?: Maybe<LiveLikeReactionPackCollection>;
  liveLikeReactionSpace?: Maybe<LiveLikeReactionSpace>;
  liveLikeReactionSpaces?: Maybe<LiveLikeReactionSpaceCollection>;
  liveLikeReactionSpacesCount?: Maybe<Array<LiveLikeReactionSpaceCount>>;
  liveLikeRewardBalance?: Maybe<LiveLikeRewardItemBalance>;
  liveLikeRewardBalances?: Maybe<LiveLikeRewardItemBalanceCollection>;
  liveLikeRewardItem?: Maybe<LiveLikeRewardItem>;
  liveLikeRewardItems?: Maybe<LiveLikeRewardItemCollection>;
  liveLikeRewardTable?: Maybe<LiveLikeRewardTable>;
  liveLikeRewardTableEntry?: Maybe<LiveLikeRewardTableEntry>;
  liveLikeRewardTables?: Maybe<LiveLikeRewardTableCollection>;
  liveLikeRichPost?: Maybe<LiveLikeRichPost>;
  liveLikeRoles?: Maybe<LiveLikeRoleConnection>;
  liveLikeRolesAssignment?: Maybe<LiveLikeRoleAssignmentConnection>;
  /**  Get a Social Embed widget by ID  */
  liveLikeSocialEmbed?: Maybe<LiveLikeSocialEmbed>;
  liveLikeTextPoll?: Maybe<LiveLikeTextPoll>;
  /**
   * Fetch the text prediction widget with the id.
   * Returns the TextPrediction object.
   */
  liveLikeTextPrediction?: Maybe<LiveLikeTextPrediction>;
  /**
   * Fetch the text prediction follow up widget with the id.
   * Returns the TextPredictionFollowUp object.
   */
  liveLikeTextPredictionFollowUp?: Maybe<LiveLikeTextPredictionFollowUp>;
  /**
   * Fetch the text quiz widget with the id.
   * Returns the TextQuiz object.
   */
  liveLikeTextQuiz?: Maybe<LiveLikeTextQuiz>;
  liveLikeUserBadges?: Maybe<LiveLikeUserBadgeCollection>;
  liveLikeUserQuestRewards?: Maybe<LiveLikeUserQuestRewardsConnection>;
  liveLikeUserQuests?: Maybe<LiveLikeUserQuestCollection>;
  liveLikeUserReactionCounts?: Maybe<LiveLikeUserReactionCountCollection>;
  liveLikeUserReactions?: Maybe<LiveLikeUserReactionCollection>;
  /**  Get a Video Alert widget by ID  */
  liveLikeVideoAlert?: Maybe<LiveLikeVideoAlert>;
  liveLikeWidgetReports?: Maybe<LiveLikeWidgetReportCollection>;
  liveLikeWidgets?: Maybe<LiveLikeWidgetCollection>;
  liveLikeWidgetsInteractions?: Maybe<Array<LiveLikeWidgetInteractions>>;
  /** @deprecated This query will soon be removed in favor of paginated version of findContentModulesBySemanticIdAndTag */
  paginatedFindContentModulesBySemanticIdAndTag?: Maybe<ContentsConnection>;
  popularSearches: QueryAssistResponse;
  search: SearchResults;
  /** searchContentLibrary | CMS API */
  searchContentLibrary?: Maybe<Array<Maybe<ContentLibrarySearchResult>>>;
  /** searchTagByMatchTerm | CMS API */
  searchTagByMatchTerm: Array<TagV2>;
  /** tags | CMS API */
  tags?: Maybe<TagV2Connection>;
  test: Scalars['String']['output'];
  trendingArticles: Array<TrendingResult>;
  trendingChannels: Array<TrendingChannelResult>;
  trendingVideos: Array<TrendingResult>;
  typeAhead: QueryAssistResponse;
  v2v: Array<V2VResult>;
  videoBlocklist: Array<BlockedContent>;
};


/** TEST Query the Hydration Station Social Entities */
export type QueryA2aArgs = {
  articleUuid: Scalars['String']['input'];
  limit?: InputMaybe<Scalars['Int']['input']>;
  primaryPrioritizedTag?: InputMaybe<Scalars['String']['input']>;
  secondaryPrioritizedTags?: Array<Scalars['String']['input']>;
  version?: InputMaybe<Scalars['Int']['input']>;
};


/** TEST Query the Hydration Station Social Entities */
export type QueryA2vArgs = {
  articleUuid: Scalars['String']['input'];
  aspectRatio?: InputMaybe<AspectRatio>;
  countryCode?: InputMaybe<Scalars['String']['input']>;
  limit?: InputMaybe<Scalars['Int']['input']>;
  primaryPrioritizedTag?: InputMaybe<Scalars['String']['input']>;
  secondaryPrioritizedTags?: Array<Scalars['String']['input']>;
  version?: InputMaybe<Scalars['Int']['input']>;
};


/** TEST Query the Hydration Station Social Entities */
export type QueryAlertRanksArgs = {
  limit?: InputMaybe<Scalars['Int']['input']>;
  offset?: InputMaybe<Scalars['Int']['input']>;
};


/** TEST Query the Hydration Station Social Entities */
export type QueryArticleBlocklistArgs = {
  beforeDate?: InputMaybe<Scalars['Date']['input']>;
  limit?: InputMaybe<Scalars['Int']['input']>;
  sinceDate?: InputMaybe<Scalars['Date']['input']>;
};


/** TEST Query the Hydration Station Social Entities */
export type QueryDsModelArgs = {
  model: Scalars['String']['input'];
};


/** TEST Query the Hydration Station Social Entities */
export type QueryFetchContentModuleByContentIdAndContentTypeArgs = {
  contentId: Scalars['ID']['input'];
  contentType: Scalars['String']['input'];
  state?: InputMaybe<Array<InputMaybe<ModuleState>>>;
};


/** TEST Query the Hydration Station Social Entities */
export type QueryFetchContentModuleByIdArgs = {
  id: Scalars['ID']['input'];
};


/** TEST Query the Hydration Station Social Entities */
export type QueryFetchPackageByTypeAndTagArgs = {
  packageType: Scalars['String']['input'];
  state?: InputMaybe<Array<InputMaybe<ModuleState>>>;
  tagUUID: Scalars['String']['input'];
};


/** TEST Query the Hydration Station Social Entities */
export type QueryFetchScheduledModulesArgs = {
  endDate?: InputMaybe<Scalars['Date']['input']>;
  limit?: InputMaybe<Scalars['Int']['input']>;
  startDate?: InputMaybe<Scalars['Date']['input']>;
};


/** TEST Query the Hydration Station Social Entities */
export type QueryFindContentBrandBySourceUrlArgs = {
  publishedOnly?: InputMaybe<Scalars['Boolean']['input']>;
  source: Scalars['String']['input'];
  tenant: Tenant;
};


/** TEST Query the Hydration Station Social Entities */
export type QueryFindContentModulesBySemanticIdAndTagArgs = {
  limit?: InputMaybe<Scalars['Int']['input']>;
  semanticID?: InputMaybe<SemanticId>;
  state?: InputMaybe<Array<InputMaybe<ModuleState>>>;
  tagSlug?: InputMaybe<Scalars['String']['input']>;
  tagUUID?: InputMaybe<Scalars['String']['input']>;
};


/** TEST Query the Hydration Station Social Entities */
export type QueryFindPackageByTitleArgs = {
  state?: InputMaybe<Array<InputMaybe<ModuleState>>>;
  title?: InputMaybe<Scalars['String']['input']>;
};


/** TEST Query the Hydration Station Social Entities */
export type QueryFindTagByMatchTermArgs = {
  tenant: Tenant;
  term: Scalars['String']['input'];
};


/** TEST Query the Hydration Station Social Entities */
export type QueryGetAllArticlesArgs = {
  after?: InputMaybe<Scalars['String']['input']>;
  before?: InputMaybe<Scalars['String']['input']>;
  limit?: InputMaybe<Scalars['Int']['input']>;
  publishedOnly?: InputMaybe<Scalars['Boolean']['input']>;
  searchParams?: InputMaybe<ArticleFindManyParametersInput>;
  skip?: InputMaybe<Scalars['Int']['input']>;
  sort?: InputMaybe<ContentLibrarySortParametersInput>;
  tenant: Tenant;
};


/** TEST Query the Hydration Station Social Entities */
export type QueryGetAllCompetitorsArgs = {
  has_media?: InputMaybe<Scalars['Boolean']['input']>;
  tenant: Tenants;
  territories?: InputMaybe<Territories>;
};


/** TEST Query the Hydration Station Social Entities */
export type QueryGetAllConferencesArgs = {
  tenant: Tenants;
};


/** TEST Query the Hydration Station Social Entities */
export type QueryGetAllDivisionsArgs = {
  tenant: Tenants;
};


/** TEST Query the Hydration Station Social Entities */
export type QueryGetAllEventsArgs = {
  count_end?: InputMaybe<Scalars['String']['input']>;
  count_start?: InputMaybe<Scalars['String']['input']>;
  end_date?: InputMaybe<Scalars['String']['input']>;
  filterId?: InputMaybe<Array<InputMaybe<EventFilterType>>>;
  has_media?: InputMaybe<Scalars['Boolean']['input']>;
  media_filter?: InputMaybe<Scalars['String']['input']>;
  order?: InputMaybe<SortDirections>;
  season?: InputMaybe<Scalars['Int']['input']>;
  sort?: InputMaybe<EventSort>;
  start_date?: InputMaybe<Scalars['String']['input']>;
  tenant: Tenants;
  territories?: InputMaybe<Territories>;
  type?: InputMaybe<EventTypes>;
};


/** TEST Query the Hydration Station Social Entities */
export type QueryGetAllLeaguesArgs = {
  has_media?: InputMaybe<Scalars['Boolean']['input']>;
  tenant: Tenants;
  territories?: InputMaybe<Territories>;
};


/** TEST Query the Hydration Station Social Entities */
export type QueryGetAllMenusArgs = {
  publishedOnly?: InputMaybe<Scalars['Boolean']['input']>;
  tenant: Tenant;
};


/** TEST Query the Hydration Station Social Entities */
export type QueryGetAllNotificationsArgs = {
  lastPushNotificationId?: InputMaybe<Scalars['Int']['input']>;
  latestUnixTimestamp?: InputMaybe<Scalars['Int']['input']>;
  limit?: InputMaybe<Scalars['Int']['input']>;
  tenant: Tenant;
};


/** TEST Query the Hydration Station Social Entities */
export type QueryGetAllPlaylistsArgs = {
  publishedOnly?: InputMaybe<Scalars['Boolean']['input']>;
  tenant: Tenant;
};


/** TEST Query the Hydration Station Social Entities */
export type QueryGetAllSeriesArgs = {
  competitor_id?: InputMaybe<Scalars['String']['input']>;
  has_media?: InputMaybe<Scalars['Boolean']['input']>;
  order?: InputMaybe<SortDirections>;
  season?: InputMaybe<Scalars['String']['input']>;
  sort?: InputMaybe<SeriesSort>;
  tenant: Tenants;
  territories?: InputMaybe<Territories>;
  tournament_id?: InputMaybe<Scalars['String']['input']>;
};


/** TEST Query the Hydration Station Social Entities */
export type QueryGetAllSportsArgs = {
  tenant: Tenants;
};


/** TEST Query the Hydration Station Social Entities */
export type QueryGetAllTeamsByPermalinkArgs = {
  permalink: Scalars['String']['input'];
  tenant: Tenant;
};


/** TEST Query the Hydration Station Social Entities */
export type QueryGetAllTournamentsArgs = {
  has_media?: InputMaybe<Scalars['Boolean']['input']>;
  tenant: Tenants;
  territories?: InputMaybe<Territories>;
};


/** TEST Query the Hydration Station Social Entities */
export type QueryGetAllVenuesArgs = {
  tenant: Tenants;
};


/** TEST Query the Hydration Station Social Entities */
export type QueryGetAllVideosArgs = {
  limit?: InputMaybe<Scalars['Int']['input']>;
  order?: InputMaybe<Scalars['String']['input']>;
  publishedOnly?: InputMaybe<Scalars['Boolean']['input']>;
  skip?: InputMaybe<Scalars['Int']['input']>;
  tenant: Tenant;
  videoFilters?: InputMaybe<VideoFiltersInput>;
};


/** TEST Query the Hydration Station Social Entities */
export type QueryGetAllVideosV2Args = {
  contentType?: InputMaybe<VideoContentType>;
  playable?: InputMaybe<Scalars['Boolean']['input']>;
  publishedOnly?: InputMaybe<Scalars['Boolean']['input']>;
  tag?: InputMaybe<Scalars['String']['input']>;
  tenant: Tenant;
  videoType?: InputMaybe<VideoType>;
};


/** TEST Query the Hydration Station Social Entities */
export type QueryGetArticleByCmsIdArgs = {
  cmsId?: InputMaybe<Scalars['String']['input']>;
  publishedOnly?: InputMaybe<Scalars['Boolean']['input']>;
  tenant: Tenant;
};


/** TEST Query the Hydration Station Social Entities */
export type QueryGetArticleByDisplayIdArgs = {
  displayId: Scalars['Int']['input'];
  publishedOnly?: InputMaybe<Scalars['Boolean']['input']>;
  tenant: Tenant;
};


/** TEST Query the Hydration Station Social Entities */
export type QueryGetArticleBySlugArgs = {
  publishedOnly?: InputMaybe<Scalars['Boolean']['input']>;
  slug?: InputMaybe<Scalars['String']['input']>;
  tenant: Tenant;
};


/** TEST Query the Hydration Station Social Entities */
export type QueryGetArticleByUuidArgs = {
  publishedOnly?: InputMaybe<Scalars['Boolean']['input']>;
  tenant: Tenant;
  uuid?: InputMaybe<Scalars['String']['input']>;
};


/** TEST Query the Hydration Station Social Entities */
export type QueryGetChannelByCmsIdArgs = {
  cmsId?: InputMaybe<Scalars['String']['input']>;
  publishedOnly?: InputMaybe<Scalars['Boolean']['input']>;
  tenant: Tenant;
};


/** TEST Query the Hydration Station Social Entities */
export type QueryGetChannelBySlugArgs = {
  publishedOnly?: InputMaybe<Scalars['Boolean']['input']>;
  slug: Scalars['String']['input'];
  tenant: Tenant;
};


/** TEST Query the Hydration Station Social Entities */
export type QueryGetChannelByTagUuidArgs = {
  publishedOnly?: InputMaybe<Scalars['Boolean']['input']>;
  tagUUID: Scalars['String']['input'];
  tenant: Tenant;
};


/** TEST Query the Hydration Station Social Entities */
export type QueryGetChannelByUuidArgs = {
  publishedOnly?: InputMaybe<Scalars['Boolean']['input']>;
  tenant: Tenant;
  uuid: Scalars['String']['input'];
};


/** TEST Query the Hydration Station Social Entities */
export type QueryGetCompetitorByIdArgs = {
  id: Scalars['String']['input'];
  tenant: Tenants;
};


/** TEST Query the Hydration Station Social Entities */
export type QueryGetCompetitorListArgs = {
  count_end?: InputMaybe<Scalars['Int']['input']>;
  count_start?: InputMaybe<Scalars['Int']['input']>;
  has_media?: InputMaybe<Scalars['Boolean']['input']>;
  tenant: Tenants;
  territories?: InputMaybe<Territories>;
};


/** TEST Query the Hydration Station Social Entities */
export type QueryGetConferenceByIdArgs = {
  id: Scalars['String']['input'];
  tenant: Tenants;
};


/** TEST Query the Hydration Station Social Entities */
export type QueryGetConferenceListArgs = {
  count_end?: InputMaybe<Scalars['Int']['input']>;
  count_start?: InputMaybe<Scalars['Int']['input']>;
  tenant: Tenants;
};


/** TEST Query the Hydration Station Social Entities */
export type QueryGetConfigJsonByUriArgs = {
  publishedOnly?: InputMaybe<Scalars['Boolean']['input']>;
  tenant: Tenant;
  uri: Scalars['String']['input'];
};


/** TEST Query the Hydration Station Social Entities */
export type QueryGetContentModuleIdsWithPushNotificationIdsArgs = {
  contentModuleIds: Array<Scalars['String']['input']>;
  tenant: Tenant;
};


/** TEST Query the Hydration Station Social Entities */
export type QueryGetDivisionByIdArgs = {
  id: Scalars['String']['input'];
  tenant: Tenants;
};


/** TEST Query the Hydration Station Social Entities */
export type QueryGetDivisionListArgs = {
  count_end?: InputMaybe<Scalars['Int']['input']>;
  count_start?: InputMaybe<Scalars['Int']['input']>;
  tenant: Tenants;
};


/** TEST Query the Hydration Station Social Entities */
export type QueryGetEventByIdArgs = {
  id: Scalars['String']['input'];
  isSportRadar?: InputMaybe<Scalars['Boolean']['input']>;
  tenant: Tenants;
};


/** TEST Query the Hydration Station Social Entities */
export type QueryGetEventListArgs = {
  count_end?: InputMaybe<Scalars['String']['input']>;
  count_start?: InputMaybe<Scalars['String']['input']>;
  end_date?: InputMaybe<Scalars['String']['input']>;
  filterId?: InputMaybe<Array<InputMaybe<EventFilterType>>>;
  has_media?: InputMaybe<Scalars['Boolean']['input']>;
  media_filter?: InputMaybe<Scalars['String']['input']>;
  order?: InputMaybe<SortDirections>;
  season?: InputMaybe<Scalars['Int']['input']>;
  sort?: InputMaybe<EventSort>;
  start_date?: InputMaybe<Scalars['String']['input']>;
  tenant: Tenants;
  territories?: InputMaybe<Territories>;
  type?: InputMaybe<EventTypes>;
};


/** TEST Query the Hydration Station Social Entities */
export type QueryGetGameCastByTagUuidArgs = {
  uuid: Scalars['String']['input'];
};


/** TEST Query the Hydration Station Social Entities */
export type QueryGetGamecastBySlugArgs = {
  slug: Scalars['String']['input'];
};


/** TEST Query the Hydration Station Social Entities */
export type QueryGetGamesByGameDateArgs = {
  endDate: Scalars['String']['input'];
  leagues?: InputMaybe<Array<InputMaybe<StatsLeagues>>>;
  sortOrder?: InputMaybe<SortOrder>;
  startDate: Scalars['String']['input'];
  stateStatus?: InputMaybe<Array<InputMaybe<StateStatus>>>;
  status?: InputMaybe<Array<InputMaybe<Status>>>;
  timezone: Scalars['Int']['input'];
};


/** TEST Query the Hydration Station Social Entities */
export type QueryGetGamesByGameIdsArgs = {
  gameIds: Array<InputMaybe<Scalars['String']['input']>>;
};


/** TEST Query the Hydration Station Social Entities */
export type QueryGetGamesBySportRadarIdsArgs = {
  gameIds: Array<InputMaybe<Scalars['String']['input']>>;
};


/** TEST Query the Hydration Station Social Entities */
export type QueryGetLeagueByIdArgs = {
  id: Scalars['String']['input'];
  tenant: Tenants;
};


/** TEST Query the Hydration Station Social Entities */
export type QueryGetLeagueListArgs = {
  count_end?: InputMaybe<Scalars['Int']['input']>;
  count_start?: InputMaybe<Scalars['Int']['input']>;
  has_media?: InputMaybe<Scalars['Boolean']['input']>;
  tenant: Tenants;
  territories?: InputMaybe<Territories>;
};


/** TEST Query the Hydration Station Social Entities */
export type QueryGetMediaIdArgs = {
  id?: InputMaybe<Scalars['String']['input']>;
};


/** TEST Query the Hydration Station Social Entities */
export type QueryGetMenuByIdArgs = {
  id?: InputMaybe<Scalars['String']['input']>;
  publishedOnly?: InputMaybe<Scalars['Boolean']['input']>;
  tenant: Tenant;
};


/** TEST Query the Hydration Station Social Entities */
export type QueryGetPageByUriArgs = {
  componentFilters?: InputMaybe<PageComponentFiltersInput>;
  publishedOnly?: InputMaybe<Scalars['Boolean']['input']>;
  tenant: Tenant;
  uri: Scalars['String']['input'];
};


/** TEST Query the Hydration Station Social Entities */
export type QueryGetPlaylistByCmsIdArgs = {
  cmsId?: InputMaybe<Scalars['String']['input']>;
  publishedOnly?: InputMaybe<Scalars['Boolean']['input']>;
  tenant: Tenant;
};


/** TEST Query the Hydration Station Social Entities */
export type QueryGetPlaylistByEventIdArgs = {
  eventId?: InputMaybe<Scalars['String']['input']>;
  publishedOnly?: InputMaybe<Scalars['Boolean']['input']>;
  tenant: Tenant;
};


/** TEST Query the Hydration Station Social Entities */
export type QueryGetPlaylistByIdArgs = {
  id?: InputMaybe<Scalars['String']['input']>;
  publishedOnly?: InputMaybe<Scalars['Boolean']['input']>;
  tenant: Tenant;
};


/** TEST Query the Hydration Station Social Entities */
export type QueryGetPushNotificationByIdArgs = {
  id: Scalars['ID']['input'];
  tenant: Tenant;
};


/** TEST Query the Hydration Station Social Entities */
export type QueryGetReferenceStreamByComponentIdArgs = {
  componentID: Scalars['String']['input'];
  limit?: InputMaybe<Scalars['Int']['input']>;
};


/** TEST Query the Hydration Station Social Entities */
export type QueryGetReferenceStreamByNameArgs = {
  limit?: InputMaybe<Scalars['Int']['input']>;
  referenceStreamName: Scalars['String']['input'];
};


/** TEST Query the Hydration Station Social Entities */
export type QueryGetScheduleArgs = {
  season?: InputMaybe<Scalars['Int']['input']>;
  slug: Scalars['String']['input'];
  timezone?: InputMaybe<Scalars['Int']['input']>;
};


/** TEST Query the Hydration Station Social Entities */
export type QueryGetScheduleByFeedsArgs = {
  count?: InputMaybe<Scalars['Int']['input']>;
  feed: Feeds;
  from?: InputMaybe<Scalars['String']['input']>;
  to?: InputMaybe<Scalars['String']['input']>;
};


/** TEST Query the Hydration Station Social Entities */
export type QueryGetScoresArgs = {
  context?: InputMaybe<Scalars['String']['input']>;
  date?: InputMaybe<Scalars['String']['input']>;
  league?: InputMaybe<StatsLeagues>;
  locale?: InputMaybe<Scalars['String']['input']>;
  slugs?: InputMaybe<Array<InputMaybe<Scalars['String']['input']>>>;
  tags?: InputMaybe<Array<InputMaybe<Scalars['Int']['input']>>>;
  timezone: Scalars['Int']['input'];
};


/** TEST Query the Hydration Station Social Entities */
export type QueryGetSeriesByIdArgs = {
  id: Scalars['String']['input'];
  tenant: Tenants;
};


/** TEST Query the Hydration Station Social Entities */
export type QueryGetSeriesListArgs = {
  competitor_id?: InputMaybe<Scalars['String']['input']>;
  count_end?: InputMaybe<Scalars['Int']['input']>;
  count_start?: InputMaybe<Scalars['Int']['input']>;
  has_media?: InputMaybe<Scalars['Boolean']['input']>;
  order?: InputMaybe<SortDirections>;
  season?: InputMaybe<Scalars['String']['input']>;
  sort?: InputMaybe<SeriesSort>;
  tenant: Tenants;
  territories?: InputMaybe<Territories>;
  tournament_id?: InputMaybe<Scalars['String']['input']>;
};


/** TEST Query the Hydration Station Social Entities */
export type QueryGetSiteMapArgs = {
  client: Scalars['String']['input'];
  permalink: Scalars['String']['input'];
  tenant: Tenant;
};


/** TEST Query the Hydration Station Social Entities */
export type QueryGetSportByIdArgs = {
  id: Scalars['String']['input'];
  tenant: Tenants;
};


/** TEST Query the Hydration Station Social Entities */
export type QueryGetSportListArgs = {
  count_end?: InputMaybe<Scalars['Int']['input']>;
  count_start?: InputMaybe<Scalars['Int']['input']>;
  tenant: Tenants;
};


/** TEST Query the Hydration Station Social Entities */
export type QueryGetStandingsArgs = {
  permalink: Scalars['String']['input'];
  season?: InputMaybe<Scalars['Int']['input']>;
};


/** TEST Query the Hydration Station Social Entities */
export type QueryGetTagByForeignIdArgs = {
  foreignId: Scalars['String']['input'];
  publishedOnly?: InputMaybe<Scalars['Boolean']['input']>;
  tenant: Tenant;
};


/** TEST Query the Hydration Station Social Entities */
export type QueryGetTagByForeignIdsArgs = {
  foreignIds: Array<Scalars['String']['input']>;
  publishedOnly?: InputMaybe<Scalars['Boolean']['input']>;
  tenant: Tenant;
};


/** TEST Query the Hydration Station Social Entities */
export type QueryGetTagByIdArgs = {
  id: Scalars['ID']['input'];
  tenant: Tenant;
};


/** TEST Query the Hydration Station Social Entities */
export type QueryGetTagBySlugsArgs = {
  publishedOnly?: InputMaybe<Scalars['Boolean']['input']>;
  slugs: Array<Scalars['String']['input']>;
  tenant: Tenant;
};


/** TEST Query the Hydration Station Social Entities */
export type QueryGetTagByUuidArgs = {
  publishedOnly?: InputMaybe<Scalars['Boolean']['input']>;
  tenant: Tenant;
  uuid: Scalars['String']['input'];
};


/** TEST Query the Hydration Station Social Entities */
export type QueryGetTagGroupByUuidArgs = {
  publishedOnly?: InputMaybe<Scalars['Boolean']['input']>;
  tenant: Tenant;
  uuid: Scalars['String']['input'];
};


/** TEST Query the Hydration Station Social Entities */
export type QueryGetTagGroupsBySlugsArgs = {
  publishedOnly?: InputMaybe<Scalars['Boolean']['input']>;
  slugs: Array<Scalars['String']['input']>;
  tenant: Tenant;
};


/** TEST Query the Hydration Station Social Entities */
export type QueryGetTagsByPermalinksArgs = {
  permalinks: Array<Scalars['String']['input']>;
  tenant: Tenant;
};


/** TEST Query the Hydration Station Social Entities */
export type QueryGetTaxonomyByIdAndTypeArgs = {
  id: Scalars['String']['input'];
  publishedOnly?: InputMaybe<Scalars['Boolean']['input']>;
  tenant: Tenant;
  type: TaxonomyType;
};


/** TEST Query the Hydration Station Social Entities */
export type QueryGetTournamentByIdArgs = {
  id: Scalars['String']['input'];
  tenant: Tenants;
};


/** TEST Query the Hydration Station Social Entities */
export type QueryGetTournamentListArgs = {
  count_end?: InputMaybe<Scalars['Int']['input']>;
  count_start?: InputMaybe<Scalars['Int']['input']>;
  has_media?: InputMaybe<Scalars['Boolean']['input']>;
  tenant: Tenants;
  territories?: InputMaybe<Territories>;
};


/** TEST Query the Hydration Station Social Entities */
export type QueryGetTweetsByIdsArgs = {
  ids: Array<Scalars['ID']['input']>;
};


/** TEST Query the Hydration Station Social Entities */
export type QueryGetUserArgs = {
  profileId?: InputMaybe<Scalars['String']['input']>;
  tenant: Tenant;
};


/** TEST Query the Hydration Station Social Entities */
export type QueryGetUserPushNotificationsArgs = {
  limit?: InputMaybe<Scalars['Int']['input']>;
  tenant: Tenant;
};


/** TEST Query the Hydration Station Social Entities */
export type QueryGetVenueByIdArgs = {
  id: Scalars['String']['input'];
  tenant: Tenants;
};


/** TEST Query the Hydration Station Social Entities */
export type QueryGetVenueListArgs = {
  count_end?: InputMaybe<Scalars['Int']['input']>;
  count_start?: InputMaybe<Scalars['Int']['input']>;
  tenant: Tenants;
};


/** TEST Query the Hydration Station Social Entities */
export type QueryGetVideoByCmsIdArgs = {
  cmsId?: InputMaybe<Scalars['String']['input']>;
  limit?: InputMaybe<Scalars['Int']['input']>;
  publishedOnly?: InputMaybe<Scalars['Boolean']['input']>;
  skip?: InputMaybe<Scalars['Int']['input']>;
  tenant: Tenant;
};


/** TEST Query the Hydration Station Social Entities */
export type QueryGetVideoByIdArgs = {
  id?: InputMaybe<Scalars['String']['input']>;
  publishedOnly?: InputMaybe<Scalars['Boolean']['input']>;
  tenant: Tenant;
};


/** TEST Query the Hydration Station Social Entities */
export type QueryGetVideoV2ByCmsIdArgs = {
  cmsId?: InputMaybe<Scalars['String']['input']>;
  publishedOnly?: InputMaybe<Scalars['Boolean']['input']>;
  tenant: Tenant;
};


/** TEST Query the Hydration Station Social Entities */
export type QueryGetVideoV2ByEditIdArgs = {
  editId: Scalars['String']['input'];
  publishedOnly?: InputMaybe<Scalars['Boolean']['input']>;
  tenant: Tenant;
};


/** TEST Query the Hydration Station Social Entities */
export type QueryGetVideoV2ByIdArgs = {
  eventId: Scalars['String']['input'];
  publishedOnly?: InputMaybe<Scalars['Boolean']['input']>;
  tenant: Tenant;
};


/** TEST Query the Hydration Station Social Entities */
export type QueryGetVideoV2TagIdsFromEventIdsArgs = {
  eventIds: Array<Scalars['String']['input']>;
  publishedOnly?: InputMaybe<Scalars['Boolean']['input']>;
  tenant: Tenant;
};


/** TEST Query the Hydration Station Social Entities */
export type QueryGetVideosByEventIdArgs = {
  eventId?: InputMaybe<Scalars['String']['input']>;
  limit?: InputMaybe<Scalars['Int']['input']>;
  order?: InputMaybe<Scalars['String']['input']>;
  publishedOnly?: InputMaybe<Scalars['Boolean']['input']>;
  skip?: InputMaybe<Scalars['Int']['input']>;
  tenant: Tenant;
};


/** TEST Query the Hydration Station Social Entities */
export type QueryGetVideosByTeamIdArgs = {
  limit?: InputMaybe<Scalars['Int']['input']>;
  order?: InputMaybe<Scalars['String']['input']>;
  publishedOnly?: InputMaybe<Scalars['Boolean']['input']>;
  skip?: InputMaybe<Scalars['Int']['input']>;
  teamId?: InputMaybe<Scalars['String']['input']>;
  tenant: Tenant;
};


/** TEST Query the Hydration Station Social Entities */
export type QueryLiveLikeAlertArgs = {
  id: Scalars['UUID']['input'];
};


/** TEST Query the Hydration Station Social Entities */
export type QueryLiveLikeApplicationArgs = {
  clientId: Scalars['NonEmptyString']['input'];
};


/** TEST Query the Hydration Station Social Entities */
export type QueryLiveLikeBadgeArgs = {
  id: Scalars['UUID']['input'];
};


/** TEST Query the Hydration Station Social Entities */
export type QueryLiveLikeBadgeProfilesArgs = {
  badgeId: Scalars['UUID']['input'];
};


/** TEST Query the Hydration Station Social Entities */
export type QueryLiveLikeBadgeProgressArgs = {
  badgeId: Scalars['UUID']['input'];
  profileId: Scalars['UUID']['input'];
};


/** TEST Query the Hydration Station Social Entities */
export type QueryLiveLikeBadgesArgs = {
  clientId: Scalars['NonEmptyString']['input'];
};


/** TEST Query the Hydration Station Social Entities */
export type QueryLiveLikeChatRoomArgs = {
  id: Scalars['UUID']['input'];
};


/** TEST Query the Hydration Station Social Entities */
export type QueryLiveLikeChatRoomsArgs = {
  input: LiveLikeChatRoomsGetInput;
};


/** TEST Query the Hydration Station Social Entities */
export type QueryLiveLikeCommentArgs = {
  id: Scalars['UUID']['input'];
};


/** TEST Query the Hydration Station Social Entities */
export type QueryLiveLikeCommentBoardArgs = {
  id: Scalars['UUID']['input'];
};


/** TEST Query the Hydration Station Social Entities */
export type QueryLiveLikeCommentBoardBanArgs = {
  id: Scalars['UUID']['input'];
};


/** TEST Query the Hydration Station Social Entities */
export type QueryLiveLikeCommentBoardBansArgs = {
  input?: InputMaybe<LiveLikeCommentBoardBansInput>;
};


/** TEST Query the Hydration Station Social Entities */
export type QueryLiveLikeCommentBoardsArgs = {
  input: LiveLikeCommentBoardsGetInput;
};


/** TEST Query the Hydration Station Social Entities */
export type QueryLiveLikeCommentBoardsCountArgs = {
  input: LiveLikeCommentBoardsCountGetInput;
};


/** TEST Query the Hydration Station Social Entities */
export type QueryLiveLikeCommentRepliesArgs = {
  input: LiveLikeCommentRepliesGetInput;
};


/** TEST Query the Hydration Station Social Entities */
export type QueryLiveLikeCommentReportArgs = {
  id: Scalars['UUID']['input'];
};


/** TEST Query the Hydration Station Social Entities */
export type QueryLiveLikeCommentsArgs = {
  input: LiveLikeCommentsGetInput;
};


/** TEST Query the Hydration Station Social Entities */
export type QueryLiveLikeCommentsReportsArgs = {
  input: LiveLikeCommentsReportsGetInput;
};


/** TEST Query the Hydration Station Social Entities */
export type QueryLiveLikeEarnedBadgesArgs = {
  profileId: Scalars['UUID']['input'];
};


/** TEST Query the Hydration Station Social Entities */
export type QueryLiveLikeImagePollArgs = {
  id: Scalars['UUID']['input'];
};


/** TEST Query the Hydration Station Social Entities */
export type QueryLiveLikeImagePredictionArgs = {
  id: Scalars['UUID']['input'];
};


/** TEST Query the Hydration Station Social Entities */
export type QueryLiveLikeImagePredictionFollowUpArgs = {
  id: Scalars['UUID']['input'];
};


/** TEST Query the Hydration Station Social Entities */
export type QueryLiveLikeImageQuizArgs = {
  id: Scalars['UUID']['input'];
};


/** TEST Query the Hydration Station Social Entities */
export type QueryLiveLikeLeaderboardArgs = {
  id: Scalars['UUID']['input'];
};


/** TEST Query the Hydration Station Social Entities */
export type QueryLiveLikeLeaderboardEntriesArgs = {
  input: LiveLikeLeaderboardEntriesGetInput;
};


/** TEST Query the Hydration Station Social Entities */
export type QueryLiveLikeLeaderboardEntryArgs = {
  input: LiveLikeLeaderboardEntryGetInput;
};


/** TEST Query the Hydration Station Social Entities */
export type QueryLiveLikeLeaderboardsArgs = {
  input: LiveLikeLeaderboardsGetInput;
};


/** TEST Query the Hydration Station Social Entities */
export type QueryLiveLikePermissionsArgs = {
  page?: InputMaybe<Scalars['PositiveInt']['input']>;
};


/** TEST Query the Hydration Station Social Entities */
export type QueryLiveLikeProfileArgs = {
  id: Scalars['UUID']['input'];
};


/** TEST Query the Hydration Station Social Entities */
export type QueryLiveLikeProfileByCustomIdArgs = {
  input: LiveLikeProfileGetByCustomIdInput;
};


/** TEST Query the Hydration Station Social Entities */
export type QueryLiveLikeProfileRelationshipTypeArgs = {
  id: Scalars['UUID']['input'];
};


/** TEST Query the Hydration Station Social Entities */
export type QueryLiveLikeProfileRelationshipTypesArgs = {
  input: LiveLikeProfileRelationshipTypesInput;
};


/** TEST Query the Hydration Station Social Entities */
export type QueryLiveLikeProfileRelationshipsArgs = {
  input: LiveLikeProfileRelationshipInput;
  order?: InputMaybe<LiveLikeProfileRelationshipOrderInput>;
};


/** TEST Query the Hydration Station Social Entities */
export type QueryLiveLikeProgramArgs = {
  id: Scalars['UUID']['input'];
};


/** TEST Query the Hydration Station Social Entities */
export type QueryLiveLikeProgramBansArgs = {
  input?: InputMaybe<LiveLikeProgramBansInput>;
};


/** TEST Query the Hydration Station Social Entities */
export type QueryLiveLikeProgramByCustomIdArgs = {
  input: LiveLikeProgramGetByCustomIdInput;
};


/** TEST Query the Hydration Station Social Entities */
export type QueryLiveLikeProgramsArgs = {
  input: LiveLikeProgramsGetInput;
};


/** TEST Query the Hydration Station Social Entities */
export type QueryLiveLikeQuestsArgs = {
  clientId: Scalars['NonEmptyString']['input'];
};


/** TEST Query the Hydration Station Social Entities */
export type QueryLiveLikeReactionPackArgs = {
  id: Scalars['UUID']['input'];
};


/** TEST Query the Hydration Station Social Entities */
export type QueryLiveLikeReactionPacksArgs = {
  input: LiveLikeReactionPacksGetInput;
};


/** TEST Query the Hydration Station Social Entities */
export type QueryLiveLikeReactionSpaceArgs = {
  id: Scalars['UUID']['input'];
};


/** TEST Query the Hydration Station Social Entities */
export type QueryLiveLikeReactionSpacesArgs = {
  input: LiveLikeReactionSpaceGetInput;
};


/** TEST Query the Hydration Station Social Entities */
export type QueryLiveLikeReactionSpacesCountArgs = {
  input: LiveLikeReactionSpacesCountInput;
};


/** TEST Query the Hydration Station Social Entities */
export type QueryLiveLikeRewardBalanceArgs = {
  input: LiveLikeRewardBalanceGetInput;
  profileId: Scalars['UUID']['input'];
};


/** TEST Query the Hydration Station Social Entities */
export type QueryLiveLikeRewardBalancesArgs = {
  input?: InputMaybe<LiveLikeRewardBalancesGetInput>;
  profileId: Scalars['UUID']['input'];
};


/** TEST Query the Hydration Station Social Entities */
export type QueryLiveLikeRewardItemArgs = {
  id: Scalars['UUID']['input'];
};


/** TEST Query the Hydration Station Social Entities */
export type QueryLiveLikeRewardItemsArgs = {
  clientId: Scalars['NonEmptyString']['input'];
};


/** TEST Query the Hydration Station Social Entities */
export type QueryLiveLikeRewardTableArgs = {
  id: Scalars['UUID']['input'];
};


/** TEST Query the Hydration Station Social Entities */
export type QueryLiveLikeRewardTableEntryArgs = {
  input: LiveLikeRewardTableEntryGetInput;
};


/** TEST Query the Hydration Station Social Entities */
export type QueryLiveLikeRewardTablesArgs = {
  input: LiveLikeRewardTablesGetInput;
};


/** TEST Query the Hydration Station Social Entities */
export type QueryLiveLikeRichPostArgs = {
  id: Scalars['UUID']['input'];
};


/** TEST Query the Hydration Station Social Entities */
export type QueryLiveLikeRolesArgs = {
  input: LiveLikeRolesGetInput;
};


/** TEST Query the Hydration Station Social Entities */
export type QueryLiveLikeRolesAssignmentArgs = {
  input: LiveLikeRoleAssignmentsGetInput;
};


/** TEST Query the Hydration Station Social Entities */
export type QueryLiveLikeSocialEmbedArgs = {
  id: Scalars['UUID']['input'];
};


/** TEST Query the Hydration Station Social Entities */
export type QueryLiveLikeTextPollArgs = {
  id: Scalars['UUID']['input'];
};


/** TEST Query the Hydration Station Social Entities */
export type QueryLiveLikeTextPredictionArgs = {
  id: Scalars['UUID']['input'];
};


/** TEST Query the Hydration Station Social Entities */
export type QueryLiveLikeTextPredictionFollowUpArgs = {
  id: Scalars['UUID']['input'];
};


/** TEST Query the Hydration Station Social Entities */
export type QueryLiveLikeTextQuizArgs = {
  id: Scalars['UUID']['input'];
};


/** TEST Query the Hydration Station Social Entities */
export type QueryLiveLikeUserBadgesArgs = {
  page?: InputMaybe<Scalars['PositiveInt']['input']>;
};


/** TEST Query the Hydration Station Social Entities */
export type QueryLiveLikeUserQuestRewardsArgs = {
  input: LiveLikeUserQuestRewardsInput;
};


/** TEST Query the Hydration Station Social Entities */
export type QueryLiveLikeUserQuestsArgs = {
  input?: InputMaybe<LiveLikeUserQuestsInput>;
  profileId: Scalars['UUID']['input'];
};


/** TEST Query the Hydration Station Social Entities */
export type QueryLiveLikeUserReactionCountsArgs = {
  input: LiveLikeUserReactionCountsGetInput;
};


/** TEST Query the Hydration Station Social Entities */
export type QueryLiveLikeUserReactionsArgs = {
  input: LiveLikeUserReactionsGetInput;
};


/** TEST Query the Hydration Station Social Entities */
export type QueryLiveLikeVideoAlertArgs = {
  id: Scalars['UUID']['input'];
};


/** TEST Query the Hydration Station Social Entities */
export type QueryLiveLikeWidgetReportsArgs = {
  input?: InputMaybe<LiveLikeWidgetReportsInput>;
};


/** TEST Query the Hydration Station Social Entities */
export type QueryLiveLikeWidgetsArgs = {
  input?: InputMaybe<LiveLikeWidgetGetInput>;
  order?: InputMaybe<LiveLikeWidgetOrderInput>;
  programId: Scalars['UUID']['input'];
};


/** TEST Query the Hydration Station Social Entities */
export type QueryLiveLikeWidgetsInteractionsArgs = {
  input: Array<LiveLikeWidgetInteractionsInput>;
  profileId: Scalars['UUID']['input'];
};


/** TEST Query the Hydration Station Social Entities */
export type QueryPaginatedFindContentModulesBySemanticIdAndTagArgs = {
  after?: InputMaybe<Scalars['ContentCursor']['input']>;
  before?: InputMaybe<Scalars['ContentCursor']['input']>;
  first?: InputMaybe<Scalars['Int']['input']>;
  last?: InputMaybe<Scalars['Int']['input']>;
  semanticID?: InputMaybe<SemanticId>;
  state?: InputMaybe<Array<InputMaybe<ModuleState>>>;
  tagUUID?: InputMaybe<Scalars['String']['input']>;
};


/** TEST Query the Hydration Station Social Entities */
export type QueryPopularSearchesArgs = {
  filterTerms?: InputMaybe<Scalars['String']['input']>;
  first?: InputMaybe<Scalars['Int']['input']>;
  tenant: Tenant;
};


/** TEST Query the Hydration Station Social Entities */
export type QuerySearchArgs = {
  after?: InputMaybe<Scalars['String']['input']>;
  algorithm?: InputMaybe<Scalars['String']['input']>;
  contentTypes: Array<ContentType>;
  didYouMeanResults?: InputMaybe<Scalars['Int']['input']>;
  facets?: InputMaybe<Array<FacetRequest>>;
  filters?: InputMaybe<Array<Filter>>;
  first?: InputMaybe<Scalars['Int']['input']>;
  searchTerms?: InputMaybe<Scalars['String']['input']>;
  tenant: Tenant;
};


/** TEST Query the Hydration Station Social Entities */
export type QuerySearchContentLibraryArgs = {
  publishedOnly?: InputMaybe<Scalars['Boolean']['input']>;
  searchParams?: InputMaybe<ContentLibrarySearchParametersInput>;
  sort?: InputMaybe<ContentLibrarySortParametersInput>;
  tenant: Tenant;
};


/** TEST Query the Hydration Station Social Entities */
export type QuerySearchTagByMatchTermArgs = {
  publishedOnly?: InputMaybe<Scalars['Boolean']['input']>;
  searchParams?: InputMaybe<TagSearchParamsInput>;
  tenant: Tenant;
};


/** TEST Query the Hydration Station Social Entities */
export type QueryTagsArgs = {
  paginationControl?: InputMaybe<PaginationControlInput>;
  publishedOnly?: InputMaybe<Scalars['Boolean']['input']>;
  tagParams: TagsQueryInput;
  tenant: Tenant;
};


/** TEST Query the Hydration Station Social Entities */
export type QueryTrendingArticlesArgs = {
  primaryPrioritizedTag?: InputMaybe<Scalars['String']['input']>;
  secondaryPrioritizedTags?: Array<Scalars['String']['input']>;
  topN: Scalars['Int']['input'];
};


/** TEST Query the Hydration Station Social Entities */
export type QueryTrendingChannelsArgs = {
  topN: Scalars['Int']['input'];
};


/** TEST Query the Hydration Station Social Entities */
export type QueryTrendingVideosArgs = {
  aspectRatio?: InputMaybe<AspectRatio>;
  countryCode?: InputMaybe<Scalars['String']['input']>;
  primaryPrioritizedTag?: InputMaybe<Scalars['String']['input']>;
  secondaryPrioritizedTags?: Array<Scalars['String']['input']>;
  topN: Scalars['Int']['input'];
};


/** TEST Query the Hydration Station Social Entities */
export type QueryTypeAheadArgs = {
  first?: InputMaybe<Scalars['Int']['input']>;
  input?: InputMaybe<Scalars['String']['input']>;
  tenant: Tenant;
};


/** TEST Query the Hydration Station Social Entities */
export type QueryV2vArgs = {
  aspectRatio?: InputMaybe<AspectRatio>;
  countryCode?: InputMaybe<Scalars['String']['input']>;
  limit?: InputMaybe<Scalars['Int']['input']>;
  primaryPrioritizedTag?: InputMaybe<Scalars['String']['input']>;
  secondaryPrioritizedTags?: Array<Scalars['String']['input']>;
  version?: InputMaybe<Scalars['Int']['input']>;
  videoEventId: Scalars['String']['input'];
};


/** TEST Query the Hydration Station Social Entities */
export type QueryVideoBlocklistArgs = {
  beforeDate?: InputMaybe<Scalars['Date']['input']>;
  limit?: InputMaybe<Scalars['Int']['input']>;
  sinceDate?: InputMaybe<Scalars['Date']['input']>;
};

export type QueryAssistResponse = {
  __typename?: 'QueryAssistResponse';
  results?: Maybe<Array<QueryAssistResult>>;
};

export type QueryAssistResult = {
  __typename?: 'QueryAssistResult';
  term: Scalars['String']['output'];
};

export type Rating = {
  __typename?: 'Rating';
  classifier?: Maybe<Scalars['String']['output']>;
  contentDescriptors?: Maybe<Array<Maybe<Scalars['String']['output']>>>;
  ratingAuthority?: Maybe<Scalars['String']['output']>;
};

export type Reference = {
  __typename?: 'Reference';
  /** Author of the reference */
  author?: Maybe<Author>;
  /** When reference was created */
  createdAt: Scalars['String']['output'];
  /** Description of the reference */
  description?: Maybe<Scalars['String']['output']>;
  id: Scalars['ID']['output'];
  /** Metadata of reference */
  metadata?: Maybe<ReferenceMetadata>;
  /** Permalink of the reference */
  permalink: Scalars['String']['output'];
  /** Tags of the reference from tagapi */
  tag: Tag;
  /** Illustration to display of the reference */
  thumbnailUrl?: Maybe<Scalars['String']['output']>;
  /** Title of the reference */
  title?: Maybe<Scalars['String']['output']>;
  /** Type of reference */
  type?: Maybe<ReferenceType>;
  /** When reference was updated */
  updatedAt: Scalars['String']['output'];
  /** Url of the reference content */
  url: Scalars['String']['output'];
};

/** The object used for filtering references. */
export type ReferenceInput = {
  /** The reference type we want to filter. */
  types?: InputMaybe<Array<Scalars['String']['input']>>;
};

export type ReferenceMetadata = {
  __typename?: 'ReferenceMetadata';
  /** Gamecast's Metadata */
  gamecast?: Maybe<GamecastMetadata>;
  /** Metadata's genres (i.e. breaking_news, analysis, rumors, game_action, live_event, etc.) */
  genres?: Maybe<Array<Scalars['String']['output']>>;
  /** Metadata's labels is a list of tags that the reference was programmed into */
  labels: Array<Tag>;
  /** Image accreditation display information */
  photoCredit?: Maybe<Scalars['String']['output']>;
  /** Metadata's provider name */
  providerName?: Maybe<Scalars['String']['output']>;
  /** The content share url */
  shareUrl?: Maybe<Scalars['String']['output']>;
  /** Video's Metadata */
  video?: Maybe<VideoMetadata>;
};

export type ReferenceStream = {
  __typename?: 'ReferenceStream';
  id: Scalars['ID']['output'];
  /** The Stream name */
  name: Scalars['String']['output'];
  /** A list of References with optional limit query parameter */
  references?: Maybe<Array<Reference>>;
  /** Tags of the reference from tagapi */
  tag: Tag;
  /** The Stream type */
  type: Scalars['String']['output'];
};


export type ReferenceStreamReferencesArgs = {
  filter?: InputMaybe<ReferenceInput>;
  limit?: InputMaybe<Scalars['Int']['input']>;
};

/** GSP ReferenceType enumeration */
export enum ReferenceType {
  Gamecast = 'Gamecast',
  Highlight = 'Highlight',
  InternalArticle = 'InternalArticle',
  LiveVideo = 'LiveVideo',
  Video = 'Video'
}

export type Schedule = {
  __typename?: 'Schedule';
  dateFrom?: Maybe<Scalars['String']['output']>;
  dateTo?: Maybe<Scalars['String']['output']>;
  feeds?: Maybe<Array<Maybe<Feed>>>;
  offset?: Maybe<Scalars['String']['output']>;
};

export type Score = {
  __typename?: 'Score';
  away?: Maybe<Scalars['Int']['output']>;
  home?: Maybe<Scalars['Int']['output']>;
};

/** @deprecated This type is deprecated and will be removed in a future version. */
export type Scores = {
  __typename?: 'Scores';
  bettingLink?: Maybe<ScoresBettingLink>;
  calendarNavigation?: Maybe<ScoresCalendarNavigation>;
  gameGroups?: Maybe<Array<Maybe<GameGroup>>>;
  leagues?: Maybe<Array<Maybe<ScoresLeague>>>;
};

export type ScoresBettingLink = {
  __typename?: 'ScoresBettingLink';
  attributionText?: Maybe<Scalars['String']['output']>;
  betting?: Maybe<Scalars['Boolean']['output']>;
  clickUrl?: Maybe<Scalars['String']['output']>;
  ctaText?: Maybe<Scalars['String']['output']>;
  disclaimerText?: Maybe<Scalars['String']['output']>;
  disclaimerUrl?: Maybe<Scalars['String']['output']>;
  id?: Maybe<Scalars['String']['output']>;
  logo?: Maybe<Scalars['String']['output']>;
  logoNight?: Maybe<Scalars['String']['output']>;
  partner?: Maybe<ScoresOddsSportsbook>;
  showLinkout?: Maybe<Scalars['String']['output']>;
  success?: Maybe<Scalars['Boolean']['output']>;
};

export type ScoresCalendarNavigation = {
  __typename?: 'ScoresCalendarNavigation';
  current?: Maybe<Array<Maybe<NavigationElement>>>;
  next?: Maybe<Array<Maybe<NavigationElement>>>;
  previous?: Maybe<Array<Maybe<NavigationElement>>>;
};

export type ScoresDescription = {
  __typename?: 'ScoresDescription';
  text?: Maybe<Scalars['String']['output']>;
};

export type ScoresEvent = {
  __typename?: 'ScoresEvent';
  boxScore?: Maybe<Scalars['String']['output']>;
  current?: Maybe<Scalars['Boolean']['output']>;
  descriptions?: Maybe<Array<Maybe<ScoresDescription>>>;
  gameDate?: Maybe<Scalars['String']['output']>;
  gameEndDate?: Maybe<Scalars['String']['output']>;
  gameState?: Maybe<ScoresState>;
  gamecast?: Maybe<Scalars['String']['output']>;
  gamecastInformation?: Maybe<Scalars['String']['output']>;
  /** Returns the tag for a given event's gamecast slug */
  gamecastTag?: Maybe<TagV2>;
  id?: Maybe<Scalars['String']['output']>;
  league?: Maybe<Scalars['String']['output']>;
  metadata?: Maybe<ScoresMetadata>;
  name?: Maybe<Scalars['String']['output']>;
  nameLabels?: Maybe<Array<Maybe<ScoresEventNameLabel>>>;
  odds?: Maybe<Scalars['String']['output']>;
  participants?: Maybe<ScoresEventParticipant>;
  progress?: Maybe<ScoresProgress>;
  site?: Maybe<Scalars['String']['output']>;
  sport?: Maybe<Scalars['String']['output']>;
  status?: Maybe<Scalars['String']['output']>;
  stream?: Maybe<Scalars['String']['output']>;
  subName?: Maybe<Scalars['String']['output']>;
  type?: Maybe<Scalars['String']['output']>;
};


export type ScoresEventGamecastTagArgs = {
  tenant: Tenant;
};

export type ScoresEventNameLabel = {
  __typename?: 'ScoresEventNameLabel';
  text?: Maybe<Scalars['String']['output']>;
};

export type ScoresEventParticipant = {
  __typename?: 'ScoresEventParticipant';
  entries?: Maybe<Array<Maybe<ScoresEventParticipantEntry>>>;
  headers?: Maybe<ScoresEventParticipantHeader>;
};

export type ScoresEventParticipantEntry = {
  __typename?: 'ScoresEventParticipantEntry';
  abbrev?: Maybe<Scalars['String']['output']>;
  isWinner?: Maybe<Scalars['Boolean']['output']>;
  logo?: Maybe<Scalars['String']['output']>;
  name?: Maybe<Scalars['String']['output']>;
  number?: Maybe<Scalars['String']['output']>;
  values?: Maybe<Array<Maybe<ScoresEventParticipantEntryValue>>>;
};

export type ScoresEventParticipantEntryFontFormatting = {
  __typename?: 'ScoresEventParticipantEntryFontFormatting';
  fontColor?: Maybe<Scalars['String']['output']>;
  fontColorNight?: Maybe<Scalars['String']['output']>;
  fontIsBold?: Maybe<Scalars['Boolean']['output']>;
};

export type ScoresEventParticipantEntryValue = {
  __typename?: 'ScoresEventParticipantEntryValue';
  fontFormatting?: Maybe<ScoresEventParticipantEntryFontFormatting>;
  value?: Maybe<Scalars['String']['output']>;
};

export type ScoresEventParticipantHeader = {
  __typename?: 'ScoresEventParticipantHeader';
  value?: Maybe<Scalars['String']['output']>;
};

/** The ScoresGame is an Entity so it can be extended in other subgraphs. */
export type ScoresGame = {
  __typename?: 'ScoresGame';
  boxScore?: Maybe<Scalars['String']['output']>;
  current?: Maybe<Scalars['Boolean']['output']>;
  descriptions?: Maybe<Array<Maybe<ScoresDescription>>>;
  gameDate?: Maybe<Scalars['String']['output']>;
  gameEndDate?: Maybe<Scalars['String']['output']>;
  gameState?: Maybe<ScoresState>;
  gamecast?: Maybe<Scalars['String']['output']>;
  gamecastInformation?: Maybe<Scalars['String']['output']>;
  /** Returns the tag for a given game's gamecast slug */
  gamecastTag?: Maybe<TagV2>;
  id?: Maybe<Scalars['String']['output']>;
  league?: Maybe<Scalars['String']['output']>;
  /** For sports that display a PeriodScores array, this indicates the maximum number of PeriodScores objects possible for a regulation length game/match */
  maxPeriodScores?: Maybe<Scalars['Int']['output']>;
  metadata?: Maybe<ScoresMetadata>;
  name?: Maybe<Scalars['String']['output']>;
  odds?: Maybe<Scalars['String']['output']>;
  progress?: Maybe<ScoresProgress>;
  site?: Maybe<Scalars['String']['output']>;
  sport?: Maybe<Scalars['String']['output']>;
  squadRide?: Maybe<SquadRide>;
  status?: Maybe<Scalars['String']['output']>;
  teamOne?: Maybe<ScoresGameTeam>;
  teamTwo?: Maybe<ScoresGameTeam>;
};


/** The ScoresGame is an Entity so it can be extended in other subgraphs. */
export type ScoresGameGamecastTagArgs = {
  tenant: Tenant;
};

export type ScoresGameTeam = {
  __typename?: 'ScoresGameTeam';
  abbrev?: Maybe<Scalars['String']['output']>;
  colors?: Maybe<Array<Maybe<Scalars['String']['output']>>>;
  competitors?: Maybe<Array<Maybe<ScoresTeamCompetitor>>>;
  hasPossession?: Maybe<Scalars['Boolean']['output']>;
  isWinner?: Maybe<Scalars['Boolean']['output']>;
  logo?: Maybe<Scalars['String']['output']>;
  mainScore?: Maybe<Scalars['String']['output']>;
  name?: Maybe<Scalars['String']['output']>;
  odds?: Maybe<Scalars['String']['output']>;
  periodScores?: Maybe<Array<Maybe<PeriodScore>>>;
  permalink?: Maybe<Scalars['String']['output']>;
  rank?: Maybe<Scalars['Int']['output']>;
  record?: Maybe<Scalars['String']['output']>;
  /** @deprecated Use mainScore and secondaryScore instead */
  score?: Maybe<Scalars['String']['output']>;
  secondaryScore?: Maybe<Scalars['String']['output']>;
  shortName?: Maybe<Scalars['String']['output']>;
  /** when true, the competitors are undecided, and the competitors array represents potential competitors for this team */
  virtual?: Maybe<Scalars['Boolean']['output']>;
};

/** The League is an Entity so it can be extended in other subgraphs. */
export type ScoresLeague = {
  __typename?: 'ScoresLeague';
  children?: Maybe<Array<Maybe<ScoresLeague>>>;
  current?: Maybe<Scalars['Boolean']['output']>;
  /** @deprecated Field no longer supported */
  href?: Maybe<Scalars['String']['output']>;
  id?: Maybe<Scalars['String']['output']>;
  league?: Maybe<Scalars['Int']['output']>;
  name?: Maybe<Scalars['String']['output']>;
  queryParameters?: Maybe<ScoresLeagueQueryParameters>;
  slug?: Maybe<Scalars['String']['output']>;
  /** @deprecated Use slug field instead */
  tag?: Maybe<Tag>;
  tagV2?: Maybe<TagV2>;
};


/** The League is an Entity so it can be extended in other subgraphs. */
export type ScoresLeagueTagV2Args = {
  tenant: Tenant;
};

export type ScoresLeagueQueryParameters = {
  __typename?: 'ScoresLeagueQueryParameters';
  context?: Maybe<Scalars['String']['output']>;
  date?: Maybe<Scalars['String']['output']>;
  league?: Maybe<StatsLeagues>;
};

export type ScoresMetadata = {
  __typename?: 'ScoresMetadata';
  about?: Maybe<Scalars['String']['output']>;
  endDate?: Maybe<Scalars['String']['output']>;
  location?: Maybe<ScoresMetadataLocation>;
  name?: Maybe<Scalars['String']['output']>;
  startDate?: Maybe<Scalars['String']['output']>;
  status?: Maybe<Scalars['String']['output']>;
};

export type ScoresMetadataLocation = {
  __typename?: 'ScoresMetadataLocation';
  city?: Maybe<Scalars['String']['output']>;
  country?: Maybe<Scalars['String']['output']>;
  name?: Maybe<Scalars['String']['output']>;
  state?: Maybe<Scalars['String']['output']>;
  zip?: Maybe<Scalars['String']['output']>;
};

export enum ScoresOddsSportsbook {
  Caesars = 'Caesars',
  Consensus = 'Consensus',
  DraftKings = 'DraftKings',
  FanDuel = 'FanDuel',
  None = 'None',
  SportRadar = 'SportRadar',
  Unknown = 'Unknown'
}

export type ScoresProgress = {
  __typename?: 'ScoresProgress';
  clock?: Maybe<Scalars['String']['output']>;
  inningPhase?: Maybe<Scalars['String']['output']>;
  network?: Maybe<Scalars['String']['output']>;
  playPeriod?: Maybe<Scalars['String']['output']>;
  playPeriodCondensed?: Maybe<Scalars['String']['output']>;
  round?: Maybe<Scalars['String']['output']>;
  venue?: Maybe<Scalars['String']['output']>;
};

export type ScoresState = {
  __typename?: 'ScoresState';
  balls?: Maybe<Scalars['Int']['output']>;
  isRedZone?: Maybe<Scalars['Boolean']['output']>;
  outs?: Maybe<Scalars['Int']['output']>;
  runners?: Maybe<ScoresStateRunners>;
  strikes?: Maybe<Scalars['Int']['output']>;
};

export type ScoresStateRunners = {
  __typename?: 'ScoresStateRunners';
  first?: Maybe<Scalars['Boolean']['output']>;
  second?: Maybe<Scalars['Boolean']['output']>;
  third?: Maybe<Scalars['Boolean']['output']>;
};

export type ScoresTeamCompetitor = {
  __typename?: 'ScoresTeamCompetitor';
  abbrev?: Maybe<Scalars['String']['output']>;
  logo?: Maybe<Scalars['String']['output']>;
  name?: Maybe<Scalars['String']['output']>;
  rank?: Maybe<Scalars['Int']['output']>;
  slug?: Maybe<Scalars['String']['output']>;
  /** applicable in ScoresGame instances when some or all competitors of a ScoresGameTeam are TBD. This field identifies pairs of doubles players */
  team?: Maybe<Scalars['Int']['output']>;
};

export type SearchAsset = Article | Channel | ExternalArticle | User | VideoV2;

export type SearchResult = {
  __typename?: 'SearchResult';
  contentModule?: Maybe<StandaloneContentModule>;
  searchAsset?: Maybe<SearchAsset>;
};

export type SearchResults = {
  __typename?: 'SearchResults';
  connection?: Maybe<AssetConnection>;
  didYouMeanResponse?: Maybe<QueryAssistResponse>;
  errors?: Maybe<Array<Maybe<Scalars['String']['output']>>>;
  facetResponse?: Maybe<Array<FacetResponse>>;
};

export enum SearchSource {
  Title = 'TITLE',
  Username = 'USERNAME',
  Xauthor = 'XAUTHOR',
  Xpost = 'XPOST'
}

export type Season = {
  __typename?: 'Season';
  current?: Maybe<Scalars['Int']['output']>;
  end?: Maybe<Scalars['String']['output']>;
  id?: Maybe<Scalars['String']['output']>;
  name?: Maybe<Scalars['String']['output']>;
  start?: Maybe<Scalars['String']['output']>;
  type?: Maybe<Scalars['String']['output']>;
};

export enum SemanticId {
  Ads = 'Ads',
  AffiliateWatchBanner = 'AffiliateWatchBanner',
  AlertActivitiesFeed = 'AlertActivitiesFeed',
  AlertFollowingFeed = 'AlertFollowingFeed',
  Chat = 'Chat',
  ContentChannelFeed = 'ContentChannelFeed',
  ContentCommunityFeed = 'ContentCommunityFeed',
  ContentFullGameHighlights = 'ContentFullGameHighlights',
  ContentHighlights = 'ContentHighlights',
  ContentHomeCommunityCollections = 'ContentHomeCommunityCollections',
  ContentHomeHeadlines = 'ContentHomeHeadlines',
  ContentHomeLandscape = 'ContentHomeLandscape',
  ContentHomePortraitCollection = 'ContentHomePortraitCollection',
  ContentPremiumVideo = 'ContentPremiumVideo',
  ContentShortGameHighlights = 'ContentShortGameHighlights',
  ContentSocialFeed = 'ContentSocialFeed',
  ContentTopHeadlines = 'ContentTopHeadlines',
  ContentTrendingBets = 'ContentTrendingBets',
  ContentTrendingVideos = 'ContentTrendingVideos',
  ContentWhatsBuzzing = 'ContentWhatsBuzzing',
  Dummy = 'Dummy',
  ExternalLink = 'ExternalLink',
  Header = 'Header',
  LiveAndUpcoming = 'LiveAndUpcoming',
  LiveNow = 'LiveNow',
  LiveUpcoming = 'LiveUpcoming',
  RecCreatorsInYourCommunities = 'RecCreatorsInYourCommunities',
  RecForYou = 'RecForYou',
  RecMostFollowedLeagues = 'RecMostFollowedLeagues',
  RecMostFollowedTeams = 'RecMostFollowedTeams',
  RecRelatedCommunities = 'RecRelatedCommunities',
  RecTopCreators = 'RecTopCreators',
  RecTopInterests = 'RecTopInterests',
  RecYouMightLike = 'RecYouMightLike',
  SearchBar = 'SearchBar',
  StatsBaseball = 'StatsBaseball',
  StatsBetting = 'StatsBetting',
  StatsDrawNoBet = 'StatsDrawNoBet',
  StatsDriveChart = 'StatsDriveChart',
  StatsGameInfo = 'StatsGameInfo',
  StatsGameStats = 'StatsGameStats',
  StatsGamecast = 'StatsGamecast',
  StatsHeadToHead = 'StatsHeadToHead',
  StatsHockeyGameState = 'StatsHockeyGameState',
  StatsInjuryReport = 'StatsInjuryReport',
  StatsLeagueRankings = 'StatsLeagueRankings',
  StatsLineScore = 'StatsLineScore',
  StatsLineup = 'StatsLineup',
  StatsLiveOdds = 'StatsLiveOdds',
  StatsMatchTimeline = 'StatsMatchTimeline',
  StatsMoneyline = 'StatsMoneyline',
  StatsOdds = 'StatsOdds',
  StatsPitchingInfo = 'StatsPitchingInfo',
  StatsPlayPreview = 'StatsPlayPreview',
  StatsPlaySummary = 'StatsPlaySummary',
  StatsPlayerProp = 'StatsPlayerProp',
  StatsPlayerStats = 'StatsPlayerStats',
  StatsPlayersOnIce = 'StatsPlayersOnIce',
  StatsPlays = 'StatsPlays',
  StatsPodium = 'StatsPodium',
  StatsPodiumEntry = 'StatsPodiumEntry',
  StatsPreviousMeetings = 'StatsPreviousMeetings',
  StatsRaceInfo = 'StatsRaceInfo',
  StatsSchedule = 'StatsSchedule',
  StatsScoreboard = 'StatsScoreboard',
  StatsScorecard = 'StatsScorecard',
  StatsScores = 'StatsScores',
  StatsScoresStrip = 'StatsScoresStrip',
  StatsScoringPlays = 'StatsScoringPlays',
  StatsSeasonLeaders = 'StatsSeasonLeaders',
  StatsSeasonPerformance = 'StatsSeasonPerformance',
  StatsSpread = 'StatsSpread',
  StatsStandings = 'StatsStandings',
  StatsSubstitutions = 'StatsSubstitutions',
  StatsTeamComparison = 'StatsTeamComparison',
  StatsThreeWayMoneyline = 'StatsThreeWayMoneyline',
  StatsTotalPoints = 'StatsTotalPoints',
  StatsVenue = 'StatsVenue',
  TagFollowing = 'TagFollowing',
  TagOnboarding = 'TagOnboarding',
  TagRecommended = 'TagRecommended',
  TagSearch = 'TagSearch',
  TrendingClips = 'TrendingClips',
  UgcComments = 'UgcComments',
  UgcFeed = 'UgcFeed',
  UgcFromTheFans = 'UgcFromTheFans',
  UgcPosts = 'UgcPosts',
  UserHeader = 'UserHeader'
}

export enum SemanticType {
  AdsData = 'AdsData',
  AlertData = 'AlertData',
  ContentModuleData = 'ContentModuleData',
  Default = 'Default',
  RecommendationData = 'RecommendationData',
  SocialData = 'SocialData',
  StatsData = 'StatsData',
  StatsPlaceholder = 'StatsPlaceholder',
  TagData = 'TagData',
  UserData = 'UserData'
}

export type Series = {
  __typename?: 'Series';
  events?: Maybe<Array<Maybe<Event>>>;
  hash?: Maybe<Scalars['String']['output']>;
  id?: Maybe<Scalars['ID']['output']>;
  season?: Maybe<Scalars['String']['output']>;
  series_name?: Maybe<Scalars['String']['output']>;
  start_date?: Maybe<Scalars['String']['output']>;
  taxonomy?: Maybe<TaxonomyTerm>;
  territories_available?: Maybe<Array<Maybe<Territories>>>;
  tournament?: Maybe<Tournament>;
};


export type SeriesEventsArgs = {
  filter?: InputMaybe<EventFilterInput>;
};

export enum SeriesSort {
  Id = 'id',
  Season = 'season',
  SeriesName = 'series_name',
  StartDate = 'start_date'
}

export type Serieses = {
  __typename?: 'Serieses';
  index_end?: Maybe<Scalars['Int']['output']>;
  index_start?: Maybe<Scalars['Int']['output']>;
  series?: Maybe<Array<Maybe<Series>>>;
  total?: Maybe<Scalars['Int']['output']>;
};

export type Settings = {
  __typename?: 'Settings';
  alerts?: Maybe<Array<AlertPreference>>;
  social?: Maybe<Array<SocialPreference>>;
  spoilers_enabled?: Maybe<Scalars['String']['output']>;
};

export type Show = {
  __typename?: 'Show';
  airDateTime?: Maybe<Scalars['String']['output']>;
  begin?: Maybe<Scalars['String']['output']>;
  end?: Maybe<Scalars['String']['output']>;
  episode?: Maybe<Scalars['String']['output']>;
  franchiseId?: Maybe<Scalars['String']['output']>;
  franchiseName?: Maybe<Scalars['String']['output']>;
  genreList?: Maybe<Scalars['String']['output']>;
  hash?: Maybe<Scalars['String']['output']>;
  highlightList?: Maybe<Scalars['String']['output']>;
  id?: Maybe<Scalars['String']['output']>;
  lang?: Maybe<Scalars['String']['output']>;
  length?: Maybe<Scalars['String']['output']>;
  offset?: Maybe<Scalars['String']['output']>;
  originalTitle?: Maybe<Scalars['String']['output']>;
  rate?: Maybe<Scalars['String']['output']>;
  ratingArgentina?: Maybe<Scalars['String']['output']>;
  ratingBrasil?: Maybe<Scalars['String']['output']>;
  ratingMexico?: Maybe<Scalars['String']['output']>;
  season?: Maybe<Scalars['String']['output']>;
  serie?: Maybe<Scalars['String']['output']>;
  /** Status Values (derived from "begin", "end" and "offset" values): "estimated" (before)  || "current" (during)  || "actual" (after) */
  status?: Maybe<Scalars['String']['output']>;
  storyline?: Maybe<Scalars['String']['output']>;
  summary?: Maybe<Scalars['String']['output']>;
  taxonomy?: Maybe<TaxonomyTerm>;
  title?: Maybe<Scalars['String']['output']>;
  titleId?: Maybe<Scalars['String']['output']>;
};


export type ShowTaxonomyArgs = {
  tenant: Tenant;
};

export type Slide = {
  __typename?: 'Slide';
  elements?: Maybe<Array<Maybe<Element>>>;
  featuredMedia: Element;
  id?: Maybe<Scalars['Int']['output']>;
  slideNumber?: Maybe<Scalars['Int']['output']>;
  title: Scalars['String']['output'];
};

export type SocialLinks = {
  __typename?: 'SocialLinks';
  instagram?: Maybe<Scalars['String']['output']>;
  tiktok?: Maybe<Scalars['String']['output']>;
  twitch?: Maybe<Scalars['String']['output']>;
  twitter?: Maybe<Scalars['String']['output']>;
  youtube?: Maybe<Scalars['String']['output']>;
};

export type SocialMediaHandle = {
  __typename?: 'SocialMediaHandle';
  handle?: Maybe<Scalars['String']['output']>;
  platform?: Maybe<Scalars['String']['output']>;
};

/** SocialPreference | Mock-only */
export type SocialPreference = {
  __typename?: 'SocialPreference';
  enabled: Scalars['Boolean']['output'];
  type: Scalars['String']['output'];
};

export type SocialWidget = {
  __typename?: 'SocialWidget';
  clientId: Scalars['String']['output'];
  commentBoardReactionSpaceId?: Maybe<Scalars['String']['output']>;
  count?: Maybe<Scalars['Int']['output']>;
  fireReactionId?: Maybe<Scalars['String']['output']>;
  liveLikeUserReaction?: Maybe<CustomLiveLikeUserReaction>;
  targetGroupId?: Maybe<Scalars['String']['output']>;
  type: Scalars['String']['output'];
  widgetId: Scalars['String']['output'];
};

export enum SortDirections {
  Asc = 'asc',
  Desc = 'desc'
}

export enum SortOrder {
  Ascending = 'Ascending',
  Descending = 'Descending'
}

export type Sport = {
  __typename?: 'Sport';
  event_image?: Maybe<Scalars['String']['output']>;
  gracenote_id?: Maybe<Scalars['String']['output']>;
  has_media?: Maybe<Scalars['Boolean']['output']>;
  icon_dark?: Maybe<Scalars['String']['output']>;
  icon_light?: Maybe<Scalars['String']['output']>;
  id?: Maybe<Scalars['ID']['output']>;
  leagues?: Maybe<Array<Maybe<League>>>;
  name?: Maybe<Scalars['String']['output']>;
  sportradar_id?: Maybe<Scalars['String']['output']>;
  territories_available?: Maybe<Array<Maybe<Territories>>>;
};


export type SportLeaguesArgs = {
  id?: InputMaybe<Scalars['ID']['input']>;
};

export type SportMetaData = {
  __typename?: 'SportMetaData';
  league?: Maybe<StatsLeagues>;
  sport?: Maybe<StatsSport>;
};

export type Sports = {
  __typename?: 'Sports';
  index_end?: Maybe<Scalars['Int']['output']>;
  index_start?: Maybe<Scalars['Int']['output']>;
  sports?: Maybe<Array<Maybe<Sport>>>;
  total?: Maybe<Scalars['Int']['output']>;
};

export type SquadRide = {
  __typename?: 'SquadRide';
  id?: Maybe<Scalars['String']['output']>;
  outcome?: Maybe<Scalars['String']['output']>;
};

export type StandaloneContentModule = ContentModule & {
  __typename?: 'StandaloneContentModule';
  /** Ads Configuration | Ads API */
  adsConfig?: Maybe<AdsConfiguration>;
  alertRanks: Array<Maybe<AlertRank>>;
  /** Indicates to what tagUUID the content module was alerted to. */
  alertedChannelTagUUID?: Maybe<Scalars['String']['output']>;
  /** List of countries that a content module will be visible. */
  allowedCountries?: Maybe<Array<Maybe<Scalars['String']['output']>>>;
  commentsEnabled?: Maybe<Scalars['Boolean']['output']>;
  /** List of Channels/Components (tag + semanticID) a content module is programmed to. */
  components?: Maybe<Array<Maybe<ComponentModule>>>;
  composites?: Maybe<Array<Maybe<PackageContentModule>>>;
  /** The content object, will be resolved by one of the downstream graphs. */
  content: ProgrammedContent;
  /** ID of the content of a content module. */
  contentID?: Maybe<Scalars['String']['output']>;
  contentMetadata?: Maybe<ContentMetadata>;
  /** Also known as Commentary, short description of the content of a content module. */
  description: Scalars['String']['output'];
  /** Date and Time when a content module will not be visible anymore for end users. The state will be `UNPROGRAMMED`. */
  expiresAt?: Maybe<Scalars['Date']['output']>;
  hidden?: Maybe<Scalars['Boolean']['output']>;
  /** Date and Time when a hidden content module will automatically become visible again. */
  hiddenExpiresAt?: Maybe<Scalars['Date']['output']>;
  id: Scalars['ID']['output'];
  /** Date and time that the Content Modules was created. */
  insertedAt?: Maybe<Scalars['Date']['output']>;
  /** Indicates if a push notification was sent to the content module. */
  isAlerted?: Maybe<Scalars['Boolean']['output']>;
  isPositionLocked?: Maybe<Scalars['Boolean']['output']>;
  /** Audit only field to capture the last system or person that updated the content module. */
  lastModifiedBy?: Maybe<Scalars['String']['output']>;
  /** Metadata containing community tag, author, and brand information for logos and display. */
  metaData?: Maybe<ModuleMetaData>;
  /** Content module orientation, one of: Landscape or Portrait */
  orientation: ModuleOrientation;
  position?: Maybe<Scalars['Int']['output']>;
  positionLockExpiresAt?: Maybe<Scalars['Date']['output']>;
  /** Date and Time that the Content Module was last updated, considering the programming relevant fields (title, description, thumbnail, contentID/contentType) */
  programmingUpdatedAt?: Maybe<Scalars['Date']['output']>;
  /** Date and Time when a content module will start to be visible for end users. The state will be `SCHEDULED`. */
  scheduledDate?: Maybe<Scalars['Date']['output']>;
  socialWidgets?: Maybe<Array<Maybe<SocialWidget>>>;
  /** List of possible states of content module. One of `SCHEDULED`, `PROGRAMMED` or `UNPROGRAMMED`. */
  state?: Maybe<ModuleState>;
  /** Thumbnail URL of the content module */
  thumbnail: Scalars['String']['output'];
  thumbnailAccreditation?: Maybe<Scalars['String']['output']>;
  thumbnailCopyright?: Maybe<Scalars['String']['output']>;
  /** Also known as Headline, that's the heading text of a content module. */
  title: Scalars['String']['output'];
  /** Type of the content of a content module, e.g: Article, Video, Tweet */
  type: ContentModuleType;
  /** Date and time that a content module was last updated. */
  updatedAt?: Maybe<Scalars['Date']['output']>;
  /** Identifies content modules created with the same contentID and contentType for Social features. */
  wrapperContentModuleId?: Maybe<Scalars['ID']['output']>;
};


export type StandaloneContentModuleAlertRanksArgs = {
  limit?: InputMaybe<Scalars['Int']['input']>;
};

export enum StateStatus {
  Complete = 'Complete',
  InProgress = 'InProgress',
  Scheduled = 'Scheduled'
}

export type StatsBetOffer = {
  __typename?: 'StatsBetOffer';
  jsonResponse?: Maybe<Scalars['String']['output']>;
};

/** The StatsBetting is an Entity so it can be extended in other subgraphs. */
export type StatsBetting = {
  __typename?: 'StatsBetting';
  id: Scalars['ID']['output'];
  jsonResponse?: Maybe<Scalars['String']['output']>;
};

export enum StatsGameStatus {
  Closed = 'Closed',
  Complete = 'Complete',
  InProgress = 'InProgress',
  Scheduled = 'Scheduled',
  Unknow = 'Unknow'
}

/**
 * The jsonResponse field will soon be deprecated. Use new GraphQL types IF they exist.
 * jsonResponse is being split into native types. Currently GraphQL types exist for Gamecast Content Modules / Scoreboards, not yet the full Gamecast experience.
 * New types exist for the following StatMilk payloads: **scoreLeaderboard**, **gameDate**, **linescore**, **podium**, **raceInfo**, **scoreboard**, **sport**, **status**, **venue**, **pbp**
 */
export type StatsGamecast = {
  __typename?: 'StatsGamecast';
  gameDate?: Maybe<Scalars['String']['output']>;
  /** The jsonResponse field will soon be deprecated. Use new GraphQL types IF they exist. */
  jsonResponse?: Maybe<Scalars['String']['output']>;
  linescore?: Maybe<StatsLinescore>;
  pbp?: Maybe<StatsPbp>;
  podium?: Maybe<StatsPodium>;
  raceInfo?: Maybe<StatsRaceInfo>;
  scoreLeaderboard?: Maybe<ScoresEvent>;
  scoreboard?: Maybe<StatsScoreboard>;
  slug: Scalars['String']['output'];
  sport?: Maybe<StatsSport>;
  status?: Maybe<StatsGameStatus>;
  tag?: Maybe<TagV2>;
  venue?: Maybe<StatsVenue>;
};


/**
 * The jsonResponse field will soon be deprecated. Use new GraphQL types IF they exist.
 * jsonResponse is being split into native types. Currently GraphQL types exist for Gamecast Content Modules / Scoreboards, not yet the full Gamecast experience.
 * New types exist for the following StatMilk payloads: **scoreLeaderboard**, **gameDate**, **linescore**, **podium**, **raceInfo**, **scoreboard**, **sport**, **status**, **venue**, **pbp**
 */
export type StatsGamecastTagArgs = {
  tenant?: InputMaybe<Tenant>;
};

export enum StatsLeagues {
  Formula1 = 'Formula1',
  GLeague = 'GLeague',
  Golf = 'Golf',
  Mlb = 'MLB',
  Nascar = 'NASCAR',
  Nba = 'NBA',
  Ncaabb = 'NCAABB',
  Ncaabbw = 'NCAABBW',
  Ncaaf = 'NCAAF',
  Nfl = 'NFL',
  Nhl = 'NHL',
  OlympicBasketball = 'OlympicBasketball',
  Olympics = 'Olympics',
  Other = 'Other',
  Soccer = 'Soccer',
  Tennis = 'Tennis',
  Unknown = 'Unknown',
  Unrivaled = 'Unrivaled',
  Wnba = 'WNBA'
}

export type StatsLinescore = {
  __typename?: 'StatsLinescore';
  gameState?: Maybe<StatsLinescoreGameState>;
  headers?: Maybe<Array<Maybe<StatsLinescoreValue>>>;
  summaryHeaders?: Maybe<Array<Maybe<StatsLinescoreValue>>>;
  teamOne?: Maybe<StatsLinescoreTeam>;
  teamTwo?: Maybe<StatsLinescoreTeam>;
  title?: Maybe<Scalars['String']['output']>;
};

export type StatsLinescoreBatter = {
  __typename?: 'StatsLinescoreBatter';
  atBats?: Maybe<Scalars['Int']['output']>;
  average?: Maybe<Scalars['Float']['output']>;
  player?: Maybe<Scalars['String']['output']>;
  totalHits?: Maybe<Scalars['Int']['output']>;
};

export type StatsLinescoreDiamond = {
  __typename?: 'StatsLinescoreDiamond';
  first?: Maybe<Scalars['Boolean']['output']>;
  second?: Maybe<Scalars['Boolean']['output']>;
  third?: Maybe<Scalars['Boolean']['output']>;
};

export type StatsLinescoreGameState = {
  __typename?: 'StatsLinescoreGameState';
  balls?: Maybe<Scalars['Int']['output']>;
  batter?: Maybe<StatsLinescoreBatter>;
  outs?: Maybe<Scalars['Int']['output']>;
  pitcher?: Maybe<StatsLinescorePitcher>;
  runners?: Maybe<StatsLinescoreDiamond>;
  strikes?: Maybe<Scalars['Int']['output']>;
};

export type StatsLinescorePitcher = {
  __typename?: 'StatsLinescorePitcher';
  player?: Maybe<Scalars['String']['output']>;
  totalPitches?: Maybe<Scalars['Int']['output']>;
  totalStrikeouts?: Maybe<Scalars['Int']['output']>;
};

export type StatsLinescoreTeam = {
  __typename?: 'StatsLinescoreTeam';
  colors?: Maybe<Array<Maybe<Scalars['String']['output']>>>;
  logo?: Maybe<Scalars['String']['output']>;
  name?: Maybe<Scalars['String']['output']>;
  record?: Maybe<Scalars['String']['output']>;
  summaryValues?: Maybe<Array<Maybe<StatsLinescoreValue>>>;
  values?: Maybe<Array<Maybe<StatsLinescoreValue>>>;
};

export type StatsLinescoreValue = {
  __typename?: 'StatsLinescoreValue';
  value?: Maybe<Scalars['String']['output']>;
};

export type StatsPbp = {
  __typename?: 'StatsPbp';
  pbpPreview?: Maybe<StatsPbpPreview>;
  plays?: Maybe<Array<StatsPbpPlay>>;
  scoringSummary?: Maybe<StatsPbpTabGrouping>;
  tabs?: Maybe<StatsPbpTabs>;
};

export type StatsPbpDriveChart = {
  __typename?: 'StatsPbpDriveChart';
  currentPosition?: Maybe<Scalars['Float']['output']>;
  direction?: Maybe<Scalars['String']['output']>;
  firstDownPosition?: Maybe<Scalars['Float']['output']>;
  startingPosition?: Maybe<Scalars['Float']['output']>;
};

export type StatsPbpDriveSummary = {
  __typename?: 'StatsPbpDriveSummary';
  isRedzone?: Maybe<Scalars['Boolean']['output']>;
  logo?: Maybe<Scalars['String']['output']>;
  primaryDescription?: Maybe<Scalars['String']['output']>;
  secondaryDescription?: Maybe<Scalars['String']['output']>;
};

export type StatsPbpPeriodGrouping = {
  __typename?: 'StatsPbpPeriodGrouping';
  collapsable?: Maybe<Scalars['Boolean']['output']>;
  collapsed?: Maybe<Scalars['Boolean']['output']>;
  description?: Maybe<Scalars['String']['output']>;
  plays?: Maybe<Array<Scalars['Int']['output']>>;
};

export type StatsPbpPlay = {
  __typename?: 'StatsPbpPlay';
  boldPenalty?: Maybe<Scalars['Boolean']['output']>;
  gameProgress?: Maybe<Scalars['String']['output']>;
  gameProgressPrimary?: Maybe<Scalars['String']['output']>;
  gameProgressSecondary?: Maybe<Scalars['String']['output']>;
  logo?: Maybe<Scalars['String']['output']>;
  playStoppage?: Maybe<Scalars['Boolean']['output']>;
  scoreTeamOne?: Maybe<Scalars['Int']['output']>;
  scoreTeamTwo?: Maybe<Scalars['Int']['output']>;
  sequence?: Maybe<Scalars['Int']['output']>;
  summary?: Maybe<Scalars['String']['output']>;
  teamName?: Maybe<Scalars['String']['output']>;
  teamOneScoringPlay?: Maybe<Scalars['Boolean']['output']>;
  teamTwoScoringPlay?: Maybe<Scalars['Boolean']['output']>;
};

export type StatsPbpPreview = {
  __typename?: 'StatsPbpPreview';
  description?: Maybe<Scalars['String']['output']>;
  driveChart?: Maybe<StatsPbpDriveChart>;
  driveSummary?: Maybe<StatsPbpDriveSummary>;
  formatting?: Maybe<StatsPbpTextFormatting>;
  gameStateDescription?: Maybe<Scalars['String']['output']>;
  groupings?: Maybe<Array<StatsPbpPeriodGrouping>>;
  id?: Maybe<Scalars['String']['output']>;
  useGameProgressSecondary?: Maybe<Scalars['Boolean']['output']>;
};

export type StatsPbpTabGrouping = {
  __typename?: 'StatsPbpTabGrouping';
  description?: Maybe<Scalars['String']['output']>;
  groupings: Array<StatsPbpPeriodGrouping>;
  id?: Maybe<Scalars['String']['output']>;
  useGameProgressSecondary?: Maybe<Scalars['Boolean']['output']>;
};

export type StatsPbpTabs = {
  __typename?: 'StatsPbpTabs';
  byPeriod?: Maybe<StatsPbpTabGrouping>;
  penalties?: Maybe<StatsPbpTabGrouping>;
  scoringSummary?: Maybe<StatsPbpTabGrouping>;
};

export type StatsPbpTextFormatting = {
  __typename?: 'StatsPbpTextFormatting';
  fontColor?: Maybe<Scalars['String']['output']>;
  fontColorNight?: Maybe<Scalars['String']['output']>;
  fontIsBold?: Maybe<Scalars['Boolean']['output']>;
  fontIsItalic?: Maybe<Scalars['Boolean']['output']>;
  textClass?: Maybe<Scalars['String']['output']>;
};

export type StatsPodium = {
  __typename?: 'StatsPodium';
  entries?: Maybe<Array<Maybe<StatsPodiumEntry>>>;
  title?: Maybe<Scalars['String']['output']>;
};

export type StatsPodiumEntry = {
  __typename?: 'StatsPodiumEntry';
  logo?: Maybe<Scalars['String']['output']>;
  name?: Maybe<Scalars['String']['output']>;
  place?: Maybe<Scalars['String']['output']>;
  result?: Maybe<Scalars['String']['output']>;
  subResult?: Maybe<Scalars['String']['output']>;
};

export type StatsRaceInfo = {
  __typename?: 'StatsRaceInfo';
  distance?: Maybe<Scalars['String']['output']>;
  distanceUnit?: Maybe<Scalars['String']['output']>;
  laps?: Maybe<Scalars['String']['output']>;
  name?: Maybe<Scalars['String']['output']>;
  status?: Maybe<StatsGameStatus>;
  type?: Maybe<Scalars['String']['output']>;
};

export type StatsSchedule = {
  __typename?: 'StatsSchedule';
  adPlacement?: Maybe<Array<Maybe<StatsScheduleAdPlacement>>>;
  league?: Maybe<Scalars['String']['output']>;
  name?: Maybe<Scalars['String']['output']>;
  scheduleGroupings?: Maybe<Array<Maybe<StatsScheduleGrouping>>>;
  slug: Scalars['String']['output'];
};

export type StatsScheduleAdPlacement = {
  __typename?: 'StatsScheduleAdPlacement';
  adId?: Maybe<Scalars['String']['output']>;
  gameRowIndex?: Maybe<Scalars['Int']['output']>;
  groupIndex?: Maybe<Scalars['Int']['output']>;
  repeatOffset?: Maybe<Scalars['Int']['output']>;
};

export type StatsScheduleEntry = {
  __typename?: 'StatsScheduleEntry';
  current?: Maybe<Scalars['Boolean']['output']>;
  date?: Maybe<Scalars['String']['output']>;
  group?: Maybe<Scalars['String']['output']>;
  homeAway?: Maybe<Scalars['String']['output']>;
  isoUtcDatetime?: Maybe<Scalars['String']['output']>;
  location?: Maybe<ScoresMetadataLocation>;
  opponent?: Maybe<Scalars['String']['output']>;
  opponentLogo?: Maybe<Scalars['String']['output']>;
  resultCode?: Maybe<StatsScheduleResultCode>;
  resultDescription?: Maybe<Scalars['String']['output']>;
  slug?: Maybe<Scalars['String']['output']>;
  startTimeTbd?: Maybe<Scalars['Boolean']['output']>;
  status?: Maybe<StatsGameStatus>;
  ticketInfo?: Maybe<StatsScheduleTickets>;
};

export type StatsScheduleGrouping = {
  __typename?: 'StatsScheduleGrouping';
  current?: Maybe<Scalars['Boolean']['output']>;
  entries?: Maybe<Array<Maybe<StatsScheduleEntry>>>;
  key?: Maybe<Array<Maybe<StatsScheduleKey>>>;
  link?: Maybe<StatsScheduleLink>;
  title?: Maybe<Scalars['String']['output']>;
};

export type StatsScheduleKey = {
  __typename?: 'StatsScheduleKey';
  color?: Maybe<Scalars['String']['output']>;
  returnColor?: Maybe<Scalars['Boolean']['output']>;
  value?: Maybe<Scalars['String']['output']>;
};

export type StatsScheduleLink = {
  __typename?: 'StatsScheduleLink';
  title?: Maybe<Scalars['String']['output']>;
  type?: Maybe<Scalars['String']['output']>;
  value?: Maybe<Scalars['String']['output']>;
};

export type StatsScheduleResultCode = {
  __typename?: 'StatsScheduleResultCode';
  color?: Maybe<Scalars['String']['output']>;
  colorNight?: Maybe<Scalars['String']['output']>;
  value?: Maybe<Scalars['String']['output']>;
};

export type StatsScheduleTickets = {
  __typename?: 'StatsScheduleTickets';
  minPrice?: Maybe<Scalars['String']['output']>;
  url?: Maybe<Scalars['String']['output']>;
};

export type StatsScoreboard = {
  __typename?: 'StatsScoreboard';
  gameDate?: Maybe<Scalars['String']['output']>;
  progress?: Maybe<ScoresProgress>;
  teamOne?: Maybe<ScoresGameTeam>;
  teamTwo?: Maybe<ScoresGameTeam>;
};

export type StatsScoreboardTeam = {
  __typename?: 'StatsScoreboardTeam';
  abbrev?: Maybe<Scalars['String']['output']>;
  bonus?: Maybe<Scalars['Boolean']['output']>;
  colors?: Maybe<Array<Maybe<Scalars['String']['output']>>>;
  competitors?: Maybe<Array<Maybe<ScoresTeamCompetitor>>>;
  doubleBonus?: Maybe<Scalars['Boolean']['output']>;
  hasPossession?: Maybe<Scalars['Boolean']['output']>;
  hasPowerPlay?: Maybe<Scalars['Boolean']['output']>;
  isRedZone?: Maybe<Scalars['Boolean']['output']>;
  isWinner?: Maybe<Scalars['Boolean']['output']>;
  logo?: Maybe<Scalars['String']['output']>;
  name?: Maybe<Scalars['String']['output']>;
  odds?: Maybe<Scalars['String']['output']>;
  periodScores?: Maybe<Array<Maybe<PeriodScore>>>;
  permalink?: Maybe<Scalars['String']['output']>;
  rank?: Maybe<Scalars['Int']['output']>;
  record?: Maybe<Scalars['String']['output']>;
  score?: Maybe<Scalars['String']['output']>;
  shortName?: Maybe<Scalars['String']['output']>;
  timeoutsRemaining?: Maybe<Scalars['Int']['output']>;
  totalTimeouts?: Maybe<Scalars['Int']['output']>;
  /** when true, the competitors are undecided, and the competitors array represents potential competitors for this team */
  virtual?: Maybe<Scalars['Boolean']['output']>;
};

export enum StatsSport {
  Baseball = 'Baseball',
  Basketball = 'Basketball',
  Football = 'Football',
  Golf = 'Golf',
  Hockey = 'Hockey',
  Motorsports = 'Motorsports',
  Other = 'Other',
  Soccer = 'Soccer',
  Tennis = 'Tennis'
}

export type StatsStanding = {
  __typename?: 'StatsStanding';
  name?: Maybe<Scalars['String']['output']>;
  season?: Maybe<Scalars['Int']['output']>;
  slug?: Maybe<Scalars['String']['output']>;
  standingGroupings?: Maybe<Array<Maybe<StatsStandingGrouping>>>;
  /** @deprecated Use slug field instead */
  tag?: Maybe<Tag>;
};

export type StatsStandingAdPlacement = {
  __typename?: 'StatsStandingAdPlacement';
  adId?: Maybe<Scalars['String']['output']>;
  index?: Maybe<Scalars['Int']['output']>;
};

export type StatsStandingEntry = {
  __typename?: 'StatsStandingEntry';
  current?: Maybe<Scalars['Boolean']['output']>;
  headers?: Maybe<Array<Maybe<StatsStandingHeader>>>;
  keys?: Maybe<Array<Maybe<StatsStandingKey>>>;
  separator?: Maybe<StatsStandingSeparator>;
  teams?: Maybe<Array<Maybe<StatsStandingTeam>>>;
  title?: Maybe<Scalars['String']['output']>;
};

export type StatsStandingGrouping = {
  __typename?: 'StatsStandingGrouping';
  adPlacement?: Maybe<Array<Maybe<StatsStandingAdPlacement>>>;
  entries?: Maybe<Array<Maybe<StatsStandingEntry>>>;
  title?: Maybe<Scalars['String']['output']>;
};

export type StatsStandingHeader = {
  __typename?: 'StatsStandingHeader';
  title?: Maybe<Scalars['String']['output']>;
};

export type StatsStandingKey = {
  __typename?: 'StatsStandingKey';
  color?: Maybe<Scalars['String']['output']>;
  returnColor?: Maybe<Scalars['Boolean']['output']>;
  value?: Maybe<Scalars['String']['output']>;
};

export type StatsStandingSeparator = {
  __typename?: 'StatsStandingSeparator';
  color?: Maybe<Scalars['String']['output']>;
  index?: Maybe<Scalars['Int']['output']>;
};

export type StatsStandingTeam = {
  __typename?: 'StatsStandingTeam';
  color?: Maybe<Scalars['String']['output']>;
  current?: Maybe<Scalars['Boolean']['output']>;
  logo?: Maybe<Scalars['String']['output']>;
  name?: Maybe<Scalars['String']['output']>;
  number?: Maybe<Scalars['String']['output']>;
  prefixSuperscript?: Maybe<Scalars['String']['output']>;
  returnColor?: Maybe<Scalars['Boolean']['output']>;
  slug?: Maybe<Scalars['String']['output']>;
  superscript?: Maybe<Scalars['String']['output']>;
  /** @deprecated Use slug field instead */
  tag?: Maybe<Tag>;
  values?: Maybe<Array<Maybe<StatsStandingValue>>>;
};

export type StatsStandingValue = {
  __typename?: 'StatsStandingValue';
  value?: Maybe<Scalars['String']['output']>;
};

export type StatsVenue = {
  __typename?: 'StatsVenue';
  location?: Maybe<Scalars['String']['output']>;
  stadium?: Maybe<Scalars['String']['output']>;
  weatherEmoji?: Maybe<Scalars['String']['output']>;
  weatherPrimary?: Maybe<Scalars['String']['output']>;
  weatherSecondary?: Maybe<Scalars['String']['output']>;
};

export enum Status {
  Abandoned = 'Abandoned',
  Cancelled = 'Cancelled',
  Closed = 'Closed',
  Complete = 'Complete',
  Created = 'Created',
  Delayed = 'Delayed',
  FDelay = 'FDelay',
  FlexSchedule = 'FlexSchedule',
  Halftime = 'Halftime',
  IfNecessary = 'IfNecessary',
  InProgress = 'InProgress',
  Interrupted = 'Interrupted',
  Maintenance = 'Maintenance',
  ODelay = 'ODelay',
  Postponed = 'Postponed',
  Reopened = 'Reopened',
  Scheduled = 'Scheduled',
  Suspended = 'Suspended',
  TimeTbd = 'TimeTBD',
  Unnecessary = 'Unnecessary',
  WDelay = 'WDelay'
}

export type StreamMetaData = {
  __typename?: 'StreamMetaData';
  _id?: Maybe<Scalars['MongoID']['output']>;
  headline?: Maybe<Scalars['String']['output']>;
  id?: Maybe<Scalars['String']['output']>;
  /** The reference stream */
  referenceStream?: Maybe<ReferenceStream>;
  subtype?: Maybe<Scalars['String']['output']>;
  weight?: Maybe<Scalars['Float']['output']>;
};

export type Tag = {
  __typename?: 'Tag';
  /** Programmable abbreviation to avoid complicated rules in the client */
  abbreviation?: Maybe<Scalars['String']['output']>;
  /** Active is a control for discoverability; inactive tags are hidden by default in searchTags */
  active?: Maybe<Scalars['Boolean']['output']>;
  /** A list of child tags associated with a tag */
  children: Array<Tag>;
  /** The primary color associated with the tag, represented as a string in hexadecimal format */
  color1?: Maybe<Scalars['String']['output']>;
  /** The secondary color associated with the tag, represented as a string in hexadecimal format */
  color2?: Maybe<Scalars['String']['output']>;
  /** A boolean value indicating whether the tag should display a logo or not */
  displayLogo?: Maybe<Scalars['Boolean']['output']>;
  /** The date and time when the tag expires, represented as a string in ISO 8601 format */
  expiresAt?: Maybe<Scalars['String']['output']>;
  /** A URL for the tag the origin resource */
  href?: Maybe<Scalars['String']['output']>;
  id: Scalars['ID']['output'];
  /** The logo filename (currently) assumes that it is the tail of a URI */
  logoFileName?: Maybe<Scalars['String']['output']>;
  menu?: Maybe<Menu>;
  /** Full display name for the tag */
  name: Scalars['String']['output'];
  /** Indicates if a tag  */
  newsletterEnabled?: Maybe<Scalars['Boolean']['output']>;
  /** The parent tag */
  parent?: Maybe<Tag>;
  /** A list of parents tags associated with a tag */
  parents: Array<Tag>;
  /** A unique name for the tag in a URL friendly format (i.e. nfl) */
  permalink: Scalars['String']['output'];
  /** A display hint for relative positioning. Siblings should be well-ordered, but positions don't freely translate elsewhere */
  position?: Maybe<Scalars['Int']['output']>;
  /** The root tag in the particular subtree */
  root?: Maybe<Tag>;
  /** The URL BR Shop related to tag or campaign */
  shopUrl?: Maybe<Scalars['String']['output']>;
  /** A short name for representing the tag */
  shortName?: Maybe<Scalars['String']['output']>;
  /** Site section the tag belongs to */
  site?: Maybe<Scalars['String']['output']>;
  /** The color associated with a team, represented as a string in hexadecimal format */
  teamColor?: Maybe<Scalars['String']['output']>;
  /** A URL linking to a page where tickets for events associated with the tag can be purchased */
  ticketsLink?: Maybe<Scalars['String']['output']>;
  /** Type of the tag and the entity it represents */
  type?: Maybe<TagType>;
};


export type TagMenuArgs = {
  tenant: Tenant;
};

export type TagComponent = {
  isPinned?: InputMaybe<Scalars['Boolean']['input']>;
  isPositionLocked?: InputMaybe<Scalars['Boolean']['input']>;
  position?: InputMaybe<Scalars['Int']['input']>;
  positionLockExpiresAt?: InputMaybe<Scalars['Date']['input']>;
  semanticID: SemanticId;
  tagUUID: Scalars['String']['input'];
};

export type TagGroup = {
  __typename?: 'TagGroup';
  _id: Scalars['MongoID']['output'];
  children?: Maybe<Array<Maybe<TagV2>>>;
  cmsId?: Maybe<Scalars['String']['output']>;
  displayName?: Maybe<Scalars['String']['output']>;
  isPublished?: Maybe<Scalars['Boolean']['output']>;
  language?: Maybe<Scalars['String']['output']>;
  schemaVersion?: Maybe<Scalars['String']['output']>;
  slug: Scalars['String']['output'];
  tenant?: Maybe<Scalars['String']['output']>;
  type: EnumTagGroupType;
  uuid: Scalars['String']['output'];
};

export type TagInput = {
  id?: InputMaybe<Scalars['String']['input']>;
};

export type TagSearchParamsInput = {
  /** Filter search results to only Tags that have a Channel */
  isChannel?: InputMaybe<Scalars['Boolean']['input']>;
  /** Whether or not the tag should be visible in the Content Tool */
  isVisibleInContentTool?: InputMaybe<Scalars['Boolean']['input']>;
  /** Whether or not the tag should be visible in the Programming Tool */
  isVisibleInProgrammingTool?: InputMaybe<Scalars['Boolean']['input']>;
  /**
   * Term or characters to search for.
   *
   * Requires a minimum of 2 characters to start getting results.
   */
  term: Scalars['String']['input'];
};

export enum TagType {
  Aggregated = 'Aggregated',
  Archived = 'Archived',
  Blog = 'Blog',
  CampaignHub = 'CampaignHub',
  Chain = 'Chain',
  City = 'City',
  Conference = 'Conference',
  Division = 'Division',
  Editorial = 'Editorial',
  Event = 'Event',
  ExternalContributor = 'ExternalContributor',
  GridHub = 'GridHub',
  Grouping = 'Grouping',
  LeadWriter = 'LeadWriter',
  League = 'League',
  Location = 'Location',
  Moment = 'Moment',
  National = 'National',
  Person = 'Person',
  Sport = 'Sport',
  State = 'State',
  Tag = 'Tag',
  Talent = 'Talent',
  Team = 'Team',
  Topic = 'Topic',
  Venue = 'Venue',
  Video = 'Video'
}

export enum TagTypeV2 {
  Conference = 'Conference',
  Creator = 'Creator',
  Division = 'Division',
  Editor = 'Editor',
  Editorial = 'Editorial',
  Event = 'Event',
  GameCast = 'GameCast',
  Interest = 'Interest',
  League = 'League',
  Page = 'Page',
  Person = 'Person',
  Player = 'Player',
  Sport = 'Sport',
  Team = 'Team'
}

export type TagV2 = {
  __typename?: 'TagV2';
  _id: Scalars['MongoID']['output'];
  abbreviation?: Maybe<Scalars['String']['output']>;
  /** @deprecated use field updatedAt which is a correctly typed Date */
  changed?: Maybe<Scalars['String']['output']>;
  channelState?: Maybe<EnumTagV2ChannelState>;
  children?: Maybe<Array<Maybe<TagV2>>>;
  cmsId?: Maybe<Scalars['String']['output']>;
  colorPrimary?: Maybe<Scalars['String']['output']>;
  colorSecondary?: Maybe<Scalars['String']['output']>;
  creatorTier?: Maybe<CreatorTier>;
  description?: Maybe<Scalars['String']['output']>;
  displayName?: Maybe<Scalars['String']['output']>;
  endTime?: Maybe<Scalars['Date']['output']>;
  eyebrow?: Maybe<Scalars['String']['output']>;
  followers?: Maybe<Array<Maybe<User>>>;
  followersCount: Scalars['Int']['output'];
  following?: Maybe<Array<Maybe<TagV2>>>;
  followingMetadata?: Maybe<FollowingMetadata>;
  foreignId?: Maybe<Scalars['String']['output']>;
  gameStatus?: Maybe<Scalars['String']['output']>;
  isChannel?: Maybe<Scalars['Boolean']['output']>;
  isFeatured?: Maybe<Scalars['Boolean']['output']>;
  isPublished?: Maybe<Scalars['Boolean']['output']>;
  isVisibleContentTool?: Maybe<Scalars['Boolean']['output']>;
  isVisibleProgrammingTool?: Maybe<Scalars['Boolean']['output']>;
  language?: Maybe<Scalars['String']['output']>;
  locationRelatedTags?: Maybe<Array<Maybe<TagV2>>>;
  logo?: Maybe<Image>;
  menu?: Maybe<Menu>;
  notifications?: Maybe<Array<Maybe<Notifications>>>;
  parent?: Maybe<TagV2>;
  parents?: Maybe<Array<Maybe<TagV2>>>;
  recommendedArticles: Array<DsContentModelResult>;
  recommendedTags: Array<ChannelRecommenderResult>;
  root?: Maybe<TagV2>;
  schemaVersion?: Maybe<Scalars['String']['output']>;
  settings?: Maybe<Settings>;
  shortName?: Maybe<Scalars['String']['output']>;
  slug: Scalars['String']['output'];
  startTime?: Maybe<Scalars['Date']['output']>;
  tagUUID?: Maybe<Scalars['String']['output']>;
  tenant?: Maybe<Scalars['String']['output']>;
  ticketLink?: Maybe<Scalars['String']['output']>;
  type?: Maybe<TagTypeV2>;
  updatedAt?: Maybe<Scalars['Date']['output']>;
  user?: Maybe<User>;
  uuid: Scalars['String']['output'];
  watchInfo?: Maybe<Array<Maybe<WatchInfo>>>;
};


export type TagV2FollowersArgs = {
  last_user_id?: InputMaybe<Scalars['String']['input']>;
  limit: Scalars['Int']['input'];
  tenant: Tenant;
};


export type TagV2FollowersCountArgs = {
  tenant?: InputMaybe<Tenant>;
};


export type TagV2FollowingArgs = {
  creatorBoltId?: InputMaybe<Scalars['String']['input']>;
  limit: Scalars['Int']['input'];
  tenant: Tenant;
};


export type TagV2RecommendedArticlesArgs = {
  limit?: InputMaybe<Scalars['Int']['input']>;
};


export type TagV2RecommendedTagsArgs = {
  limit?: InputMaybe<Scalars['Int']['input']>;
  type?: InputMaybe<TagTypeV2>;
};


export type TagV2WatchInfoArgs = {
  providerName?: InputMaybe<Scalars['String']['input']>;
};

export type TagV2Connection = {
  __typename?: 'TagV2Connection';
  edges: Array<TagV2Edge>;
  pageInfo: PageInfo;
  totalCount: Scalars['Int']['output'];
};

export type TagV2Edge = {
  __typename?: 'TagV2Edge';
  cursor: Scalars['ComponentCursor']['output'];
  node: TagV2;
};

export type Tagging = {
  __typename?: 'Tagging';
  _id?: Maybe<Scalars['MongoID']['output']>;
  competitors?: Maybe<Array<Maybe<Competitor>>>;
  events?: Maybe<Array<Maybe<Event>>>;
  shows?: Maybe<Array<Maybe<Scalars['String']['output']>>>;
  tags?: Maybe<Array<Maybe<Scalars['String']['output']>>>;
  tournaments?: Maybe<Array<Maybe<Tournament>>>;
};

export type TagsQueryInput = {
  slugs?: InputMaybe<Array<Scalars['String']['input']>>;
  uuids?: InputMaybe<Array<Scalars['String']['input']>>;
};

export type TaxonomyReference = {
  __typename?: 'TaxonomyReference';
  taxonomyId?: Maybe<Identifier>;
};

export type TaxonomyReferenceGroup = {
  __typename?: 'TaxonomyReferenceGroup';
  kind?: Maybe<Scalars['String']['output']>;
  taxonomyReferences?: Maybe<Array<Maybe<TaxonomyReference>>>;
};

export type TaxonomyTerm = {
  __typename?: 'TaxonomyTerm';
  _id: Scalars['MongoID']['output'];
  changed?: Maybe<Scalars['String']['output']>;
  cmsId: Scalars['String']['output'];
  created?: Maybe<Scalars['String']['output']>;
  description?: Maybe<Scalars['String']['output']>;
  id: Scalars['String']['output'];
  image?: Maybe<Image>;
  isPublished?: Maybe<Scalars['Boolean']['output']>;
  language?: Maybe<Scalars['String']['output']>;
  name?: Maybe<Scalars['String']['output']>;
  parentId?: Maybe<Scalars['String']['output']>;
  schemaVersion?: Maybe<Scalars['String']['output']>;
  sportsRadarId?: Maybe<Scalars['String']['output']>;
  tenant?: Maybe<Scalars['String']['output']>;
  tournamentId?: Maybe<Scalars['String']['output']>;
  type?: Maybe<Scalars['String']['output']>;
  uuid: Scalars['String']['output'];
  year?: Maybe<Scalars['String']['output']>;
};

export enum TaxonomyType {
  SeriesTaxonomy = 'seriesTaxonomy',
  ShowTaxonomy = 'showTaxonomy'
}

export type Team = {
  __typename?: 'Team';
  abbreviation?: Maybe<Scalars['String']['output']>;
  draws?: Maybe<Scalars['String']['output']>;
  logo?: Maybe<Scalars['String']['output']>;
  losses?: Maybe<Scalars['String']['output']>;
  market?: Maybe<Scalars['String']['output']>;
  mascot?: Maybe<Scalars['String']['output']>;
  name?: Maybe<Scalars['String']['output']>;
  wins?: Maybe<Scalars['String']['output']>;
};

/** GSP Tenant enumeration */
export enum Tenant {
  AewGame = 'aewGame',
  BleacherReport = 'bleacherReport',
  EstadioArgentina = 'estadioArgentina',
  EstadioBrazil = 'estadioBrazil',
  EstadioChile = 'estadioChile',
  Ncaa = 'ncaa'
}

export enum Tenants {
  BleacherReport = 'bleacherReport',
  EstadioArgentina = 'estadioArgentina',
  EstadioChile = 'estadioChile',
  HboMaxBrazil = 'hboMaxBrazil',
  HboMaxMexico = 'hboMaxMexico'
}

export enum Territories {
  Usa = 'USA'
}

export type TextPollInput = {
  contentId?: InputMaybe<Scalars['ID']['input']>;
  interactiveUntil?: InputMaybe<Scalars['String']['input']>;
  options?: InputMaybe<Array<TextPollOptionInput>>;
  question: Scalars['String']['input'];
  semanticId?: InputMaybe<SemanticId>;
  tagUUIDs: Array<Scalars['String']['input']>;
  timeout?: InputMaybe<Scalars['String']['input']>;
  uploadId?: InputMaybe<Scalars['ID']['input']>;
  widget_attributes?: InputMaybe<Array<TextPollWidgetInput>>;
};

export type TextPollOptionInput = {
  description: Scalars['String']['input'];
  id?: InputMaybe<Scalars['ID']['input']>;
};

export type TextPollWidgetInput = {
  key: Scalars['String']['input'];
  value: Scalars['String']['input'];
};

export type Tournament = {
  __typename?: 'Tournament';
  display_name?: Maybe<Scalars['String']['output']>;
  display_name_short?: Maybe<Scalars['String']['output']>;
  has_media?: Maybe<Scalars['Boolean']['output']>;
  hash?: Maybe<Scalars['String']['output']>;
  id?: Maybe<Scalars['ID']['output']>;
  is_featured?: Maybe<Scalars['Boolean']['output']>;
  is_popular?: Maybe<Scalars['Boolean']['output']>;
  league?: Maybe<League>;
  name?: Maybe<Scalars['String']['output']>;
  sport?: Maybe<Sport>;
  team_tournament?: Maybe<Scalars['Boolean']['output']>;
  territories_available?: Maybe<Array<Maybe<Territories>>>;
};

export type Tournaments = {
  __typename?: 'Tournaments';
  index_end?: Maybe<Scalars['Int']['output']>;
  index_start?: Maybe<Scalars['Int']['output']>;
  total?: Maybe<Scalars['Int']['output']>;
  tournaments?: Maybe<Array<Maybe<Tournament>>>;
};

export type TrendingChannelResult = {
  __typename?: 'TrendingChannelResult';
  rank: Scalars['Int']['output'];
  tagV2: TagV2;
};

export type TrendingResult = DsContentModelResult & {
  __typename?: 'TrendingResult';
  contentID: Scalars['String']['output'];
  contentModule?: Maybe<StandaloneContentModule>;
  rank: Scalars['Int']['output'];
  type: ContentModuleType;
};

/** A Tweet Entity from X */
export type Tweet = {
  __typename?: 'Tweet';
  /** The Tweet Author */
  author?: Maybe<TwitterUser>;
  /** A Data-Struct of the Tweet */
  data?: Maybe<TweetData>;
  /** Tweet Uuid */
  id: Scalars['ID']['output'];
  /** Additional Media referenced by the Tweet */
  media?: Maybe<Array<Maybe<TweetMedia>>>;
  /** Another Tweet that is referenced by this Tweet */
  referencedTweet?: Maybe<Tweet>;
  /** Type of the tweet */
  type: TweetType;
};

/** A Tweet's Attachments */
export type TweetAttachments = {
  __typename?: 'TweetAttachments';
  /** MediaKeys */
  mediaKeys?: Maybe<Array<Maybe<Scalars['String']['output']>>>;
  /** Ids for Polls */
  pollIds?: Maybe<Array<Maybe<Scalars['String']['output']>>>;
};

/** A Tweet's Primary Data */
export type TweetData = {
  __typename?: 'TweetData';
  /** Tweet Attachments */
  attachments?: Maybe<TweetAttachments>;
  /** Tweet AuthorId */
  authorId: Scalars['String']['output'];
  /** Tweet created Date */
  createdAt: Scalars['String']['output'];
  /** Tweet engagement entities */
  entities?: Maybe<TweetEntities>;
  /** Tweet metrics */
  publicMetrics: TweetMetrics;
  /** Other tweet entities referenced */
  referencedTweets?: Maybe<Array<Maybe<TweetReference>>>;
  /** Tweet text */
  text: Scalars['String']['output'];
};

/** Social Media Entities */
export type TweetEntities = {
  __typename?: 'TweetEntities';
  /** Hash Tags */
  hashTags?: Maybe<Array<Maybe<TweetHashtag>>>;
  /** Mentions */
  mentions?: Maybe<Array<Maybe<TweetMention>>>;
  /** Urls */
  urls?: Maybe<Array<Maybe<TweetUrl>>>;
};

/** Tweet HashTag */
export type TweetHashtag = {
  __typename?: 'TweetHashtag';
  /** End */
  end: Scalars['Int']['output'];
  /** Start */
  start: Scalars['Int']['output'];
  /** Tag */
  tag: Scalars['String']['output'];
};

/** Tweet Media */
export type TweetMedia = {
  __typename?: 'TweetMedia';
  /** Height in px */
  height: Scalars['Int']['output'];
  /** MediaKey */
  mediaKey: Scalars['String']['output'];
  /** Preview Image Url */
  previewImageUrl?: Maybe<Scalars['String']['output']>;
  /** Media Type */
  type: TweetMediaType;
  /** Url */
  url?: Maybe<Scalars['String']['output']>;
  /** Variant */
  variants?: Maybe<Array<Maybe<TweetVariant>>>;
  /** Width in px */
  width: Scalars['Int']['output'];
};

export enum TweetMediaType {
  AnimatedGif = 'ANIMATED_GIF',
  Photo = 'PHOTO',
  Video = 'VIDEO'
}

/** Tweet Mention */
export type TweetMention = {
  __typename?: 'TweetMention';
  /** End */
  end: Scalars['Int']['output'];
  /** Start */
  start: Scalars['Int']['output'];
  /** Username */
  username: Scalars['String']['output'];
};

/** A Tweet's Metrics */
export type TweetMetrics = {
  __typename?: 'TweetMetrics';
  /** Bookmark Count */
  bookmarkCount: Scalars['Int']['output'];
  /** Impression Count */
  impressionCount: Scalars['Int']['output'];
  /** Like Count */
  likeCount: Scalars['Int']['output'];
  /** Quote Count */
  quoteCount: Scalars['Int']['output'];
  /** Reply Count */
  replyCount: Scalars['Int']['output'];
  /** Retweet Count */
  retweetCount: Scalars['Int']['output'];
};

/** Tweet Reference */
export type TweetReference = {
  __typename?: 'TweetReference';
  /** Id */
  id: Scalars['ID']['output'];
  /** Reference Type */
  referenceType?: Maybe<Scalars['String']['output']>;
};

export enum TweetType {
  Original = 'ORIGINAL',
  Quoted = 'QUOTED',
  RepliedTo = 'REPLIED_TO',
  Retweeted = 'RETWEETED'
}

/** Tweet Url */
export type TweetUrl = {
  __typename?: 'TweetUrl';
  /** Display Url Format */
  displayUrl: Scalars['String']['output'];
  /** End */
  end: Scalars['Int']['output'];
  /** Expanded Url */
  expandedUrl: Scalars['String']['output'];
  /** Start */
  start: Scalars['Int']['output'];
  /** Url */
  url: Scalars['String']['output'];
};

/** Tweet Variant */
export type TweetVariant = {
  __typename?: 'TweetVariant';
  /** BitRate */
  bitRate?: Maybe<Scalars['Int']['output']>;
  /** Content Type */
  contentType: Scalars['String']['output'];
  /** Url */
  url: Scalars['String']['output'];
};

/** A Twitter User */
export type TwitterUser = {
  __typename?: 'TwitterUser';
  /** Twitter User Id */
  id: Scalars['ID']['output'];
  /** Name of the User */
  name: Scalars['String']['output'];
  /** URL of the User's Profile Image */
  profileImageUrl: Scalars['String']['output'];
  /** Username of the User */
  username: Scalars['String']['output'];
  /** Whether the User is Verified */
  verified: Scalars['Boolean']['output'];
};

export type UgcImagePoll = {
  __typename?: 'UGCImagePoll';
  id: Scalars['ID']['output'];
  /**  LiveLike resolver for ImagePoll  */
  liveLikeImagePoll?: Maybe<LiveLikeImagePoll>;
  /**  LiveLike resolver for ImagePoll userVote  */
  liveLikeUserVote?: Maybe<LiveLikeImagePollVote>;
};

export type UgcPost = {
  __typename?: 'UGCPost';
  id: Scalars['ID']['output'];
  /**  LiveLike resolver for RichPost  */
  liveLikeRichPost?: Maybe<LiveLikeRichPost>;
  uploadId?: Maybe<Scalars['String']['output']>;
};

export type UgcTextPoll = {
  __typename?: 'UGCTextPoll';
  id: Scalars['ID']['output'];
  /**  LiveLike resolver for TextPoll  */
  liveLikeTextPoll?: Maybe<LiveLikeTextPoll>;
  /**  LiveLike resolver for TextPoll userVote  */
  liveLikeUserVote?: Maybe<LiveLikeTextPollVote>;
};

export type UgcWidget = {
  __typename?: 'UGCWidget';
  clientId: Scalars['String']['output'];
  /**  LiveLike resolver for total reactions on type REACTION_SPACE | COMMENT_BOARD */
  count?: Maybe<Scalars['Int']['output']>;
  fireReactionId?: Maybe<Scalars['String']['output']>;
  /**  LiveLike resolver for user reaction on type REACTION_SPACE  */
  liveLikeUserReaction?: Maybe<LiveLikeUserReaction>;
  targetGroupId?: Maybe<Scalars['String']['output']>;
  type: Scalars['String']['output'];
  widgetId: Scalars['String']['output'];
};

export type UpdatePostInput = {
  content: Scalars['String']['input'];
  postId: Scalars['String']['input'];
  uploadId?: InputMaybe<Scalars['ID']['input']>;
};

export type UpdateTextPollInput = {
  contentId?: InputMaybe<Scalars['ID']['input']>;
  interactiveUntil?: InputMaybe<Scalars['String']['input']>;
  options?: InputMaybe<Array<TextPollOptionInput>>;
  pollId: Scalars['String']['input'];
  question: Scalars['String']['input'];
  semanticId?: InputMaybe<SemanticId>;
  timeout?: InputMaybe<Scalars['String']['input']>;
  uploadId?: InputMaybe<Scalars['ID']['input']>;
  widget_attributes?: InputMaybe<Array<TextPollWidgetInput>>;
};

export type UrlMapping = {
  __typename?: 'UrlMapping';
  mediaId: Scalars['String']['output'];
  status: Scalars['String']['output'];
  uploadUrl: Scalars['String']['output'];
};

export type User = {
  __typename?: 'User';
  avatar?: Maybe<Avatar>;
  badges?: Maybe<Array<Maybe<BadgeComponent>>>;
  creatorId?: Maybe<Scalars['String']['output']>;
  creatorTag?: Maybe<TagV2>;
  favoriteTeams?: Maybe<Array<Maybe<TagV2>>>;
  followers?: Maybe<Scalars['Int']['output']>;
  following?: Maybe<Scalars['Int']['output']>;
  globalBan?: Maybe<Scalars['String']['output']>;
  id?: Maybe<Scalars['String']['output']>;
  liveLikeProfileId?: Maybe<Scalars['String']['output']>;
  liveLikeToken?: Maybe<Scalars['String']['output']>;
  name?: Maybe<Name>;
  profileDescription?: Maybe<Scalars['String']['output']>;
  profileId?: Maybe<Scalars['String']['output']>;
  recommendedLeagues?: Maybe<Array<TrendingChannelResult>>;
  recommendedTeams?: Maybe<Array<TrendingChannelResult>>;
  recommendedVideos?: Maybe<Array<TrendingResult>>;
  /** @deprecated This field is deprecated and will be removed in a future version. Please use alternative scoring endpoints. */
  scores?: Maybe<Scores>;
  settings?: Maybe<Settings>;
  socialLinks?: Maybe<SocialLinks>;
  tags?: Maybe<Array<Maybe<TagV2>>>;
  type?: Maybe<Scalars['String']['output']>;
};


export type UserFollowersArgs = {
  tenant?: InputMaybe<Tenant>;
};


export type UserFollowingArgs = {
  tenant?: InputMaybe<Tenant>;
};


export type UserScoresArgs = {
  context?: InputMaybe<Scalars['String']['input']>;
  date?: InputMaybe<Scalars['String']['input']>;
  league?: InputMaybe<Scalars['String']['input']>;
};

export type UserDestination = {
  __typename?: 'UserDestination';
  contentModule?: Maybe<StandaloneContentModule>;
  /** The Content Module ID. It can be null when the alert is sent to the Channel */
  contentModuleId?: Maybe<Scalars['ID']['output']>;
  tag: TagV2;
};

/**
 * UserSocialAlert | Mock-only helper type
 *
 * This exists in `frontend-mock/schema.graphql` to enable frontend development
 * against mocked social-alert responses without requiring remote schema publish.
 */
export type UserSocialAlert = {
  __typename?: 'UserSocialAlert';
  activityType?: Maybe<Scalars['String']['output']>;
  adParameters?: Maybe<Scalars['String']['output']>;
  attachments?: Maybe<Array<AlertMediaAttachment>>;
  commentId?: Maybe<Scalars['String']['output']>;
  createdAt?: Maybe<Scalars['DateTime']['output']>;
  id: Scalars['ID']['output'];
  postId?: Maybe<Scalars['String']['output']>;
  showActivityCard?: Maybe<Scalars['Boolean']['output']>;
  showAlertCard?: Maybe<Scalars['Boolean']['output']>;
  sourceUserId?: Maybe<Scalars['String']['output']>;
  targetUserId?: Maybe<Scalars['String']['output']>;
  text?: Maybe<Scalars['String']['output']>;
  textHtml?: Maybe<Scalars['String']['output']>;
  title?: Maybe<Scalars['String']['output']>;
  titleHtml?: Maybe<Scalars['String']['output']>;
  userDestination?: Maybe<UserDestination>;
};

export type UserTagInput = {
  alerts?: InputMaybe<Array<InputMaybe<AlertInput>>>;
  notifications?: InputMaybe<Array<InputMaybe<NotificationInput>>>;
  tagUUID: Scalars['String']['input'];
  weight?: InputMaybe<Scalars['Float']['input']>;
};

export type V2VResult = DsContentModelResult & {
  __typename?: 'V2VResult';
  contentID: Scalars['String']['output'];
  score: Scalars['Float']['output'];
  type: ContentModuleType;
  video?: Maybe<StandaloneContentModule>;
};

export type Venue = {
  __typename?: 'Venue';
  address?: Maybe<Scalars['String']['output']>;
  capacity?: Maybe<Scalars['String']['output']>;
  city?: Maybe<Scalars['String']['output']>;
  country?: Maybe<Scalars['String']['output']>;
  id?: Maybe<Scalars['ID']['output']>;
  name?: Maybe<Scalars['String']['output']>;
  state?: Maybe<Scalars['String']['output']>;
  time_zone?: Maybe<Scalars['String']['output']>;
  zip?: Maybe<Scalars['String']['output']>;
};

export type Venues = {
  __typename?: 'Venues';
  index_end?: Maybe<Scalars['Int']['output']>;
  index_start?: Maybe<Scalars['Int']['output']>;
  total?: Maybe<Scalars['Int']['output']>;
  venues?: Maybe<Array<Maybe<Venue>>>;
};

export type Video = {
  __typename?: 'Video';
  _id: Scalars['MongoID']['output'];
  cardLabel?: Maybe<Scalars['String']['output']>;
  changed?: Maybe<Scalars['String']['output']>;
  cmsId: Scalars['String']['output'];
  collectionName?: Maybe<Scalars['String']['output']>;
  created?: Maybe<Scalars['String']['output']>;
  duration?: Maybe<Scalars['String']['output']>;
  episodeNumber?: Maybe<Scalars['String']['output']>;
  /** @deprecated Use Video.tagging.events. */
  events?: Maybe<Array<Maybe<Event>>>;
  headline?: Maybe<Scalars['String']['output']>;
  isPublished?: Maybe<Scalars['Boolean']['output']>;
  language?: Maybe<Scalars['String']['output']>;
  mediaId?: Maybe<Scalars['String']['output']>;
  schemaVersion?: Maybe<Scalars['String']['output']>;
  sortDate?: Maybe<Scalars['String']['output']>;
  subHeadline?: Maybe<Scalars['String']['output']>;
  tagging?: Maybe<Tagging>;
  tenant?: Maybe<Scalars['String']['output']>;
  thumbnail?: Maybe<Scalars['String']['output']>;
  title?: Maybe<Scalars['String']['output']>;
  uuid: Scalars['String']['output'];
};

export type VideoAnalytics = {
  __typename?: 'VideoAnalytics';
  /** Video Analytics creationTimePeriod */
  creationTimePeriod?: Maybe<Scalars['String']['output']>;
  /** Video Analytics id */
  id: Scalars['String']['output'];
  /** Video Analytics league */
  league?: Maybe<Scalars['String']['output']>;
  /** Video Analytics publishMethod */
  publishMethod?: Maybe<Scalars['String']['output']>;
  /** Video Analytics publishedAt time */
  publishedAt?: Maybe<Scalars['String']['output']>;
  /** Video Analytics rating */
  rating?: Maybe<Scalars['String']['output']>;
  /** Video Analytics rule Id */
  ruleId?: Maybe<Scalars['String']['output']>;
  /** Video Analytics rule Name */
  ruleName?: Maybe<Scalars['String']['output']>;
  /** Video Analytics stream */
  stream?: Maybe<Scalars['String']['output']>;
  /** Video Analytics team */
  team?: Maybe<Scalars['String']['output']>;
  /** Video Analytics title */
  title?: Maybe<Scalars['String']['output']>;
  /** Video Analytics video Id */
  videoId?: Maybe<Scalars['Int']['output']>;
  /** Video Analytics video Type from vid - (i.e. video/highlight) */
  videoType?: Maybe<Scalars['String']['output']>;
};

export type VideoAppName = {
  __typename?: 'VideoAppName';
  allowValues?: Maybe<Array<Maybe<Scalars['String']['output']>>>;
};

export enum VideoContentType {
  ContentTypeAdvertisement = 'CONTENT_TYPE_ADVERTISEMENT',
  ContentTypeClip = 'CONTENT_TYPE_CLIP',
  ContentTypeFullEventReplay = 'CONTENT_TYPE_FULL_EVENT_REPLAY',
  ContentTypeLive = 'CONTENT_TYPE_LIVE',
  ContentTypeQuickvod = 'CONTENT_TYPE_QUICKVOD',
  ContentTypeStartOver = 'CONTENT_TYPE_START_OVER',
  ContentTypeUnspecified = 'CONTENT_TYPE_UNSPECIFIED',
  ContentTypeVod = 'CONTENT_TYPE_VOD'
}

export enum VideoContentTypeFilter {
  Clip = 'CLIP',
  FullLength = 'FULL_LENGTH'
}

/** Passing multiple filter values is currently **not supported** */
export type VideoFiltersInput = {
  /** Provides the ability to filter video clips to a specific Event. Value passed should be the **sportradar_id** (ex. `sr:match:1234`) */
  event?: InputMaybe<Scalars['String']['input']>;
  /** Provides the ability to filter video clips to a specific Team. Value passed should be the **sportradar_id** (ex. `sr:competitor:1234`) */
  team?: InputMaybe<Scalars['String']['input']>;
};

export type VideoImpressionTracking = {
  __typename?: 'VideoImpressionTracking';
  /** Video Impression Tracking name */
  name?: Maybe<Scalars['String']['output']>;
  /** Video Impression Tracking url */
  url?: Maybe<Scalars['String']['output']>;
};

export type VideoMetadata = {
  __typename?: 'VideoMetadata';
  /** Video's analytics */
  analytics?: Maybe<VideoAnalytics>;
  /** Video's duration */
  duration?: Maybe<Scalars['Int']['output']>;
  /** Video's height */
  height?: Maybe<Scalars['Int']['output']>;
  /** Video's hlsUrl */
  hlsUrl?: Maybe<Scalars['String']['output']>;
  /** Video's impressionTracking */
  impressionTracking?: Maybe<Array<Maybe<VideoImpressionTracking>>>;
  /** Video's mp4Url */
  mp4Url?: Maybe<Scalars['String']['output']>;
  /** Video's state from airchain and hotmic (i.e. live, upcoming, etc.) */
  state?: Maybe<Scalars['String']['output']>;
  /** Video's Id */
  videoId?: Maybe<Scalars['Int']['output']>;
  /** Video's videoUrl */
  videoUrl?: Maybe<Scalars['String']['output']>;
  /** Video's width */
  width?: Maybe<Scalars['Int']['output']>;
};

export type VideoMetadataInput = {
  newState: VideoState;
  videoId: Scalars['String']['input'];
};

export enum VideoState {
  Ended = 'ENDED',
  Live = 'LIVE',
  Upcoming = 'UPCOMING',
  Vod = 'VOD'
}

export type VideoTitle = {
  __typename?: 'VideoTitle';
  localizations?: Maybe<Array<Maybe<Localization>>>;
  scope?: Maybe<Scalars['String']['output']>;
  type?: Maybe<Scalars['String']['output']>;
};

export enum VideoType {
  VideoTypeClip = 'VIDEO_TYPE_CLIP',
  VideoTypeEpisode = 'VIDEO_TYPE_EPISODE',
  VideoTypeLive = 'VIDEO_TYPE_LIVE',
  VideoTypeMovie = 'VIDEO_TYPE_MOVIE',
  VideoTypePromo = 'VIDEO_TYPE_PROMO',
  VideoTypeStandalone = 'VIDEO_TYPE_STANDALONE',
  VideoTypeStandaloneEvent = 'VIDEO_TYPE_STANDALONE_EVENT',
  VideoTypeTrailer = 'VIDEO_TYPE_TRAILER',
  VideoTypeUnspecified = 'VIDEO_TYPE_UNSPECIFIED'
}

export type VideoV2 = {
  __typename?: 'VideoV2';
  _id: Scalars['MongoID']['output'];
  cmsId?: Maybe<Scalars['String']['output']>;
  contentType?: Maybe<VideoContentType>;
  createdAt?: Maybe<Scalars['Date']['output']>;
  /** @deprecated use field createdAt which is a correctly typed Date */
  createdDateTime?: Maybe<Scalars['String']['output']>;
  deliverableImage?: Maybe<Image>;
  description?: Maybe<Scalars['String']['output']>;
  durationSeconds?: Maybe<Scalars['Float']['output']>;
  eventId: Scalars['String']['output'];
  headline?: Maybe<Scalars['String']['output']>;
  height?: Maybe<Scalars['Int']['output']>;
  isPtScheduled?: Maybe<Scalars['Boolean']['output']>;
  isPublished?: Maybe<Scalars['Boolean']['output']>;
  /** @deprecated use field updatedAt which is a correctly typed Date */
  lastModifiedDateTime?: Maybe<Scalars['String']['output']>;
  offering?: Maybe<Offering>;
  playable?: Maybe<Scalars['Boolean']['output']>;
  program?: Maybe<Program>;
  recommendedVideos: Array<V2VResult>;
  schemaVersion?: Maybe<Scalars['String']['output']>;
  subHeadline?: Maybe<Scalars['String']['output']>;
  tags?: Maybe<Array<Maybe<TagV2>>>;
  tenant?: Maybe<Scalars['String']['output']>;
  title?: Maybe<Scalars['String']['output']>;
  /**
   * trendingRank | Data Services API
   *
   * Returns the Trending Rank from [1,100]. Returns null if not trending.
   */
  trendingRank?: Maybe<Scalars['Int']['output']>;
  updatedAt?: Maybe<Scalars['Date']['output']>;
  uuid?: Maybe<Scalars['String']['output']>;
  videoSource?: Maybe<Scalars['String']['output']>;
  videoState?: Maybe<VideoState>;
  videoType?: Maybe<VideoType>;
  width?: Maybe<Scalars['Int']['output']>;
};


export type VideoV2RecommendedVideosArgs = {
  aspectRatio?: InputMaybe<AspectRatio>;
  countryCode?: InputMaybe<Scalars['String']['input']>;
  limit?: InputMaybe<Scalars['Int']['input']>;
  version?: InputMaybe<Scalars['Int']['input']>;
};

export type VideoV2Metadata = {
  __typename?: 'VideoV2Metadata';
  state?: Maybe<VideoState>;
};

export type VideoV2TagData = {
  __typename?: 'VideoV2TagData';
  /** The type of tag for the associated id */
  type: TagTypeV2;
  /** List of tags on a given VideoV2 */
  uuid: Scalars['String']['output'];
};

export type VideoV2TagIds = {
  __typename?: 'VideoV2TagIds';
  /** VideoV2 eventId */
  eventId: Scalars['String']['output'];
  /** Ordered list of tag UUIDs associated with the video */
  tagData?: Maybe<Array<Maybe<VideoV2TagData>>>;
};

export enum VisibilityReason {
  HasData = 'HAS_DATA',
  InsideTimeWindow = 'INSIDE_TIME_WINDOW',
  NoData = 'NO_DATA',
  OutsideTimeWindow = 'OUTSIDE_TIME_WINDOW'
}

/**
 * Returns Affiliate TV Link information for Games/Events
 * if any are configured for a given GameCast tag/channel
 */
export type WatchInfo = {
  __typename?: 'WatchInfo';
  logoUrl?: Maybe<Scalars['String']['output']>;
  name?: Maybe<Scalars['String']['output']>;
  text?: Maybe<Array<Maybe<Scalars['String']['output']>>>;
  url?: Maybe<Scalars['String']['output']>;
};

export type BlockProfileResponse = {
  __typename?: 'blockProfileResponse';
  id?: Maybe<Scalars['String']['output']>;
  nickname?: Maybe<Scalars['String']['output']>;
};

export type GetSocialAlertsQueryVariables = Exact<{
  slug: Scalars['String']['input'];
  tenant: Tenant;
  userAlertsTenant2: Tenant;
}>;


export type GetSocialAlertsQuery = { __typename?: 'Query', getChannelBySlug?: { __typename?: 'Channel', uuid: string, components: Array<{ __typename?: 'ChannelComponent', userSocialAlerts?: Array<{ __typename?: 'UserSocialAlert', id: string, text?: string | null, title?: string | null, adParameters?: string | null, createdAt?: any | null, showAlertCard?: boolean | null, attachments?: Array<{ __typename?: 'AlertMediaAttachment', mediaType: AlertMediaType, mediaUrl: string, height?: string | null, width?: string | null }> | null, userDestination?: { __typename?: 'UserDestination', contentModule?: { __typename?: 'StandaloneContentModule', contentID?: string | null, type: ContentModuleType, id: string, commentsEnabled?: boolean | null, socialWidgets?: Array<{ __typename?: 'SocialWidget', clientId: string } | null> | null } | null, tag: { __typename?: 'TagV2', _id: any } } | null }> | null, userAlerts?: Array<{ __typename?: 'PushNotification', id: string, text: string, title: string, adParameters?: string | null, createdAt: any, showAlertCard?: boolean | null, attachments: Array<{ __typename?: 'AlertMediaAttachment', mediaType: AlertMediaType, mediaUrl: string, height?: string | null, width?: string | null }>, userDestination?: { __typename?: 'UserDestination', contentModule?: { __typename?: 'StandaloneContentModule', contentID?: string | null, type: ContentModuleType, id: string, commentsEnabled?: boolean | null, socialWidgets?: Array<{ __typename?: 'SocialWidget', clientId: string } | null> | null } | null, tag: { __typename?: 'TagV2', _id: any } } | null }> | null } | null> } | null };

export type GetUserQueryVariables = Exact<{
  tenant: Tenant;
}>;


export type GetUserQuery = { __typename?: 'Query', getUser?: { __typename?: 'User', id?: string | null, profileId?: string | null, settings?: { __typename?: 'Settings', spoilers_enabled?: string | null, alerts?: Array<{ __typename?: 'AlertPreference', type: AlertTypes, enabled: boolean }> | null, social?: Array<{ __typename?: 'SocialPreference', type: string, enabled: boolean }> | null } | null } | null };

export type SetGlobalAlertsMutationVariables = Exact<{
  input: Array<InputMaybe<AlertInput>> | InputMaybe<AlertInput>;
}>;


export type SetGlobalAlertsMutation = { __typename?: 'Mutation', setGlobalAlerts?: { __typename?: 'Settings', spoilers_enabled?: string | null, alerts?: Array<{ __typename?: 'AlertPreference', type: AlertTypes, enabled: boolean }> | null, social?: Array<{ __typename?: 'SocialPreference', type: string, enabled: boolean }> | null } | null };


export const GetSocialAlertsDocument = {"kind":"Document","definitions":[{"kind":"OperationDefinition","operation":"query","name":{"kind":"Name","value":"GetSocialAlerts"},"variableDefinitions":[{"kind":"VariableDefinition","variable":{"kind":"Variable","name":{"kind":"Name","value":"slug"}},"type":{"kind":"NonNullType","type":{"kind":"NamedType","name":{"kind":"Name","value":"String"}}}},{"kind":"VariableDefinition","variable":{"kind":"Variable","name":{"kind":"Name","value":"tenant"}},"type":{"kind":"NonNullType","type":{"kind":"NamedType","name":{"kind":"Name","value":"Tenant"}}}},{"kind":"VariableDefinition","variable":{"kind":"Variable","name":{"kind":"Name","value":"userAlertsTenant2"}},"type":{"kind":"NonNullType","type":{"kind":"NamedType","name":{"kind":"Name","value":"Tenant"}}}}],"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"getChannelBySlug"},"arguments":[{"kind":"Argument","name":{"kind":"Name","value":"slug"},"value":{"kind":"Variable","name":{"kind":"Name","value":"slug"}}},{"kind":"Argument","name":{"kind":"Name","value":"tenant"},"value":{"kind":"Variable","name":{"kind":"Name","value":"tenant"}}}],"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"uuid"}},{"kind":"Field","name":{"kind":"Name","value":"components"},"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"userSocialAlerts"},"arguments":[{"kind":"Argument","name":{"kind":"Name","value":"tenant"},"value":{"kind":"Variable","name":{"kind":"Name","value":"tenant"}}}],"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"id"}},{"kind":"Field","name":{"kind":"Name","value":"text"}},{"kind":"Field","name":{"kind":"Name","value":"title"}},{"kind":"Field","name":{"kind":"Name","value":"adParameters"}},{"kind":"Field","name":{"kind":"Name","value":"createdAt"}},{"kind":"Field","name":{"kind":"Name","value":"showAlertCard"}},{"kind":"Field","name":{"kind":"Name","value":"attachments"},"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"mediaType"}},{"kind":"Field","name":{"kind":"Name","value":"mediaUrl"}},{"kind":"Field","name":{"kind":"Name","value":"height"}},{"kind":"Field","name":{"kind":"Name","value":"width"}}]}},{"kind":"Field","name":{"kind":"Name","value":"userDestination"},"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"contentModule"},"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"contentID"}},{"kind":"Field","name":{"kind":"Name","value":"type"}},{"kind":"Field","name":{"kind":"Name","value":"id"}},{"kind":"Field","name":{"kind":"Name","value":"commentsEnabled"}},{"kind":"Field","name":{"kind":"Name","value":"socialWidgets"},"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"clientId"}}]}}]}},{"kind":"Field","name":{"kind":"Name","value":"tag"},"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"_id"}}]}}]}}]}},{"kind":"Field","name":{"kind":"Name","value":"userAlerts"},"arguments":[{"kind":"Argument","name":{"kind":"Name","value":"tenant"},"value":{"kind":"Variable","name":{"kind":"Name","value":"userAlertsTenant2"}}}],"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"id"}},{"kind":"Field","name":{"kind":"Name","value":"text"}},{"kind":"Field","name":{"kind":"Name","value":"title"}},{"kind":"Field","name":{"kind":"Name","value":"adParameters"}},{"kind":"Field","name":{"kind":"Name","value":"createdAt"}},{"kind":"Field","name":{"kind":"Name","value":"showAlertCard"}},{"kind":"Field","name":{"kind":"Name","value":"attachments"},"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"mediaType"}},{"kind":"Field","name":{"kind":"Name","value":"mediaUrl"}},{"kind":"Field","name":{"kind":"Name","value":"height"}},{"kind":"Field","name":{"kind":"Name","value":"width"}}]}},{"kind":"Field","name":{"kind":"Name","value":"userDestination"},"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"contentModule"},"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"contentID"}},{"kind":"Field","name":{"kind":"Name","value":"type"}},{"kind":"Field","name":{"kind":"Name","value":"id"}},{"kind":"Field","name":{"kind":"Name","value":"commentsEnabled"}},{"kind":"Field","name":{"kind":"Name","value":"socialWidgets"},"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"clientId"}}]}}]}},{"kind":"Field","name":{"kind":"Name","value":"tag"},"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"_id"}}]}}]}}]}}]}}]}}]}}]} as unknown as DocumentNode<GetSocialAlertsQuery, GetSocialAlertsQueryVariables>;
export const GetUserDocument = {"kind":"Document","definitions":[{"kind":"OperationDefinition","operation":"query","name":{"kind":"Name","value":"GetUser"},"variableDefinitions":[{"kind":"VariableDefinition","variable":{"kind":"Variable","name":{"kind":"Name","value":"tenant"}},"type":{"kind":"NonNullType","type":{"kind":"NamedType","name":{"kind":"Name","value":"Tenant"}}}}],"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"getUser"},"arguments":[{"kind":"Argument","name":{"kind":"Name","value":"tenant"},"value":{"kind":"Variable","name":{"kind":"Name","value":"tenant"}}}],"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"id"}},{"kind":"Field","name":{"kind":"Name","value":"profileId"}},{"kind":"Field","name":{"kind":"Name","value":"settings"},"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"spoilers_enabled"}},{"kind":"Field","name":{"kind":"Name","value":"alerts"},"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"type"}},{"kind":"Field","name":{"kind":"Name","value":"enabled"}}]}},{"kind":"Field","name":{"kind":"Name","value":"social"},"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"type"}},{"kind":"Field","name":{"kind":"Name","value":"enabled"}}]}}]}}]}}]}}]} as unknown as DocumentNode<GetUserQuery, GetUserQueryVariables>;
export const SetGlobalAlertsDocument = {"kind":"Document","definitions":[{"kind":"OperationDefinition","operation":"mutation","name":{"kind":"Name","value":"SetGlobalAlerts"},"variableDefinitions":[{"kind":"VariableDefinition","variable":{"kind":"Variable","name":{"kind":"Name","value":"input"}},"type":{"kind":"NonNullType","type":{"kind":"ListType","type":{"kind":"NamedType","name":{"kind":"Name","value":"AlertInput"}}}}}],"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"setGlobalAlerts"},"arguments":[{"kind":"Argument","name":{"kind":"Name","value":"input"},"value":{"kind":"Variable","name":{"kind":"Name","value":"input"}}}],"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"spoilers_enabled"}},{"kind":"Field","name":{"kind":"Name","value":"alerts"},"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"type"}},{"kind":"Field","name":{"kind":"Name","value":"enabled"}}]}},{"kind":"Field","name":{"kind":"Name","value":"social"},"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"type"}},{"kind":"Field","name":{"kind":"Name","value":"enabled"}}]}}]}}]}}]} as unknown as DocumentNode<SetGlobalAlertsMutation, SetGlobalAlertsMutationVariables>;
export type WithIndex<TObject> = TObject & Record<string, any>;
export type ResolversObject<TObject> = WithIndex<TObject>;

export type ResolverTypeWrapper<T> = Promise<T> | T;


export type ResolverWithResolve<TResult, TParent, TContext, TArgs> = {
  resolve: ResolverFn<TResult, TParent, TContext, TArgs>;
};
export type Resolver<TResult, TParent = {}, TContext = {}, TArgs = {}> = ResolverFn<TResult, TParent, TContext, TArgs> | ResolverWithResolve<TResult, TParent, TContext, TArgs>;

export type ResolverFn<TResult, TParent, TContext, TArgs> = (
  parent: TParent,
  args: TArgs,
  context: TContext,
  info: GraphQLResolveInfo
) => Promise<TResult> | TResult;

export type SubscriptionSubscribeFn<TResult, TParent, TContext, TArgs> = (
  parent: TParent,
  args: TArgs,
  context: TContext,
  info: GraphQLResolveInfo
) => AsyncIterable<TResult> | Promise<AsyncIterable<TResult>>;

export type SubscriptionResolveFn<TResult, TParent, TContext, TArgs> = (
  parent: TParent,
  args: TArgs,
  context: TContext,
  info: GraphQLResolveInfo
) => TResult | Promise<TResult>;

export interface SubscriptionSubscriberObject<TResult, TKey extends string, TParent, TContext, TArgs> {
  subscribe: SubscriptionSubscribeFn<{ [key in TKey]: TResult }, TParent, TContext, TArgs>;
  resolve?: SubscriptionResolveFn<TResult, { [key in TKey]: TResult }, TContext, TArgs>;
}

export interface SubscriptionResolverObject<TResult, TParent, TContext, TArgs> {
  subscribe: SubscriptionSubscribeFn<any, TParent, TContext, TArgs>;
  resolve: SubscriptionResolveFn<TResult, any, TContext, TArgs>;
}

export type SubscriptionObject<TResult, TKey extends string, TParent, TContext, TArgs> =
  | SubscriptionSubscriberObject<TResult, TKey, TParent, TContext, TArgs>
  | SubscriptionResolverObject<TResult, TParent, TContext, TArgs>;

export type SubscriptionResolver<TResult, TKey extends string, TParent = {}, TContext = {}, TArgs = {}> =
  | ((...args: any[]) => SubscriptionObject<TResult, TKey, TParent, TContext, TArgs>)
  | SubscriptionObject<TResult, TKey, TParent, TContext, TArgs>;

export type TypeResolveFn<TTypes, TParent = {}, TContext = {}> = (
  parent: TParent,
  context: TContext,
  info: GraphQLResolveInfo
) => Maybe<TTypes> | Promise<Maybe<TTypes>>;

export type IsTypeOfResolverFn<T = {}, TContext = {}> = (obj: T, context: TContext, info: GraphQLResolveInfo) => boolean | Promise<boolean>;

export type NextResolverFn<T> = () => Promise<T>;

export type DirectiveResolverFn<TResult = {}, TParent = {}, TContext = {}, TArgs = {}> = (
  next: NextResolverFn<TResult>,
  parent: TParent,
  args: TArgs,
  context: TContext,
  info: GraphQLResolveInfo
) => TResult | Promise<TResult>;

/** Mapping of union types */
export type ResolversUnionTypes<_RefType extends Record<string, unknown>> = ResolversObject<{
  ContentLibrarySearchResult: ( Omit<Article, 'betTags' | 'primaryTag' | 'recommendedArticles' | 'recommendedVideos' | 'slides' | 'tags'> & { betTags?: Maybe<Array<Maybe<_RefType['TagV2']>>>, primaryTag: _RefType['TagV2'], recommendedArticles: Array<_RefType['A2AResult']>, recommendedVideos: Array<_RefType['A2VResult']>, slides?: Maybe<Array<Maybe<_RefType['Slide']>>>, tags?: Maybe<Array<Maybe<_RefType['TagV2']>>> } ) | ( Tweet ) | ( Omit<VideoV2, 'recommendedVideos' | 'tags'> & { recommendedVideos: Array<_RefType['V2VResult']>, tags?: Maybe<Array<Maybe<_RefType['TagV2']>>> } );
  LiveLikeWidget: ( LiveLikeAlert ) | ( Omit<LiveLikeImagePoll, 'userVote'> & { userVote?: Maybe<_RefType['LiveLikeWidgetInteraction']> } ) | ( LiveLikeImagePrediction ) | ( LiveLikeImagePredictionFollowUp ) | ( LiveLikeImageQuiz ) | ( LiveLikeRichPost ) | ( LiveLikeSocialEmbed ) | ( Omit<LiveLikeTextPoll, 'userVote'> & { userVote?: Maybe<_RefType['LiveLikeWidgetInteraction']> } ) | ( LiveLikeTextPrediction ) | ( LiveLikeTextPredictionFollowUp ) | ( LiveLikeTextQuiz ) | ( LiveLikeVideoAlert );
  LiveLikeWidgetInteractionUnion: ( Omit<LiveLikeImagePollVote, 'leaderboardRewards' | 'widget'> & { leaderboardRewards?: Maybe<Array<_RefType['LiveLikeLeaderboardReward']>>, widget: _RefType['LiveLikeImagePoll'] } ) | ( Omit<LiveLikeImagePredictionVote, 'leaderboardRewards'> & { leaderboardRewards?: Maybe<Array<_RefType['LiveLikeLeaderboardReward']>> } ) | ( Omit<LiveLikeImageQuizAnswer, 'leaderboardRewards'> & { leaderboardRewards?: Maybe<Array<_RefType['LiveLikeLeaderboardReward']>> } ) | ( Omit<LiveLikeTextPollVote, 'leaderboardRewards' | 'widget'> & { leaderboardRewards?: Maybe<Array<_RefType['LiveLikeLeaderboardReward']>>, widget: _RefType['LiveLikeTextPoll'] } ) | ( Omit<LiveLikeTextPredictionVote, 'leaderboardRewards'> & { leaderboardRewards?: Maybe<Array<_RefType['LiveLikeLeaderboardReward']>> } ) | ( Omit<LiveLikeTextQuizAnswer, 'leaderboardRewards'> & { leaderboardRewards?: Maybe<Array<_RefType['LiveLikeLeaderboardReward']>> } );
  ProgrammedContent: ( Omit<Article, 'betTags' | 'primaryTag' | 'recommendedArticles' | 'recommendedVideos' | 'slides' | 'tags'> & { betTags?: Maybe<Array<Maybe<_RefType['TagV2']>>>, primaryTag: _RefType['TagV2'], recommendedArticles: Array<_RefType['A2AResult']>, recommendedVideos: Array<_RefType['A2VResult']>, slides?: Maybe<Array<Maybe<_RefType['Slide']>>>, tags?: Maybe<Array<Maybe<_RefType['TagV2']>>> } ) | ( ExternalArticle ) | ( StatsBetting ) | ( Omit<StatsGamecast, 'raceInfo' | 'tag'> & { raceInfo?: Maybe<_RefType['StatsRaceInfo']>, tag?: Maybe<_RefType['TagV2']> } ) | ( Tweet ) | ( Omit<UgcImagePoll, 'liveLikeImagePoll' | 'liveLikeUserVote'> & { liveLikeImagePoll?: Maybe<_RefType['LiveLikeImagePoll']>, liveLikeUserVote?: Maybe<_RefType['LiveLikeImagePollVote']> } ) | ( UgcPost ) | ( Omit<UgcTextPoll, 'liveLikeTextPoll' | 'liveLikeUserVote'> & { liveLikeTextPoll?: Maybe<_RefType['LiveLikeTextPoll']>, liveLikeUserVote?: Maybe<_RefType['LiveLikeTextPollVote']> } ) | ( Omit<VideoV2, 'recommendedVideos' | 'tags'> & { recommendedVideos: Array<_RefType['V2VResult']>, tags?: Maybe<Array<Maybe<_RefType['TagV2']>>> } );
  SearchAsset: ( Omit<Article, 'betTags' | 'primaryTag' | 'recommendedArticles' | 'recommendedVideos' | 'slides' | 'tags'> & { betTags?: Maybe<Array<Maybe<_RefType['TagV2']>>>, primaryTag: _RefType['TagV2'], recommendedArticles: Array<_RefType['A2AResult']>, recommendedVideos: Array<_RefType['A2VResult']>, slides?: Maybe<Array<Maybe<_RefType['Slide']>>>, tags?: Maybe<Array<Maybe<_RefType['TagV2']>>> } ) | ( Omit<Channel, 'components' | 'groupings' | 'pinnedContentModule' | 'tag'> & { components: Array<Maybe<_RefType['ChannelComponent']>>, groupings?: Maybe<Array<Maybe<_RefType['Grouping']>>>, pinnedContentModule?: Maybe<_RefType['ContentModule']>, tag: _RefType['TagV2'] } ) | ( ExternalArticle ) | ( Omit<User, 'creatorTag' | 'favoriteTeams' | 'tags'> & { creatorTag?: Maybe<_RefType['TagV2']>, favoriteTeams?: Maybe<Array<Maybe<_RefType['TagV2']>>>, tags?: Maybe<Array<Maybe<_RefType['TagV2']>>> } ) | ( Omit<VideoV2, 'recommendedVideos' | 'tags'> & { recommendedVideos: Array<_RefType['V2VResult']>, tags?: Maybe<Array<Maybe<_RefType['TagV2']>>> } );
}>;

/** Mapping of interface types */
export type ResolversInterfaceTypes<_RefType extends Record<string, unknown>> = ResolversObject<{
  ContentModule: ( Omit<PackageContentModule, 'alertRanks' | 'components' | 'contents' | 'metaData'> & { alertRanks: Array<Maybe<_RefType['AlertRank']>>, components?: Maybe<Array<Maybe<_RefType['ComponentModule']>>>, contents?: Maybe<Array<Maybe<_RefType['StandaloneContentModule']>>>, metaData?: Maybe<_RefType['ModuleMetaData']> } ) | ( Omit<StandaloneContentModule, 'alertRanks' | 'components' | 'composites' | 'content' | 'metaData'> & { alertRanks: Array<Maybe<_RefType['AlertRank']>>, components?: Maybe<Array<Maybe<_RefType['ComponentModule']>>>, composites?: Maybe<Array<Maybe<_RefType['PackageContentModule']>>>, content: _RefType['ProgrammedContent'], metaData?: Maybe<_RefType['ModuleMetaData']> } );
  DsContentModelResult: ( Omit<A2AResult, 'article'> & { article?: Maybe<_RefType['StandaloneContentModule']> } ) | ( Omit<A2VResult, 'video'> & { video?: Maybe<_RefType['StandaloneContentModule']> } ) | ( Omit<TrendingResult, 'contentModule'> & { contentModule?: Maybe<_RefType['StandaloneContentModule']> } ) | ( Omit<V2VResult, 'video'> & { video?: Maybe<_RefType['StandaloneContentModule']> } );
  LiveLikeConnection: ( LiveLikeBadgeCollection ) | ( LiveLikeChatRoomCollection ) | ( LiveLikeCommentBoardBanCollection ) | ( LiveLikeCommentBoardCollection ) | ( Omit<LiveLikeCommentCollection, 'edges'> & { edges?: Maybe<Array<Maybe<_RefType['LiveLikeCommentEdge']>>> } ) | ( Omit<LiveLikeCommentReportCollection, 'edges'> & { edges?: Maybe<Array<Maybe<_RefType['LiveLikeCommentReportEdge']>>> } ) | ( LiveLikeLeaderboardCollection ) | ( LiveLikePermissions ) | ( LiveLikeProfileRelationshipCollection ) | ( LiveLikeProfileRelationshipTypeCollection ) | ( Omit<LiveLikeProgramConnection, 'edges'> & { edges?: Maybe<Array<Maybe<_RefType['LiveLikeProgramEdge']>>> } ) | ( LiveLikeQuestCollection ) | ( LiveLikeReactionPackCollection ) | ( LiveLikeReactionSpaceCollection ) | ( LiveLikeRewardItemCollection ) | ( LiveLikeRewardTableCollection ) | ( Omit<LiveLikeRoleAssignmentConnection, 'edges'> & { edges?: Maybe<Array<_RefType['LiveLikeRoleAssignmentEdge']>> } ) | ( LiveLikeRoleConnection ) | ( LiveLikeUserQuestCollection ) | ( LiveLikeUserQuestRewardsConnection ) | ( LiveLikeUserReactionCollection ) | ( LiveLikeWidgetReportCollection );
  LiveLikeEdge: ( LiveLikeBadgeEdge ) | ( LiveLikeChatRoomEdge ) | ( LiveLikeCommentBoardBanEdge ) | ( LiveLikeCommentBoardEdge ) | ( Omit<LiveLikeCommentEdge, 'node'> & { node: _RefType['LiveLikeComment'] } ) | ( Omit<LiveLikeCommentReportEdge, 'node'> & { node: _RefType['LiveLikeCommentReport'] } ) | ( LiveLikeLeaderboardEdge ) | ( LiveLikePermissionEdge ) | ( LiveLikeProfileRelationshipEdge ) | ( LiveLikeProfileRelationshipTypeEdge ) | ( Omit<LiveLikeProgramEdge, 'node'> & { node: _RefType['LiveLikeProgram'] } ) | ( LiveLikeQuestEdge ) | ( LiveLikeReactionPackEdge ) | ( LiveLikeReactionSpaceEdge ) | ( LiveLikeRewardItemEdge ) | ( LiveLikeRewardTableEdge ) | ( Omit<LiveLikeRoleAssignmentEdge, 'node'> & { node: _RefType['LiveLikeRoleAssignment'] } ) | ( LiveLikeRoleEdge ) | ( LiveLikeUserQuestEdge ) | ( LiveLikeUserQuestRewardsEdge ) | ( LiveLikeUserReactionEdge ) | ( LiveLikeWidgetReportEdge );
  LiveLikeNode: ( LiveLikeAlert ) | ( LiveLikeBadge ) | ( Omit<LiveLikeBlockProfile, 'blockedByProfile' | 'blockedProfile'> & { blockedByProfile: _RefType['LiveLikeProfile'], blockedProfile: _RefType['LiveLikeProfile'] } ) | ( LiveLikeChatRoom ) | ( Omit<LiveLikeComment, 'author'> & { author: _RefType['LiveLikeProfile'] } ) | ( LiveLikeCommentBoard ) | ( LiveLikeCommentBoardBan ) | ( LiveLikeCommentBoardCount ) | ( Omit<LiveLikeCommentReport, 'comment'> & { comment: _RefType['LiveLikeComment'] } ) | ( LiveLikeEmoji ) | ( LiveLikeEmojiCount ) | ( Omit<LiveLikeImagePoll, 'userVote'> & { userVote?: Maybe<_RefType['LiveLikeWidgetInteraction']> } ) | ( LiveLikeImagePollOption ) | ( LiveLikeImagePrediction ) | ( LiveLikeImagePredictionFollowUp ) | ( LiveLikeImagePredictionOption ) | ( LiveLikeImageQuiz ) | ( LiveLikeImageQuizChoice ) | ( LiveLikeLeaderboard ) | ( LiveLikePermission ) | ( Omit<LiveLikeProfile, 'rewardBalance' | 'widgetsInteractions'> & { rewardBalance?: Maybe<_RefType['LiveLikeRewardItemBalance']>, widgetsInteractions?: Maybe<Array<_RefType['LiveLikeWidgetInteractions']>> } ) | ( LiveLikeProfileAuth ) | ( Omit<LiveLikeProfileRelationship, 'fromProfile' | 'toProfile'> & { fromProfile: _RefType['LiveLikeProfile'], toProfile: _RefType['LiveLikeProfile'] } ) | ( LiveLikeProfileRelationshipType ) | ( Omit<LiveLikeProgram, 'widgets'> & { widgets?: Maybe<_RefType['LiveLikeWidgetCollection']> } ) | ( Omit<LiveLikeProgramBan, 'bannedByProfile' | 'bannedProfile'> & { bannedByProfile: _RefType['LiveLikeProfile'], bannedProfile: _RefType['LiveLikeProfile'] } ) | ( LiveLikeProgramSchedule ) | ( LiveLikeQuest ) | ( LiveLikeQuestReward ) | ( LiveLikeQuestTask ) | ( LiveLikeReaction ) | ( LiveLikeReactionPack ) | ( LiveLikeReactionSpace ) | ( LiveLikeResource ) | ( LiveLikeRewardAction ) | ( LiveLikeRewardActionItem ) | ( LiveLikeRewardItem ) | ( LiveLikeRewardItemImage ) | ( LiveLikeRewardItemTransaction ) | ( LiveLikeRewardTable ) | ( LiveLikeRichPost ) | ( LiveLikeRole ) | ( Omit<LiveLikeRoleAssignment, 'profile'> & { profile?: Maybe<_RefType['LiveLikeProfile']> } ) | ( LiveLikeScope ) | ( LiveLikeSocialEmbed ) | ( LiveLikeSocialEmbedItem ) | ( Omit<LiveLikeTextPoll, 'userVote'> & { userVote?: Maybe<_RefType['LiveLikeWidgetInteraction']> } ) | ( LiveLikeTextPollOption ) | ( LiveLikeTextPrediction ) | ( LiveLikeTextPredictionFollowUp ) | ( LiveLikeTextPredictionOption ) | ( LiveLikeTextQuiz ) | ( LiveLikeTextQuizChoice ) | ( Omit<LiveLikeUserBadge, 'profile'> & { profile: _RefType['LiveLikeProfile'] } ) | ( LiveLikeUserQuest ) | ( LiveLikeUserQuestReward ) | ( LiveLikeUserQuestTask ) | ( LiveLikeUserReaction ) | ( LiveLikeVideoAlert ) | ( LiveLikeWidgetReport );
  LiveLikeWidgetBase: ( LiveLikeAlert ) | ( Omit<LiveLikeImagePoll, 'userVote'> & { userVote?: Maybe<_RefType['LiveLikeWidgetInteraction']> } ) | ( LiveLikeImagePrediction ) | ( LiveLikeImagePredictionFollowUp ) | ( LiveLikeImageQuiz ) | ( LiveLikeRichPost ) | ( LiveLikeSocialEmbed ) | ( Omit<LiveLikeTextPoll, 'userVote'> & { userVote?: Maybe<_RefType['LiveLikeWidgetInteraction']> } ) | ( LiveLikeTextPrediction ) | ( LiveLikeTextPredictionFollowUp ) | ( LiveLikeTextQuiz ) | ( LiveLikeVideoAlert );
  LiveLikeWidgetInteractionBase: ( Omit<LiveLikeImagePollVote, 'leaderboardRewards' | 'widget'> & { leaderboardRewards?: Maybe<Array<_RefType['LiveLikeLeaderboardReward']>>, widget: _RefType['LiveLikeImagePoll'] } ) | ( Omit<LiveLikeImagePredictionVote, 'leaderboardRewards'> & { leaderboardRewards?: Maybe<Array<_RefType['LiveLikeLeaderboardReward']>> } ) | ( Omit<LiveLikeImageQuizAnswer, 'leaderboardRewards'> & { leaderboardRewards?: Maybe<Array<_RefType['LiveLikeLeaderboardReward']>> } ) | ( Omit<LiveLikeTextPollVote, 'leaderboardRewards' | 'widget'> & { leaderboardRewards?: Maybe<Array<_RefType['LiveLikeLeaderboardReward']>>, widget: _RefType['LiveLikeTextPoll'] } ) | ( Omit<LiveLikeTextPredictionVote, 'leaderboardRewards'> & { leaderboardRewards?: Maybe<Array<_RefType['LiveLikeLeaderboardReward']>> } ) | ( Omit<LiveLikeTextQuizAnswer, 'leaderboardRewards'> & { leaderboardRewards?: Maybe<Array<_RefType['LiveLikeLeaderboardReward']>> } );
  LiveLikeWidgetInteractionBaseCreateInput: never;
}>;

/** Mapping between all available schema types and the resolvers types */
export type ResolversTypes = ResolversObject<{
  A2AResult: ResolverTypeWrapper<Omit<A2AResult, 'article'> & { article?: Maybe<ResolversTypes['StandaloneContentModule']> }>;
  A2VResult: ResolverTypeWrapper<Omit<A2VResult, 'video'> & { video?: Maybe<ResolversTypes['StandaloneContentModule']> }>;
  Action: ResolverTypeWrapper<Action>;
  Actions: Actions;
  AddAlertRankInput: AddAlertRankInput;
  AddAlertRankResponse: ResolverTypeWrapper<AddAlertRankResponse>;
  AdsAdSize: ResolverTypeWrapper<AdsAdSize>;
  AdsChannelConfiguration: ResolverTypeWrapper<AdsChannelConfiguration>;
  AdsChannelGroupingConfiguration: ResolverTypeWrapper<AdsChannelGroupingConfiguration>;
  AdsConfiguration: ResolverTypeWrapper<AdsConfiguration>;
  AdsDeployedState: ResolverTypeWrapper<AdsDeployedState>;
  AdsHistory: ResolverTypeWrapper<AdsHistory>;
  AdsModuleConfiguration: ResolverTypeWrapper<AdsModuleConfiguration>;
  AdsRegistryDetailItem: ResolverTypeWrapper<AdsRegistryDetailItem>;
  AdsSlot: ResolverTypeWrapper<AdsSlot>;
  AdsTargeting: ResolverTypeWrapper<AdsTargeting>;
  AdsViewport: ResolverTypeWrapper<AdsViewport>;
  AlertAnalytics: ResolverTypeWrapper<AlertAnalytics>;
  AlertAnalyticsInput: AlertAnalyticsInput;
  AlertCategory: AlertCategory;
  AlertDestination: ResolverTypeWrapper<AlertDestination>;
  AlertDestinationInput: AlertDestinationInput;
  AlertGamecastType: AlertGamecastType;
  AlertGenre: AlertGenre;
  AlertInput: AlertInput;
  AlertMediaAttachment: ResolverTypeWrapper<AlertMediaAttachment>;
  AlertMediaAttachmentInput: AlertMediaAttachmentInput;
  AlertMediaType: AlertMediaType;
  AlertPreference: ResolverTypeWrapper<AlertPreference>;
  AlertRank: ResolverTypeWrapper<Omit<AlertRank, 'pushNotification'> & { pushNotification: ResolversTypes['PushNotification'] }>;
  AlertRankInput: AlertRankInput;
  AlertRegion: AlertRegion;
  AlertTypes: AlertTypes;
  AllowAll: ResolverTypeWrapper<AllowAll>;
  Allowed: ResolverTypeWrapper<Allowed>;
  Article: ResolverTypeWrapper<Omit<Article, 'betTags' | 'primaryTag' | 'recommendedArticles' | 'recommendedVideos' | 'slides' | 'tags'> & { betTags?: Maybe<Array<Maybe<ResolversTypes['TagV2']>>>, primaryTag: ResolversTypes['TagV2'], recommendedArticles: Array<ResolversTypes['A2AResult']>, recommendedVideos: Array<ResolversTypes['A2VResult']>, slides?: Maybe<Array<Maybe<ResolversTypes['Slide']>>>, tags?: Maybe<Array<Maybe<ResolversTypes['TagV2']>>> }>;
  ArticleAuthor: ResolverTypeWrapper<ArticleAuthor>;
  ArticleConnection: ResolverTypeWrapper<Omit<ArticleConnection, 'edges'> & { edges: Array<ResolversTypes['ArticleEdge']> }>;
  ArticleEdge: ResolverTypeWrapper<Omit<ArticleEdge, 'node'> & { node: ResolversTypes['Article'] }>;
  ArticleFindManyParametersInput: ArticleFindManyParametersInput;
  ArticleType: ArticleType;
  AspectRatio: AspectRatio;
  AssetConnection: ResolverTypeWrapper<Omit<AssetConnection, 'edges' | 'nodes'> & { edges?: Maybe<Array<Maybe<ResolversTypes['AssetEdge']>>>, nodes?: Maybe<Array<Maybe<ResolversTypes['SearchResult']>>> }>;
  AssetEdge: ResolverTypeWrapper<Omit<AssetEdge, 'node'> & { node?: Maybe<ResolversTypes['SearchResult']> }>;
  Author: ResolverTypeWrapper<Author>;
  Avatar: ResolverTypeWrapper<Avatar>;
  Badge: ResolverTypeWrapper<Badge>;
  BadgeComponent: ResolverTypeWrapper<BadgeComponent>;
  BillingOrder: ResolverTypeWrapper<BillingOrder>;
  BlockedContent: ResolverTypeWrapper<BlockedContent>;
  Boolean: ResolverTypeWrapper<Scalars['Boolean']['output']>;
  Brand: ResolverTypeWrapper<Brand>;
  CacheControlScope: CacheControlScope;
  Category: Category;
  CategoryType: CategoryType;
  Channel: ResolverTypeWrapper<Omit<Channel, 'components' | 'groupings' | 'pinnedContentModule' | 'tag'> & { components: Array<Maybe<ResolversTypes['ChannelComponent']>>, groupings?: Maybe<Array<Maybe<ResolversTypes['Grouping']>>>, pinnedContentModule?: Maybe<ResolversTypes['ContentModule']>, tag: ResolversTypes['TagV2'] }>;
  ChannelComponent: ResolverTypeWrapper<Omit<ChannelComponent, 'chat' | 'contents' | 'contentsConnection' | 'dataServicesTagData' | 'statsGamecast' | 'tagData' | 'userAlerts' | 'userContents' | 'userSocialAlerts' | 'userTags'> & { chat?: Maybe<ResolversTypes['ChatModule']>, contents?: Maybe<Array<Maybe<ResolversTypes['ContentModule']>>>, contentsConnection?: Maybe<ResolversTypes['ContentsConnection']>, dataServicesTagData: Array<ResolversTypes['TagV2']>, statsGamecast?: Maybe<ResolversTypes['StatsGamecast']>, tagData?: Maybe<Array<Maybe<ResolversTypes['TagV2']>>>, userAlerts?: Maybe<Array<ResolversTypes['PushNotification']>>, userContents?: Maybe<Array<Maybe<ResolversTypes['StandaloneContentModule']>>>, userSocialAlerts?: Maybe<Array<ResolversTypes['UserSocialAlert']>>, userTags?: Maybe<Array<Maybe<ResolversTypes['TagV2']>>> }>;
  ChannelRecommenderResult: ResolverTypeWrapper<Omit<ChannelRecommenderResult, 'tagV2'> & { tagV2: ResolversTypes['TagV2'] }>;
  ChannelStreamMetaData: ResolverTypeWrapper<Omit<ChannelStreamMetaData, 'contents'> & { contents?: Maybe<Array<Maybe<ResolversTypes['ContentModule']>>> }>;
  ChannelType: ChannelType;
  ChatModule: ResolverTypeWrapper<ChatModule>;
  Clock: ResolverTypeWrapper<Clock>;
  Competitor: ResolverTypeWrapper<Competitor>;
  Competitors: ResolverTypeWrapper<Competitors>;
  Component: ResolverTypeWrapper<Omit<Component, 'content'> & { content?: Maybe<Array<Maybe<ResolversTypes['Content']>>> }>;
  ComponentCursor: ResolverTypeWrapper<Scalars['ComponentCursor']['output']>;
  ComponentEdge: ResolverTypeWrapper<Omit<ComponentEdge, 'node'> & { node: ResolversTypes['Component'] }>;
  ComponentModule: ResolverTypeWrapper<Omit<ComponentModule, 'tag'> & { tag?: Maybe<ResolversTypes['TagV2']> }>;
  ComponentsConnection: ResolverTypeWrapper<Omit<ComponentsConnection, 'edges'> & { edges: Array<ResolversTypes['ComponentEdge']> }>;
  Conference: ResolverTypeWrapper<Conference>;
  Conferences: ResolverTypeWrapper<Conferences>;
  ConfigJson: ResolverTypeWrapper<ConfigJson>;
  Content: ResolverTypeWrapper<Omit<Content, 'channelStream' | 'contentModules'> & { channelStream?: Maybe<ResolversTypes['ChannelStreamMetaData']>, contentModules?: Maybe<Array<Maybe<ResolversTypes['ContentModule']>>> }>;
  ContentBrand: ResolverTypeWrapper<ContentBrand>;
  ContentCursor: ResolverTypeWrapper<Scalars['ContentCursor']['output']>;
  ContentEdge: ResolverTypeWrapper<Omit<ContentEdge, 'node'> & { node: ResolversTypes['ContentModule'] }>;
  ContentFilters: ResolverTypeWrapper<ContentFilters>;
  ContentForm: ResolverTypeWrapper<ContentForm>;
  ContentLibrarySearchParametersInput: ContentLibrarySearchParametersInput;
  ContentLibrarySearchResult: ResolverTypeWrapper<ResolversUnionTypes<ResolversTypes>['ContentLibrarySearchResult']>;
  ContentLibrarySortDirection: ContentLibrarySortDirection;
  ContentLibrarySortParametersInput: ContentLibrarySortParametersInput;
  ContentMetadata: ResolverTypeWrapper<ContentMetadata>;
  ContentModule: ResolverTypeWrapper<ResolversInterfaceTypes<ResolversTypes>['ContentModule']>;
  ContentModuleInput: ContentModuleInput;
  ContentModuleType: ContentModuleType;
  ContentSearchType: ContentSearchType;
  ContentShow: ResolverTypeWrapper<ContentShow>;
  ContentSort: ResolverTypeWrapper<ContentSort>;
  ContentType: ContentType;
  ContentsConnection: ResolverTypeWrapper<Omit<ContentsConnection, 'edges'> & { edges: Array<ResolversTypes['ContentEdge']> }>;
  ContextFieldValue: ResolverTypeWrapper<Scalars['ContextFieldValue']['output']>;
  CreatePollResponse: ResolverTypeWrapper<CreatePollResponse>;
  CreatePostResponse: ResolverTypeWrapper<CreatePostResponse>;
  CreateProgramResponse: ResolverTypeWrapper<CreateProgramResponse>;
  CreatorTier: CreatorTier;
  Credit: ResolverTypeWrapper<Credit>;
  CustomLiveLikeUserReaction: ResolverTypeWrapper<CustomLiveLikeUserReaction>;
  Date: ResolverTypeWrapper<Scalars['Date']['output']>;
  DateRangeFilter: DateRangeFilter;
  DateTime: ResolverTypeWrapper<Scalars['DateTime']['output']>;
  DateTimeISO: ResolverTypeWrapper<Scalars['DateTimeISO']['output']>;
  DeleteVideoContentModulesResult: ResolverTypeWrapper<DeleteVideoContentModulesResult>;
  Device: ResolverTypeWrapper<Device>;
  DeviceInput: DeviceInput;
  DeviceType: DeviceType;
  Division: ResolverTypeWrapper<Division>;
  Divisions: ResolverTypeWrapper<Divisions>;
  DsContentModelResult: ResolverTypeWrapper<ResolversInterfaceTypes<ResolversTypes>['DsContentModelResult']>;
  DsModel: ResolverTypeWrapper<DsModel>;
  Duration: ResolverTypeWrapper<Scalars['Duration']['output']>;
  Element: ResolverTypeWrapper<Omit<Element, 'content'> & { content?: Maybe<ResolversTypes['ElementContent']> }>;
  ElementContent: ResolverTypeWrapper<Omit<ElementContent, 'media'> & { media?: Maybe<ResolversTypes['VideoV2']> }>;
  EnumTagGroupType: EnumTagGroupType;
  EnumTagV2ChannelState: EnumTagV2ChannelState;
  Event: ResolverTypeWrapper<Event>;
  EventFilterInput: EventFilterInput;
  EventFilterNames: EventFilterNames;
  EventFilterType: EventFilterType;
  EventSort: EventSort;
  EventTypes: EventTypes;
  Events: ResolverTypeWrapper<Events>;
  ExternalArticle: ResolverTypeWrapper<ExternalArticle>;
  FacetRequest: FacetRequest;
  FacetResponse: ResolverTypeWrapper<FacetResponse>;
  FacetResult: ResolverTypeWrapper<FacetResult>;
  Feed: ResolverTypeWrapper<Feed>;
  Feeds: Feeds;
  Filter: Filter;
  Float: ResolverTypeWrapper<Scalars['Float']['output']>;
  FollowingMetadata: ResolverTypeWrapper<FollowingMetadata>;
  FormElement: ResolverTypeWrapper<FormElement>;
  Game: ResolverTypeWrapper<Game>;
  GameDate: ResolverTypeWrapper<GameDate>;
  GameGroup: ResolverTypeWrapper<GameGroup>;
  GameProgress: ResolverTypeWrapper<GameProgress>;
  GameState: GameState;
  GamecastAnalytics: ResolverTypeWrapper<GamecastAnalytics>;
  GamecastMetadata: ResolverTypeWrapper<GamecastMetadata>;
  GamecastProgress: ResolverTypeWrapper<GamecastProgress>;
  GamecastScoreboard: ResolverTypeWrapper<GamecastScoreboard>;
  GamecastTeam: ResolverTypeWrapper<GamecastTeam>;
  Grouping: ResolverTypeWrapper<Omit<Grouping, 'components'> & { components?: Maybe<Array<Maybe<ResolversTypes['ChannelComponent']>>> }>;
  GroupingHeader: ResolverTypeWrapper<GroupingHeader>;
  ID: ResolverTypeWrapper<Scalars['ID']['output']>;
  Identifier: ResolverTypeWrapper<Identifier>;
  Image: ResolverTypeWrapper<Image>;
  ImagePollInput: ImagePollInput;
  ImagePollOptionInput: ImagePollOptionInput;
  ImageTypes: ImageTypes;
  ImageWithStyle: ResolverTypeWrapper<ImageWithStyle>;
  Int: ResolverTypeWrapper<Scalars['Int']['output']>;
  Item: ResolverTypeWrapper<Item>;
  JSON: ResolverTypeWrapper<Scalars['JSON']['output']>;
  JSONObject: ResolverTypeWrapper<Scalars['JSONObject']['output']>;
  JWT: ResolverTypeWrapper<Scalars['JWT']['output']>;
  League: ResolverTypeWrapper<League>;
  Leagues: ResolverTypeWrapper<Leagues>;
  Legacy: ResolverTypeWrapper<Legacy>;
  Limitation: ResolverTypeWrapper<Limitation>;
  Link: ResolverTypeWrapper<Link>;
  LiveLikeAlert: ResolverTypeWrapper<LiveLikeAlert>;
  LiveLikeAlertCreateInput: LiveLikeAlertCreateInput;
  LiveLikeAlertLocalizedInput: LiveLikeAlertLocalizedInput;
  LiveLikeApplication: ResolverTypeWrapper<LiveLikeApplication>;
  LiveLikeAwardBadgeInput: LiveLikeAwardBadgeInput;
  LiveLikeBadge: ResolverTypeWrapper<LiveLikeBadge>;
  LiveLikeBadgeCollection: ResolverTypeWrapper<LiveLikeBadgeCollection>;
  LiveLikeBadgeEdge: ResolverTypeWrapper<LiveLikeBadgeEdge>;
  LiveLikeBadgeProfile: ResolverTypeWrapper<Omit<LiveLikeBadgeProfile, 'profile'> & { profile: ResolversTypes['LiveLikeProfile'] }>;
  LiveLikeBadgeProfileCollection: ResolverTypeWrapper<Omit<LiveLikeBadgeProfileCollection, 'edges'> & { edges?: Maybe<Array<ResolversTypes['LiveLikeBadgeProfileEdge']>> }>;
  LiveLikeBadgeProfileEdge: ResolverTypeWrapper<Omit<LiveLikeBadgeProfileEdge, 'node'> & { node: ResolversTypes['LiveLikeBadgeProfile'] }>;
  LiveLikeBadgeRewardProgress: ResolverTypeWrapper<LiveLikeBadgeRewardProgress>;
  LiveLikeBadgeRewardProgressCollection: ResolverTypeWrapper<LiveLikeBadgeRewardProgressCollection>;
  LiveLikeBlockProfile: ResolverTypeWrapper<Omit<LiveLikeBlockProfile, 'blockedByProfile' | 'blockedProfile'> & { blockedByProfile: ResolversTypes['LiveLikeProfile'], blockedProfile: ResolversTypes['LiveLikeProfile'] }>;
  LiveLikeChatRoom: ResolverTypeWrapper<LiveLikeChatRoom>;
  LiveLikeChatRoomChannel: ResolverTypeWrapper<LiveLikeChatRoomChannel>;
  LiveLikeChatRoomCollection: ResolverTypeWrapper<LiveLikeChatRoomCollection>;
  LiveLikeChatRoomContentFilterEnum: LiveLikeChatRoomContentFilterEnum;
  LiveLikeChatRoomCreateInput: LiveLikeChatRoomCreateInput;
  LiveLikeChatRoomEdge: ResolverTypeWrapper<LiveLikeChatRoomEdge>;
  LiveLikeChatRoomUpdateInput: LiveLikeChatRoomUpdateInput;
  LiveLikeChatRoomVisibilityEnum: LiveLikeChatRoomVisibilityEnum;
  LiveLikeChatRoomsGetInput: LiveLikeChatRoomsGetInput;
  LiveLikeComment: ResolverTypeWrapper<Omit<LiveLikeComment, 'author'> & { author: ResolversTypes['LiveLikeProfile'] }>;
  LiveLikeCommentBoard: ResolverTypeWrapper<LiveLikeCommentBoard>;
  LiveLikeCommentBoardBan: ResolverTypeWrapper<LiveLikeCommentBoardBan>;
  LiveLikeCommentBoardBanCollection: ResolverTypeWrapper<LiveLikeCommentBoardBanCollection>;
  LiveLikeCommentBoardBanEdge: ResolverTypeWrapper<LiveLikeCommentBoardBanEdge>;
  LiveLikeCommentBoardBanInput: LiveLikeCommentBoardBanInput;
  LiveLikeCommentBoardBansInput: LiveLikeCommentBoardBansInput;
  LiveLikeCommentBoardCollection: ResolverTypeWrapper<LiveLikeCommentBoardCollection>;
  LiveLikeCommentBoardCount: ResolverTypeWrapper<LiveLikeCommentBoardCount>;
  LiveLikeCommentBoardCreateInput: LiveLikeCommentBoardCreateInput;
  LiveLikeCommentBoardEdge: ResolverTypeWrapper<LiveLikeCommentBoardEdge>;
  LiveLikeCommentBoardUpdateInput: LiveLikeCommentBoardUpdateInput;
  LiveLikeCommentBoardsCountGetInput: LiveLikeCommentBoardsCountGetInput;
  LiveLikeCommentBoardsGetInput: LiveLikeCommentBoardsGetInput;
  LiveLikeCommentCollection: ResolverTypeWrapper<Omit<LiveLikeCommentCollection, 'edges'> & { edges?: Maybe<Array<Maybe<ResolversTypes['LiveLikeCommentEdge']>>> }>;
  LiveLikeCommentCreateInput: LiveLikeCommentCreateInput;
  LiveLikeCommentEdge: ResolverTypeWrapper<Omit<LiveLikeCommentEdge, 'node'> & { node: ResolversTypes['LiveLikeComment'] }>;
  LiveLikeCommentRepliesGetInput: LiveLikeCommentRepliesGetInput;
  LiveLikeCommentReplyCreateInput: LiveLikeCommentReplyCreateInput;
  LiveLikeCommentReport: ResolverTypeWrapper<Omit<LiveLikeCommentReport, 'comment'> & { comment: ResolversTypes['LiveLikeComment'] }>;
  LiveLikeCommentReportCollection: ResolverTypeWrapper<Omit<LiveLikeCommentReportCollection, 'edges'> & { edges?: Maybe<Array<Maybe<ResolversTypes['LiveLikeCommentReportEdge']>>> }>;
  LiveLikeCommentReportCreateInput: LiveLikeCommentReportCreateInput;
  LiveLikeCommentReportEdge: ResolverTypeWrapper<Omit<LiveLikeCommentReportEdge, 'node'> & { node: ResolversTypes['LiveLikeCommentReport'] }>;
  LiveLikeCommentReportStatusEnum: LiveLikeCommentReportStatusEnum;
  LiveLikeCommentsGetInput: LiveLikeCommentsGetInput;
  LiveLikeCommentsReportsGetInput: LiveLikeCommentsReportsGetInput;
  LiveLikeConnection: ResolverTypeWrapper<ResolversInterfaceTypes<ResolversTypes>['LiveLikeConnection']>;
  LiveLikeContentFilterEnum: LiveLikeContentFilterEnum;
  LiveLikeEarnedBadge: ResolverTypeWrapper<LiveLikeEarnedBadge>;
  LiveLikeEarnedBadgeCollection: ResolverTypeWrapper<LiveLikeEarnedBadgeCollection>;
  LiveLikeEarnedBadgeEdge: ResolverTypeWrapper<LiveLikeEarnedBadgeEdge>;
  LiveLikeEdge: ResolverTypeWrapper<ResolversInterfaceTypes<ResolversTypes>['LiveLikeEdge']>;
  LiveLikeEmoji: ResolverTypeWrapper<LiveLikeEmoji>;
  LiveLikeEmojiCount: ResolverTypeWrapper<LiveLikeEmojiCount>;
  LiveLikeImagePoll: ResolverTypeWrapper<Omit<LiveLikeImagePoll, 'userVote'> & { userVote?: Maybe<ResolversTypes['LiveLikeWidgetInteraction']> }>;
  LiveLikeImagePollCreateInput: LiveLikeImagePollCreateInput;
  LiveLikeImagePollCreateOptionInput: LiveLikeImagePollCreateOptionInput;
  LiveLikeImagePollLocalizedInput: LiveLikeImagePollLocalizedInput;
  LiveLikeImagePollOption: ResolverTypeWrapper<LiveLikeImagePollOption>;
  LiveLikeImagePollOptionLocalizedInput: LiveLikeImagePollOptionLocalizedInput;
  LiveLikeImagePollVote: ResolverTypeWrapper<Omit<LiveLikeImagePollVote, 'leaderboardRewards' | 'widget'> & { leaderboardRewards?: Maybe<Array<ResolversTypes['LiveLikeLeaderboardReward']>>, widget: ResolversTypes['LiveLikeImagePoll'] }>;
  LiveLikeImagePollVoteCreateInput: LiveLikeImagePollVoteCreateInput;
  LiveLikeImagePollVoteUpdateInput: LiveLikeImagePollVoteUpdateInput;
  LiveLikeImagePrediction: ResolverTypeWrapper<LiveLikeImagePrediction>;
  LiveLikeImagePredictionCreateInput: LiveLikeImagePredictionCreateInput;
  LiveLikeImagePredictionCreateOptionInput: LiveLikeImagePredictionCreateOptionInput;
  LiveLikeImagePredictionFollowUp: ResolverTypeWrapper<LiveLikeImagePredictionFollowUp>;
  LiveLikeImagePredictionFollowUpCreateInput: LiveLikeImagePredictionFollowUpCreateInput;
  LiveLikeImagePredictionLocalizedInput: LiveLikeImagePredictionLocalizedInput;
  LiveLikeImagePredictionOption: ResolverTypeWrapper<LiveLikeImagePredictionOption>;
  LiveLikeImagePredictionOptionLocalizedInput: LiveLikeImagePredictionOptionLocalizedInput;
  LiveLikeImagePredictionVote: ResolverTypeWrapper<Omit<LiveLikeImagePredictionVote, 'leaderboardRewards'> & { leaderboardRewards?: Maybe<Array<ResolversTypes['LiveLikeLeaderboardReward']>> }>;
  LiveLikeImagePredictionVoteCreateInput: LiveLikeImagePredictionVoteCreateInput;
  LiveLikeImagePredictionVoteUpdateInput: LiveLikeImagePredictionVoteUpdateInput;
  LiveLikeImageQuiz: ResolverTypeWrapper<LiveLikeImageQuiz>;
  LiveLikeImageQuizAnswer: ResolverTypeWrapper<Omit<LiveLikeImageQuizAnswer, 'leaderboardRewards'> & { leaderboardRewards?: Maybe<Array<ResolversTypes['LiveLikeLeaderboardReward']>> }>;
  LiveLikeImageQuizAnswerCreateInput: LiveLikeImageQuizAnswerCreateInput;
  LiveLikeImageQuizAnswerUpdateInput: LiveLikeImageQuizAnswerUpdateInput;
  LiveLikeImageQuizChoice: ResolverTypeWrapper<LiveLikeImageQuizChoice>;
  LiveLikeImageQuizChoiceLocalizedInput: LiveLikeImageQuizChoiceLocalizedInput;
  LiveLikeImageQuizCreateChoiceInput: LiveLikeImageQuizCreateChoiceInput;
  LiveLikeImageQuizCreateInput: LiveLikeImageQuizCreateInput;
  LiveLikeImageQuizLocalizedInput: LiveLikeImageQuizLocalizedInput;
  LiveLikeIncomingProfileRelationshipInput: LiveLikeIncomingProfileRelationshipInput;
  LiveLikeKeyValuePair: ResolverTypeWrapper<LiveLikeKeyValuePair>;
  LiveLikeKeyValuePairInput: LiveLikeKeyValuePairInput;
  LiveLikeLeaderboard: ResolverTypeWrapper<LiveLikeLeaderboard>;
  LiveLikeLeaderboardCollection: ResolverTypeWrapper<LiveLikeLeaderboardCollection>;
  LiveLikeLeaderboardCreateInput: LiveLikeLeaderboardCreateInput;
  LiveLikeLeaderboardEdge: ResolverTypeWrapper<LiveLikeLeaderboardEdge>;
  LiveLikeLeaderboardEntriesGetInput: LiveLikeLeaderboardEntriesGetInput;
  LiveLikeLeaderboardEntry: ResolverTypeWrapper<LiveLikeLeaderboardEntry>;
  LiveLikeLeaderboardEntryCollection: ResolverTypeWrapper<LiveLikeLeaderboardEntryCollection>;
  LiveLikeLeaderboardEntryEdge: ResolverTypeWrapper<LiveLikeLeaderboardEntryEdge>;
  LiveLikeLeaderboardEntryGetInput: LiveLikeLeaderboardEntryGetInput;
  LiveLikeLeaderboardProgramLinkInput: LiveLikeLeaderboardProgramLinkInput;
  LiveLikeLeaderboardReward: ResolverTypeWrapper<LiveLikeLeaderboardReward>;
  LiveLikeLeaderboardUpdateInput: LiveLikeLeaderboardUpdateInput;
  LiveLikeLeaderboardsGetInput: LiveLikeLeaderboardsGetInput;
  LiveLikeLinkRewardTableWithProgramInput: LiveLikeLinkRewardTableWithProgramInput;
  LiveLikeNode: ResolverTypeWrapper<ResolversInterfaceTypes<ResolversTypes>['LiveLikeNode']>;
  LiveLikeOrderEnum: LiveLikeOrderEnum;
  LiveLikeOutgoingProfileRelationshipInput: LiveLikeOutgoingProfileRelationshipInput;
  LiveLikePage: ResolverTypeWrapper<LiveLikePage>;
  LiveLikePageOffset: ResolverTypeWrapper<LiveLikePageOffset>;
  LiveLikePaginationOffset: ResolverTypeWrapper<LiveLikePaginationOffset>;
  LiveLikePaginationOffsetInput: LiveLikePaginationOffsetInput;
  LiveLikePermission: ResolverTypeWrapper<LiveLikePermission>;
  LiveLikePermissionEdge: ResolverTypeWrapper<LiveLikePermissionEdge>;
  LiveLikePermissions: ResolverTypeWrapper<LiveLikePermissions>;
  LiveLikePollInteractionEnum: LiveLikePollInteractionEnum;
  LiveLikePollVoteCreateInput: LiveLikePollVoteCreateInput;
  LiveLikePollVoteUpdateInput: LiveLikePollVoteUpdateInput;
  LiveLikeProfile: ResolverTypeWrapper<Omit<LiveLikeProfile, 'rewardBalance' | 'widgetsInteractions'> & { rewardBalance?: Maybe<ResolversTypes['LiveLikeRewardItemBalance']>, widgetsInteractions?: Maybe<Array<ResolversTypes['LiveLikeWidgetInteractions']>> }>;
  LiveLikeProfileAuth: ResolverTypeWrapper<LiveLikeProfileAuth>;
  LiveLikeProfileByCustomIdCreateInput: LiveLikeProfileByCustomIdCreateInput;
  LiveLikeProfileCreateInput: LiveLikeProfileCreateInput;
  LiveLikeProfileGetByCustomIdInput: LiveLikeProfileGetByCustomIdInput;
  LiveLikeProfileRelationship: ResolverTypeWrapper<Omit<LiveLikeProfileRelationship, 'fromProfile' | 'toProfile'> & { fromProfile: ResolversTypes['LiveLikeProfile'], toProfile: ResolversTypes['LiveLikeProfile'] }>;
  LiveLikeProfileRelationshipCollection: ResolverTypeWrapper<LiveLikeProfileRelationshipCollection>;
  LiveLikeProfileRelationshipCreateInput: LiveLikeProfileRelationshipCreateInput;
  LiveLikeProfileRelationshipEdge: ResolverTypeWrapper<LiveLikeProfileRelationshipEdge>;
  LiveLikeProfileRelationshipInput: LiveLikeProfileRelationshipInput;
  LiveLikeProfileRelationshipOrderField: LiveLikeProfileRelationshipOrderField;
  LiveLikeProfileRelationshipOrderInput: LiveLikeProfileRelationshipOrderInput;
  LiveLikeProfileRelationshipType: ResolverTypeWrapper<LiveLikeProfileRelationshipType>;
  LiveLikeProfileRelationshipTypeCollection: ResolverTypeWrapper<LiveLikeProfileRelationshipTypeCollection>;
  LiveLikeProfileRelationshipTypeCreateInput: LiveLikeProfileRelationshipTypeCreateInput;
  LiveLikeProfileRelationshipTypeEdge: ResolverTypeWrapper<LiveLikeProfileRelationshipTypeEdge>;
  LiveLikeProfileRelationshipTypesInput: LiveLikeProfileRelationshipTypesInput;
  LiveLikeProfileUpdateInput: LiveLikeProfileUpdateInput;
  LiveLikeProgram: ResolverTypeWrapper<Omit<LiveLikeProgram, 'widgets'> & { widgets?: Maybe<ResolversTypes['LiveLikeWidgetCollection']> }>;
  LiveLikeProgramBan: ResolverTypeWrapper<Omit<LiveLikeProgramBan, 'bannedByProfile' | 'bannedProfile'> & { bannedByProfile: ResolversTypes['LiveLikeProfile'], bannedProfile: ResolversTypes['LiveLikeProfile'] }>;
  LiveLikeProgramBanCollection: ResolverTypeWrapper<Omit<LiveLikeProgramBanCollection, 'edges'> & { edges?: Maybe<Array<ResolversTypes['LiveLikeProgramBanEdge']>> }>;
  LiveLikeProgramBanEdge: ResolverTypeWrapper<Omit<LiveLikeProgramBanEdge, 'node'> & { node: ResolversTypes['LiveLikeProgramBan'] }>;
  LiveLikeProgramBanInput: LiveLikeProgramBanInput;
  LiveLikeProgramBansInput: LiveLikeProgramBansInput;
  LiveLikeProgramConnection: ResolverTypeWrapper<Omit<LiveLikeProgramConnection, 'edges'> & { edges?: Maybe<Array<Maybe<ResolversTypes['LiveLikeProgramEdge']>>> }>;
  LiveLikeProgramCreateInput: LiveLikeProgramCreateInput;
  LiveLikeProgramDeleteByCustomIdInput: LiveLikeProgramDeleteByCustomIdInput;
  LiveLikeProgramEdge: ResolverTypeWrapper<Omit<LiveLikeProgramEdge, 'node'> & { node: ResolversTypes['LiveLikeProgram'] }>;
  LiveLikeProgramGetByCustomIdInput: LiveLikeProgramGetByCustomIdInput;
  LiveLikeProgramLocalizedInput: LiveLikeProgramLocalizedInput;
  LiveLikeProgramSchedule: ResolverTypeWrapper<LiveLikeProgramSchedule>;
  LiveLikeProgramStatusEnum: LiveLikeProgramStatusEnum;
  LiveLikeProgramUpdateByCustomIdInput: LiveLikeProgramUpdateByCustomIdInput;
  LiveLikeProgramUpdateInput: LiveLikeProgramUpdateInput;
  LiveLikeProgramsGetInput: LiveLikeProgramsGetInput;
  LiveLikeQuest: ResolverTypeWrapper<LiveLikeQuest>;
  LiveLikeQuestCollection: ResolverTypeWrapper<LiveLikeQuestCollection>;
  LiveLikeQuestEdge: ResolverTypeWrapper<LiveLikeQuestEdge>;
  LiveLikeQuestInput: LiveLikeQuestInput;
  LiveLikeQuestReward: ResolverTypeWrapper<LiveLikeQuestReward>;
  LiveLikeQuestStatusEnum: LiveLikeQuestStatusEnum;
  LiveLikeQuestTask: ResolverTypeWrapper<LiveLikeQuestTask>;
  LiveLikeReaction: ResolverTypeWrapper<LiveLikeReaction>;
  LiveLikeReactionPack: ResolverTypeWrapper<LiveLikeReactionPack>;
  LiveLikeReactionPackCollection: ResolverTypeWrapper<LiveLikeReactionPackCollection>;
  LiveLikeReactionPackEdge: ResolverTypeWrapper<LiveLikeReactionPackEdge>;
  LiveLikeReactionPacksGetInput: LiveLikeReactionPacksGetInput;
  LiveLikeReactionSpace: ResolverTypeWrapper<LiveLikeReactionSpace>;
  LiveLikeReactionSpaceCollection: ResolverTypeWrapper<LiveLikeReactionSpaceCollection>;
  LiveLikeReactionSpaceCount: ResolverTypeWrapper<LiveLikeReactionSpaceCount>;
  LiveLikeReactionSpaceCreateInput: LiveLikeReactionSpaceCreateInput;
  LiveLikeReactionSpaceDeleteInput: LiveLikeReactionSpaceDeleteInput;
  LiveLikeReactionSpaceEdge: ResolverTypeWrapper<LiveLikeReactionSpaceEdge>;
  LiveLikeReactionSpaceGetInput: LiveLikeReactionSpaceGetInput;
  LiveLikeReactionSpacePatch: ResolverTypeWrapper<LiveLikeReactionSpacePatch>;
  LiveLikeReactionSpaceUpdateInput: LiveLikeReactionSpaceUpdateInput;
  LiveLikeReactionSpacesCountInput: LiveLikeReactionSpacesCountInput;
  LiveLikeReactions: ResolverTypeWrapper<LiveLikeReactions>;
  LiveLikeResource: ResolverTypeWrapper<LiveLikeResource>;
  LiveLikeResourceKindEnum: LiveLikeResourceKindEnum;
  LiveLikeReward: ResolverTypeWrapper<LiveLikeReward>;
  LiveLikeRewardATableActionChoice: ResolverTypeWrapper<LiveLikeRewardATableActionChoice>;
  LiveLikeRewardAction: ResolverTypeWrapper<LiveLikeRewardAction>;
  LiveLikeRewardActionCreateInput: LiveLikeRewardActionCreateInput;
  LiveLikeRewardActionEnum: LiveLikeRewardActionEnum;
  LiveLikeRewardActionItem: ResolverTypeWrapper<LiveLikeRewardActionItem>;
  LiveLikeRewardBalanceGetInput: LiveLikeRewardBalanceGetInput;
  LiveLikeRewardBalancesGetInput: LiveLikeRewardBalancesGetInput;
  LiveLikeRewardItem: ResolverTypeWrapper<LiveLikeRewardItem>;
  LiveLikeRewardItemBalance: ResolverTypeWrapper<LiveLikeRewardItemBalance>;
  LiveLikeRewardItemBalanceCollection: ResolverTypeWrapper<LiveLikeRewardItemBalanceCollection>;
  LiveLikeRewardItemBalanceEdge: ResolverTypeWrapper<Omit<LiveLikeRewardItemBalanceEdge, 'node'> & { node: ResolversTypes['LiveLikeRewardItemBalance'] }>;
  LiveLikeRewardItemCollection: ResolverTypeWrapper<LiveLikeRewardItemCollection>;
  LiveLikeRewardItemCreateInput: LiveLikeRewardItemCreateInput;
  LiveLikeRewardItemEdge: ResolverTypeWrapper<LiveLikeRewardItemEdge>;
  LiveLikeRewardItemImage: ResolverTypeWrapper<LiveLikeRewardItemImage>;
  LiveLikeRewardItemTransaction: ResolverTypeWrapper<LiveLikeRewardItemTransaction>;
  LiveLikeRewardItemTransactionInput: LiveLikeRewardItemTransactionInput;
  LiveLikeRewardTable: ResolverTypeWrapper<LiveLikeRewardTable>;
  LiveLikeRewardTableCollection: ResolverTypeWrapper<LiveLikeRewardTableCollection>;
  LiveLikeRewardTableCreateInput: LiveLikeRewardTableCreateInput;
  LiveLikeRewardTableEdge: ResolverTypeWrapper<LiveLikeRewardTableEdge>;
  LiveLikeRewardTableEntry: ResolverTypeWrapper<LiveLikeRewardTableEntry>;
  LiveLikeRewardTableEntryCreateInput: LiveLikeRewardTableEntryCreateInput;
  LiveLikeRewardTableEntryDeleteInput: LiveLikeRewardTableEntryDeleteInput;
  LiveLikeRewardTableEntryGetInput: LiveLikeRewardTableEntryGetInput;
  LiveLikeRewardTableEntryInput: LiveLikeRewardTableEntryInput;
  LiveLikeRewardTableUpdateInput: LiveLikeRewardTableUpdateInput;
  LiveLikeRewardTablesGetInput: LiveLikeRewardTablesGetInput;
  LiveLikeRichPost: ResolverTypeWrapper<LiveLikeRichPost>;
  LiveLikeRichPostCreateInput: LiveLikeRichPostCreateInput;
  LiveLikeRichPostLocalizedInput: LiveLikeRichPostLocalizedInput;
  LiveLikeRole: ResolverTypeWrapper<LiveLikeRole>;
  LiveLikeRoleAssignment: ResolverTypeWrapper<Omit<LiveLikeRoleAssignment, 'profile'> & { profile?: Maybe<ResolversTypes['LiveLikeProfile']> }>;
  LiveLikeRoleAssignmentConnection: ResolverTypeWrapper<Omit<LiveLikeRoleAssignmentConnection, 'edges'> & { edges?: Maybe<Array<ResolversTypes['LiveLikeRoleAssignmentEdge']>> }>;
  LiveLikeRoleAssignmentCreateInput: LiveLikeRoleAssignmentCreateInput;
  LiveLikeRoleAssignmentEdge: ResolverTypeWrapper<Omit<LiveLikeRoleAssignmentEdge, 'node'> & { node: ResolversTypes['LiveLikeRoleAssignment'] }>;
  LiveLikeRoleAssignmentsGetInput: LiveLikeRoleAssignmentsGetInput;
  LiveLikeRoleConnection: ResolverTypeWrapper<LiveLikeRoleConnection>;
  LiveLikeRoleCreateInput: LiveLikeRoleCreateInput;
  LiveLikeRoleEdge: ResolverTypeWrapper<LiveLikeRoleEdge>;
  LiveLikeRolesGetInput: LiveLikeRolesGetInput;
  LiveLikeScope: ResolverTypeWrapper<LiveLikeScope>;
  LiveLikeSocialEmbed: ResolverTypeWrapper<LiveLikeSocialEmbed>;
  LiveLikeSocialEmbedCreateInput: LiveLikeSocialEmbedCreateInput;
  LiveLikeSocialEmbedItem: ResolverTypeWrapper<LiveLikeSocialEmbedItem>;
  LiveLikeSocialEmbedLocalizedInput: LiveLikeSocialEmbedLocalizedInput;
  LiveLikeTextPoll: ResolverTypeWrapper<Omit<LiveLikeTextPoll, 'userVote'> & { userVote?: Maybe<ResolversTypes['LiveLikeWidgetInteraction']> }>;
  LiveLikeTextPollCreateInput: LiveLikeTextPollCreateInput;
  LiveLikeTextPollCreateOptionInput: LiveLikeTextPollCreateOptionInput;
  LiveLikeTextPollLocalizedInput: LiveLikeTextPollLocalizedInput;
  LiveLikeTextPollOption: ResolverTypeWrapper<LiveLikeTextPollOption>;
  LiveLikeTextPollOptionLocalizedInput: LiveLikeTextPollOptionLocalizedInput;
  LiveLikeTextPollVote: ResolverTypeWrapper<Omit<LiveLikeTextPollVote, 'leaderboardRewards' | 'widget'> & { leaderboardRewards?: Maybe<Array<ResolversTypes['LiveLikeLeaderboardReward']>>, widget: ResolversTypes['LiveLikeTextPoll'] }>;
  LiveLikeTextPollVoteCreateInput: LiveLikeTextPollVoteCreateInput;
  LiveLikeTextPollVoteUpdateInput: LiveLikeTextPollVoteUpdateInput;
  LiveLikeTextPrediction: ResolverTypeWrapper<LiveLikeTextPrediction>;
  LiveLikeTextPredictionCreateInput: LiveLikeTextPredictionCreateInput;
  LiveLikeTextPredictionCreateOptionInput: LiveLikeTextPredictionCreateOptionInput;
  LiveLikeTextPredictionFollowUp: ResolverTypeWrapper<LiveLikeTextPredictionFollowUp>;
  LiveLikeTextPredictionFollowUpCreateInput: LiveLikeTextPredictionFollowUpCreateInput;
  LiveLikeTextPredictionLocalizedInput: LiveLikeTextPredictionLocalizedInput;
  LiveLikeTextPredictionOption: ResolverTypeWrapper<LiveLikeTextPredictionOption>;
  LiveLikeTextPredictionOptionLocalizedInput: LiveLikeTextPredictionOptionLocalizedInput;
  LiveLikeTextPredictionVote: ResolverTypeWrapper<Omit<LiveLikeTextPredictionVote, 'leaderboardRewards'> & { leaderboardRewards?: Maybe<Array<ResolversTypes['LiveLikeLeaderboardReward']>> }>;
  LiveLikeTextPredictionVoteCreateInput: LiveLikeTextPredictionVoteCreateInput;
  LiveLikeTextPredictionVoteUpdateInput: LiveLikeTextPredictionVoteUpdateInput;
  LiveLikeTextQuiz: ResolverTypeWrapper<LiveLikeTextQuiz>;
  LiveLikeTextQuizAnswer: ResolverTypeWrapper<Omit<LiveLikeTextQuizAnswer, 'leaderboardRewards'> & { leaderboardRewards?: Maybe<Array<ResolversTypes['LiveLikeLeaderboardReward']>> }>;
  LiveLikeTextQuizAnswerCreateInput: LiveLikeTextQuizAnswerCreateInput;
  LiveLikeTextQuizAnswerUpdateInput: LiveLikeTextQuizAnswerUpdateInput;
  LiveLikeTextQuizChoice: ResolverTypeWrapper<LiveLikeTextQuizChoice>;
  LiveLikeTextQuizChoiceLocalizedInput: LiveLikeTextQuizChoiceLocalizedInput;
  LiveLikeTextQuizCreateChoiceInput: LiveLikeTextQuizCreateChoiceInput;
  LiveLikeTextQuizCreateInput: LiveLikeTextQuizCreateInput;
  LiveLikeTextQuizLocalizedInput: LiveLikeTextQuizLocalizedInput;
  LiveLikeTokenGate: ResolverTypeWrapper<LiveLikeTokenGate>;
  LiveLikeTokenGateAttribute: ResolverTypeWrapper<LiveLikeTokenGateAttribute>;
  LiveLikeTokenGateAttributesInput: LiveLikeTokenGateAttributesInput;
  LiveLikeTokenGateInput: LiveLikeTokenGateInput;
  LiveLikeTokenGateNetworkTypeEnum: LiveLikeTokenGateNetworkTypeEnum;
  LiveLikeTokenGateTokenTypeEnum: LiveLikeTokenGateTokenTypeEnum;
  LiveLikeUnlinkRewardTableWithProgramInput: LiveLikeUnlinkRewardTableWithProgramInput;
  LiveLikeUserBadge: ResolverTypeWrapper<Omit<LiveLikeUserBadge, 'profile'> & { profile: ResolversTypes['LiveLikeProfile'] }>;
  LiveLikeUserBadgeCollection: ResolverTypeWrapper<Omit<LiveLikeUserBadgeCollection, 'edges'> & { edges?: Maybe<Array<ResolversTypes['LiveLikeUserBadgeEdge']>> }>;
  LiveLikeUserBadgeEdge: ResolverTypeWrapper<Omit<LiveLikeUserBadgeEdge, 'node'> & { node: ResolversTypes['LiveLikeUserBadge'] }>;
  LiveLikeUserQuest: ResolverTypeWrapper<LiveLikeUserQuest>;
  LiveLikeUserQuestCollection: ResolverTypeWrapper<LiveLikeUserQuestCollection>;
  LiveLikeUserQuestEdge: ResolverTypeWrapper<LiveLikeUserQuestEdge>;
  LiveLikeUserQuestInput: LiveLikeUserQuestInput;
  LiveLikeUserQuestReward: ResolverTypeWrapper<LiveLikeUserQuestReward>;
  LiveLikeUserQuestRewardStatus: LiveLikeUserQuestRewardStatus;
  LiveLikeUserQuestRewardsConnection: ResolverTypeWrapper<LiveLikeUserQuestRewardsConnection>;
  LiveLikeUserQuestRewardsEdge: ResolverTypeWrapper<LiveLikeUserQuestRewardsEdge>;
  LiveLikeUserQuestRewardsInput: LiveLikeUserQuestRewardsInput;
  LiveLikeUserQuestStatusEnum: LiveLikeUserQuestStatusEnum;
  LiveLikeUserQuestTask: ResolverTypeWrapper<LiveLikeUserQuestTask>;
  LiveLikeUserQuestTaskProgress: ResolverTypeWrapper<LiveLikeUserQuestTaskProgress>;
  LiveLikeUserQuestTaskStatusEnum: LiveLikeUserQuestTaskStatusEnum;
  LiveLikeUserQuestsInput: LiveLikeUserQuestsInput;
  LiveLikeUserQuestsTaskProgressInput: LiveLikeUserQuestsTaskProgressInput;
  LiveLikeUserReaction: ResolverTypeWrapper<LiveLikeUserReaction>;
  LiveLikeUserReactionCollection: ResolverTypeWrapper<LiveLikeUserReactionCollection>;
  LiveLikeUserReactionCountCollection: ResolverTypeWrapper<LiveLikeUserReactionCountCollection>;
  LiveLikeUserReactionCountEdge: ResolverTypeWrapper<LiveLikeUserReactionCountEdge>;
  LiveLikeUserReactionCountsGetInput: LiveLikeUserReactionCountsGetInput;
  LiveLikeUserReactionCreateInput: LiveLikeUserReactionCreateInput;
  LiveLikeUserReactionEdge: ResolverTypeWrapper<LiveLikeUserReactionEdge>;
  LiveLikeUserReactionsGetInput: LiveLikeUserReactionsGetInput;
  LiveLikeVideoAlert: ResolverTypeWrapper<LiveLikeVideoAlert>;
  LiveLikeVideoAlertCreateInput: LiveLikeVideoAlertCreateInput;
  LiveLikeVideoAlertLocalizedInput: LiveLikeVideoAlertLocalizedInput;
  LiveLikeWidget: ResolverTypeWrapper<ResolversUnionTypes<ResolversTypes>['LiveLikeWidget']>;
  LiveLikeWidgetBase: ResolverTypeWrapper<ResolversInterfaceTypes<ResolversTypes>['LiveLikeWidgetBase']>;
  LiveLikeWidgetCollection: ResolverTypeWrapper<Omit<LiveLikeWidgetCollection, 'edges'> & { edges?: Maybe<Array<Maybe<ResolversTypes['LiveLikeWidgetEdge']>>> }>;
  LiveLikeWidgetCreator: ResolverTypeWrapper<LiveLikeWidgetCreator>;
  LiveLikeWidgetDeleteInput: LiveLikeWidgetDeleteInput;
  LiveLikeWidgetEdge: ResolverTypeWrapper<Omit<LiveLikeWidgetEdge, 'node'> & { node: ResolversTypes['LiveLikeWidget'] }>;
  LiveLikeWidgetGetInput: LiveLikeWidgetGetInput;
  LiveLikeWidgetInteraction: ResolverTypeWrapper<Omit<LiveLikeWidgetInteraction, 'leaderboardRewards' | 'widget'> & { leaderboardRewards?: Maybe<Array<ResolversTypes['LiveLikeLeaderboardReward']>>, widget?: Maybe<ResolversTypes['LiveLikeWidget']> }>;
  LiveLikeWidgetInteractionBase: ResolverTypeWrapper<ResolversInterfaceTypes<ResolversTypes>['LiveLikeWidgetInteractionBase']>;
  LiveLikeWidgetInteractionBaseCreateInput: ResolverTypeWrapper<ResolversInterfaceTypes<ResolversTypes>['LiveLikeWidgetInteractionBaseCreateInput']>;
  LiveLikeWidgetInteractionCreateInput: LiveLikeWidgetInteractionCreateInput;
  LiveLikeWidgetInteractionEnum: LiveLikeWidgetInteractionEnum;
  LiveLikeWidgetInteractionUnion: ResolverTypeWrapper<ResolversUnionTypes<ResolversTypes>['LiveLikeWidgetInteractionUnion']>;
  LiveLikeWidgetInteractionUpdateInput: LiveLikeWidgetInteractionUpdateInput;
  LiveLikeWidgetInteractions: ResolverTypeWrapper<Omit<LiveLikeWidgetInteractions, 'interactions'> & { interactions?: Maybe<Array<ResolversTypes['LiveLikeWidgetInteractionUnion']>> }>;
  LiveLikeWidgetInteractionsInput: LiveLikeWidgetInteractionsInput;
  LiveLikeWidgetKindEnum: LiveLikeWidgetKindEnum;
  LiveLikeWidgetOrder: ResolverTypeWrapper<LiveLikeWidgetOrder>;
  LiveLikeWidgetOrderField: LiveLikeWidgetOrderField;
  LiveLikeWidgetOrderInput: LiveLikeWidgetOrderInput;
  LiveLikeWidgetPublish: ResolverTypeWrapper<LiveLikeWidgetPublish>;
  LiveLikeWidgetPublishInput: LiveLikeWidgetPublishInput;
  LiveLikeWidgetReport: ResolverTypeWrapper<LiveLikeWidgetReport>;
  LiveLikeWidgetReportCollection: ResolverTypeWrapper<LiveLikeWidgetReportCollection>;
  LiveLikeWidgetReportCount: ResolverTypeWrapper<LiveLikeWidgetReportCount>;
  LiveLikeWidgetReportEdge: ResolverTypeWrapper<LiveLikeWidgetReportEdge>;
  LiveLikeWidgetReportInput: LiveLikeWidgetReportInput;
  LiveLikeWidgetReportStatusEnum: LiveLikeWidgetReportStatusEnum;
  LiveLikeWidgetReportsInput: LiveLikeWidgetReportsInput;
  LiveLikeWidgetStatusEnum: LiveLikeWidgetStatusEnum;
  LiveLikeclaimUserQuestRewardInput: LiveLikeclaimUserQuestRewardInput;
  Locale: ResolverTypeWrapper<Scalars['Locale']['output']>;
  Localization: ResolverTypeWrapper<Localization>;
  Media: ResolverTypeWrapper<Media>;
  Menu: ResolverTypeWrapper<Menu>;
  MenuLinks: ResolverTypeWrapper<Omit<MenuLinks, 'tags'> & { tags?: Maybe<Array<Maybe<ResolversTypes['TagV2']>>> }>;
  MenuOptions: ResolverTypeWrapper<MenuOptions>;
  MenuOptionsAttributes: ResolverTypeWrapper<MenuOptionsAttributes>;
  MenuRoutes: ResolverTypeWrapper<MenuRoutes>;
  Metadata: ResolverTypeWrapper<Metadata>;
  ModuleMetaData: ResolverTypeWrapper<Omit<ModuleMetaData, 'author' | 'communityTag'> & { author?: Maybe<ResolversTypes['TagV2']>, communityTag?: Maybe<ResolversTypes['TagV2']> }>;
  ModuleOrientation: ModuleOrientation;
  ModuleState: ModuleState;
  MongoID: ResolverTypeWrapper<Scalars['MongoID']['output']>;
  Mutation: ResolverTypeWrapper<{}>;
  Name: ResolverTypeWrapper<Name>;
  NavigationElement: ResolverTypeWrapper<NavigationElement>;
  NavigationQueryParameters: ResolverTypeWrapper<NavigationQueryParameters>;
  NewPushNotification: NewPushNotification;
  NonEmptyString: ResolverTypeWrapper<Scalars['NonEmptyString']['output']>;
  NonNegativeFloat: ResolverTypeWrapper<Scalars['NonNegativeFloat']['output']>;
  NonNegativeInt: ResolverTypeWrapper<Scalars['NonNegativeInt']['output']>;
  NotificationInput: NotificationInput;
  NotificationMethod: ResolverTypeWrapper<NotificationMethod>;
  NotificationMethodInput: NotificationMethodInput;
  Notifications: ResolverTypeWrapper<Notifications>;
  Offering: ResolverTypeWrapper<Offering>;
  PackageContent: PackageContent;
  PackageContentModule: ResolverTypeWrapper<Omit<PackageContentModule, 'alertRanks' | 'components' | 'contents' | 'metaData'> & { alertRanks: Array<Maybe<ResolversTypes['AlertRank']>>, components?: Maybe<Array<Maybe<ResolversTypes['ComponentModule']>>>, contents?: Maybe<Array<Maybe<ResolversTypes['StandaloneContentModule']>>>, metaData?: Maybe<ResolversTypes['ModuleMetaData']> }>;
  PackageInput: PackageInput;
  PackageType: PackageType;
  Page: ResolverTypeWrapper<Omit<Page, 'components' | 'componentsConnection'> & { components?: Maybe<Array<Maybe<ResolversTypes['Component']>>>, componentsConnection: ResolversTypes['ComponentsConnection'] }>;
  PageBody: ResolverTypeWrapper<PageBody>;
  PageComponentFiltersInput: PageComponentFiltersInput;
  PageInfo: ResolverTypeWrapper<PageInfo>;
  PageMetatags: ResolverTypeWrapper<PageMetatags>;
  PaginationControl: PaginationControl;
  PaginationControlInput: PaginationControlInput;
  PeriodScore: ResolverTypeWrapper<PeriodScore>;
  PeriodScoreType: PeriodScoreType;
  Playlist: ResolverTypeWrapper<Playlist>;
  Poll: ResolverTypeWrapper<Poll>;
  PositiveInt: ResolverTypeWrapper<Scalars['PositiveInt']['output']>;
  Post: ResolverTypeWrapper<Post>;
  PostInput: PostInput;
  PrepareImageResponse: ResolverTypeWrapper<PrepareImageResponse>;
  Product: ResolverTypeWrapper<Product>;
  ProductLine: ResolverTypeWrapper<ProductLine>;
  Program: ResolverTypeWrapper<Program>;
  ProgrammedContent: ResolverTypeWrapper<ResolversUnionTypes<ResolversTypes>['ProgrammedContent']>;
  PushNotification: ResolverTypeWrapper<Omit<PushNotification, 'analytics' | 'tags' | 'userDestination'> & { analytics?: Maybe<ResolversTypes['AlertAnalytics']>, tags: Array<ResolversTypes['TagV2']>, userDestination?: Maybe<ResolversTypes['UserDestination']> }>;
  PushNotificationAlertRankInput: PushNotificationAlertRankInput;
  PushNotificationAlertRankResponse: ResolverTypeWrapper<PushNotificationAlertRankResponse>;
  Query: ResolverTypeWrapper<{}>;
  QueryAssistResponse: ResolverTypeWrapper<QueryAssistResponse>;
  QueryAssistResult: ResolverTypeWrapper<QueryAssistResult>;
  Rating: ResolverTypeWrapper<Rating>;
  Reference: ResolverTypeWrapper<Reference>;
  ReferenceInput: ReferenceInput;
  ReferenceMetadata: ResolverTypeWrapper<ReferenceMetadata>;
  ReferenceStream: ResolverTypeWrapper<ReferenceStream>;
  ReferenceType: ReferenceType;
  Schedule: ResolverTypeWrapper<Schedule>;
  Score: ResolverTypeWrapper<Score>;
  Scores: ResolverTypeWrapper<Scores>;
  ScoresBettingLink: ResolverTypeWrapper<ScoresBettingLink>;
  ScoresCalendarNavigation: ResolverTypeWrapper<ScoresCalendarNavigation>;
  ScoresDescription: ResolverTypeWrapper<ScoresDescription>;
  ScoresEvent: ResolverTypeWrapper<Omit<ScoresEvent, 'gamecastTag'> & { gamecastTag?: Maybe<ResolversTypes['TagV2']> }>;
  ScoresEventNameLabel: ResolverTypeWrapper<ScoresEventNameLabel>;
  ScoresEventParticipant: ResolverTypeWrapper<ScoresEventParticipant>;
  ScoresEventParticipantEntry: ResolverTypeWrapper<ScoresEventParticipantEntry>;
  ScoresEventParticipantEntryFontFormatting: ResolverTypeWrapper<ScoresEventParticipantEntryFontFormatting>;
  ScoresEventParticipantEntryValue: ResolverTypeWrapper<ScoresEventParticipantEntryValue>;
  ScoresEventParticipantHeader: ResolverTypeWrapper<ScoresEventParticipantHeader>;
  ScoresGame: ResolverTypeWrapper<Omit<ScoresGame, 'gamecastTag'> & { gamecastTag?: Maybe<ResolversTypes['TagV2']> }>;
  ScoresGameTeam: ResolverTypeWrapper<ScoresGameTeam>;
  ScoresLeague: ResolverTypeWrapper<Omit<ScoresLeague, 'tagV2'> & { tagV2?: Maybe<ResolversTypes['TagV2']> }>;
  ScoresLeagueQueryParameters: ResolverTypeWrapper<ScoresLeagueQueryParameters>;
  ScoresMetadata: ResolverTypeWrapper<ScoresMetadata>;
  ScoresMetadataLocation: ResolverTypeWrapper<ScoresMetadataLocation>;
  ScoresOddsSportsbook: ScoresOddsSportsbook;
  ScoresProgress: ResolverTypeWrapper<ScoresProgress>;
  ScoresState: ResolverTypeWrapper<ScoresState>;
  ScoresStateRunners: ResolverTypeWrapper<ScoresStateRunners>;
  ScoresTeamCompetitor: ResolverTypeWrapper<ScoresTeamCompetitor>;
  SearchAsset: ResolverTypeWrapper<ResolversUnionTypes<ResolversTypes>['SearchAsset']>;
  SearchResult: ResolverTypeWrapper<Omit<SearchResult, 'contentModule' | 'searchAsset'> & { contentModule?: Maybe<ResolversTypes['StandaloneContentModule']>, searchAsset?: Maybe<ResolversTypes['SearchAsset']> }>;
  SearchResults: ResolverTypeWrapper<Omit<SearchResults, 'connection'> & { connection?: Maybe<ResolversTypes['AssetConnection']> }>;
  SearchSource: SearchSource;
  Season: ResolverTypeWrapper<Season>;
  SemanticID: SemanticId;
  SemanticType: SemanticType;
  Series: ResolverTypeWrapper<Series>;
  SeriesSort: SeriesSort;
  Serieses: ResolverTypeWrapper<Serieses>;
  Settings: ResolverTypeWrapper<Settings>;
  Show: ResolverTypeWrapper<Show>;
  Slide: ResolverTypeWrapper<Omit<Slide, 'elements' | 'featuredMedia'> & { elements?: Maybe<Array<Maybe<ResolversTypes['Element']>>>, featuredMedia: ResolversTypes['Element'] }>;
  SocialLinks: ResolverTypeWrapper<SocialLinks>;
  SocialMediaHandle: ResolverTypeWrapper<SocialMediaHandle>;
  SocialPreference: ResolverTypeWrapper<SocialPreference>;
  SocialWidget: ResolverTypeWrapper<SocialWidget>;
  SortDirections: SortDirections;
  SortOrder: SortOrder;
  Sport: ResolverTypeWrapper<Sport>;
  SportMetaData: ResolverTypeWrapper<SportMetaData>;
  Sports: ResolverTypeWrapper<Sports>;
  SquadRide: ResolverTypeWrapper<SquadRide>;
  StandaloneContentModule: ResolverTypeWrapper<Omit<StandaloneContentModule, 'alertRanks' | 'components' | 'composites' | 'content' | 'metaData'> & { alertRanks: Array<Maybe<ResolversTypes['AlertRank']>>, components?: Maybe<Array<Maybe<ResolversTypes['ComponentModule']>>>, composites?: Maybe<Array<Maybe<ResolversTypes['PackageContentModule']>>>, content: ResolversTypes['ProgrammedContent'], metaData?: Maybe<ResolversTypes['ModuleMetaData']> }>;
  StateStatus: StateStatus;
  StatsBetOffer: ResolverTypeWrapper<StatsBetOffer>;
  StatsBetting: ResolverTypeWrapper<StatsBetting>;
  StatsGameStatus: StatsGameStatus;
  StatsGamecast: ResolverTypeWrapper<Omit<StatsGamecast, 'raceInfo' | 'tag'> & { raceInfo?: Maybe<ResolversTypes['StatsRaceInfo']>, tag?: Maybe<ResolversTypes['TagV2']> }>;
  StatsLeagues: StatsLeagues;
  StatsLinescore: ResolverTypeWrapper<StatsLinescore>;
  StatsLinescoreBatter: ResolverTypeWrapper<StatsLinescoreBatter>;
  StatsLinescoreDiamond: ResolverTypeWrapper<StatsLinescoreDiamond>;
  StatsLinescoreGameState: ResolverTypeWrapper<StatsLinescoreGameState>;
  StatsLinescorePitcher: ResolverTypeWrapper<StatsLinescorePitcher>;
  StatsLinescoreTeam: ResolverTypeWrapper<StatsLinescoreTeam>;
  StatsLinescoreValue: ResolverTypeWrapper<StatsLinescoreValue>;
  StatsPbp: ResolverTypeWrapper<StatsPbp>;
  StatsPbpDriveChart: ResolverTypeWrapper<StatsPbpDriveChart>;
  StatsPbpDriveSummary: ResolverTypeWrapper<StatsPbpDriveSummary>;
  StatsPbpPeriodGrouping: ResolverTypeWrapper<StatsPbpPeriodGrouping>;
  StatsPbpPlay: ResolverTypeWrapper<StatsPbpPlay>;
  StatsPbpPreview: ResolverTypeWrapper<StatsPbpPreview>;
  StatsPbpTabGrouping: ResolverTypeWrapper<StatsPbpTabGrouping>;
  StatsPbpTabs: ResolverTypeWrapper<StatsPbpTabs>;
  StatsPbpTextFormatting: ResolverTypeWrapper<StatsPbpTextFormatting>;
  StatsPodium: ResolverTypeWrapper<StatsPodium>;
  StatsPodiumEntry: ResolverTypeWrapper<StatsPodiumEntry>;
  StatsRaceInfo: ResolverTypeWrapper<StatsRaceInfo>;
  StatsSchedule: ResolverTypeWrapper<StatsSchedule>;
  StatsScheduleAdPlacement: ResolverTypeWrapper<StatsScheduleAdPlacement>;
  StatsScheduleEntry: ResolverTypeWrapper<StatsScheduleEntry>;
  StatsScheduleGrouping: ResolverTypeWrapper<StatsScheduleGrouping>;
  StatsScheduleKey: ResolverTypeWrapper<StatsScheduleKey>;
  StatsScheduleLink: ResolverTypeWrapper<StatsScheduleLink>;
  StatsScheduleResultCode: ResolverTypeWrapper<StatsScheduleResultCode>;
  StatsScheduleTickets: ResolverTypeWrapper<StatsScheduleTickets>;
  StatsScoreboard: ResolverTypeWrapper<StatsScoreboard>;
  StatsScoreboardTeam: ResolverTypeWrapper<StatsScoreboardTeam>;
  StatsSport: StatsSport;
  StatsStanding: ResolverTypeWrapper<StatsStanding>;
  StatsStandingAdPlacement: ResolverTypeWrapper<StatsStandingAdPlacement>;
  StatsStandingEntry: ResolverTypeWrapper<StatsStandingEntry>;
  StatsStandingGrouping: ResolverTypeWrapper<StatsStandingGrouping>;
  StatsStandingHeader: ResolverTypeWrapper<StatsStandingHeader>;
  StatsStandingKey: ResolverTypeWrapper<StatsStandingKey>;
  StatsStandingSeparator: ResolverTypeWrapper<StatsStandingSeparator>;
  StatsStandingTeam: ResolverTypeWrapper<StatsStandingTeam>;
  StatsStandingValue: ResolverTypeWrapper<StatsStandingValue>;
  StatsVenue: ResolverTypeWrapper<StatsVenue>;
  Status: Status;
  StreamMetaData: ResolverTypeWrapper<StreamMetaData>;
  String: ResolverTypeWrapper<Scalars['String']['output']>;
  Tag: ResolverTypeWrapper<Tag>;
  TagComponent: TagComponent;
  TagGroup: ResolverTypeWrapper<Omit<TagGroup, 'children'> & { children?: Maybe<Array<Maybe<ResolversTypes['TagV2']>>> }>;
  TagInput: TagInput;
  TagSearchParamsInput: TagSearchParamsInput;
  TagType: TagType;
  TagTypeV2: TagTypeV2;
  TagV2: ResolverTypeWrapper<Omit<TagV2, 'children' | 'following' | 'followingMetadata' | 'locationRelatedTags' | 'parent' | 'parents' | 'recommendedArticles' | 'recommendedTags' | 'root'> & { children?: Maybe<Array<Maybe<ResolversTypes['TagV2']>>>, following?: Maybe<Array<Maybe<ResolversTypes['TagV2']>>>, followingMetadata?: Maybe<ResolversTypes['FollowingMetadata']>, locationRelatedTags?: Maybe<Array<Maybe<ResolversTypes['TagV2']>>>, parent?: Maybe<ResolversTypes['TagV2']>, parents?: Maybe<Array<Maybe<ResolversTypes['TagV2']>>>, recommendedArticles: Array<ResolversTypes['DsContentModelResult']>, recommendedTags: Array<ResolversTypes['ChannelRecommenderResult']>, root?: Maybe<ResolversTypes['TagV2']> }>;
  TagV2Connection: ResolverTypeWrapper<Omit<TagV2Connection, 'edges'> & { edges: Array<ResolversTypes['TagV2Edge']> }>;
  TagV2Edge: ResolverTypeWrapper<Omit<TagV2Edge, 'node'> & { node: ResolversTypes['TagV2'] }>;
  Tagging: ResolverTypeWrapper<Tagging>;
  TagsQueryInput: TagsQueryInput;
  TaxonomyReference: ResolverTypeWrapper<TaxonomyReference>;
  TaxonomyReferenceGroup: ResolverTypeWrapper<TaxonomyReferenceGroup>;
  TaxonomyTerm: ResolverTypeWrapper<TaxonomyTerm>;
  TaxonomyType: TaxonomyType;
  Team: ResolverTypeWrapper<Team>;
  Tenant: Tenant;
  Tenants: Tenants;
  Territories: Territories;
  TextPollInput: TextPollInput;
  TextPollOptionInput: TextPollOptionInput;
  TextPollWidgetInput: TextPollWidgetInput;
  Tournament: ResolverTypeWrapper<Tournament>;
  Tournaments: ResolverTypeWrapper<Tournaments>;
  TrendingChannelResult: ResolverTypeWrapper<Omit<TrendingChannelResult, 'tagV2'> & { tagV2: ResolversTypes['TagV2'] }>;
  TrendingResult: ResolverTypeWrapper<Omit<TrendingResult, 'contentModule'> & { contentModule?: Maybe<ResolversTypes['StandaloneContentModule']> }>;
  Tweet: ResolverTypeWrapper<Tweet>;
  TweetAttachments: ResolverTypeWrapper<TweetAttachments>;
  TweetData: ResolverTypeWrapper<TweetData>;
  TweetEntities: ResolverTypeWrapper<TweetEntities>;
  TweetHashtag: ResolverTypeWrapper<TweetHashtag>;
  TweetMedia: ResolverTypeWrapper<TweetMedia>;
  TweetMediaType: TweetMediaType;
  TweetMention: ResolverTypeWrapper<TweetMention>;
  TweetMetrics: ResolverTypeWrapper<TweetMetrics>;
  TweetReference: ResolverTypeWrapper<TweetReference>;
  TweetType: TweetType;
  TweetUrl: ResolverTypeWrapper<TweetUrl>;
  TweetVariant: ResolverTypeWrapper<TweetVariant>;
  TwitterUser: ResolverTypeWrapper<TwitterUser>;
  UGCImagePoll: ResolverTypeWrapper<Omit<UgcImagePoll, 'liveLikeImagePoll' | 'liveLikeUserVote'> & { liveLikeImagePoll?: Maybe<ResolversTypes['LiveLikeImagePoll']>, liveLikeUserVote?: Maybe<ResolversTypes['LiveLikeImagePollVote']> }>;
  UGCPost: ResolverTypeWrapper<UgcPost>;
  UGCTextPoll: ResolverTypeWrapper<Omit<UgcTextPoll, 'liveLikeTextPoll' | 'liveLikeUserVote'> & { liveLikeTextPoll?: Maybe<ResolversTypes['LiveLikeTextPoll']>, liveLikeUserVote?: Maybe<ResolversTypes['LiveLikeTextPollVote']> }>;
  UGCWidget: ResolverTypeWrapper<UgcWidget>;
  URL: ResolverTypeWrapper<Scalars['URL']['output']>;
  UUID: ResolverTypeWrapper<Scalars['UUID']['output']>;
  UpdatePostInput: UpdatePostInput;
  UpdateTextPollInput: UpdateTextPollInput;
  UrlMapping: ResolverTypeWrapper<UrlMapping>;
  User: ResolverTypeWrapper<Omit<User, 'creatorTag' | 'favoriteTeams' | 'tags'> & { creatorTag?: Maybe<ResolversTypes['TagV2']>, favoriteTeams?: Maybe<Array<Maybe<ResolversTypes['TagV2']>>>, tags?: Maybe<Array<Maybe<ResolversTypes['TagV2']>>> }>;
  UserDestination: ResolverTypeWrapper<Omit<UserDestination, 'contentModule' | 'tag'> & { contentModule?: Maybe<ResolversTypes['StandaloneContentModule']>, tag: ResolversTypes['TagV2'] }>;
  UserSocialAlert: ResolverTypeWrapper<Omit<UserSocialAlert, 'userDestination'> & { userDestination?: Maybe<ResolversTypes['UserDestination']> }>;
  UserTagInput: UserTagInput;
  V2VResult: ResolverTypeWrapper<Omit<V2VResult, 'video'> & { video?: Maybe<ResolversTypes['StandaloneContentModule']> }>;
  Venue: ResolverTypeWrapper<Venue>;
  Venues: ResolverTypeWrapper<Venues>;
  Video: ResolverTypeWrapper<Video>;
  VideoAnalytics: ResolverTypeWrapper<VideoAnalytics>;
  VideoAppName: ResolverTypeWrapper<VideoAppName>;
  VideoContentType: VideoContentType;
  VideoContentTypeFilter: VideoContentTypeFilter;
  VideoFiltersInput: VideoFiltersInput;
  VideoImpressionTracking: ResolverTypeWrapper<VideoImpressionTracking>;
  VideoMetadata: ResolverTypeWrapper<VideoMetadata>;
  VideoMetadataInput: VideoMetadataInput;
  VideoState: VideoState;
  VideoTitle: ResolverTypeWrapper<VideoTitle>;
  VideoType: VideoType;
  VideoV2: ResolverTypeWrapper<Omit<VideoV2, 'recommendedVideos' | 'tags'> & { recommendedVideos: Array<ResolversTypes['V2VResult']>, tags?: Maybe<Array<Maybe<ResolversTypes['TagV2']>>> }>;
  VideoV2Metadata: ResolverTypeWrapper<VideoV2Metadata>;
  VideoV2TagData: ResolverTypeWrapper<VideoV2TagData>;
  VideoV2TagIds: ResolverTypeWrapper<VideoV2TagIds>;
  VisibilityReason: VisibilityReason;
  WatchInfo: ResolverTypeWrapper<WatchInfo>;
  blockProfileResponse: ResolverTypeWrapper<BlockProfileResponse>;
}>;

/** Mapping between all available schema types and the resolvers parents */
export type ResolversParentTypes = ResolversObject<{
  A2AResult: Omit<A2AResult, 'article'> & { article?: Maybe<ResolversParentTypes['StandaloneContentModule']> };
  A2VResult: Omit<A2VResult, 'video'> & { video?: Maybe<ResolversParentTypes['StandaloneContentModule']> };
  Action: Action;
  AddAlertRankInput: AddAlertRankInput;
  AddAlertRankResponse: AddAlertRankResponse;
  AdsAdSize: AdsAdSize;
  AdsChannelConfiguration: AdsChannelConfiguration;
  AdsChannelGroupingConfiguration: AdsChannelGroupingConfiguration;
  AdsConfiguration: AdsConfiguration;
  AdsDeployedState: AdsDeployedState;
  AdsHistory: AdsHistory;
  AdsModuleConfiguration: AdsModuleConfiguration;
  AdsRegistryDetailItem: AdsRegistryDetailItem;
  AdsSlot: AdsSlot;
  AdsTargeting: AdsTargeting;
  AdsViewport: AdsViewport;
  AlertAnalytics: AlertAnalytics;
  AlertAnalyticsInput: AlertAnalyticsInput;
  AlertDestination: AlertDestination;
  AlertDestinationInput: AlertDestinationInput;
  AlertInput: AlertInput;
  AlertMediaAttachment: AlertMediaAttachment;
  AlertMediaAttachmentInput: AlertMediaAttachmentInput;
  AlertPreference: AlertPreference;
  AlertRank: Omit<AlertRank, 'pushNotification'> & { pushNotification: ResolversParentTypes['PushNotification'] };
  AlertRankInput: AlertRankInput;
  AllowAll: AllowAll;
  Allowed: Allowed;
  Article: Omit<Article, 'betTags' | 'primaryTag' | 'recommendedArticles' | 'recommendedVideos' | 'slides' | 'tags'> & { betTags?: Maybe<Array<Maybe<ResolversParentTypes['TagV2']>>>, primaryTag: ResolversParentTypes['TagV2'], recommendedArticles: Array<ResolversParentTypes['A2AResult']>, recommendedVideos: Array<ResolversParentTypes['A2VResult']>, slides?: Maybe<Array<Maybe<ResolversParentTypes['Slide']>>>, tags?: Maybe<Array<Maybe<ResolversParentTypes['TagV2']>>> };
  ArticleAuthor: ArticleAuthor;
  ArticleConnection: Omit<ArticleConnection, 'edges'> & { edges: Array<ResolversParentTypes['ArticleEdge']> };
  ArticleEdge: Omit<ArticleEdge, 'node'> & { node: ResolversParentTypes['Article'] };
  ArticleFindManyParametersInput: ArticleFindManyParametersInput;
  AssetConnection: Omit<AssetConnection, 'edges' | 'nodes'> & { edges?: Maybe<Array<Maybe<ResolversParentTypes['AssetEdge']>>>, nodes?: Maybe<Array<Maybe<ResolversParentTypes['SearchResult']>>> };
  AssetEdge: Omit<AssetEdge, 'node'> & { node?: Maybe<ResolversParentTypes['SearchResult']> };
  Author: Author;
  Avatar: Avatar;
  Badge: Badge;
  BadgeComponent: BadgeComponent;
  BillingOrder: BillingOrder;
  BlockedContent: BlockedContent;
  Boolean: Scalars['Boolean']['output'];
  Brand: Brand;
  Channel: Omit<Channel, 'components' | 'groupings' | 'pinnedContentModule' | 'tag'> & { components: Array<Maybe<ResolversParentTypes['ChannelComponent']>>, groupings?: Maybe<Array<Maybe<ResolversParentTypes['Grouping']>>>, pinnedContentModule?: Maybe<ResolversParentTypes['ContentModule']>, tag: ResolversParentTypes['TagV2'] };
  ChannelComponent: Omit<ChannelComponent, 'chat' | 'contents' | 'contentsConnection' | 'dataServicesTagData' | 'statsGamecast' | 'tagData' | 'userAlerts' | 'userContents' | 'userSocialAlerts' | 'userTags'> & { chat?: Maybe<ResolversParentTypes['ChatModule']>, contents?: Maybe<Array<Maybe<ResolversParentTypes['ContentModule']>>>, contentsConnection?: Maybe<ResolversParentTypes['ContentsConnection']>, dataServicesTagData: Array<ResolversParentTypes['TagV2']>, statsGamecast?: Maybe<ResolversParentTypes['StatsGamecast']>, tagData?: Maybe<Array<Maybe<ResolversParentTypes['TagV2']>>>, userAlerts?: Maybe<Array<ResolversParentTypes['PushNotification']>>, userContents?: Maybe<Array<Maybe<ResolversParentTypes['StandaloneContentModule']>>>, userSocialAlerts?: Maybe<Array<ResolversParentTypes['UserSocialAlert']>>, userTags?: Maybe<Array<Maybe<ResolversParentTypes['TagV2']>>> };
  ChannelRecommenderResult: Omit<ChannelRecommenderResult, 'tagV2'> & { tagV2: ResolversParentTypes['TagV2'] };
  ChannelStreamMetaData: Omit<ChannelStreamMetaData, 'contents'> & { contents?: Maybe<Array<Maybe<ResolversParentTypes['ContentModule']>>> };
  ChatModule: ChatModule;
  Clock: Clock;
  Competitor: Competitor;
  Competitors: Competitors;
  Component: Omit<Component, 'content'> & { content?: Maybe<Array<Maybe<ResolversParentTypes['Content']>>> };
  ComponentCursor: Scalars['ComponentCursor']['output'];
  ComponentEdge: Omit<ComponentEdge, 'node'> & { node: ResolversParentTypes['Component'] };
  ComponentModule: Omit<ComponentModule, 'tag'> & { tag?: Maybe<ResolversParentTypes['TagV2']> };
  ComponentsConnection: Omit<ComponentsConnection, 'edges'> & { edges: Array<ResolversParentTypes['ComponentEdge']> };
  Conference: Conference;
  Conferences: Conferences;
  ConfigJson: ConfigJson;
  Content: Omit<Content, 'channelStream' | 'contentModules'> & { channelStream?: Maybe<ResolversParentTypes['ChannelStreamMetaData']>, contentModules?: Maybe<Array<Maybe<ResolversParentTypes['ContentModule']>>> };
  ContentBrand: ContentBrand;
  ContentCursor: Scalars['ContentCursor']['output'];
  ContentEdge: Omit<ContentEdge, 'node'> & { node: ResolversParentTypes['ContentModule'] };
  ContentFilters: ContentFilters;
  ContentForm: ContentForm;
  ContentLibrarySearchParametersInput: ContentLibrarySearchParametersInput;
  ContentLibrarySearchResult: ResolversUnionTypes<ResolversParentTypes>['ContentLibrarySearchResult'];
  ContentLibrarySortParametersInput: ContentLibrarySortParametersInput;
  ContentMetadata: ContentMetadata;
  ContentModule: ResolversInterfaceTypes<ResolversParentTypes>['ContentModule'];
  ContentModuleInput: ContentModuleInput;
  ContentShow: ContentShow;
  ContentSort: ContentSort;
  ContentsConnection: Omit<ContentsConnection, 'edges'> & { edges: Array<ResolversParentTypes['ContentEdge']> };
  ContextFieldValue: Scalars['ContextFieldValue']['output'];
  CreatePollResponse: CreatePollResponse;
  CreatePostResponse: CreatePostResponse;
  CreateProgramResponse: CreateProgramResponse;
  Credit: Credit;
  CustomLiveLikeUserReaction: CustomLiveLikeUserReaction;
  Date: Scalars['Date']['output'];
  DateRangeFilter: DateRangeFilter;
  DateTime: Scalars['DateTime']['output'];
  DateTimeISO: Scalars['DateTimeISO']['output'];
  DeleteVideoContentModulesResult: DeleteVideoContentModulesResult;
  Device: Device;
  DeviceInput: DeviceInput;
  Division: Division;
  Divisions: Divisions;
  DsContentModelResult: ResolversInterfaceTypes<ResolversParentTypes>['DsContentModelResult'];
  DsModel: DsModel;
  Duration: Scalars['Duration']['output'];
  Element: Omit<Element, 'content'> & { content?: Maybe<ResolversParentTypes['ElementContent']> };
  ElementContent: Omit<ElementContent, 'media'> & { media?: Maybe<ResolversParentTypes['VideoV2']> };
  Event: Event;
  EventFilterInput: EventFilterInput;
  EventFilterType: EventFilterType;
  Events: Events;
  ExternalArticle: ExternalArticle;
  FacetRequest: FacetRequest;
  FacetResponse: FacetResponse;
  FacetResult: FacetResult;
  Feed: Feed;
  Filter: Filter;
  Float: Scalars['Float']['output'];
  FollowingMetadata: FollowingMetadata;
  FormElement: FormElement;
  Game: Game;
  GameDate: GameDate;
  GameGroup: GameGroup;
  GameProgress: GameProgress;
  GamecastAnalytics: GamecastAnalytics;
  GamecastMetadata: GamecastMetadata;
  GamecastProgress: GamecastProgress;
  GamecastScoreboard: GamecastScoreboard;
  GamecastTeam: GamecastTeam;
  Grouping: Omit<Grouping, 'components'> & { components?: Maybe<Array<Maybe<ResolversParentTypes['ChannelComponent']>>> };
  GroupingHeader: GroupingHeader;
  ID: Scalars['ID']['output'];
  Identifier: Identifier;
  Image: Image;
  ImagePollInput: ImagePollInput;
  ImagePollOptionInput: ImagePollOptionInput;
  ImageWithStyle: ImageWithStyle;
  Int: Scalars['Int']['output'];
  Item: Item;
  JSON: Scalars['JSON']['output'];
  JSONObject: Scalars['JSONObject']['output'];
  JWT: Scalars['JWT']['output'];
  League: League;
  Leagues: Leagues;
  Legacy: Legacy;
  Limitation: Limitation;
  Link: Link;
  LiveLikeAlert: LiveLikeAlert;
  LiveLikeAlertCreateInput: LiveLikeAlertCreateInput;
  LiveLikeAlertLocalizedInput: LiveLikeAlertLocalizedInput;
  LiveLikeApplication: LiveLikeApplication;
  LiveLikeAwardBadgeInput: LiveLikeAwardBadgeInput;
  LiveLikeBadge: LiveLikeBadge;
  LiveLikeBadgeCollection: LiveLikeBadgeCollection;
  LiveLikeBadgeEdge: LiveLikeBadgeEdge;
  LiveLikeBadgeProfile: Omit<LiveLikeBadgeProfile, 'profile'> & { profile: ResolversParentTypes['LiveLikeProfile'] };
  LiveLikeBadgeProfileCollection: Omit<LiveLikeBadgeProfileCollection, 'edges'> & { edges?: Maybe<Array<ResolversParentTypes['LiveLikeBadgeProfileEdge']>> };
  LiveLikeBadgeProfileEdge: Omit<LiveLikeBadgeProfileEdge, 'node'> & { node: ResolversParentTypes['LiveLikeBadgeProfile'] };
  LiveLikeBadgeRewardProgress: LiveLikeBadgeRewardProgress;
  LiveLikeBadgeRewardProgressCollection: LiveLikeBadgeRewardProgressCollection;
  LiveLikeBlockProfile: Omit<LiveLikeBlockProfile, 'blockedByProfile' | 'blockedProfile'> & { blockedByProfile: ResolversParentTypes['LiveLikeProfile'], blockedProfile: ResolversParentTypes['LiveLikeProfile'] };
  LiveLikeChatRoom: LiveLikeChatRoom;
  LiveLikeChatRoomChannel: LiveLikeChatRoomChannel;
  LiveLikeChatRoomCollection: LiveLikeChatRoomCollection;
  LiveLikeChatRoomCreateInput: LiveLikeChatRoomCreateInput;
  LiveLikeChatRoomEdge: LiveLikeChatRoomEdge;
  LiveLikeChatRoomUpdateInput: LiveLikeChatRoomUpdateInput;
  LiveLikeChatRoomsGetInput: LiveLikeChatRoomsGetInput;
  LiveLikeComment: Omit<LiveLikeComment, 'author'> & { author: ResolversParentTypes['LiveLikeProfile'] };
  LiveLikeCommentBoard: LiveLikeCommentBoard;
  LiveLikeCommentBoardBan: LiveLikeCommentBoardBan;
  LiveLikeCommentBoardBanCollection: LiveLikeCommentBoardBanCollection;
  LiveLikeCommentBoardBanEdge: LiveLikeCommentBoardBanEdge;
  LiveLikeCommentBoardBanInput: LiveLikeCommentBoardBanInput;
  LiveLikeCommentBoardBansInput: LiveLikeCommentBoardBansInput;
  LiveLikeCommentBoardCollection: LiveLikeCommentBoardCollection;
  LiveLikeCommentBoardCount: LiveLikeCommentBoardCount;
  LiveLikeCommentBoardCreateInput: LiveLikeCommentBoardCreateInput;
  LiveLikeCommentBoardEdge: LiveLikeCommentBoardEdge;
  LiveLikeCommentBoardUpdateInput: LiveLikeCommentBoardUpdateInput;
  LiveLikeCommentBoardsCountGetInput: LiveLikeCommentBoardsCountGetInput;
  LiveLikeCommentBoardsGetInput: LiveLikeCommentBoardsGetInput;
  LiveLikeCommentCollection: Omit<LiveLikeCommentCollection, 'edges'> & { edges?: Maybe<Array<Maybe<ResolversParentTypes['LiveLikeCommentEdge']>>> };
  LiveLikeCommentCreateInput: LiveLikeCommentCreateInput;
  LiveLikeCommentEdge: Omit<LiveLikeCommentEdge, 'node'> & { node: ResolversParentTypes['LiveLikeComment'] };
  LiveLikeCommentRepliesGetInput: LiveLikeCommentRepliesGetInput;
  LiveLikeCommentReplyCreateInput: LiveLikeCommentReplyCreateInput;
  LiveLikeCommentReport: Omit<LiveLikeCommentReport, 'comment'> & { comment: ResolversParentTypes['LiveLikeComment'] };
  LiveLikeCommentReportCollection: Omit<LiveLikeCommentReportCollection, 'edges'> & { edges?: Maybe<Array<Maybe<ResolversParentTypes['LiveLikeCommentReportEdge']>>> };
  LiveLikeCommentReportCreateInput: LiveLikeCommentReportCreateInput;
  LiveLikeCommentReportEdge: Omit<LiveLikeCommentReportEdge, 'node'> & { node: ResolversParentTypes['LiveLikeCommentReport'] };
  LiveLikeCommentsGetInput: LiveLikeCommentsGetInput;
  LiveLikeCommentsReportsGetInput: LiveLikeCommentsReportsGetInput;
  LiveLikeConnection: ResolversInterfaceTypes<ResolversParentTypes>['LiveLikeConnection'];
  LiveLikeEarnedBadge: LiveLikeEarnedBadge;
  LiveLikeEarnedBadgeCollection: LiveLikeEarnedBadgeCollection;
  LiveLikeEarnedBadgeEdge: LiveLikeEarnedBadgeEdge;
  LiveLikeEdge: ResolversInterfaceTypes<ResolversParentTypes>['LiveLikeEdge'];
  LiveLikeEmoji: LiveLikeEmoji;
  LiveLikeEmojiCount: LiveLikeEmojiCount;
  LiveLikeImagePoll: Omit<LiveLikeImagePoll, 'userVote'> & { userVote?: Maybe<ResolversParentTypes['LiveLikeWidgetInteraction']> };
  LiveLikeImagePollCreateInput: LiveLikeImagePollCreateInput;
  LiveLikeImagePollCreateOptionInput: LiveLikeImagePollCreateOptionInput;
  LiveLikeImagePollLocalizedInput: LiveLikeImagePollLocalizedInput;
  LiveLikeImagePollOption: LiveLikeImagePollOption;
  LiveLikeImagePollOptionLocalizedInput: LiveLikeImagePollOptionLocalizedInput;
  LiveLikeImagePollVote: Omit<LiveLikeImagePollVote, 'leaderboardRewards' | 'widget'> & { leaderboardRewards?: Maybe<Array<ResolversParentTypes['LiveLikeLeaderboardReward']>>, widget: ResolversParentTypes['LiveLikeImagePoll'] };
  LiveLikeImagePollVoteCreateInput: LiveLikeImagePollVoteCreateInput;
  LiveLikeImagePollVoteUpdateInput: LiveLikeImagePollVoteUpdateInput;
  LiveLikeImagePrediction: LiveLikeImagePrediction;
  LiveLikeImagePredictionCreateInput: LiveLikeImagePredictionCreateInput;
  LiveLikeImagePredictionCreateOptionInput: LiveLikeImagePredictionCreateOptionInput;
  LiveLikeImagePredictionFollowUp: LiveLikeImagePredictionFollowUp;
  LiveLikeImagePredictionFollowUpCreateInput: LiveLikeImagePredictionFollowUpCreateInput;
  LiveLikeImagePredictionLocalizedInput: LiveLikeImagePredictionLocalizedInput;
  LiveLikeImagePredictionOption: LiveLikeImagePredictionOption;
  LiveLikeImagePredictionOptionLocalizedInput: LiveLikeImagePredictionOptionLocalizedInput;
  LiveLikeImagePredictionVote: Omit<LiveLikeImagePredictionVote, 'leaderboardRewards'> & { leaderboardRewards?: Maybe<Array<ResolversParentTypes['LiveLikeLeaderboardReward']>> };
  LiveLikeImagePredictionVoteCreateInput: LiveLikeImagePredictionVoteCreateInput;
  LiveLikeImagePredictionVoteUpdateInput: LiveLikeImagePredictionVoteUpdateInput;
  LiveLikeImageQuiz: LiveLikeImageQuiz;
  LiveLikeImageQuizAnswer: Omit<LiveLikeImageQuizAnswer, 'leaderboardRewards'> & { leaderboardRewards?: Maybe<Array<ResolversParentTypes['LiveLikeLeaderboardReward']>> };
  LiveLikeImageQuizAnswerCreateInput: LiveLikeImageQuizAnswerCreateInput;
  LiveLikeImageQuizAnswerUpdateInput: LiveLikeImageQuizAnswerUpdateInput;
  LiveLikeImageQuizChoice: LiveLikeImageQuizChoice;
  LiveLikeImageQuizChoiceLocalizedInput: LiveLikeImageQuizChoiceLocalizedInput;
  LiveLikeImageQuizCreateChoiceInput: LiveLikeImageQuizCreateChoiceInput;
  LiveLikeImageQuizCreateInput: LiveLikeImageQuizCreateInput;
  LiveLikeImageQuizLocalizedInput: LiveLikeImageQuizLocalizedInput;
  LiveLikeIncomingProfileRelationshipInput: LiveLikeIncomingProfileRelationshipInput;
  LiveLikeKeyValuePair: LiveLikeKeyValuePair;
  LiveLikeKeyValuePairInput: LiveLikeKeyValuePairInput;
  LiveLikeLeaderboard: LiveLikeLeaderboard;
  LiveLikeLeaderboardCollection: LiveLikeLeaderboardCollection;
  LiveLikeLeaderboardCreateInput: LiveLikeLeaderboardCreateInput;
  LiveLikeLeaderboardEdge: LiveLikeLeaderboardEdge;
  LiveLikeLeaderboardEntriesGetInput: LiveLikeLeaderboardEntriesGetInput;
  LiveLikeLeaderboardEntry: LiveLikeLeaderboardEntry;
  LiveLikeLeaderboardEntryCollection: LiveLikeLeaderboardEntryCollection;
  LiveLikeLeaderboardEntryEdge: LiveLikeLeaderboardEntryEdge;
  LiveLikeLeaderboardEntryGetInput: LiveLikeLeaderboardEntryGetInput;
  LiveLikeLeaderboardProgramLinkInput: LiveLikeLeaderboardProgramLinkInput;
  LiveLikeLeaderboardReward: LiveLikeLeaderboardReward;
  LiveLikeLeaderboardUpdateInput: LiveLikeLeaderboardUpdateInput;
  LiveLikeLeaderboardsGetInput: LiveLikeLeaderboardsGetInput;
  LiveLikeLinkRewardTableWithProgramInput: LiveLikeLinkRewardTableWithProgramInput;
  LiveLikeNode: ResolversInterfaceTypes<ResolversParentTypes>['LiveLikeNode'];
  LiveLikeOutgoingProfileRelationshipInput: LiveLikeOutgoingProfileRelationshipInput;
  LiveLikePage: LiveLikePage;
  LiveLikePageOffset: LiveLikePageOffset;
  LiveLikePaginationOffset: LiveLikePaginationOffset;
  LiveLikePaginationOffsetInput: LiveLikePaginationOffsetInput;
  LiveLikePermission: LiveLikePermission;
  LiveLikePermissionEdge: LiveLikePermissionEdge;
  LiveLikePermissions: LiveLikePermissions;
  LiveLikePollVoteCreateInput: LiveLikePollVoteCreateInput;
  LiveLikePollVoteUpdateInput: LiveLikePollVoteUpdateInput;
  LiveLikeProfile: Omit<LiveLikeProfile, 'rewardBalance' | 'widgetsInteractions'> & { rewardBalance?: Maybe<ResolversParentTypes['LiveLikeRewardItemBalance']>, widgetsInteractions?: Maybe<Array<ResolversParentTypes['LiveLikeWidgetInteractions']>> };
  LiveLikeProfileAuth: LiveLikeProfileAuth;
  LiveLikeProfileByCustomIdCreateInput: LiveLikeProfileByCustomIdCreateInput;
  LiveLikeProfileCreateInput: LiveLikeProfileCreateInput;
  LiveLikeProfileGetByCustomIdInput: LiveLikeProfileGetByCustomIdInput;
  LiveLikeProfileRelationship: Omit<LiveLikeProfileRelationship, 'fromProfile' | 'toProfile'> & { fromProfile: ResolversParentTypes['LiveLikeProfile'], toProfile: ResolversParentTypes['LiveLikeProfile'] };
  LiveLikeProfileRelationshipCollection: LiveLikeProfileRelationshipCollection;
  LiveLikeProfileRelationshipCreateInput: LiveLikeProfileRelationshipCreateInput;
  LiveLikeProfileRelationshipEdge: LiveLikeProfileRelationshipEdge;
  LiveLikeProfileRelationshipInput: LiveLikeProfileRelationshipInput;
  LiveLikeProfileRelationshipOrderInput: LiveLikeProfileRelationshipOrderInput;
  LiveLikeProfileRelationshipType: LiveLikeProfileRelationshipType;
  LiveLikeProfileRelationshipTypeCollection: LiveLikeProfileRelationshipTypeCollection;
  LiveLikeProfileRelationshipTypeCreateInput: LiveLikeProfileRelationshipTypeCreateInput;
  LiveLikeProfileRelationshipTypeEdge: LiveLikeProfileRelationshipTypeEdge;
  LiveLikeProfileRelationshipTypesInput: LiveLikeProfileRelationshipTypesInput;
  LiveLikeProfileUpdateInput: LiveLikeProfileUpdateInput;
  LiveLikeProgram: Omit<LiveLikeProgram, 'widgets'> & { widgets?: Maybe<ResolversParentTypes['LiveLikeWidgetCollection']> };
  LiveLikeProgramBan: Omit<LiveLikeProgramBan, 'bannedByProfile' | 'bannedProfile'> & { bannedByProfile: ResolversParentTypes['LiveLikeProfile'], bannedProfile: ResolversParentTypes['LiveLikeProfile'] };
  LiveLikeProgramBanCollection: Omit<LiveLikeProgramBanCollection, 'edges'> & { edges?: Maybe<Array<ResolversParentTypes['LiveLikeProgramBanEdge']>> };
  LiveLikeProgramBanEdge: Omit<LiveLikeProgramBanEdge, 'node'> & { node: ResolversParentTypes['LiveLikeProgramBan'] };
  LiveLikeProgramBanInput: LiveLikeProgramBanInput;
  LiveLikeProgramBansInput: LiveLikeProgramBansInput;
  LiveLikeProgramConnection: Omit<LiveLikeProgramConnection, 'edges'> & { edges?: Maybe<Array<Maybe<ResolversParentTypes['LiveLikeProgramEdge']>>> };
  LiveLikeProgramCreateInput: LiveLikeProgramCreateInput;
  LiveLikeProgramDeleteByCustomIdInput: LiveLikeProgramDeleteByCustomIdInput;
  LiveLikeProgramEdge: Omit<LiveLikeProgramEdge, 'node'> & { node: ResolversParentTypes['LiveLikeProgram'] };
  LiveLikeProgramGetByCustomIdInput: LiveLikeProgramGetByCustomIdInput;
  LiveLikeProgramLocalizedInput: LiveLikeProgramLocalizedInput;
  LiveLikeProgramSchedule: LiveLikeProgramSchedule;
  LiveLikeProgramUpdateByCustomIdInput: LiveLikeProgramUpdateByCustomIdInput;
  LiveLikeProgramUpdateInput: LiveLikeProgramUpdateInput;
  LiveLikeProgramsGetInput: LiveLikeProgramsGetInput;
  LiveLikeQuest: LiveLikeQuest;
  LiveLikeQuestCollection: LiveLikeQuestCollection;
  LiveLikeQuestEdge: LiveLikeQuestEdge;
  LiveLikeQuestInput: LiveLikeQuestInput;
  LiveLikeQuestReward: LiveLikeQuestReward;
  LiveLikeQuestTask: LiveLikeQuestTask;
  LiveLikeReaction: LiveLikeReaction;
  LiveLikeReactionPack: LiveLikeReactionPack;
  LiveLikeReactionPackCollection: LiveLikeReactionPackCollection;
  LiveLikeReactionPackEdge: LiveLikeReactionPackEdge;
  LiveLikeReactionPacksGetInput: LiveLikeReactionPacksGetInput;
  LiveLikeReactionSpace: LiveLikeReactionSpace;
  LiveLikeReactionSpaceCollection: LiveLikeReactionSpaceCollection;
  LiveLikeReactionSpaceCount: LiveLikeReactionSpaceCount;
  LiveLikeReactionSpaceCreateInput: LiveLikeReactionSpaceCreateInput;
  LiveLikeReactionSpaceDeleteInput: LiveLikeReactionSpaceDeleteInput;
  LiveLikeReactionSpaceEdge: LiveLikeReactionSpaceEdge;
  LiveLikeReactionSpaceGetInput: LiveLikeReactionSpaceGetInput;
  LiveLikeReactionSpacePatch: LiveLikeReactionSpacePatch;
  LiveLikeReactionSpaceUpdateInput: LiveLikeReactionSpaceUpdateInput;
  LiveLikeReactionSpacesCountInput: LiveLikeReactionSpacesCountInput;
  LiveLikeReactions: LiveLikeReactions;
  LiveLikeResource: LiveLikeResource;
  LiveLikeReward: LiveLikeReward;
  LiveLikeRewardATableActionChoice: LiveLikeRewardATableActionChoice;
  LiveLikeRewardAction: LiveLikeRewardAction;
  LiveLikeRewardActionCreateInput: LiveLikeRewardActionCreateInput;
  LiveLikeRewardActionItem: LiveLikeRewardActionItem;
  LiveLikeRewardBalanceGetInput: LiveLikeRewardBalanceGetInput;
  LiveLikeRewardBalancesGetInput: LiveLikeRewardBalancesGetInput;
  LiveLikeRewardItem: LiveLikeRewardItem;
  LiveLikeRewardItemBalance: LiveLikeRewardItemBalance;
  LiveLikeRewardItemBalanceCollection: LiveLikeRewardItemBalanceCollection;
  LiveLikeRewardItemBalanceEdge: Omit<LiveLikeRewardItemBalanceEdge, 'node'> & { node: ResolversParentTypes['LiveLikeRewardItemBalance'] };
  LiveLikeRewardItemCollection: LiveLikeRewardItemCollection;
  LiveLikeRewardItemCreateInput: LiveLikeRewardItemCreateInput;
  LiveLikeRewardItemEdge: LiveLikeRewardItemEdge;
  LiveLikeRewardItemImage: LiveLikeRewardItemImage;
  LiveLikeRewardItemTransaction: LiveLikeRewardItemTransaction;
  LiveLikeRewardItemTransactionInput: LiveLikeRewardItemTransactionInput;
  LiveLikeRewardTable: LiveLikeRewardTable;
  LiveLikeRewardTableCollection: LiveLikeRewardTableCollection;
  LiveLikeRewardTableCreateInput: LiveLikeRewardTableCreateInput;
  LiveLikeRewardTableEdge: LiveLikeRewardTableEdge;
  LiveLikeRewardTableEntry: LiveLikeRewardTableEntry;
  LiveLikeRewardTableEntryCreateInput: LiveLikeRewardTableEntryCreateInput;
  LiveLikeRewardTableEntryDeleteInput: LiveLikeRewardTableEntryDeleteInput;
  LiveLikeRewardTableEntryGetInput: LiveLikeRewardTableEntryGetInput;
  LiveLikeRewardTableEntryInput: LiveLikeRewardTableEntryInput;
  LiveLikeRewardTableUpdateInput: LiveLikeRewardTableUpdateInput;
  LiveLikeRewardTablesGetInput: LiveLikeRewardTablesGetInput;
  LiveLikeRichPost: LiveLikeRichPost;
  LiveLikeRichPostCreateInput: LiveLikeRichPostCreateInput;
  LiveLikeRichPostLocalizedInput: LiveLikeRichPostLocalizedInput;
  LiveLikeRole: LiveLikeRole;
  LiveLikeRoleAssignment: Omit<LiveLikeRoleAssignment, 'profile'> & { profile?: Maybe<ResolversParentTypes['LiveLikeProfile']> };
  LiveLikeRoleAssignmentConnection: Omit<LiveLikeRoleAssignmentConnection, 'edges'> & { edges?: Maybe<Array<ResolversParentTypes['LiveLikeRoleAssignmentEdge']>> };
  LiveLikeRoleAssignmentCreateInput: LiveLikeRoleAssignmentCreateInput;
  LiveLikeRoleAssignmentEdge: Omit<LiveLikeRoleAssignmentEdge, 'node'> & { node: ResolversParentTypes['LiveLikeRoleAssignment'] };
  LiveLikeRoleAssignmentsGetInput: LiveLikeRoleAssignmentsGetInput;
  LiveLikeRoleConnection: LiveLikeRoleConnection;
  LiveLikeRoleCreateInput: LiveLikeRoleCreateInput;
  LiveLikeRoleEdge: LiveLikeRoleEdge;
  LiveLikeRolesGetInput: LiveLikeRolesGetInput;
  LiveLikeScope: LiveLikeScope;
  LiveLikeSocialEmbed: LiveLikeSocialEmbed;
  LiveLikeSocialEmbedCreateInput: LiveLikeSocialEmbedCreateInput;
  LiveLikeSocialEmbedItem: LiveLikeSocialEmbedItem;
  LiveLikeSocialEmbedLocalizedInput: LiveLikeSocialEmbedLocalizedInput;
  LiveLikeTextPoll: Omit<LiveLikeTextPoll, 'userVote'> & { userVote?: Maybe<ResolversParentTypes['LiveLikeWidgetInteraction']> };
  LiveLikeTextPollCreateInput: LiveLikeTextPollCreateInput;
  LiveLikeTextPollCreateOptionInput: LiveLikeTextPollCreateOptionInput;
  LiveLikeTextPollLocalizedInput: LiveLikeTextPollLocalizedInput;
  LiveLikeTextPollOption: LiveLikeTextPollOption;
  LiveLikeTextPollOptionLocalizedInput: LiveLikeTextPollOptionLocalizedInput;
  LiveLikeTextPollVote: Omit<LiveLikeTextPollVote, 'leaderboardRewards' | 'widget'> & { leaderboardRewards?: Maybe<Array<ResolversParentTypes['LiveLikeLeaderboardReward']>>, widget: ResolversParentTypes['LiveLikeTextPoll'] };
  LiveLikeTextPollVoteCreateInput: LiveLikeTextPollVoteCreateInput;
  LiveLikeTextPollVoteUpdateInput: LiveLikeTextPollVoteUpdateInput;
  LiveLikeTextPrediction: LiveLikeTextPrediction;
  LiveLikeTextPredictionCreateInput: LiveLikeTextPredictionCreateInput;
  LiveLikeTextPredictionCreateOptionInput: LiveLikeTextPredictionCreateOptionInput;
  LiveLikeTextPredictionFollowUp: LiveLikeTextPredictionFollowUp;
  LiveLikeTextPredictionFollowUpCreateInput: LiveLikeTextPredictionFollowUpCreateInput;
  LiveLikeTextPredictionLocalizedInput: LiveLikeTextPredictionLocalizedInput;
  LiveLikeTextPredictionOption: LiveLikeTextPredictionOption;
  LiveLikeTextPredictionOptionLocalizedInput: LiveLikeTextPredictionOptionLocalizedInput;
  LiveLikeTextPredictionVote: Omit<LiveLikeTextPredictionVote, 'leaderboardRewards'> & { leaderboardRewards?: Maybe<Array<ResolversParentTypes['LiveLikeLeaderboardReward']>> };
  LiveLikeTextPredictionVoteCreateInput: LiveLikeTextPredictionVoteCreateInput;
  LiveLikeTextPredictionVoteUpdateInput: LiveLikeTextPredictionVoteUpdateInput;
  LiveLikeTextQuiz: LiveLikeTextQuiz;
  LiveLikeTextQuizAnswer: Omit<LiveLikeTextQuizAnswer, 'leaderboardRewards'> & { leaderboardRewards?: Maybe<Array<ResolversParentTypes['LiveLikeLeaderboardReward']>> };
  LiveLikeTextQuizAnswerCreateInput: LiveLikeTextQuizAnswerCreateInput;
  LiveLikeTextQuizAnswerUpdateInput: LiveLikeTextQuizAnswerUpdateInput;
  LiveLikeTextQuizChoice: LiveLikeTextQuizChoice;
  LiveLikeTextQuizChoiceLocalizedInput: LiveLikeTextQuizChoiceLocalizedInput;
  LiveLikeTextQuizCreateChoiceInput: LiveLikeTextQuizCreateChoiceInput;
  LiveLikeTextQuizCreateInput: LiveLikeTextQuizCreateInput;
  LiveLikeTextQuizLocalizedInput: LiveLikeTextQuizLocalizedInput;
  LiveLikeTokenGate: LiveLikeTokenGate;
  LiveLikeTokenGateAttribute: LiveLikeTokenGateAttribute;
  LiveLikeTokenGateAttributesInput: LiveLikeTokenGateAttributesInput;
  LiveLikeTokenGateInput: LiveLikeTokenGateInput;
  LiveLikeUnlinkRewardTableWithProgramInput: LiveLikeUnlinkRewardTableWithProgramInput;
  LiveLikeUserBadge: Omit<LiveLikeUserBadge, 'profile'> & { profile: ResolversParentTypes['LiveLikeProfile'] };
  LiveLikeUserBadgeCollection: Omit<LiveLikeUserBadgeCollection, 'edges'> & { edges?: Maybe<Array<ResolversParentTypes['LiveLikeUserBadgeEdge']>> };
  LiveLikeUserBadgeEdge: Omit<LiveLikeUserBadgeEdge, 'node'> & { node: ResolversParentTypes['LiveLikeUserBadge'] };
  LiveLikeUserQuest: LiveLikeUserQuest;
  LiveLikeUserQuestCollection: LiveLikeUserQuestCollection;
  LiveLikeUserQuestEdge: LiveLikeUserQuestEdge;
  LiveLikeUserQuestInput: LiveLikeUserQuestInput;
  LiveLikeUserQuestReward: LiveLikeUserQuestReward;
  LiveLikeUserQuestRewardsConnection: LiveLikeUserQuestRewardsConnection;
  LiveLikeUserQuestRewardsEdge: LiveLikeUserQuestRewardsEdge;
  LiveLikeUserQuestRewardsInput: LiveLikeUserQuestRewardsInput;
  LiveLikeUserQuestTask: LiveLikeUserQuestTask;
  LiveLikeUserQuestTaskProgress: LiveLikeUserQuestTaskProgress;
  LiveLikeUserQuestsInput: LiveLikeUserQuestsInput;
  LiveLikeUserQuestsTaskProgressInput: LiveLikeUserQuestsTaskProgressInput;
  LiveLikeUserReaction: LiveLikeUserReaction;
  LiveLikeUserReactionCollection: LiveLikeUserReactionCollection;
  LiveLikeUserReactionCountCollection: LiveLikeUserReactionCountCollection;
  LiveLikeUserReactionCountEdge: LiveLikeUserReactionCountEdge;
  LiveLikeUserReactionCountsGetInput: LiveLikeUserReactionCountsGetInput;
  LiveLikeUserReactionCreateInput: LiveLikeUserReactionCreateInput;
  LiveLikeUserReactionEdge: LiveLikeUserReactionEdge;
  LiveLikeUserReactionsGetInput: LiveLikeUserReactionsGetInput;
  LiveLikeVideoAlert: LiveLikeVideoAlert;
  LiveLikeVideoAlertCreateInput: LiveLikeVideoAlertCreateInput;
  LiveLikeVideoAlertLocalizedInput: LiveLikeVideoAlertLocalizedInput;
  LiveLikeWidget: ResolversUnionTypes<ResolversParentTypes>['LiveLikeWidget'];
  LiveLikeWidgetBase: ResolversInterfaceTypes<ResolversParentTypes>['LiveLikeWidgetBase'];
  LiveLikeWidgetCollection: Omit<LiveLikeWidgetCollection, 'edges'> & { edges?: Maybe<Array<Maybe<ResolversParentTypes['LiveLikeWidgetEdge']>>> };
  LiveLikeWidgetCreator: LiveLikeWidgetCreator;
  LiveLikeWidgetDeleteInput: LiveLikeWidgetDeleteInput;
  LiveLikeWidgetEdge: Omit<LiveLikeWidgetEdge, 'node'> & { node: ResolversParentTypes['LiveLikeWidget'] };
  LiveLikeWidgetGetInput: LiveLikeWidgetGetInput;
  LiveLikeWidgetInteraction: Omit<LiveLikeWidgetInteraction, 'leaderboardRewards' | 'widget'> & { leaderboardRewards?: Maybe<Array<ResolversParentTypes['LiveLikeLeaderboardReward']>>, widget?: Maybe<ResolversParentTypes['LiveLikeWidget']> };
  LiveLikeWidgetInteractionBase: ResolversInterfaceTypes<ResolversParentTypes>['LiveLikeWidgetInteractionBase'];
  LiveLikeWidgetInteractionBaseCreateInput: ResolversInterfaceTypes<ResolversParentTypes>['LiveLikeWidgetInteractionBaseCreateInput'];
  LiveLikeWidgetInteractionCreateInput: LiveLikeWidgetInteractionCreateInput;
  LiveLikeWidgetInteractionUnion: ResolversUnionTypes<ResolversParentTypes>['LiveLikeWidgetInteractionUnion'];
  LiveLikeWidgetInteractionUpdateInput: LiveLikeWidgetInteractionUpdateInput;
  LiveLikeWidgetInteractions: Omit<LiveLikeWidgetInteractions, 'interactions'> & { interactions?: Maybe<Array<ResolversParentTypes['LiveLikeWidgetInteractionUnion']>> };
  LiveLikeWidgetInteractionsInput: LiveLikeWidgetInteractionsInput;
  LiveLikeWidgetOrder: LiveLikeWidgetOrder;
  LiveLikeWidgetOrderInput: LiveLikeWidgetOrderInput;
  LiveLikeWidgetPublish: LiveLikeWidgetPublish;
  LiveLikeWidgetPublishInput: LiveLikeWidgetPublishInput;
  LiveLikeWidgetReport: LiveLikeWidgetReport;
  LiveLikeWidgetReportCollection: LiveLikeWidgetReportCollection;
  LiveLikeWidgetReportCount: LiveLikeWidgetReportCount;
  LiveLikeWidgetReportEdge: LiveLikeWidgetReportEdge;
  LiveLikeWidgetReportInput: LiveLikeWidgetReportInput;
  LiveLikeWidgetReportsInput: LiveLikeWidgetReportsInput;
  LiveLikeclaimUserQuestRewardInput: LiveLikeclaimUserQuestRewardInput;
  Locale: Scalars['Locale']['output'];
  Localization: Localization;
  Media: Media;
  Menu: Menu;
  MenuLinks: Omit<MenuLinks, 'tags'> & { tags?: Maybe<Array<Maybe<ResolversParentTypes['TagV2']>>> };
  MenuOptions: MenuOptions;
  MenuOptionsAttributes: MenuOptionsAttributes;
  MenuRoutes: MenuRoutes;
  Metadata: Metadata;
  ModuleMetaData: Omit<ModuleMetaData, 'author' | 'communityTag'> & { author?: Maybe<ResolversParentTypes['TagV2']>, communityTag?: Maybe<ResolversParentTypes['TagV2']> };
  MongoID: Scalars['MongoID']['output'];
  Mutation: {};
  Name: Name;
  NavigationElement: NavigationElement;
  NavigationQueryParameters: NavigationQueryParameters;
  NewPushNotification: NewPushNotification;
  NonEmptyString: Scalars['NonEmptyString']['output'];
  NonNegativeFloat: Scalars['NonNegativeFloat']['output'];
  NonNegativeInt: Scalars['NonNegativeInt']['output'];
  NotificationInput: NotificationInput;
  NotificationMethod: NotificationMethod;
  NotificationMethodInput: NotificationMethodInput;
  Notifications: Notifications;
  Offering: Offering;
  PackageContent: PackageContent;
  PackageContentModule: Omit<PackageContentModule, 'alertRanks' | 'components' | 'contents' | 'metaData'> & { alertRanks: Array<Maybe<ResolversParentTypes['AlertRank']>>, components?: Maybe<Array<Maybe<ResolversParentTypes['ComponentModule']>>>, contents?: Maybe<Array<Maybe<ResolversParentTypes['StandaloneContentModule']>>>, metaData?: Maybe<ResolversParentTypes['ModuleMetaData']> };
  PackageInput: PackageInput;
  Page: Omit<Page, 'components' | 'componentsConnection'> & { components?: Maybe<Array<Maybe<ResolversParentTypes['Component']>>>, componentsConnection: ResolversParentTypes['ComponentsConnection'] };
  PageBody: PageBody;
  PageComponentFiltersInput: PageComponentFiltersInput;
  PageInfo: PageInfo;
  PageMetatags: PageMetatags;
  PaginationControl: PaginationControl;
  PaginationControlInput: PaginationControlInput;
  PeriodScore: PeriodScore;
  Playlist: Playlist;
  Poll: Poll;
  PositiveInt: Scalars['PositiveInt']['output'];
  Post: Post;
  PostInput: PostInput;
  PrepareImageResponse: PrepareImageResponse;
  Product: Product;
  ProductLine: ProductLine;
  Program: Program;
  ProgrammedContent: ResolversUnionTypes<ResolversParentTypes>['ProgrammedContent'];
  PushNotification: Omit<PushNotification, 'analytics' | 'tags' | 'userDestination'> & { analytics?: Maybe<ResolversParentTypes['AlertAnalytics']>, tags: Array<ResolversParentTypes['TagV2']>, userDestination?: Maybe<ResolversParentTypes['UserDestination']> };
  PushNotificationAlertRankInput: PushNotificationAlertRankInput;
  PushNotificationAlertRankResponse: PushNotificationAlertRankResponse;
  Query: {};
  QueryAssistResponse: QueryAssistResponse;
  QueryAssistResult: QueryAssistResult;
  Rating: Rating;
  Reference: Reference;
  ReferenceInput: ReferenceInput;
  ReferenceMetadata: ReferenceMetadata;
  ReferenceStream: ReferenceStream;
  Schedule: Schedule;
  Score: Score;
  Scores: Scores;
  ScoresBettingLink: ScoresBettingLink;
  ScoresCalendarNavigation: ScoresCalendarNavigation;
  ScoresDescription: ScoresDescription;
  ScoresEvent: Omit<ScoresEvent, 'gamecastTag'> & { gamecastTag?: Maybe<ResolversParentTypes['TagV2']> };
  ScoresEventNameLabel: ScoresEventNameLabel;
  ScoresEventParticipant: ScoresEventParticipant;
  ScoresEventParticipantEntry: ScoresEventParticipantEntry;
  ScoresEventParticipantEntryFontFormatting: ScoresEventParticipantEntryFontFormatting;
  ScoresEventParticipantEntryValue: ScoresEventParticipantEntryValue;
  ScoresEventParticipantHeader: ScoresEventParticipantHeader;
  ScoresGame: Omit<ScoresGame, 'gamecastTag'> & { gamecastTag?: Maybe<ResolversParentTypes['TagV2']> };
  ScoresGameTeam: ScoresGameTeam;
  ScoresLeague: Omit<ScoresLeague, 'tagV2'> & { tagV2?: Maybe<ResolversParentTypes['TagV2']> };
  ScoresLeagueQueryParameters: ScoresLeagueQueryParameters;
  ScoresMetadata: ScoresMetadata;
  ScoresMetadataLocation: ScoresMetadataLocation;
  ScoresProgress: ScoresProgress;
  ScoresState: ScoresState;
  ScoresStateRunners: ScoresStateRunners;
  ScoresTeamCompetitor: ScoresTeamCompetitor;
  SearchAsset: ResolversUnionTypes<ResolversParentTypes>['SearchAsset'];
  SearchResult: Omit<SearchResult, 'contentModule' | 'searchAsset'> & { contentModule?: Maybe<ResolversParentTypes['StandaloneContentModule']>, searchAsset?: Maybe<ResolversParentTypes['SearchAsset']> };
  SearchResults: Omit<SearchResults, 'connection'> & { connection?: Maybe<ResolversParentTypes['AssetConnection']> };
  Season: Season;
  Series: Series;
  Serieses: Serieses;
  Settings: Settings;
  Show: Show;
  Slide: Omit<Slide, 'elements' | 'featuredMedia'> & { elements?: Maybe<Array<Maybe<ResolversParentTypes['Element']>>>, featuredMedia: ResolversParentTypes['Element'] };
  SocialLinks: SocialLinks;
  SocialMediaHandle: SocialMediaHandle;
  SocialPreference: SocialPreference;
  SocialWidget: SocialWidget;
  Sport: Sport;
  SportMetaData: SportMetaData;
  Sports: Sports;
  SquadRide: SquadRide;
  StandaloneContentModule: Omit<StandaloneContentModule, 'alertRanks' | 'components' | 'composites' | 'content' | 'metaData'> & { alertRanks: Array<Maybe<ResolversParentTypes['AlertRank']>>, components?: Maybe<Array<Maybe<ResolversParentTypes['ComponentModule']>>>, composites?: Maybe<Array<Maybe<ResolversParentTypes['PackageContentModule']>>>, content: ResolversParentTypes['ProgrammedContent'], metaData?: Maybe<ResolversParentTypes['ModuleMetaData']> };
  StatsBetOffer: StatsBetOffer;
  StatsBetting: StatsBetting;
  StatsGamecast: Omit<StatsGamecast, 'raceInfo' | 'tag'> & { raceInfo?: Maybe<ResolversParentTypes['StatsRaceInfo']>, tag?: Maybe<ResolversParentTypes['TagV2']> };
  StatsLinescore: StatsLinescore;
  StatsLinescoreBatter: StatsLinescoreBatter;
  StatsLinescoreDiamond: StatsLinescoreDiamond;
  StatsLinescoreGameState: StatsLinescoreGameState;
  StatsLinescorePitcher: StatsLinescorePitcher;
  StatsLinescoreTeam: StatsLinescoreTeam;
  StatsLinescoreValue: StatsLinescoreValue;
  StatsPbp: StatsPbp;
  StatsPbpDriveChart: StatsPbpDriveChart;
  StatsPbpDriveSummary: StatsPbpDriveSummary;
  StatsPbpPeriodGrouping: StatsPbpPeriodGrouping;
  StatsPbpPlay: StatsPbpPlay;
  StatsPbpPreview: StatsPbpPreview;
  StatsPbpTabGrouping: StatsPbpTabGrouping;
  StatsPbpTabs: StatsPbpTabs;
  StatsPbpTextFormatting: StatsPbpTextFormatting;
  StatsPodium: StatsPodium;
  StatsPodiumEntry: StatsPodiumEntry;
  StatsRaceInfo: StatsRaceInfo;
  StatsSchedule: StatsSchedule;
  StatsScheduleAdPlacement: StatsScheduleAdPlacement;
  StatsScheduleEntry: StatsScheduleEntry;
  StatsScheduleGrouping: StatsScheduleGrouping;
  StatsScheduleKey: StatsScheduleKey;
  StatsScheduleLink: StatsScheduleLink;
  StatsScheduleResultCode: StatsScheduleResultCode;
  StatsScheduleTickets: StatsScheduleTickets;
  StatsScoreboard: StatsScoreboard;
  StatsScoreboardTeam: StatsScoreboardTeam;
  StatsStanding: StatsStanding;
  StatsStandingAdPlacement: StatsStandingAdPlacement;
  StatsStandingEntry: StatsStandingEntry;
  StatsStandingGrouping: StatsStandingGrouping;
  StatsStandingHeader: StatsStandingHeader;
  StatsStandingKey: StatsStandingKey;
  StatsStandingSeparator: StatsStandingSeparator;
  StatsStandingTeam: StatsStandingTeam;
  StatsStandingValue: StatsStandingValue;
  StatsVenue: StatsVenue;
  StreamMetaData: StreamMetaData;
  String: Scalars['String']['output'];
  Tag: Tag;
  TagComponent: TagComponent;
  TagGroup: Omit<TagGroup, 'children'> & { children?: Maybe<Array<Maybe<ResolversParentTypes['TagV2']>>> };
  TagInput: TagInput;
  TagSearchParamsInput: TagSearchParamsInput;
  TagV2: Omit<TagV2, 'children' | 'following' | 'followingMetadata' | 'locationRelatedTags' | 'parent' | 'parents' | 'recommendedArticles' | 'recommendedTags' | 'root'> & { children?: Maybe<Array<Maybe<ResolversParentTypes['TagV2']>>>, following?: Maybe<Array<Maybe<ResolversParentTypes['TagV2']>>>, followingMetadata?: Maybe<ResolversParentTypes['FollowingMetadata']>, locationRelatedTags?: Maybe<Array<Maybe<ResolversParentTypes['TagV2']>>>, parent?: Maybe<ResolversParentTypes['TagV2']>, parents?: Maybe<Array<Maybe<ResolversParentTypes['TagV2']>>>, recommendedArticles: Array<ResolversParentTypes['DsContentModelResult']>, recommendedTags: Array<ResolversParentTypes['ChannelRecommenderResult']>, root?: Maybe<ResolversParentTypes['TagV2']> };
  TagV2Connection: Omit<TagV2Connection, 'edges'> & { edges: Array<ResolversParentTypes['TagV2Edge']> };
  TagV2Edge: Omit<TagV2Edge, 'node'> & { node: ResolversParentTypes['TagV2'] };
  Tagging: Tagging;
  TagsQueryInput: TagsQueryInput;
  TaxonomyReference: TaxonomyReference;
  TaxonomyReferenceGroup: TaxonomyReferenceGroup;
  TaxonomyTerm: TaxonomyTerm;
  Team: Team;
  TextPollInput: TextPollInput;
  TextPollOptionInput: TextPollOptionInput;
  TextPollWidgetInput: TextPollWidgetInput;
  Tournament: Tournament;
  Tournaments: Tournaments;
  TrendingChannelResult: Omit<TrendingChannelResult, 'tagV2'> & { tagV2: ResolversParentTypes['TagV2'] };
  TrendingResult: Omit<TrendingResult, 'contentModule'> & { contentModule?: Maybe<ResolversParentTypes['StandaloneContentModule']> };
  Tweet: Tweet;
  TweetAttachments: TweetAttachments;
  TweetData: TweetData;
  TweetEntities: TweetEntities;
  TweetHashtag: TweetHashtag;
  TweetMedia: TweetMedia;
  TweetMention: TweetMention;
  TweetMetrics: TweetMetrics;
  TweetReference: TweetReference;
  TweetUrl: TweetUrl;
  TweetVariant: TweetVariant;
  TwitterUser: TwitterUser;
  UGCImagePoll: Omit<UgcImagePoll, 'liveLikeImagePoll' | 'liveLikeUserVote'> & { liveLikeImagePoll?: Maybe<ResolversParentTypes['LiveLikeImagePoll']>, liveLikeUserVote?: Maybe<ResolversParentTypes['LiveLikeImagePollVote']> };
  UGCPost: UgcPost;
  UGCTextPoll: Omit<UgcTextPoll, 'liveLikeTextPoll' | 'liveLikeUserVote'> & { liveLikeTextPoll?: Maybe<ResolversParentTypes['LiveLikeTextPoll']>, liveLikeUserVote?: Maybe<ResolversParentTypes['LiveLikeTextPollVote']> };
  UGCWidget: UgcWidget;
  URL: Scalars['URL']['output'];
  UUID: Scalars['UUID']['output'];
  UpdatePostInput: UpdatePostInput;
  UpdateTextPollInput: UpdateTextPollInput;
  UrlMapping: UrlMapping;
  User: Omit<User, 'creatorTag' | 'favoriteTeams' | 'tags'> & { creatorTag?: Maybe<ResolversParentTypes['TagV2']>, favoriteTeams?: Maybe<Array<Maybe<ResolversParentTypes['TagV2']>>>, tags?: Maybe<Array<Maybe<ResolversParentTypes['TagV2']>>> };
  UserDestination: Omit<UserDestination, 'contentModule' | 'tag'> & { contentModule?: Maybe<ResolversParentTypes['StandaloneContentModule']>, tag: ResolversParentTypes['TagV2'] };
  UserSocialAlert: Omit<UserSocialAlert, 'userDestination'> & { userDestination?: Maybe<ResolversParentTypes['UserDestination']> };
  UserTagInput: UserTagInput;
  V2VResult: Omit<V2VResult, 'video'> & { video?: Maybe<ResolversParentTypes['StandaloneContentModule']> };
  Venue: Venue;
  Venues: Venues;
  Video: Video;
  VideoAnalytics: VideoAnalytics;
  VideoAppName: VideoAppName;
  VideoFiltersInput: VideoFiltersInput;
  VideoImpressionTracking: VideoImpressionTracking;
  VideoMetadata: VideoMetadata;
  VideoMetadataInput: VideoMetadataInput;
  VideoTitle: VideoTitle;
  VideoV2: Omit<VideoV2, 'recommendedVideos' | 'tags'> & { recommendedVideos: Array<ResolversParentTypes['V2VResult']>, tags?: Maybe<Array<Maybe<ResolversParentTypes['TagV2']>>> };
  VideoV2Metadata: VideoV2Metadata;
  VideoV2TagData: VideoV2TagData;
  VideoV2TagIds: VideoV2TagIds;
  WatchInfo: WatchInfo;
  blockProfileResponse: BlockProfileResponse;
}>;

export type A2AResultResolvers<ContextType = any, ParentType extends ResolversParentTypes['A2AResult'] = ResolversParentTypes['A2AResult']> = ResolversObject<{
  article?: Resolver<Maybe<ResolversTypes['StandaloneContentModule']>, ParentType, ContextType>;
  contentID?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  score?: Resolver<ResolversTypes['Float'], ParentType, ContextType>;
  type?: Resolver<ResolversTypes['ContentModuleType'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type A2VResultResolvers<ContextType = any, ParentType extends ResolversParentTypes['A2VResult'] = ResolversParentTypes['A2VResult']> = ResolversObject<{
  contentID?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  score?: Resolver<ResolversTypes['Float'], ParentType, ContextType>;
  type?: Resolver<ResolversTypes['ContentModuleType'], ParentType, ContextType>;
  video?: Resolver<Maybe<ResolversTypes['StandaloneContentModule']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type ActionResolvers<ContextType = any, ParentType extends ResolversParentTypes['Action'] = ResolversParentTypes['Action']> = ResolversObject<{
  download?: Resolver<Maybe<ResolversTypes['Allowed']>, ParentType, ContextType>;
  list?: Resolver<Maybe<ResolversTypes['Allowed']>, ParentType, ContextType>;
  play?: Resolver<Maybe<ResolversTypes['Allowed']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type AddAlertRankResponseResolvers<ContextType = any, ParentType extends ResolversParentTypes['AddAlertRankResponse'] = ResolversParentTypes['AddAlertRankResponse']> = ResolversObject<{
  message?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  status?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type AdsAdSizeResolvers<ContextType = any, ParentType extends ResolversParentTypes['AdsAdSize'] = ResolversParentTypes['AdsAdSize']> = ResolversObject<{
  height?: Resolver<Maybe<ResolversTypes['Int']>, ParentType, ContextType>;
  width?: Resolver<Maybe<ResolversTypes['Int']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type AdsChannelConfigurationResolvers<ContextType = any, ParentType extends ResolversParentTypes['AdsChannelConfiguration'] = ResolversParentTypes['AdsChannelConfiguration']> = ResolversObject<{
  adUnitPath?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  configuration?: Resolver<Maybe<ResolversTypes['AdsModuleConfiguration']>, ParentType, ContextType>;
  groupings?: Resolver<Maybe<Array<Maybe<ResolversTypes['AdsChannelGroupingConfiguration']>>>, ParentType, ContextType>;
  registry?: Resolver<ResolversTypes['AdsDeployedState'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type AdsChannelGroupingConfigurationResolvers<ContextType = any, ParentType extends ResolversParentTypes['AdsChannelGroupingConfiguration'] = ResolversParentTypes['AdsChannelGroupingConfiguration']> = ResolversObject<{
  adUnitPath?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  id?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  registry?: Resolver<ResolversTypes['AdsDeployedState'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type AdsConfigurationResolvers<ContextType = any, ParentType extends ResolversParentTypes['AdsConfiguration'] = ResolversParentTypes['AdsConfiguration']> = ResolversObject<{
  adUnitPath?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  configuration?: Resolver<Maybe<ResolversTypes['AdsModuleConfiguration']>, ParentType, ContextType>;
  registry?: Resolver<ResolversTypes['AdsDeployedState'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type AdsDeployedStateResolvers<ContextType = any, ParentType extends ResolversParentTypes['AdsDeployedState'] = ResolversParentTypes['AdsDeployedState']> = ResolversObject<{
  error?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  hasInViewRefresh?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  hasRealTimeAdInsertion?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  inViewRefreshCount?: Resolver<Maybe<ResolversTypes['Int']>, ParentType, ContextType>;
  inViewRefreshInterval?: Resolver<Maybe<ResolversTypes['Int']>, ParentType, ContextType>;
  isSingleton?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  name?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  rtaiBuffer?: Resolver<Maybe<ResolversTypes['Int']>, ParentType, ContextType>;
  rtaiInitialPlacement?: Resolver<Maybe<ResolversTypes['Int']>, ParentType, ContextType>;
  rtaiMaxNoOfAds?: Resolver<Maybe<ResolversTypes['Int']>, ParentType, ContextType>;
  rtaiOffset?: Resolver<Maybe<ResolversTypes['Int']>, ParentType, ContextType>;
  rtaiParentSelector?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  safeFrameAllowPushExpansion?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  safeFrameConfig?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  safeFrameOverlayExpansion?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  safeFrameSandboxMode?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  slots?: Resolver<Maybe<Array<Maybe<ResolversTypes['AdsSlot']>>>, ParentType, ContextType>;
  tagForChildDirectedTreatment?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  targetings?: Resolver<Maybe<Array<Maybe<ResolversTypes['AdsTargeting']>>>, ParentType, ContextType>;
  template?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type AdsHistoryResolvers<ContextType = any, ParentType extends ResolversParentTypes['AdsHistory'] = ResolversParentTypes['AdsHistory']> = ResolversObject<{
  area?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  modifiedBy?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  modifiedOn?: Resolver<Maybe<ResolversTypes['Float']>, ParentType, ContextType>;
  newValue?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  oldValue?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type AdsModuleConfigurationResolvers<ContextType = any, ParentType extends ResolversParentTypes['AdsModuleConfiguration'] = ResolversParentTypes['AdsModuleConfiguration']> = ResolversObject<{
  jsonBlob?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type AdsRegistryDetailItemResolvers<ContextType = any, ParentType extends ResolversParentTypes['AdsRegistryDetailItem'] = ResolversParentTypes['AdsRegistryDetailItem']> = ResolversObject<{
  adUnitPath?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  description?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  error?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  lastDeployedOn?: Resolver<Maybe<ResolversTypes['Date']>, ParentType, ContextType>;
  name?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  nameLowered?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  slots?: Resolver<Maybe<Array<Maybe<ResolversTypes['String']>>>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type AdsSlotResolvers<ContextType = any, ParentType extends ResolversParentTypes['AdsSlot'] = ResolversParentTypes['AdsSlot']> = ResolversObject<{
  adSizes?: Resolver<Maybe<Array<Maybe<ResolversTypes['AdsAdSize']>>>, ParentType, ContextType>;
  adUnitPath?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  hasInViewRefresh?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  inViewRefreshCount?: Resolver<Maybe<ResolversTypes['Int']>, ParentType, ContextType>;
  inViewRefreshInterval?: Resolver<Maybe<ResolversTypes['Int']>, ParentType, ContextType>;
  isFluid?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  isInheritAdUnitFromRegistry?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  isResponsive?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  name?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  safeFrameAllowOverlayExpansion?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  safeFrameAllowPushExpansion?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  safeFrameConfig?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  safeFrameSandboxMode?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  targetings?: Resolver<Maybe<Array<Maybe<ResolversTypes['AdsTargeting']>>>, ParentType, ContextType>;
  viewports?: Resolver<Maybe<Array<Maybe<ResolversTypes['AdsViewport']>>>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type AdsTargetingResolvers<ContextType = any, ParentType extends ResolversParentTypes['AdsTargeting'] = ResolversParentTypes['AdsTargeting']> = ResolversObject<{
  key?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  value?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type AdsViewportResolvers<ContextType = any, ParentType extends ResolversParentTypes['AdsViewport'] = ResolversParentTypes['AdsViewport']> = ResolversObject<{
  fluid?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  height?: Resolver<ResolversTypes['Int'], ParentType, ContextType>;
  name?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  sizes?: Resolver<Maybe<Array<Maybe<ResolversTypes['String']>>>, ParentType, ContextType>;
  width?: Resolver<ResolversTypes['Int'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type AlertAnalyticsResolvers<ContextType = any, ParentType extends ResolversParentTypes['AlertAnalytics'] = ResolversParentTypes['AlertAnalytics']> = ResolversObject<{
  gamecastType?: Resolver<Maybe<ResolversTypes['AlertGamecastType']>, ParentType, ContextType>;
  genres?: Resolver<Array<ResolversTypes['AlertGenre']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type AlertDestinationResolvers<ContextType = any, ParentType extends ResolversParentTypes['AlertDestination'] = ResolversParentTypes['AlertDestination']> = ResolversObject<{
  contentModuleId?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  tagUUID?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type AlertMediaAttachmentResolvers<ContextType = any, ParentType extends ResolversParentTypes['AlertMediaAttachment'] = ResolversParentTypes['AlertMediaAttachment']> = ResolversObject<{
  editId?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  height?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  mediaType?: Resolver<ResolversTypes['AlertMediaType'], ParentType, ContextType>;
  mediaUrl?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  width?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type AlertPreferenceResolvers<ContextType = any, ParentType extends ResolversParentTypes['AlertPreference'] = ResolversParentTypes['AlertPreference']> = ResolversObject<{
  enabled?: Resolver<ResolversTypes['Boolean'], ParentType, ContextType>;
  type?: Resolver<ResolversTypes['AlertTypes'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type AlertRankResolvers<ContextType = any, ParentType extends ResolversParentTypes['AlertRank'] = ResolversParentTypes['AlertRank']> = ResolversObject<{
  pushNotification?: Resolver<ResolversTypes['PushNotification'], ParentType, ContextType>;
  rank?: Resolver<ResolversTypes['Int'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type AllowAllResolvers<ContextType = any, ParentType extends ResolversParentTypes['AllowAll'] = ResolversParentTypes['AllowAll']> = ResolversObject<{
  allowAll?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type AllowedResolvers<ContextType = any, ParentType extends ResolversParentTypes['Allowed'] = ResolversParentTypes['Allowed']> = ResolversObject<{
  allowed?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type ArticleResolvers<ContextType = any, ParentType extends ResolversParentTypes['Article'] = ResolversParentTypes['Article']> = ResolversObject<{
  _id?: Resolver<ResolversTypes['MongoID'], ParentType, ContextType>;
  adsConfig?: Resolver<Maybe<ResolversTypes['AdsConfiguration']>, ParentType, ContextType>;
  ampUrl?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  author?: Resolver<Maybe<ResolversTypes['ArticleAuthor']>, ParentType, ContextType>;
  betTags?: Resolver<Maybe<Array<Maybe<ResolversTypes['TagV2']>>>, ParentType, ContextType>;
  changed?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  cmsId?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  containsGeoblockedContent?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  contentSubtype?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  contentType?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  created?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  createdAt?: Resolver<Maybe<ResolversTypes['Date']>, ParentType, ContextType>;
  description?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  displayId?: Resolver<Maybe<ResolversTypes['Int']>, ParentType, ContextType>;
  hash?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  hideBetModule?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  image?: Resolver<Maybe<ResolversTypes['Image']>, ParentType, ContextType>;
  isAdSensitive?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  isEvergreen?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  isPtScheduled?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  isPublished?: Resolver<ResolversTypes['Boolean'], ParentType, ContextType>;
  language?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  legacy?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  metatags?: Resolver<Maybe<Array<Maybe<ResolversTypes['PageMetatags']>>>, ParentType, ContextType>;
  primaryTag?: Resolver<ResolversTypes['TagV2'], ParentType, ContextType>;
  publishedDateTime?: Resolver<Maybe<ResolversTypes['Date']>, ParentType, ContextType>;
  recommendedArticles?: Resolver<Array<ResolversTypes['A2AResult']>, ParentType, ContextType, RequireFields<ArticleRecommendedArticlesArgs, 'limit' | 'version'>>;
  recommendedVideos?: Resolver<Array<ResolversTypes['A2VResult']>, ParentType, ContextType, RequireFields<ArticleRecommendedVideosArgs, 'aspectRatio' | 'limit' | 'version'>>;
  schemaVersion?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  slides?: Resolver<Maybe<Array<Maybe<ResolversTypes['Slide']>>>, ParentType, ContextType>;
  slug?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  statsBetOffers?: Resolver<Maybe<ResolversTypes['StatsBetOffer']>, ParentType, ContextType, Partial<ArticleStatsBetOffersArgs>>;
  tags?: Resolver<Maybe<Array<Maybe<ResolversTypes['TagV2']>>>, ParentType, ContextType>;
  tenant?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  title?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  trendingRank?: Resolver<Maybe<ResolversTypes['Int']>, ParentType, ContextType>;
  updatedAt?: Resolver<Maybe<ResolversTypes['Date']>, ParentType, ContextType>;
  uuid?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type ArticleAuthorResolvers<ContextType = any, ParentType extends ResolversParentTypes['ArticleAuthor'] = ResolversParentTypes['ArticleAuthor']> = ResolversObject<{
  id?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  name?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  photoUrl?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  socialMediaHandles?: Resolver<Maybe<Array<Maybe<ResolversTypes['SocialMediaHandle']>>>, ParentType, ContextType>;
  title?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type ArticleConnectionResolvers<ContextType = any, ParentType extends ResolversParentTypes['ArticleConnection'] = ResolversParentTypes['ArticleConnection']> = ResolversObject<{
  edges?: Resolver<Array<ResolversTypes['ArticleEdge']>, ParentType, ContextType>;
  pageInfo?: Resolver<ResolversTypes['PageInfo'], ParentType, ContextType>;
  totalFound?: Resolver<ResolversTypes['Int'], ParentType, ContextType>;
  totalReturned?: Resolver<ResolversTypes['Int'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type ArticleEdgeResolvers<ContextType = any, ParentType extends ResolversParentTypes['ArticleEdge'] = ResolversParentTypes['ArticleEdge']> = ResolversObject<{
  cursor?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  node?: Resolver<ResolversTypes['Article'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type AssetConnectionResolvers<ContextType = any, ParentType extends ResolversParentTypes['AssetConnection'] = ResolversParentTypes['AssetConnection']> = ResolversObject<{
  edges?: Resolver<Maybe<Array<Maybe<ResolversTypes['AssetEdge']>>>, ParentType, ContextType>;
  nodes?: Resolver<Maybe<Array<Maybe<ResolversTypes['SearchResult']>>>, ParentType, ContextType>;
  pageInfo?: Resolver<Maybe<ResolversTypes['PageInfo']>, ParentType, ContextType>;
  totalCount?: Resolver<Maybe<ResolversTypes['Int']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type AssetEdgeResolvers<ContextType = any, ParentType extends ResolversParentTypes['AssetEdge'] = ResolversParentTypes['AssetEdge']> = ResolversObject<{
  cursor?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  node?: Resolver<Maybe<ResolversTypes['SearchResult']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type AuthorResolvers<ContextType = any, ParentType extends ResolversParentTypes['Author'] = ResolversParentTypes['Author']> = ResolversObject<{
  name?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type AvatarResolvers<ContextType = any, ParentType extends ResolversParentTypes['Avatar'] = ResolversParentTypes['Avatar']> = ResolversObject<{
  file_name?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  url?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type BadgeResolvers<ContextType = any, ParentType extends ResolversParentTypes['Badge'] = ResolversParentTypes['Badge']> = ResolversObject<{
  badge_icon_url?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  description?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  id?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  mimetype?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  name?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type BadgeComponentResolvers<ContextType = any, ParentType extends ResolversParentTypes['BadgeComponent'] = ResolversParentTypes['BadgeComponent']> = ResolversObject<{
  awarded_at?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  badge?: Resolver<Maybe<ResolversTypes['Badge']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type BillingOrderResolvers<ContextType = any, ParentType extends ResolversParentTypes['BillingOrder'] = ResolversParentTypes['BillingOrder']> = ResolversObject<{
  scope?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  value?: Resolver<Maybe<ResolversTypes['Int']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type BlockedContentResolvers<ContextType = any, ParentType extends ResolversParentTypes['BlockedContent'] = ResolversParentTypes['BlockedContent']> = ResolversObject<{
  contentID?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  insertedAt?: Resolver<ResolversTypes['Date'], ParentType, ContextType>;
  type?: Resolver<ResolversTypes['ContentModuleType'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type BrandResolvers<ContextType = any, ParentType extends ResolversParentTypes['Brand'] = ResolversParentTypes['Brand']> = ResolversObject<{
  id?: Resolver<Maybe<ResolversTypes['Identifier']>, ParentType, ContextType>;
  primary?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type ChannelResolvers<ContextType = any, ParentType extends ResolversParentTypes['Channel'] = ResolversParentTypes['Channel']> = ResolversObject<{
  _id?: Resolver<ResolversTypes['MongoID'], ParentType, ContextType>;
  adsConfig?: Resolver<Maybe<ResolversTypes['AdsChannelConfiguration']>, ParentType, ContextType>;
  changed?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  cmsId?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  components?: Resolver<Array<Maybe<ResolversTypes['ChannelComponent']>>, ParentType, ContextType>;
  created?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  createdAt?: Resolver<Maybe<ResolversTypes['Date']>, ParentType, ContextType>;
  gameState?: Resolver<Maybe<ResolversTypes['GameState']>, ParentType, ContextType>;
  groupingList?: Resolver<Maybe<Array<Maybe<ResolversTypes['GroupingHeader']>>>, ParentType, ContextType>;
  groupings?: Resolver<Maybe<Array<Maybe<ResolversTypes['Grouping']>>>, ParentType, ContextType, Partial<ChannelGroupingsArgs>>;
  headline?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  isPublished?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  isTemplate?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  language?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  metatags?: Resolver<Maybe<Array<Maybe<ResolversTypes['PageMetatags']>>>, ParentType, ContextType>;
  pinnedContentModule?: Resolver<Maybe<ResolversTypes['ContentModule']>, ParentType, ContextType>;
  schemaVersion?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  tag?: Resolver<ResolversTypes['TagV2'], ParentType, ContextType>;
  tenant?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  title?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  type?: Resolver<Maybe<ResolversTypes['ChannelType']>, ParentType, ContextType>;
  updatedAt?: Resolver<Maybe<ResolversTypes['Date']>, ParentType, ContextType>;
  uuid?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type ChannelComponentResolvers<ContextType = any, ParentType extends ResolversParentTypes['ChannelComponent'] = ResolversParentTypes['ChannelComponent']> = ResolversObject<{
  chat?: Resolver<Maybe<ResolversTypes['ChatModule']>, ParentType, ContextType>;
  contents?: Resolver<Maybe<Array<Maybe<ResolversTypes['ContentModule']>>>, ParentType, ContextType, RequireFields<ChannelComponentContentsArgs, 'limit' | 'state'>>;
  contentsConnection?: Resolver<Maybe<ResolversTypes['ContentsConnection']>, ParentType, ContextType, RequireFields<ChannelComponentContentsConnectionArgs, 'state'>>;
  dataServicesTagData?: Resolver<Array<ResolversTypes['TagV2']>, ParentType, ContextType, RequireFields<ChannelComponentDataServicesTagDataArgs, 'limit'>>;
  description?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  headline?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  images?: Resolver<Maybe<Array<Maybe<ResolversTypes['ImageWithStyle']>>>, ParentType, ContextType>;
  interlacingInterval?: Resolver<Maybe<ResolversTypes['Int']>, ParentType, ContextType>;
  isDomesticOnly?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  link?: Resolver<Maybe<ResolversTypes['Link']>, ParentType, ContextType>;
  semanticID?: Resolver<Maybe<ResolversTypes['SemanticID']>, ParentType, ContextType>;
  semanticType?: Resolver<Maybe<ResolversTypes['SemanticType']>, ParentType, ContextType>;
  statsGamecast?: Resolver<Maybe<ResolversTypes['StatsGamecast']>, ParentType, ContextType>;
  statsSchedule?: Resolver<Maybe<ResolversTypes['StatsSchedule']>, ParentType, ContextType, Partial<ChannelComponentStatsScheduleArgs>>;
  statsScores?: Resolver<Maybe<ResolversTypes['Scores']>, ParentType, ContextType, Partial<ChannelComponentStatsScoresArgs>>;
  statsStandings?: Resolver<Maybe<ResolversTypes['StatsStanding']>, ParentType, ContextType, Partial<ChannelComponentStatsStandingsArgs>>;
  subheadline?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  tagData?: Resolver<Maybe<Array<Maybe<ResolversTypes['TagV2']>>>, ParentType, ContextType>;
  tagSlug?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  tagType?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  tagUUID?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  userAlerts?: Resolver<Maybe<Array<ResolversTypes['PushNotification']>>, ParentType, ContextType, RequireFields<ChannelComponentUserAlertsArgs, 'limit' | 'tenant'>>;
  userContents?: Resolver<Maybe<Array<Maybe<ResolversTypes['StandaloneContentModule']>>>, ParentType, ContextType, Partial<ChannelComponentUserContentsArgs>>;
  userInfo?: Resolver<Maybe<ResolversTypes['User']>, ParentType, ContextType, RequireFields<ChannelComponentUserInfoArgs, 'tenant'>>;
  userSocialAlerts?: Resolver<Maybe<Array<ResolversTypes['UserSocialAlert']>>, ParentType, ContextType, RequireFields<ChannelComponentUserSocialAlertsArgs, 'tenant'>>;
  userTags?: Resolver<Maybe<Array<Maybe<ResolversTypes['TagV2']>>>, ParentType, ContextType, RequireFields<ChannelComponentUserTagsArgs, 'tenant'>>;
  uuid?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  watchInfo?: Resolver<Maybe<Array<Maybe<ResolversTypes['WatchInfo']>>>, ParentType, ContextType, Partial<ChannelComponentWatchInfoArgs>>;
  weight?: Resolver<Maybe<ResolversTypes['Int']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type ChannelRecommenderResultResolvers<ContextType = any, ParentType extends ResolversParentTypes['ChannelRecommenderResult'] = ResolversParentTypes['ChannelRecommenderResult']> = ResolversObject<{
  score?: Resolver<ResolversTypes['Float'], ParentType, ContextType>;
  tagV2?: Resolver<ResolversTypes['TagV2'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type ChannelStreamMetaDataResolvers<ContextType = any, ParentType extends ResolversParentTypes['ChannelStreamMetaData'] = ResolversParentTypes['ChannelStreamMetaData']> = ResolversObject<{
  _id?: Resolver<Maybe<ResolversTypes['MongoID']>, ParentType, ContextType>;
  contents?: Resolver<Maybe<Array<Maybe<ResolversTypes['ContentModule']>>>, ParentType, ContextType, RequireFields<ChannelStreamMetaDataContentsArgs, 'state'>>;
  id?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  semanticID?: Resolver<Maybe<ResolversTypes['SemanticID']>, ParentType, ContextType>;
  tagUUID?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  weight?: Resolver<Maybe<ResolversTypes['Float']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type ChatModuleResolvers<ContextType = any, ParentType extends ResolversParentTypes['ChatModule'] = ResolversParentTypes['ChatModule']> = ResolversObject<{
  chatroom?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type ClockResolvers<ContextType = any, ParentType extends ResolversParentTypes['Clock'] = ResolversParentTypes['Clock']> = ResolversObject<{
  hours?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  milliseconds?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  minutes?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  seconds?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  stoppage?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type CompetitorResolvers<ContextType = any, ParentType extends ResolversParentTypes['Competitor'] = ResolversParentTypes['Competitor']> = ResolversObject<{
  description?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  display_name_1?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  display_name_2?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  draws?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  hash?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  header_image_bucket?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  id?: Resolver<Maybe<ResolversTypes['ID']>, ParentType, ContextType>;
  league?: Resolver<Maybe<ResolversTypes['League']>, ParentType, ContextType>;
  leagues?: Resolver<Maybe<Array<Maybe<ResolversTypes['League']>>>, ParentType, ContextType, Partial<CompetitorLeaguesArgs>>;
  logo_dark?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  logo_light?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  logo_split?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  losses?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  market?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  name?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  overtime_losses?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  rank?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  sport?: Resolver<Maybe<ResolversTypes['Sport']>, ParentType, ContextType>;
  sportradar_id?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  team_abbr?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  team_alias?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  tournaments?: Resolver<Maybe<Array<Maybe<ResolversTypes['Tournament']>>>, ParentType, ContextType, Partial<CompetitorTournamentsArgs>>;
  wins?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type CompetitorsResolvers<ContextType = any, ParentType extends ResolversParentTypes['Competitors'] = ResolversParentTypes['Competitors']> = ResolversObject<{
  competitors?: Resolver<Maybe<Array<Maybe<ResolversTypes['Competitor']>>>, ParentType, ContextType>;
  index_end?: Resolver<Maybe<ResolversTypes['Int']>, ParentType, ContextType>;
  index_start?: Resolver<Maybe<ResolversTypes['Int']>, ParentType, ContextType>;
  total?: Resolver<Maybe<ResolversTypes['Int']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type ComponentResolvers<ContextType = any, ParentType extends ResolversParentTypes['Component'] = ResolversParentTypes['Component']> = ResolversObject<{
  _id?: Resolver<Maybe<ResolversTypes['MongoID']>, ParentType, ContextType>;
  content?: Resolver<Maybe<Array<Maybe<ResolversTypes['Content']>>>, ParentType, ContextType>;
  description?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  endTime?: Resolver<Maybe<ResolversTypes['Date']>, ParentType, ContextType>;
  format?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  headline?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  id?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  image?: Resolver<Maybe<ResolversTypes['Image']>, ParentType, ContextType>;
  images?: Resolver<Maybe<Array<Maybe<ResolversTypes['ImageWithStyle']>>>, ParentType, ContextType>;
  isFavoriteTeam?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  link?: Resolver<Maybe<ResolversTypes['Link']>, ParentType, ContextType>;
  orientation?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  referenceStream?: Resolver<Maybe<ResolversTypes['ReferenceStream']>, ParentType, ContextType>;
  startTime?: Resolver<Maybe<ResolversTypes['Date']>, ParentType, ContextType>;
  subheadline?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  type?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  uuid?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  weight?: Resolver<Maybe<ResolversTypes['Float']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export interface ComponentCursorScalarConfig extends GraphQLScalarTypeConfig<ResolversTypes['ComponentCursor'], any> {
  name: 'ComponentCursor';
}

export type ComponentEdgeResolvers<ContextType = any, ParentType extends ResolversParentTypes['ComponentEdge'] = ResolversParentTypes['ComponentEdge']> = ResolversObject<{
  cursor?: Resolver<ResolversTypes['ComponentCursor'], ParentType, ContextType>;
  node?: Resolver<ResolversTypes['Component'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type ComponentModuleResolvers<ContextType = any, ParentType extends ResolversParentTypes['ComponentModule'] = ResolversParentTypes['ComponentModule']> = ResolversObject<{
  hash?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  insertedAt?: Resolver<Maybe<ResolversTypes['Date']>, ParentType, ContextType>;
  isPinned?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  isPositionLocked?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  position?: Resolver<ResolversTypes['Int'], ParentType, ContextType>;
  positionLockExpiresAt?: Resolver<Maybe<ResolversTypes['Date']>, ParentType, ContextType>;
  semanticID?: Resolver<Maybe<ResolversTypes['SemanticID']>, ParentType, ContextType>;
  tag?: Resolver<Maybe<ResolversTypes['TagV2']>, ParentType, ContextType, RequireFields<ComponentModuleTagArgs, 'tenant'>>;
  widgets?: Resolver<Maybe<Array<Maybe<ResolversTypes['UGCWidget']>>>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type ComponentsConnectionResolvers<ContextType = any, ParentType extends ResolversParentTypes['ComponentsConnection'] = ResolversParentTypes['ComponentsConnection']> = ResolversObject<{
  edges?: Resolver<Array<ResolversTypes['ComponentEdge']>, ParentType, ContextType>;
  pageInfo?: Resolver<ResolversTypes['PageInfo'], ParentType, ContextType>;
  totalCount?: Resolver<ResolversTypes['Int'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type ConferenceResolvers<ContextType = any, ParentType extends ResolversParentTypes['Conference'] = ResolversParentTypes['Conference']> = ResolversObject<{
  divisions?: Resolver<Maybe<Array<Maybe<ResolversTypes['Division']>>>, ParentType, ContextType, Partial<ConferenceDivisionsArgs>>;
  id?: Resolver<Maybe<ResolversTypes['ID']>, ParentType, ContextType>;
  league?: Resolver<Maybe<ResolversTypes['League']>, ParentType, ContextType>;
  name?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  sport?: Resolver<Maybe<ResolversTypes['Sport']>, ParentType, ContextType>;
  sportradar_id?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  teams?: Resolver<Maybe<Array<Maybe<ResolversTypes['Competitor']>>>, ParentType, ContextType, Partial<ConferenceTeamsArgs>>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type ConferencesResolvers<ContextType = any, ParentType extends ResolversParentTypes['Conferences'] = ResolversParentTypes['Conferences']> = ResolversObject<{
  conferences?: Resolver<Maybe<Array<Maybe<ResolversTypes['Conference']>>>, ParentType, ContextType>;
  index_end?: Resolver<Maybe<ResolversTypes['Int']>, ParentType, ContextType>;
  index_start?: Resolver<Maybe<ResolversTypes['Int']>, ParentType, ContextType>;
  total?: Resolver<Maybe<ResolversTypes['Int']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type ConfigJsonResolvers<ContextType = any, ParentType extends ResolversParentTypes['ConfigJson'] = ResolversParentTypes['ConfigJson']> = ResolversObject<{
  _id?: Resolver<ResolversTypes['MongoID'], ParentType, ContextType>;
  changed?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  cmsId?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  created?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  isPublished?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  jsonBlob?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  language?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  schemaVersion?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  tenant?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  title?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  uri?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  uuid?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type ContentResolvers<ContextType = any, ParentType extends ResolversParentTypes['Content'] = ResolversParentTypes['Content']> = ResolversObject<{
  _id?: Resolver<Maybe<ResolversTypes['MongoID']>, ParentType, ContextType>;
  allowedTypes?: Resolver<Maybe<Array<Maybe<ResolversTypes['String']>>>, ParentType, ContextType>;
  channelStream?: Resolver<Maybe<ResolversTypes['ChannelStreamMetaData']>, ParentType, ContextType>;
  clip?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  clips?: Resolver<Maybe<Array<Maybe<ResolversTypes['Video']>>>, ParentType, ContextType>;
  contentModules?: Resolver<Maybe<Array<Maybe<ResolversTypes['ContentModule']>>>, ParentType, ContextType>;
  episodes?: Resolver<Maybe<Array<Maybe<ResolversTypes['Show']>>>, ParentType, ContextType>;
  event?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  events?: Resolver<Maybe<Array<Maybe<ResolversTypes['Event']>>>, ParentType, ContextType>;
  filters?: Resolver<Maybe<ResolversTypes['ContentFilters']>, ParentType, ContextType>;
  form?: Resolver<Maybe<ResolversTypes['ContentForm']>, ParentType, ContextType>;
  hash?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  image?: Resolver<Maybe<ResolversTypes['Image']>, ParentType, ContextType>;
  item?: Resolver<Maybe<ResolversTypes['Item']>, ParentType, ContextType>;
  league?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  liveStream?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  product?: Resolver<Maybe<Array<Maybe<ResolversTypes['Product']>>>, ParentType, ContextType>;
  series?: Resolver<Maybe<Array<Maybe<ResolversTypes['Series']>>>, ParentType, ContextType>;
  show?: Resolver<Maybe<ResolversTypes['ContentShow']>, ParentType, ContextType>;
  sort?: Resolver<Maybe<ResolversTypes['ContentSort']>, ParentType, ContextType>;
  stream?: Resolver<Maybe<ResolversTypes['StreamMetaData']>, ParentType, ContextType>;
  team?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  teams?: Resolver<Maybe<Array<Maybe<ResolversTypes['Competitor']>>>, ParentType, ContextType>;
  tournament?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  tournaments?: Resolver<Maybe<Array<Maybe<ResolversTypes['Tournament']>>>, ParentType, ContextType>;
  weight?: Resolver<Maybe<ResolversTypes['Float']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type ContentBrandResolvers<ContextType = any, ParentType extends ResolversParentTypes['ContentBrand'] = ResolversParentTypes['ContentBrand']> = ResolversObject<{
  brandSourceUrls?: Resolver<Maybe<Array<Maybe<ResolversTypes['String']>>>, ParentType, ContextType>;
  cmsId?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  isDeleted?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  isPartner?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  isPublished?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  language?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  logos?: Resolver<Maybe<Array<Maybe<ResolversTypes['ImageWithStyle']>>>, ParentType, ContextType>;
  name?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  source?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  tenant?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  uuid?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export interface ContentCursorScalarConfig extends GraphQLScalarTypeConfig<ResolversTypes['ContentCursor'], any> {
  name: 'ContentCursor';
}

export type ContentEdgeResolvers<ContextType = any, ParentType extends ResolversParentTypes['ContentEdge'] = ResolversParentTypes['ContentEdge']> = ResolversObject<{
  cursor?: Resolver<ResolversTypes['ContentCursor'], ParentType, ContextType>;
  node?: Resolver<ResolversTypes['ContentModule'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type ContentFiltersResolvers<ContextType = any, ParentType extends ResolversParentTypes['ContentFilters'] = ResolversParentTypes['ContentFilters']> = ResolversObject<{
  _id?: Resolver<Maybe<ResolversTypes['MongoID']>, ParentType, ContextType>;
  collections?: Resolver<Maybe<Array<Maybe<ResolversTypes['String']>>>, ParentType, ContextType>;
  isFavoriteTeam?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  maxItems?: Resolver<Maybe<ResolversTypes['Float']>, ParentType, ContextType>;
  shows?: Resolver<Maybe<Array<Maybe<ResolversTypes['String']>>>, ParentType, ContextType>;
  status?: Resolver<Maybe<Array<Maybe<ResolversTypes['String']>>>, ParentType, ContextType>;
  tags?: Resolver<Maybe<Array<Maybe<ResolversTypes['String']>>>, ParentType, ContextType>;
  timeWindow?: Resolver<Maybe<Array<Maybe<ResolversTypes['Float']>>>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type ContentFormResolvers<ContextType = any, ParentType extends ResolversParentTypes['ContentForm'] = ResolversParentTypes['ContentForm']> = ResolversObject<{
  element?: Resolver<Maybe<ResolversTypes['FormElement']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type ContentLibrarySearchResultResolvers<ContextType = any, ParentType extends ResolversParentTypes['ContentLibrarySearchResult'] = ResolversParentTypes['ContentLibrarySearchResult']> = ResolversObject<{
  __resolveType: TypeResolveFn<'Article' | 'Tweet' | 'VideoV2', ParentType, ContextType>;
}>;

export type ContentMetadataResolvers<ContextType = any, ParentType extends ResolversParentTypes['ContentMetadata'] = ResolversParentTypes['ContentMetadata']> = ResolversObject<{
  video?: Resolver<Maybe<ResolversTypes['VideoV2Metadata']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type ContentModuleResolvers<ContextType = any, ParentType extends ResolversParentTypes['ContentModule'] = ResolversParentTypes['ContentModule']> = ResolversObject<{
  __resolveType: TypeResolveFn<'PackageContentModule' | 'StandaloneContentModule', ParentType, ContextType>;
  alertedChannelTagUUID?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  allowedCountries?: Resolver<Maybe<Array<Maybe<ResolversTypes['String']>>>, ParentType, ContextType>;
  commentsEnabled?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  components?: Resolver<Maybe<Array<Maybe<ResolversTypes['ComponentModule']>>>, ParentType, ContextType>;
  description?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  expiresAt?: Resolver<Maybe<ResolversTypes['Date']>, ParentType, ContextType>;
  hidden?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  hiddenExpiresAt?: Resolver<Maybe<ResolversTypes['Date']>, ParentType, ContextType>;
  id?: Resolver<ResolversTypes['ID'], ParentType, ContextType>;
  insertedAt?: Resolver<Maybe<ResolversTypes['Date']>, ParentType, ContextType>;
  isAlerted?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  metaData?: Resolver<Maybe<ResolversTypes['ModuleMetaData']>, ParentType, ContextType>;
  scheduledDate?: Resolver<Maybe<ResolversTypes['Date']>, ParentType, ContextType>;
  state?: Resolver<Maybe<ResolversTypes['ModuleState']>, ParentType, ContextType>;
  title?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  updatedAt?: Resolver<Maybe<ResolversTypes['Date']>, ParentType, ContextType>;
}>;

export type ContentShowResolvers<ContextType = any, ParentType extends ResolversParentTypes['ContentShow'] = ResolversParentTypes['ContentShow']> = ResolversObject<{
  _id?: Resolver<Maybe<ResolversTypes['MongoID']>, ParentType, ContextType>;
  id?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  image?: Resolver<Maybe<ResolversTypes['Image']>, ParentType, ContextType>;
  title?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  weight?: Resolver<Maybe<ResolversTypes['Float']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type ContentSortResolvers<ContextType = any, ParentType extends ResolversParentTypes['ContentSort'] = ResolversParentTypes['ContentSort']> = ResolversObject<{
  field?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  order?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type ContentsConnectionResolvers<ContextType = any, ParentType extends ResolversParentTypes['ContentsConnection'] = ResolversParentTypes['ContentsConnection']> = ResolversObject<{
  edges?: Resolver<Array<ResolversTypes['ContentEdge']>, ParentType, ContextType>;
  pageInfo?: Resolver<ResolversTypes['PageInfo'], ParentType, ContextType>;
  totalCount?: Resolver<ResolversTypes['Int'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export interface ContextFieldValueScalarConfig extends GraphQLScalarTypeConfig<ResolversTypes['ContextFieldValue'], any> {
  name: 'ContextFieldValue';
}

export type CreatePollResponseResolvers<ContextType = any, ParentType extends ResolversParentTypes['CreatePollResponse'] = ResolversParentTypes['CreatePollResponse']> = ResolversObject<{
  created?: Resolver<ResolversTypes['Boolean'], ParentType, ContextType>;
  errorMsg?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  poll?: Resolver<Maybe<ResolversTypes['Poll']>, ParentType, ContextType>;
  status?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type CreatePostResponseResolvers<ContextType = any, ParentType extends ResolversParentTypes['CreatePostResponse'] = ResolversParentTypes['CreatePostResponse']> = ResolversObject<{
  created?: Resolver<ResolversTypes['Boolean'], ParentType, ContextType>;
  errorMsg?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  post?: Resolver<Maybe<ResolversTypes['Post']>, ParentType, ContextType>;
  status?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type CreateProgramResponseResolvers<ContextType = any, ParentType extends ResolversParentTypes['CreateProgramResponse'] = ResolversParentTypes['CreateProgramResponse']> = ResolversObject<{
  created?: Resolver<ResolversTypes['Boolean'], ParentType, ContextType>;
  errorMsg?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  program?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type CreditResolvers<ContextType = any, ParentType extends ResolversParentTypes['Credit'] = ResolversParentTypes['Credit']> = ResolversObject<{
  billingOrders?: Resolver<Maybe<Array<Maybe<ResolversTypes['BillingOrder']>>>, ParentType, ContextType>;
  id?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  personId?: Resolver<Maybe<ResolversTypes['ID']>, ParentType, ContextType>;
  role?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type CustomLiveLikeUserReactionResolvers<ContextType = any, ParentType extends ResolversParentTypes['CustomLiveLikeUserReaction'] = ResolversParentTypes['CustomLiveLikeUserReaction']> = ResolversObject<{
  clientId?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  createdAt?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  customData?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  id?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  reactedById?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  reactionId?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  reactionSpaceId?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  targetId?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export interface DateScalarConfig extends GraphQLScalarTypeConfig<ResolversTypes['Date'], any> {
  name: 'Date';
}

export interface DateTimeScalarConfig extends GraphQLScalarTypeConfig<ResolversTypes['DateTime'], any> {
  name: 'DateTime';
}

export interface DateTimeIsoScalarConfig extends GraphQLScalarTypeConfig<ResolversTypes['DateTimeISO'], any> {
  name: 'DateTimeISO';
}

export type DeleteVideoContentModulesResultResolvers<ContextType = any, ParentType extends ResolversParentTypes['DeleteVideoContentModulesResult'] = ResolversParentTypes['DeleteVideoContentModulesResult']> = ResolversObject<{
  contentId?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  deletedCount?: Resolver<ResolversTypes['Int'], ParentType, ContextType>;
  deletedModuleIds?: Resolver<Array<ResolversTypes['String']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type DeviceResolvers<ContextType = any, ParentType extends ResolversParentTypes['Device'] = ResolversParentTypes['Device']> = ResolversObject<{
  appVersion?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  id?: Resolver<ResolversTypes['Int'], ParentType, ContextType>;
  osVersion?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  token?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  type?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type DivisionResolvers<ContextType = any, ParentType extends ResolversParentTypes['Division'] = ResolversParentTypes['Division']> = ResolversObject<{
  conference?: Resolver<Maybe<ResolversTypes['Conference']>, ParentType, ContextType>;
  division_alias?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  id?: Resolver<Maybe<ResolversTypes['ID']>, ParentType, ContextType>;
  league?: Resolver<Maybe<ResolversTypes['League']>, ParentType, ContextType>;
  name?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  sport?: Resolver<Maybe<ResolversTypes['Sport']>, ParentType, ContextType>;
  sportradar_id?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  teams?: Resolver<Maybe<Array<Maybe<ResolversTypes['Competitor']>>>, ParentType, ContextType, Partial<DivisionTeamsArgs>>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type DivisionsResolvers<ContextType = any, ParentType extends ResolversParentTypes['Divisions'] = ResolversParentTypes['Divisions']> = ResolversObject<{
  divisions?: Resolver<Maybe<Array<Maybe<ResolversTypes['Division']>>>, ParentType, ContextType>;
  index_end?: Resolver<Maybe<ResolversTypes['Int']>, ParentType, ContextType>;
  index_start?: Resolver<Maybe<ResolversTypes['Int']>, ParentType, ContextType>;
  total?: Resolver<Maybe<ResolversTypes['Int']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type DsContentModelResultResolvers<ContextType = any, ParentType extends ResolversParentTypes['DsContentModelResult'] = ResolversParentTypes['DsContentModelResult']> = ResolversObject<{
  __resolveType: TypeResolveFn<'A2AResult' | 'A2VResult' | 'TrendingResult' | 'V2VResult', ParentType, ContextType>;
  contentID?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  type?: Resolver<ResolversTypes['ContentModuleType'], ParentType, ContextType>;
}>;

export type DsModelResolvers<ContextType = any, ParentType extends ResolversParentTypes['DsModel'] = ResolversParentTypes['DsModel']> = ResolversObject<{
  defaultVersion?: Resolver<ResolversTypes['Int'], ParentType, ContextType>;
  name?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export interface DurationScalarConfig extends GraphQLScalarTypeConfig<ResolversTypes['Duration'], any> {
  name: 'Duration';
}

export type ElementResolvers<ContextType = any, ParentType extends ResolversParentTypes['Element'] = ResolversParentTypes['Element']> = ResolversObject<{
  content?: Resolver<Maybe<ResolversTypes['ElementContent']>, ParentType, ContextType>;
  contentType?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  order?: Resolver<Maybe<ResolversTypes['Int']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type ElementContentResolvers<ContextType = any, ParentType extends ResolversParentTypes['ElementContent'] = ResolversParentTypes['ElementContent']> = ResolversObject<{
  html?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  image?: Resolver<Maybe<ResolversTypes['Image']>, ParentType, ContextType>;
  media?: Resolver<Maybe<ResolversTypes['VideoV2']>, ParentType, ContextType>;
  url?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  wordCount?: Resolver<Maybe<ResolversTypes['Float']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type EventResolvers<ContextType = any, ParentType extends ResolversParentTypes['Event'] = ResolversParentTypes['Event']> = ResolversObject<{
  away?: Resolver<Maybe<ResolversTypes['Competitor']>, ParentType, ContextType>;
  away_team_points?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  card_type?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  color_1?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  color_2?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  derived_status?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  event_image?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  event_image_bucket?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  free_event?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  free_preview?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  game?: Resolver<Maybe<ResolversTypes['Game']>, ParentType, ContextType>;
  has_media?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  hash?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  header_image_bucket?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  hidden?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  home?: Resolver<Maybe<ResolversTypes['Competitor']>, ParentType, ContextType>;
  home_team_points?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  id?: Resolver<Maybe<ResolversTypes['ID']>, ParentType, ContextType>;
  is_live?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  league?: Resolver<Maybe<ResolversTypes['League']>, ParentType, ContextType>;
  logo_dark?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  logo_light?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  media_asset_id_live?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  media_asset_id_vod?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  medium_vod?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  period?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  recommended?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  scheduled_utc?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  season?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  season_type?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  series_id?: Resolver<Maybe<ResolversTypes['Int']>, ParentType, ContextType>;
  series_name?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  sponsor_text?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  sport?: Resolver<Maybe<ResolversTypes['Sport']>, ParentType, ContextType>;
  sportradar_id?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  status?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  territories_available?: Resolver<Maybe<Array<Maybe<ResolversTypes['Territories']>>>, ParentType, ContextType>;
  time_zone?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  title?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  tournament?: Resolver<Maybe<ResolversTypes['Tournament']>, ParentType, ContextType>;
  trending?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  type?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  updated_at?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  venue?: Resolver<Maybe<ResolversTypes['Venue']>, ParentType, ContextType>;
  week?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type EventsResolvers<ContextType = any, ParentType extends ResolversParentTypes['Events'] = ResolversParentTypes['Events']> = ResolversObject<{
  events?: Resolver<Maybe<Array<Maybe<ResolversTypes['Event']>>>, ParentType, ContextType>;
  index_end?: Resolver<Maybe<ResolversTypes['Int']>, ParentType, ContextType>;
  index_start?: Resolver<Maybe<ResolversTypes['Int']>, ParentType, ContextType>;
  total?: Resolver<Maybe<ResolversTypes['Int']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type ExternalArticleResolvers<ContextType = any, ParentType extends ResolversParentTypes['ExternalArticle'] = ResolversParentTypes['ExternalArticle']> = ResolversObject<{
  brand?: Resolver<Maybe<ResolversTypes['ContentBrand']>, ParentType, ContextType, RequireFields<ExternalArticleBrandArgs, 'tenant'>>;
  created?: Resolver<ResolversTypes['Date'], ParentType, ContextType>;
  id?: Resolver<ResolversTypes['ID'], ParentType, ContextType>;
  providerName?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  source?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  url?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type FacetResponseResolvers<ContextType = any, ParentType extends ResolversParentTypes['FacetResponse'] = ResolversParentTypes['FacetResponse']> = ResolversObject<{
  facetResults?: Resolver<Maybe<Array<ResolversTypes['FacetResult']>>, ParentType, ContextType>;
  field?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type FacetResultResolvers<ContextType = any, ParentType extends ResolversParentTypes['FacetResult'] = ResolversParentTypes['FacetResult']> = ResolversObject<{
  count?: Resolver<ResolversTypes['Int'], ParentType, ContextType>;
  value?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type FeedResolvers<ContextType = any, ParentType extends ResolversParentTypes['Feed'] = ResolversParentTypes['Feed']> = ResolversObject<{
  code?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  description?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  link?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  logo?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  shows?: Resolver<Maybe<Array<Maybe<ResolversTypes['Show']>>>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type FollowingMetadataResolvers<ContextType = any, ParentType extends ResolversParentTypes['FollowingMetadata'] = ResolversParentTypes['FollowingMetadata']> = ResolversObject<{
  categoryLogo?: Resolver<Maybe<ResolversTypes['Image']>, ParentType, ContextType>;
  chipLabel?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  primaryLabel?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  secondaryLabel?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  uuid?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  weight?: Resolver<Maybe<ResolversTypes['Float']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type FormElementResolvers<ContextType = any, ParentType extends ResolversParentTypes['FormElement'] = ResolversParentTypes['FormElement']> = ResolversObject<{
  _id?: Resolver<Maybe<ResolversTypes['MongoID']>, ParentType, ContextType>;
  headline?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  options?: Resolver<Maybe<ResolversTypes['JSON']>, ParentType, ContextType>;
  type?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  weight?: Resolver<Maybe<ResolversTypes['Float']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type GameResolvers<ContextType = any, ParentType extends ResolversParentTypes['Game'] = ResolversParentTypes['Game']> = ResolversObject<{
  away?: Resolver<Maybe<ResolversTypes['Team']>, ParentType, ContextType>;
  gameDate?: Resolver<Maybe<ResolversTypes['GameDate']>, ParentType, ContextType>;
  gameProgress?: Resolver<Maybe<ResolversTypes['GameProgress']>, ParentType, ContextType>;
  home?: Resolver<Maybe<ResolversTypes['Team']>, ParentType, ContextType>;
  id?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  name?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  score?: Resolver<Maybe<ResolversTypes['Score']>, ParentType, ContextType>;
  sourceGameId?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  sport?: Resolver<Maybe<ResolversTypes['SportMetaData']>, ParentType, ContextType>;
  sportradar_id?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  stateStatus?: Resolver<Maybe<ResolversTypes['StateStatus']>, ParentType, ContextType>;
  status?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  weekId?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type GameDateResolvers<ContextType = any, ParentType extends ResolversParentTypes['GameDate'] = ResolversParentTypes['GameDate']> = ResolversObject<{
  epoch?: Resolver<Maybe<ResolversTypes['Int']>, ParentType, ContextType>;
  iso8501?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type GameGroupResolvers<ContextType = any, ParentType extends ResolversParentTypes['GameGroup'] = ResolversParentTypes['GameGroup']> = ResolversObject<{
  current?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  events?: Resolver<Maybe<Array<Maybe<ResolversTypes['ScoresEvent']>>>, ParentType, ContextType>;
  games?: Resolver<Maybe<Array<Maybe<ResolversTypes['ScoresGame']>>>, ParentType, ContextType>;
  name?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type GameProgressResolvers<ContextType = any, ParentType extends ResolversParentTypes['GameProgress'] = ResolversParentTypes['GameProgress']> = ResolversObject<{
  clock?: Resolver<Maybe<ResolversTypes['Clock']>, ParentType, ContextType>;
  currentPeriod?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  displayPrimary?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  displaySecondary?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  totalPeriods?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type GamecastAnalyticsResolvers<ContextType = any, ParentType extends ResolversParentTypes['GamecastAnalytics'] = ResolversParentTypes['GamecastAnalytics']> = ResolversObject<{
  awayTeamTag?: Resolver<Maybe<ResolversTypes['Tag']>, ParentType, ContextType>;
  coverageType?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  gamePeriod?: Resolver<Maybe<ResolversTypes['Int']>, ParentType, ContextType>;
  gamePermalinkTag?: Resolver<Maybe<ResolversTypes['Tag']>, ParentType, ContextType>;
  gameStart?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  headlineTitle?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  headlineTitleAbbreviated?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  homeTeamTag?: Resolver<Maybe<ResolversTypes['Tag']>, ParentType, ContextType>;
  seasonType?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  tournamentName?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type GamecastMetadataResolvers<ContextType = any, ParentType extends ResolversParentTypes['GamecastMetadata'] = ResolversParentTypes['GamecastMetadata']> = ResolversObject<{
  analytics?: Resolver<Maybe<ResolversTypes['GamecastAnalytics']>, ParentType, ContextType>;
  gamePermalink?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  scoreBoard?: Resolver<Maybe<ResolversTypes['GamecastScoreboard']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type GamecastProgressResolvers<ContextType = any, ParentType extends ResolversParentTypes['GamecastProgress'] = ResolversParentTypes['GamecastProgress']> = ResolversObject<{
  footer?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  header?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  primary?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type GamecastScoreboardResolvers<ContextType = any, ParentType extends ResolversParentTypes['GamecastScoreboard'] = ResolversParentTypes['GamecastScoreboard']> = ResolversObject<{
  gameDate?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  id?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  league?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  progress?: Resolver<Maybe<ResolversTypes['GamecastProgress']>, ParentType, ContextType>;
  sport?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  status?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  teamOne?: Resolver<Maybe<ResolversTypes['GamecastTeam']>, ParentType, ContextType>;
  teamTwo?: Resolver<Maybe<ResolversTypes['GamecastTeam']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type GamecastTeamResolvers<ContextType = any, ParentType extends ResolversParentTypes['GamecastTeam'] = ResolversParentTypes['GamecastTeam']> = ResolversObject<{
  abbrev?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  hasPossession?: Resolver<ResolversTypes['Boolean'], ParentType, ContextType>;
  isWinner?: Resolver<ResolversTypes['Boolean'], ParentType, ContextType>;
  logo?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  name?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  permalink?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  score?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  shortName?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type GroupingResolvers<ContextType = any, ParentType extends ResolversParentTypes['Grouping'] = ResolversParentTypes['Grouping']> = ResolversObject<{
  components?: Resolver<Maybe<Array<Maybe<ResolversTypes['ChannelComponent']>>>, ParentType, ContextType>;
  header?: Resolver<Maybe<ResolversTypes['GroupingHeader']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type GroupingHeaderResolvers<ContextType = any, ParentType extends ResolversParentTypes['GroupingHeader'] = ResolversParentTypes['GroupingHeader']> = ResolversObject<{
  applicableGameStates?: Resolver<Maybe<Array<Maybe<ResolversTypes['GameState']>>>, ParentType, ContextType>;
  gameEndTime?: Resolver<Maybe<ResolversTypes['Date']>, ParentType, ContextType>;
  gameStartTime?: Resolver<Maybe<ResolversTypes['Date']>, ParentType, ContextType>;
  id?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  image?: Resolver<Maybe<ResolversTypes['Image']>, ParentType, ContextType>;
  isDefault?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  isDomesticOnly?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  slug?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  title?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  visible?: Resolver<ResolversTypes['Boolean'], ParentType, ContextType>;
  visibleReason?: Resolver<Maybe<ResolversTypes['VisibilityReason']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type IdentifierResolvers<ContextType = any, ParentType extends ResolversParentTypes['Identifier'] = ResolversParentTypes['Identifier']> = ResolversObject<{
  id?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  namespace?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type ImageResolvers<ContextType = any, ParentType extends ResolversParentTypes['Image'] = ResolversParentTypes['Image']> = ResolversObject<{
  _id?: Resolver<Maybe<ResolversTypes['MongoID']>, ParentType, ContextType>;
  accreditation?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  alt?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  caption?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  copyright?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  focalPointX?: Resolver<Maybe<ResolversTypes['Float']>, ParentType, ContextType>;
  focalPointY?: Resolver<Maybe<ResolversTypes['Float']>, ParentType, ContextType>;
  height?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  url?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  width?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type ImageWithStyleResolvers<ContextType = any, ParentType extends ResolversParentTypes['ImageWithStyle'] = ResolversParentTypes['ImageWithStyle']> = ResolversObject<{
  _id?: Resolver<Maybe<ResolversTypes['MongoID']>, ParentType, ContextType>;
  image?: Resolver<Maybe<ResolversTypes['Image']>, ParentType, ContextType>;
  style?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  type?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type ItemResolvers<ContextType = any, ParentType extends ResolversParentTypes['Item'] = ResolversParentTypes['Item']> = ResolversObject<{
  _id?: Resolver<Maybe<ResolversTypes['MongoID']>, ParentType, ContextType>;
  description?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  endTime?: Resolver<Maybe<ResolversTypes['Date']>, ParentType, ContextType>;
  headline?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  images?: Resolver<Maybe<Array<Maybe<ResolversTypes['ImageWithStyle']>>>, ParentType, ContextType>;
  link?: Resolver<Maybe<ResolversTypes['Link']>, ParentType, ContextType>;
  startTime?: Resolver<Maybe<ResolversTypes['Date']>, ParentType, ContextType>;
  style?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  subheadline?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export interface JsonScalarConfig extends GraphQLScalarTypeConfig<ResolversTypes['JSON'], any> {
  name: 'JSON';
}

export interface JsonObjectScalarConfig extends GraphQLScalarTypeConfig<ResolversTypes['JSONObject'], any> {
  name: 'JSONObject';
}

export interface JwtScalarConfig extends GraphQLScalarTypeConfig<ResolversTypes['JWT'], any> {
  name: 'JWT';
}

export type LeagueResolvers<ContextType = any, ParentType extends ResolversParentTypes['League'] = ResolversParentTypes['League']> = ResolversObject<{
  alias?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  current_season?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  display_name?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  display_name_short?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  id?: Resolver<Maybe<ResolversTypes['ID']>, ParentType, ContextType>;
  name?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  season_end?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  season_start?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  sport?: Resolver<Maybe<ResolversTypes['Sport']>, ParentType, ContextType>;
  type?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LeaguesResolvers<ContextType = any, ParentType extends ResolversParentTypes['Leagues'] = ResolversParentTypes['Leagues']> = ResolversObject<{
  index_end?: Resolver<Maybe<ResolversTypes['Int']>, ParentType, ContextType>;
  index_start?: Resolver<Maybe<ResolversTypes['Int']>, ParentType, ContextType>;
  leagues?: Resolver<Maybe<Array<Maybe<ResolversTypes['League']>>>, ParentType, ContextType>;
  total?: Resolver<Maybe<ResolversTypes['Int']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LegacyResolvers<ContextType = any, ParentType extends ResolversParentTypes['Legacy'] = ResolversParentTypes['Legacy']> = ResolversObject<{
  league_id?: Resolver<Maybe<ResolversTypes['Int']>, ParentType, ContextType>;
  sport_id?: Resolver<Maybe<ResolversTypes['Int']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LimitationResolvers<ContextType = any, ParentType extends ResolversParentTypes['Limitation'] = ResolversParentTypes['Limitation']> = ResolversObject<{
  adPlacement?: Resolver<Maybe<ResolversTypes['AllowAll']>, ParentType, ContextType>;
  audioLanguage?: Resolver<Maybe<ResolversTypes['AllowAll']>, ParentType, ContextType>;
  technicalQuality?: Resolver<Maybe<ResolversTypes['AllowAll']>, ParentType, ContextType>;
  textLanguage?: Resolver<Maybe<ResolversTypes['AllowAll']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LinkResolvers<ContextType = any, ParentType extends ResolversParentTypes['Link'] = ResolversParentTypes['Link']> = ResolversObject<{
  _id?: Resolver<Maybe<ResolversTypes['MongoID']>, ParentType, ContextType>;
  text?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  uri?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeAlertResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeAlert'] = ResolversParentTypes['LiveLikeAlert']> = ResolversObject<{
  clientId?: Resolver<ResolversTypes['NonEmptyString'], ParentType, ContextType>;
  createdAt?: Resolver<ResolversTypes['DateTimeISO'], ParentType, ContextType>;
  createdBy?: Resolver<ResolversTypes['LiveLikeWidgetCreator'], ParentType, ContextType>;
  customData?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  id?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  imageUrl?: Resolver<Maybe<ResolversTypes['URL']>, ParentType, ContextType>;
  interactiveUntil?: Resolver<Maybe<ResolversTypes['DateTimeISO']>, ParentType, ContextType>;
  kind?: Resolver<ResolversTypes['LiveLikeWidgetKindEnum'], ParentType, ContextType>;
  linkLabel?: Resolver<Maybe<ResolversTypes['NonEmptyString']>, ParentType, ContextType>;
  linkUrl?: Resolver<Maybe<ResolversTypes['URL']>, ParentType, ContextType>;
  playbackTimeMs?: Resolver<Maybe<ResolversTypes['NonNegativeInt']>, ParentType, ContextType>;
  programDateTime?: Resolver<Maybe<ResolversTypes['DateTimeISO']>, ParentType, ContextType>;
  programId?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  publishDelay?: Resolver<ResolversTypes['Duration'], ParentType, ContextType>;
  publishedAt?: Resolver<Maybe<ResolversTypes['DateTimeISO']>, ParentType, ContextType>;
  pubnubEnabled?: Resolver<ResolversTypes['Boolean'], ParentType, ContextType>;
  reportCount?: Resolver<Maybe<ResolversTypes['LiveLikeWidgetReportCount']>, ParentType, ContextType>;
  scheduledAt?: Resolver<Maybe<ResolversTypes['DateTimeISO']>, ParentType, ContextType>;
  sponsorIds?: Resolver<Maybe<Array<ResolversTypes['UUID']>>, ParentType, ContextType>;
  status?: Resolver<ResolversTypes['LiveLikeWidgetStatusEnum'], ParentType, ContextType>;
  text?: Resolver<Maybe<ResolversTypes['NonEmptyString']>, ParentType, ContextType>;
  timeout?: Resolver<ResolversTypes['Duration'], ParentType, ContextType>;
  title?: Resolver<Maybe<ResolversTypes['NonEmptyString']>, ParentType, ContextType>;
  uniqueImpressionCount?: Resolver<Maybe<ResolversTypes['NonNegativeInt']>, ParentType, ContextType>;
  widgetAttributes?: Resolver<Maybe<Array<ResolversTypes['LiveLikeKeyValuePair']>>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeApplicationResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeApplication'] = ResolversParentTypes['LiveLikeApplication']> = ResolversObject<{
  apiPollingInterval?: Resolver<ResolversTypes['PositiveInt'], ParentType, ContextType>;
  clientId?: Resolver<ResolversTypes['NonEmptyString'], ParentType, ContextType>;
  imageUrl?: Resolver<ResolversTypes['URL'], ParentType, ContextType>;
  mediaUrl?: Resolver<ResolversTypes['URL'], ParentType, ContextType>;
  name?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  organizationId?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  organizationName?: Resolver<ResolversTypes['NonEmptyString'], ParentType, ContextType>;
  pubnubHeartbeatInterval?: Resolver<Maybe<ResolversTypes['NonNegativeInt']>, ParentType, ContextType>;
  pubnubOrigin?: Resolver<Maybe<ResolversTypes['NonEmptyString']>, ParentType, ContextType>;
  pubnubPresenceTimeout?: Resolver<Maybe<ResolversTypes['NonNegativeInt']>, ParentType, ContextType>;
  pubnubPublishKey?: Resolver<Maybe<ResolversTypes['NonEmptyString']>, ParentType, ContextType>;
  pubnubSubscribeKey?: Resolver<Maybe<ResolversTypes['NonEmptyString']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeBadgeResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeBadge'] = ResolversParentTypes['LiveLikeBadge']> = ResolversObject<{
  attributes?: Resolver<Maybe<Array<ResolversTypes['LiveLikeKeyValuePair']>>, ParentType, ContextType>;
  badgeIconUrl?: Resolver<ResolversTypes['URL'], ParentType, ContextType>;
  clientId?: Resolver<ResolversTypes['NonEmptyString'], ParentType, ContextType>;
  description?: Resolver<Maybe<ResolversTypes['NonEmptyString']>, ParentType, ContextType>;
  file?: Resolver<ResolversTypes['URL'], ParentType, ContextType>;
  id?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  mimetype?: Resolver<ResolversTypes['NonEmptyString'], ParentType, ContextType>;
  name?: Resolver<ResolversTypes['NonEmptyString'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeBadgeCollectionResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeBadgeCollection'] = ResolversParentTypes['LiveLikeBadgeCollection']> = ResolversObject<{
  edges?: Resolver<Maybe<Array<ResolversTypes['LiveLikeBadgeEdge']>>, ParentType, ContextType>;
  page?: Resolver<ResolversTypes['LiveLikePage'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeBadgeEdgeResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeBadgeEdge'] = ResolversParentTypes['LiveLikeBadgeEdge']> = ResolversObject<{
  cursor?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  node?: Resolver<ResolversTypes['LiveLikeBadge'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeBadgeProfileResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeBadgeProfile'] = ResolversParentTypes['LiveLikeBadgeProfile']> = ResolversObject<{
  awardedAt?: Resolver<ResolversTypes['DateTimeISO'], ParentType, ContextType>;
  badgeId?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  profile?: Resolver<ResolversTypes['LiveLikeProfile'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeBadgeProfileCollectionResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeBadgeProfileCollection'] = ResolversParentTypes['LiveLikeBadgeProfileCollection']> = ResolversObject<{
  edges?: Resolver<Maybe<Array<ResolversTypes['LiveLikeBadgeProfileEdge']>>, ParentType, ContextType>;
  page?: Resolver<ResolversTypes['LiveLikePage'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeBadgeProfileEdgeResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeBadgeProfileEdge'] = ResolversParentTypes['LiveLikeBadgeProfileEdge']> = ResolversObject<{
  cursor?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  node?: Resolver<ResolversTypes['LiveLikeBadgeProfile'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeBadgeRewardProgressResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeBadgeRewardProgress'] = ResolversParentTypes['LiveLikeBadgeRewardProgress']> = ResolversObject<{
  currentRewardAmount?: Resolver<ResolversTypes['NonNegativeInt'], ParentType, ContextType>;
  rewardItemId?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  rewardItemName?: Resolver<ResolversTypes['NonEmptyString'], ParentType, ContextType>;
  rewardItemThreshold?: Resolver<ResolversTypes['NonNegativeInt'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeBadgeRewardProgressCollectionResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeBadgeRewardProgressCollection'] = ResolversParentTypes['LiveLikeBadgeRewardProgressCollection']> = ResolversObject<{
  badge?: Resolver<ResolversTypes['LiveLikeBadge'], ParentType, ContextType>;
  badgeProgress?: Resolver<Maybe<Array<ResolversTypes['LiveLikeBadgeRewardProgress']>>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeBlockProfileResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeBlockProfile'] = ResolversParentTypes['LiveLikeBlockProfile']> = ResolversObject<{
  blockedByProfile?: Resolver<ResolversTypes['LiveLikeProfile'], ParentType, ContextType>;
  blockedByProfileId?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  blockedProfile?: Resolver<ResolversTypes['LiveLikeProfile'], ParentType, ContextType>;
  blockedProfileId?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  id?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeChatRoomResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeChatRoom'] = ResolversParentTypes['LiveLikeChatRoom']> = ResolversObject<{
  channels?: Resolver<ResolversTypes['LiveLikeChatRoomChannel'], ParentType, ContextType>;
  contentFilter?: Resolver<ResolversTypes['LiveLikeChatRoomContentFilterEnum'], ParentType, ContextType>;
  createdAt?: Resolver<ResolversTypes['DateTimeISO'], ParentType, ContextType>;
  id?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  reactionPackIds?: Resolver<Maybe<Array<ResolversTypes['UUID']>>, ParentType, ContextType>;
  reactionSpaceId?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  sponsorIds?: Resolver<Maybe<Array<ResolversTypes['UUID']>>, ParentType, ContextType>;
  title?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  tokenGates?: Resolver<Maybe<Array<ResolversTypes['LiveLikeTokenGate']>>, ParentType, ContextType>;
  visibility?: Resolver<ResolversTypes['LiveLikeChatRoomVisibilityEnum'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeChatRoomChannelResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeChatRoomChannel'] = ResolversParentTypes['LiveLikeChatRoomChannel']> = ResolversObject<{
  chat?: Resolver<ResolversTypes['NonEmptyString'], ParentType, ContextType>;
  control?: Resolver<ResolversTypes['NonEmptyString'], ParentType, ContextType>;
  reactions?: Resolver<ResolversTypes['NonEmptyString'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeChatRoomCollectionResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeChatRoomCollection'] = ResolversParentTypes['LiveLikeChatRoomCollection']> = ResolversObject<{
  edges?: Resolver<Maybe<Array<Maybe<ResolversTypes['LiveLikeChatRoomEdge']>>>, ParentType, ContextType>;
  page?: Resolver<ResolversTypes['LiveLikePage'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeChatRoomEdgeResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeChatRoomEdge'] = ResolversParentTypes['LiveLikeChatRoomEdge']> = ResolversObject<{
  cursor?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  node?: Resolver<ResolversTypes['LiveLikeChatRoom'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeCommentResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeComment'] = ResolversParentTypes['LiveLikeComment']> = ResolversObject<{
  author?: Resolver<ResolversTypes['LiveLikeProfile'], ParentType, ContextType>;
  authorId?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  commentBoardId?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  commentDepth?: Resolver<ResolversTypes['NonNegativeInt'], ParentType, ContextType>;
  commentReportsCount?: Resolver<ResolversTypes['NonNegativeInt'], ParentType, ContextType>;
  createdAt?: Resolver<ResolversTypes['DateTimeISO'], ParentType, ContextType>;
  customData?: Resolver<Maybe<ResolversTypes['NonEmptyString']>, ParentType, ContextType>;
  deletedAt?: Resolver<Maybe<ResolversTypes['DateTimeISO']>, ParentType, ContextType>;
  deletedBy?: Resolver<Maybe<ResolversTypes['UUID']>, ParentType, ContextType>;
  id?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  isDeleted?: Resolver<ResolversTypes['Boolean'], ParentType, ContextType>;
  isReported?: Resolver<ResolversTypes['Boolean'], ParentType, ContextType>;
  parentCommentId?: Resolver<Maybe<ResolversTypes['UUID']>, ParentType, ContextType>;
  repliesCount?: Resolver<ResolversTypes['NonNegativeInt'], ParentType, ContextType>;
  text?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeCommentBoardResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeCommentBoard'] = ResolversParentTypes['LiveLikeCommentBoard']> = ResolversObject<{
  allowComments?: Resolver<ResolversTypes['Boolean'], ParentType, ContextType>;
  clientId?: Resolver<ResolversTypes['NonEmptyString'], ParentType, ContextType>;
  commentsCount?: Resolver<ResolversTypes['NonNegativeInt'], ParentType, ContextType>;
  contentFilter?: Resolver<ResolversTypes['LiveLikeContentFilterEnum'], ParentType, ContextType>;
  createdAt?: Resolver<ResolversTypes['DateTimeISO'], ParentType, ContextType>;
  createdById?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  customData?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  customId?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  description?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  id?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  repliesDepth?: Resolver<ResolversTypes['PositiveInt'], ParentType, ContextType>;
  title?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeCommentBoardBanResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeCommentBoardBan'] = ResolversParentTypes['LiveLikeCommentBoardBan']> = ResolversObject<{
  bannedById?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  clientId?: Resolver<ResolversTypes['NonEmptyString'], ParentType, ContextType>;
  commentBoardId?: Resolver<Maybe<ResolversTypes['UUID']>, ParentType, ContextType>;
  createdAt?: Resolver<ResolversTypes['DateTimeISO'], ParentType, ContextType>;
  description?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  id?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  profileId?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeCommentBoardBanCollectionResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeCommentBoardBanCollection'] = ResolversParentTypes['LiveLikeCommentBoardBanCollection']> = ResolversObject<{
  edges?: Resolver<Maybe<Array<ResolversTypes['LiveLikeCommentBoardBanEdge']>>, ParentType, ContextType>;
  page?: Resolver<ResolversTypes['LiveLikePage'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeCommentBoardBanEdgeResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeCommentBoardBanEdge'] = ResolversParentTypes['LiveLikeCommentBoardBanEdge']> = ResolversObject<{
  cursor?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  node?: Resolver<ResolversTypes['LiveLikeCommentBoardBan'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeCommentBoardCollectionResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeCommentBoardCollection'] = ResolversParentTypes['LiveLikeCommentBoardCollection']> = ResolversObject<{
  edges?: Resolver<Maybe<Array<Maybe<ResolversTypes['LiveLikeCommentBoardEdge']>>>, ParentType, ContextType>;
  page?: Resolver<ResolversTypes['LiveLikePage'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeCommentBoardCountResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeCommentBoardCount'] = ResolversParentTypes['LiveLikeCommentBoardCount']> = ResolversObject<{
  commentsCount?: Resolver<ResolversTypes['NonNegativeInt'], ParentType, ContextType>;
  id?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  topLevelCommentsCount?: Resolver<ResolversTypes['NonNegativeInt'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeCommentBoardEdgeResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeCommentBoardEdge'] = ResolversParentTypes['LiveLikeCommentBoardEdge']> = ResolversObject<{
  cursor?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  node?: Resolver<ResolversTypes['LiveLikeCommentBoard'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeCommentCollectionResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeCommentCollection'] = ResolversParentTypes['LiveLikeCommentCollection']> = ResolversObject<{
  edges?: Resolver<Maybe<Array<Maybe<ResolversTypes['LiveLikeCommentEdge']>>>, ParentType, ContextType>;
  page?: Resolver<ResolversTypes['LiveLikePage'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeCommentEdgeResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeCommentEdge'] = ResolversParentTypes['LiveLikeCommentEdge']> = ResolversObject<{
  cursor?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  node?: Resolver<ResolversTypes['LiveLikeComment'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeCommentReportResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeCommentReport'] = ResolversParentTypes['LiveLikeCommentReport']> = ResolversObject<{
  comment?: Resolver<ResolversTypes['LiveLikeComment'], ParentType, ContextType>;
  commentBoardId?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  commentId?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  description?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  id?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  reportStatus?: Resolver<ResolversTypes['LiveLikeCommentReportStatusEnum'], ParentType, ContextType>;
  reportedAt?: Resolver<ResolversTypes['DateTimeISO'], ParentType, ContextType>;
  reportedById?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeCommentReportCollectionResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeCommentReportCollection'] = ResolversParentTypes['LiveLikeCommentReportCollection']> = ResolversObject<{
  edges?: Resolver<Maybe<Array<Maybe<ResolversTypes['LiveLikeCommentReportEdge']>>>, ParentType, ContextType>;
  page?: Resolver<ResolversTypes['LiveLikePage'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeCommentReportEdgeResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeCommentReportEdge'] = ResolversParentTypes['LiveLikeCommentReportEdge']> = ResolversObject<{
  cursor?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  node?: Resolver<ResolversTypes['LiveLikeCommentReport'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeConnectionResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeConnection'] = ResolversParentTypes['LiveLikeConnection']> = ResolversObject<{
  __resolveType: TypeResolveFn<'LiveLikeBadgeCollection' | 'LiveLikeChatRoomCollection' | 'LiveLikeCommentBoardBanCollection' | 'LiveLikeCommentBoardCollection' | 'LiveLikeCommentCollection' | 'LiveLikeCommentReportCollection' | 'LiveLikeLeaderboardCollection' | 'LiveLikePermissions' | 'LiveLikeProfileRelationshipCollection' | 'LiveLikeProfileRelationshipTypeCollection' | 'LiveLikeProgramConnection' | 'LiveLikeQuestCollection' | 'LiveLikeReactionPackCollection' | 'LiveLikeReactionSpaceCollection' | 'LiveLikeRewardItemCollection' | 'LiveLikeRewardTableCollection' | 'LiveLikeRoleAssignmentConnection' | 'LiveLikeRoleConnection' | 'LiveLikeUserQuestCollection' | 'LiveLikeUserQuestRewardsConnection' | 'LiveLikeUserReactionCollection' | 'LiveLikeWidgetReportCollection', ParentType, ContextType>;
  edges?: Resolver<Maybe<Array<Maybe<ResolversTypes['LiveLikeEdge']>>>, ParentType, ContextType>;
  page?: Resolver<Maybe<ResolversTypes['LiveLikePage']>, ParentType, ContextType>;
}>;

export type LiveLikeEarnedBadgeResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeEarnedBadge'] = ResolversParentTypes['LiveLikeEarnedBadge']> = ResolversObject<{
  awardedAt?: Resolver<ResolversTypes['DateTimeISO'], ParentType, ContextType>;
  badge?: Resolver<ResolversTypes['LiveLikeBadge'], ParentType, ContextType>;
  id?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeEarnedBadgeCollectionResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeEarnedBadgeCollection'] = ResolversParentTypes['LiveLikeEarnedBadgeCollection']> = ResolversObject<{
  edges?: Resolver<Maybe<Array<ResolversTypes['LiveLikeEarnedBadgeEdge']>>, ParentType, ContextType>;
  page?: Resolver<ResolversTypes['LiveLikePage'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeEarnedBadgeEdgeResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeEarnedBadgeEdge'] = ResolversParentTypes['LiveLikeEarnedBadgeEdge']> = ResolversObject<{
  cursor?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  node?: Resolver<ResolversTypes['LiveLikeEarnedBadge'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeEdgeResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeEdge'] = ResolversParentTypes['LiveLikeEdge']> = ResolversObject<{
  __resolveType: TypeResolveFn<'LiveLikeBadgeEdge' | 'LiveLikeChatRoomEdge' | 'LiveLikeCommentBoardBanEdge' | 'LiveLikeCommentBoardEdge' | 'LiveLikeCommentEdge' | 'LiveLikeCommentReportEdge' | 'LiveLikeLeaderboardEdge' | 'LiveLikePermissionEdge' | 'LiveLikeProfileRelationshipEdge' | 'LiveLikeProfileRelationshipTypeEdge' | 'LiveLikeProgramEdge' | 'LiveLikeQuestEdge' | 'LiveLikeReactionPackEdge' | 'LiveLikeReactionSpaceEdge' | 'LiveLikeRewardItemEdge' | 'LiveLikeRewardTableEdge' | 'LiveLikeRoleAssignmentEdge' | 'LiveLikeRoleEdge' | 'LiveLikeUserQuestEdge' | 'LiveLikeUserQuestRewardsEdge' | 'LiveLikeUserReactionEdge' | 'LiveLikeWidgetReportEdge', ParentType, ContextType>;
  cursor?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  node?: Resolver<Maybe<ResolversTypes['LiveLikeNode']>, ParentType, ContextType>;
}>;

export type LiveLikeEmojiResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeEmoji'] = ResolversParentTypes['LiveLikeEmoji']> = ResolversObject<{
  file?: Resolver<ResolversTypes['URL'], ParentType, ContextType>;
  id?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  mimeType?: Resolver<ResolversTypes['NonEmptyString'], ParentType, ContextType>;
  name?: Resolver<ResolversTypes['NonEmptyString'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeEmojiCountResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeEmojiCount'] = ResolversParentTypes['LiveLikeEmojiCount']> = ResolversObject<{
  id?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  reactionsCount?: Resolver<ResolversTypes['NonNegativeInt'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeImagePollResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeImagePoll'] = ResolversParentTypes['LiveLikeImagePoll']> = ResolversObject<{
  clientId?: Resolver<ResolversTypes['NonEmptyString'], ParentType, ContextType>;
  contentFilter?: Resolver<Maybe<Array<ResolversTypes['String']>>, ParentType, ContextType>;
  createdAt?: Resolver<ResolversTypes['DateTimeISO'], ParentType, ContextType>;
  createdBy?: Resolver<ResolversTypes['LiveLikeWidgetCreator'], ParentType, ContextType>;
  customData?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  filteredQuestion?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  id?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  interactiveUntil?: Resolver<Maybe<ResolversTypes['DateTimeISO']>, ParentType, ContextType>;
  kind?: Resolver<ResolversTypes['LiveLikeWidgetKindEnum'], ParentType, ContextType>;
  options?: Resolver<Array<ResolversTypes['LiveLikeImagePollOption']>, ParentType, ContextType>;
  playbackTimeMs?: Resolver<Maybe<ResolversTypes['NonNegativeInt']>, ParentType, ContextType>;
  programDateTime?: Resolver<Maybe<ResolversTypes['DateTimeISO']>, ParentType, ContextType>;
  programId?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  publishDelay?: Resolver<ResolversTypes['Duration'], ParentType, ContextType>;
  publishedAt?: Resolver<Maybe<ResolversTypes['DateTimeISO']>, ParentType, ContextType>;
  pubnubEnabled?: Resolver<ResolversTypes['Boolean'], ParentType, ContextType>;
  question?: Resolver<ResolversTypes['NonEmptyString'], ParentType, ContextType>;
  reportCount?: Resolver<Maybe<ResolversTypes['LiveLikeWidgetReportCount']>, ParentType, ContextType>;
  scheduledAt?: Resolver<Maybe<ResolversTypes['DateTimeISO']>, ParentType, ContextType>;
  sponsorIds?: Resolver<Maybe<Array<ResolversTypes['UUID']>>, ParentType, ContextType>;
  status?: Resolver<ResolversTypes['LiveLikeWidgetStatusEnum'], ParentType, ContextType>;
  timeout?: Resolver<ResolversTypes['Duration'], ParentType, ContextType>;
  uniqueImpressionCount?: Resolver<Maybe<ResolversTypes['NonNegativeInt']>, ParentType, ContextType>;
  userVote?: Resolver<Maybe<ResolversTypes['LiveLikeWidgetInteraction']>, ParentType, ContextType>;
  widgetAttributes?: Resolver<Maybe<Array<ResolversTypes['LiveLikeKeyValuePair']>>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeImagePollOptionResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeImagePollOption'] = ResolversParentTypes['LiveLikeImagePollOption']> = ResolversObject<{
  contentFilter?: Resolver<Maybe<Array<ResolversTypes['String']>>, ParentType, ContextType>;
  description?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  filteredDescription?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  id?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  imageUrl?: Resolver<ResolversTypes['URL'], ParentType, ContextType>;
  translatableFields?: Resolver<Maybe<Array<ResolversTypes['String']>>, ParentType, ContextType>;
  voteCount?: Resolver<Maybe<ResolversTypes['Int']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeImagePollVoteResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeImagePollVote'] = ResolversParentTypes['LiveLikeImagePollVote']> = ResolversObject<{
  createdAt?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  id?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  leaderboardRewards?: Resolver<Maybe<Array<ResolversTypes['LiveLikeLeaderboardReward']>>, ParentType, ContextType>;
  optionId?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  profileId?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  rewards?: Resolver<Maybe<Array<ResolversTypes['LiveLikeReward']>>, ParentType, ContextType>;
  widget?: Resolver<ResolversTypes['LiveLikeImagePoll'], ParentType, ContextType>;
  widgetId?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  widgetKind?: Resolver<ResolversTypes['LiveLikeWidgetInteractionEnum'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeImagePredictionResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeImagePrediction'] = ResolversParentTypes['LiveLikeImagePrediction']> = ResolversObject<{
  clientId?: Resolver<ResolversTypes['NonEmptyString'], ParentType, ContextType>;
  confirmationMessage?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  createdAt?: Resolver<ResolversTypes['DateTimeISO'], ParentType, ContextType>;
  createdBy?: Resolver<ResolversTypes['LiveLikeWidgetCreator'], ParentType, ContextType>;
  customData?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  followUps?: Resolver<Array<ResolversTypes['LiveLikeImagePredictionFollowUp']>, ParentType, ContextType>;
  id?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  interactiveUntil?: Resolver<Maybe<ResolversTypes['DateTimeISO']>, ParentType, ContextType>;
  kind?: Resolver<ResolversTypes['LiveLikeWidgetKindEnum'], ParentType, ContextType>;
  options?: Resolver<Array<ResolversTypes['LiveLikeImagePredictionOption']>, ParentType, ContextType>;
  playbackTimeMs?: Resolver<Maybe<ResolversTypes['NonNegativeInt']>, ParentType, ContextType>;
  programDateTime?: Resolver<Maybe<ResolversTypes['DateTimeISO']>, ParentType, ContextType>;
  programId?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  publishDelay?: Resolver<ResolversTypes['Duration'], ParentType, ContextType>;
  publishedAt?: Resolver<Maybe<ResolversTypes['DateTimeISO']>, ParentType, ContextType>;
  pubnubEnabled?: Resolver<ResolversTypes['Boolean'], ParentType, ContextType>;
  question?: Resolver<ResolversTypes['NonEmptyString'], ParentType, ContextType>;
  reportCount?: Resolver<Maybe<ResolversTypes['LiveLikeWidgetReportCount']>, ParentType, ContextType>;
  scheduledAt?: Resolver<Maybe<ResolversTypes['DateTimeISO']>, ParentType, ContextType>;
  sponsorIds?: Resolver<Maybe<Array<ResolversTypes['UUID']>>, ParentType, ContextType>;
  status?: Resolver<ResolversTypes['LiveLikeWidgetStatusEnum'], ParentType, ContextType>;
  timeout?: Resolver<ResolversTypes['Duration'], ParentType, ContextType>;
  uniqueImpressionCount?: Resolver<Maybe<ResolversTypes['NonNegativeInt']>, ParentType, ContextType>;
  widgetAttributes?: Resolver<Maybe<Array<ResolversTypes['LiveLikeKeyValuePair']>>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeImagePredictionFollowUpResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeImagePredictionFollowUp'] = ResolversParentTypes['LiveLikeImagePredictionFollowUp']> = ResolversObject<{
  clientId?: Resolver<ResolversTypes['NonEmptyString'], ParentType, ContextType>;
  correctOptionId?: Resolver<Maybe<ResolversTypes['UUID']>, ParentType, ContextType>;
  createdAt?: Resolver<ResolversTypes['DateTimeISO'], ParentType, ContextType>;
  createdBy?: Resolver<ResolversTypes['LiveLikeWidgetCreator'], ParentType, ContextType>;
  customData?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  id?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  imagePredictionId?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  interactiveUntil?: Resolver<Maybe<ResolversTypes['DateTimeISO']>, ParentType, ContextType>;
  kind?: Resolver<ResolversTypes['LiveLikeWidgetKindEnum'], ParentType, ContextType>;
  options?: Resolver<Array<ResolversTypes['LiveLikeImagePredictionOption']>, ParentType, ContextType>;
  playbackTimeMs?: Resolver<Maybe<ResolversTypes['NonNegativeInt']>, ParentType, ContextType>;
  programDateTime?: Resolver<Maybe<ResolversTypes['DateTimeISO']>, ParentType, ContextType>;
  programId?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  publishDelay?: Resolver<ResolversTypes['Duration'], ParentType, ContextType>;
  publishedAt?: Resolver<Maybe<ResolversTypes['DateTimeISO']>, ParentType, ContextType>;
  pubnubEnabled?: Resolver<ResolversTypes['Boolean'], ParentType, ContextType>;
  question?: Resolver<ResolversTypes['NonEmptyString'], ParentType, ContextType>;
  reportCount?: Resolver<Maybe<ResolversTypes['LiveLikeWidgetReportCount']>, ParentType, ContextType>;
  scheduledAt?: Resolver<Maybe<ResolversTypes['DateTimeISO']>, ParentType, ContextType>;
  sponsorIds?: Resolver<Maybe<Array<ResolversTypes['UUID']>>, ParentType, ContextType>;
  status?: Resolver<ResolversTypes['LiveLikeWidgetStatusEnum'], ParentType, ContextType>;
  timeout?: Resolver<ResolversTypes['Duration'], ParentType, ContextType>;
  uniqueImpressionCount?: Resolver<Maybe<ResolversTypes['NonNegativeInt']>, ParentType, ContextType>;
  widgetAttributes?: Resolver<Maybe<Array<ResolversTypes['LiveLikeKeyValuePair']>>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeImagePredictionOptionResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeImagePredictionOption'] = ResolversParentTypes['LiveLikeImagePredictionOption']> = ResolversObject<{
  description?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  earnableRewards?: Resolver<Maybe<Array<ResolversTypes['LiveLikeReward']>>, ParentType, ContextType>;
  id?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  imageUrl?: Resolver<ResolversTypes['URL'], ParentType, ContextType>;
  isCorrect?: Resolver<ResolversTypes['Boolean'], ParentType, ContextType>;
  rewardItemAmount?: Resolver<Maybe<ResolversTypes['NonNegativeInt']>, ParentType, ContextType>;
  rewardItemId?: Resolver<Maybe<ResolversTypes['UUID']>, ParentType, ContextType>;
  translatableFields?: Resolver<Maybe<Array<ResolversTypes['String']>>, ParentType, ContextType>;
  voteCount?: Resolver<ResolversTypes['NonNegativeInt'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeImagePredictionVoteResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeImagePredictionVote'] = ResolversParentTypes['LiveLikeImagePredictionVote']> = ResolversObject<{
  claimToken?: Resolver<ResolversTypes['JWT'], ParentType, ContextType>;
  createdAt?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  id?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  leaderboardRewards?: Resolver<Maybe<Array<ResolversTypes['LiveLikeLeaderboardReward']>>, ParentType, ContextType>;
  optionId?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  profileId?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  rewards?: Resolver<Maybe<Array<ResolversTypes['LiveLikeReward']>>, ParentType, ContextType>;
  widget?: Resolver<ResolversTypes['LiveLikeImagePrediction'], ParentType, ContextType>;
  widgetId?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  widgetKind?: Resolver<ResolversTypes['LiveLikeWidgetInteractionEnum'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeImageQuizResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeImageQuiz'] = ResolversParentTypes['LiveLikeImageQuiz']> = ResolversObject<{
  choices?: Resolver<Array<ResolversTypes['LiveLikeImageQuizChoice']>, ParentType, ContextType>;
  clientId?: Resolver<ResolversTypes['NonEmptyString'], ParentType, ContextType>;
  createdAt?: Resolver<ResolversTypes['DateTimeISO'], ParentType, ContextType>;
  createdBy?: Resolver<ResolversTypes['LiveLikeWidgetCreator'], ParentType, ContextType>;
  customData?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  id?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  interactiveUntil?: Resolver<Maybe<ResolversTypes['DateTimeISO']>, ParentType, ContextType>;
  kind?: Resolver<ResolversTypes['LiveLikeWidgetKindEnum'], ParentType, ContextType>;
  playbackTimeMs?: Resolver<Maybe<ResolversTypes['NonNegativeInt']>, ParentType, ContextType>;
  programDateTime?: Resolver<Maybe<ResolversTypes['DateTimeISO']>, ParentType, ContextType>;
  programId?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  publishDelay?: Resolver<ResolversTypes['Duration'], ParentType, ContextType>;
  publishedAt?: Resolver<Maybe<ResolversTypes['DateTimeISO']>, ParentType, ContextType>;
  pubnubEnabled?: Resolver<ResolversTypes['Boolean'], ParentType, ContextType>;
  question?: Resolver<ResolversTypes['NonEmptyString'], ParentType, ContextType>;
  reportCount?: Resolver<Maybe<ResolversTypes['LiveLikeWidgetReportCount']>, ParentType, ContextType>;
  scheduledAt?: Resolver<Maybe<ResolversTypes['DateTimeISO']>, ParentType, ContextType>;
  sponsorIds?: Resolver<Maybe<Array<ResolversTypes['UUID']>>, ParentType, ContextType>;
  status?: Resolver<ResolversTypes['LiveLikeWidgetStatusEnum'], ParentType, ContextType>;
  timeout?: Resolver<ResolversTypes['Duration'], ParentType, ContextType>;
  uniqueImpressionCount?: Resolver<Maybe<ResolversTypes['NonNegativeInt']>, ParentType, ContextType>;
  widgetAttributes?: Resolver<Maybe<Array<ResolversTypes['LiveLikeKeyValuePair']>>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeImageQuizAnswerResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeImageQuizAnswer'] = ResolversParentTypes['LiveLikeImageQuizAnswer']> = ResolversObject<{
  choiceId?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  createdAt?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  id?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  leaderboardRewards?: Resolver<Maybe<Array<ResolversTypes['LiveLikeLeaderboardReward']>>, ParentType, ContextType>;
  profileId?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  rewards?: Resolver<Maybe<Array<ResolversTypes['LiveLikeReward']>>, ParentType, ContextType>;
  widget?: Resolver<ResolversTypes['LiveLikeImageQuiz'], ParentType, ContextType>;
  widgetId?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  widgetKind?: Resolver<ResolversTypes['LiveLikeWidgetInteractionEnum'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeImageQuizChoiceResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeImageQuizChoice'] = ResolversParentTypes['LiveLikeImageQuizChoice']> = ResolversObject<{
  answerCount?: Resolver<ResolversTypes['NonNegativeInt'], ParentType, ContextType>;
  description?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  id?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  imageUrl?: Resolver<ResolversTypes['URL'], ParentType, ContextType>;
  isCorrect?: Resolver<ResolversTypes['Boolean'], ParentType, ContextType>;
  translatableFields?: Resolver<Maybe<Array<ResolversTypes['String']>>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeKeyValuePairResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeKeyValuePair'] = ResolversParentTypes['LiveLikeKeyValuePair']> = ResolversObject<{
  key?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  value?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeLeaderboardResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeLeaderboard'] = ResolversParentTypes['LiveLikeLeaderboard']> = ResolversObject<{
  clientId?: Resolver<ResolversTypes['NonEmptyString'], ParentType, ContextType>;
  id?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  isLocked?: Resolver<ResolversTypes['Boolean'], ParentType, ContextType>;
  name?: Resolver<ResolversTypes['NonEmptyString'], ParentType, ContextType>;
  rewardItem?: Resolver<Maybe<ResolversTypes['LiveLikeRewardItem']>, ParentType, ContextType>;
  rewardItemId?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeLeaderboardCollectionResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeLeaderboardCollection'] = ResolversParentTypes['LiveLikeLeaderboardCollection']> = ResolversObject<{
  edges?: Resolver<Maybe<Array<ResolversTypes['LiveLikeLeaderboardEdge']>>, ParentType, ContextType>;
  page?: Resolver<ResolversTypes['LiveLikePage'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeLeaderboardEdgeResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeLeaderboardEdge'] = ResolversParentTypes['LiveLikeLeaderboardEdge']> = ResolversObject<{
  cursor?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  node?: Resolver<ResolversTypes['LiveLikeLeaderboard'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeLeaderboardEntryResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeLeaderboardEntry'] = ResolversParentTypes['LiveLikeLeaderboardEntry']> = ResolversObject<{
  percentileRank?: Resolver<ResolversTypes['NonNegativeFloat'], ParentType, ContextType>;
  profileId?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  profileNickname?: Resolver<ResolversTypes['NonEmptyString'], ParentType, ContextType>;
  rank?: Resolver<ResolversTypes['PositiveInt'], ParentType, ContextType>;
  score?: Resolver<ResolversTypes['PositiveInt'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeLeaderboardEntryCollectionResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeLeaderboardEntryCollection'] = ResolversParentTypes['LiveLikeLeaderboardEntryCollection']> = ResolversObject<{
  edges?: Resolver<Maybe<Array<ResolversTypes['LiveLikeLeaderboardEntryEdge']>>, ParentType, ContextType>;
  page?: Resolver<ResolversTypes['LiveLikePageOffset'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeLeaderboardEntryEdgeResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeLeaderboardEntryEdge'] = ResolversParentTypes['LiveLikeLeaderboardEntryEdge']> = ResolversObject<{
  cursor?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  node?: Resolver<ResolversTypes['LiveLikeLeaderboardEntry'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeLeaderboardRewardResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeLeaderboardReward'] = ResolversParentTypes['LiveLikeLeaderboardReward']> = ResolversObject<{
  leaderboardId?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  leaderboardName?: Resolver<ResolversTypes['NonEmptyString'], ParentType, ContextType>;
  newPercentileRank?: Resolver<ResolversTypes['NonEmptyString'], ParentType, ContextType>;
  newRank?: Resolver<ResolversTypes['NonNegativeInt'], ParentType, ContextType>;
  newScore?: Resolver<ResolversTypes['NonNegativeFloat'], ParentType, ContextType>;
  rewardAction?: Resolver<ResolversTypes['LiveLikeRewardActionEnum'], ParentType, ContextType>;
  rewardItemAmount?: Resolver<ResolversTypes['PositiveInt'], ParentType, ContextType>;
  rewardItemId?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  rewardItemName?: Resolver<ResolversTypes['NonEmptyString'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeNodeResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeNode'] = ResolversParentTypes['LiveLikeNode']> = ResolversObject<{
  __resolveType: TypeResolveFn<'LiveLikeAlert' | 'LiveLikeBadge' | 'LiveLikeBlockProfile' | 'LiveLikeChatRoom' | 'LiveLikeComment' | 'LiveLikeCommentBoard' | 'LiveLikeCommentBoardBan' | 'LiveLikeCommentBoardCount' | 'LiveLikeCommentReport' | 'LiveLikeEmoji' | 'LiveLikeEmojiCount' | 'LiveLikeImagePoll' | 'LiveLikeImagePollOption' | 'LiveLikeImagePrediction' | 'LiveLikeImagePredictionFollowUp' | 'LiveLikeImagePredictionOption' | 'LiveLikeImageQuiz' | 'LiveLikeImageQuizChoice' | 'LiveLikeLeaderboard' | 'LiveLikePermission' | 'LiveLikeProfile' | 'LiveLikeProfileAuth' | 'LiveLikeProfileRelationship' | 'LiveLikeProfileRelationshipType' | 'LiveLikeProgram' | 'LiveLikeProgramBan' | 'LiveLikeProgramSchedule' | 'LiveLikeQuest' | 'LiveLikeQuestReward' | 'LiveLikeQuestTask' | 'LiveLikeReaction' | 'LiveLikeReactionPack' | 'LiveLikeReactionSpace' | 'LiveLikeResource' | 'LiveLikeRewardAction' | 'LiveLikeRewardActionItem' | 'LiveLikeRewardItem' | 'LiveLikeRewardItemImage' | 'LiveLikeRewardItemTransaction' | 'LiveLikeRewardTable' | 'LiveLikeRichPost' | 'LiveLikeRole' | 'LiveLikeRoleAssignment' | 'LiveLikeScope' | 'LiveLikeSocialEmbed' | 'LiveLikeSocialEmbedItem' | 'LiveLikeTextPoll' | 'LiveLikeTextPollOption' | 'LiveLikeTextPrediction' | 'LiveLikeTextPredictionFollowUp' | 'LiveLikeTextPredictionOption' | 'LiveLikeTextQuiz' | 'LiveLikeTextQuizChoice' | 'LiveLikeUserBadge' | 'LiveLikeUserQuest' | 'LiveLikeUserQuestReward' | 'LiveLikeUserQuestTask' | 'LiveLikeUserReaction' | 'LiveLikeVideoAlert' | 'LiveLikeWidgetReport', ParentType, ContextType>;
  id?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
}>;

export type LiveLikePageResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikePage'] = ResolversParentTypes['LiveLikePage']> = ResolversObject<{
  count?: Resolver<Maybe<ResolversTypes['NonNegativeInt']>, ParentType, ContextType>;
  endCursor?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  next?: Resolver<Maybe<ResolversTypes['PositiveInt']>, ParentType, ContextType>;
  previous?: Resolver<Maybe<ResolversTypes['PositiveInt']>, ParentType, ContextType>;
  startCursor?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikePageOffsetResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikePageOffset'] = ResolversParentTypes['LiveLikePageOffset']> = ResolversObject<{
  count?: Resolver<Maybe<ResolversTypes['NonNegativeInt']>, ParentType, ContextType>;
  next?: Resolver<Maybe<ResolversTypes['LiveLikePaginationOffset']>, ParentType, ContextType>;
  previous?: Resolver<Maybe<ResolversTypes['LiveLikePaginationOffset']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikePaginationOffsetResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikePaginationOffset'] = ResolversParentTypes['LiveLikePaginationOffset']> = ResolversObject<{
  limit?: Resolver<Maybe<ResolversTypes['NonNegativeInt']>, ParentType, ContextType>;
  offset?: Resolver<Maybe<ResolversTypes['NonNegativeInt']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikePermissionResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikePermission'] = ResolversParentTypes['LiveLikePermission']> = ResolversObject<{
  createdAt?: Resolver<ResolversTypes['DateTimeISO'], ParentType, ContextType>;
  description?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  id?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  key?: Resolver<ResolversTypes['NonEmptyString'], ParentType, ContextType>;
  name?: Resolver<ResolversTypes['NonEmptyString'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikePermissionEdgeResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikePermissionEdge'] = ResolversParentTypes['LiveLikePermissionEdge']> = ResolversObject<{
  cursor?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  node?: Resolver<ResolversTypes['LiveLikePermission'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikePermissionsResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikePermissions'] = ResolversParentTypes['LiveLikePermissions']> = ResolversObject<{
  edges?: Resolver<Maybe<Array<Maybe<ResolversTypes['LiveLikePermissionEdge']>>>, ParentType, ContextType>;
  page?: Resolver<ResolversTypes['LiveLikePage'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeProfileResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeProfile'] = ResolversParentTypes['LiveLikeProfile']> = ResolversObject<{
  badgeProgress?: Resolver<Maybe<Array<ResolversTypes['LiveLikeBadgeRewardProgressCollection']>>, ParentType, ContextType, RequireFields<LiveLikeProfileBadgeProgressArgs, 'badgeId'>>;
  badges?: Resolver<Maybe<ResolversTypes['LiveLikeEarnedBadgeCollection']>, ParentType, ContextType>;
  clientId?: Resolver<Maybe<ResolversTypes['NonEmptyString']>, ParentType, ContextType>;
  createdAt?: Resolver<ResolversTypes['NonEmptyString'], ParentType, ContextType>;
  customData?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  customId?: Resolver<Maybe<ResolversTypes['NonEmptyString']>, ParentType, ContextType>;
  id?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  incomingProfileRelationships?: Resolver<Maybe<ResolversTypes['LiveLikeProfileRelationshipCollection']>, ParentType, ContextType, Partial<LiveLikeProfileIncomingProfileRelationshipsArgs>>;
  nickname?: Resolver<ResolversTypes['NonEmptyString'], ParentType, ContextType>;
  outgoingProfileRelationships?: Resolver<Maybe<ResolversTypes['LiveLikeProfileRelationshipCollection']>, ParentType, ContextType, Partial<LiveLikeProfileOutgoingProfileRelationshipsArgs>>;
  quests?: Resolver<Maybe<ResolversTypes['LiveLikeUserQuestCollection']>, ParentType, ContextType, Partial<LiveLikeProfileQuestsArgs>>;
  rewardBalance?: Resolver<Maybe<ResolversTypes['LiveLikeRewardItemBalance']>, ParentType, ContextType, RequireFields<LiveLikeProfileRewardBalanceArgs, 'input'>>;
  rewardBalances?: Resolver<Maybe<ResolversTypes['LiveLikeRewardItemBalanceCollection']>, ParentType, ContextType, Partial<LiveLikeProfileRewardBalancesArgs>>;
  widgetsInteractions?: Resolver<Maybe<Array<ResolversTypes['LiveLikeWidgetInteractions']>>, ParentType, ContextType, RequireFields<LiveLikeProfileWidgetsInteractionsArgs, 'input'>>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeProfileAuthResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeProfileAuth'] = ResolversParentTypes['LiveLikeProfileAuth']> = ResolversObject<{
  accessToken?: Resolver<ResolversTypes['JWT'], ParentType, ContextType>;
  clientId?: Resolver<ResolversTypes['NonEmptyString'], ParentType, ContextType>;
  createdAt?: Resolver<ResolversTypes['NonEmptyString'], ParentType, ContextType>;
  customId?: Resolver<Maybe<ResolversTypes['NonEmptyString']>, ParentType, ContextType>;
  id?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  nickname?: Resolver<ResolversTypes['NonEmptyString'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeProfileRelationshipResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeProfileRelationship'] = ResolversParentTypes['LiveLikeProfileRelationship']> = ResolversObject<{
  createdAt?: Resolver<ResolversTypes['DateTimeISO'], ParentType, ContextType>;
  fromProfile?: Resolver<ResolversTypes['LiveLikeProfile'], ParentType, ContextType>;
  id?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  relationshipType?: Resolver<ResolversTypes['LiveLikeProfileRelationshipType'], ParentType, ContextType>;
  toProfile?: Resolver<ResolversTypes['LiveLikeProfile'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeProfileRelationshipCollectionResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeProfileRelationshipCollection'] = ResolversParentTypes['LiveLikeProfileRelationshipCollection']> = ResolversObject<{
  edges?: Resolver<Maybe<Array<ResolversTypes['LiveLikeProfileRelationshipEdge']>>, ParentType, ContextType>;
  page?: Resolver<ResolversTypes['LiveLikePage'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeProfileRelationshipEdgeResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeProfileRelationshipEdge'] = ResolversParentTypes['LiveLikeProfileRelationshipEdge']> = ResolversObject<{
  cursor?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  node?: Resolver<ResolversTypes['LiveLikeProfileRelationship'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeProfileRelationshipTypeResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeProfileRelationshipType'] = ResolversParentTypes['LiveLikeProfileRelationshipType']> = ResolversObject<{
  clientId?: Resolver<ResolversTypes['NonEmptyString'], ParentType, ContextType>;
  createdAt?: Resolver<ResolversTypes['DateTimeISO'], ParentType, ContextType>;
  id?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  key?: Resolver<ResolversTypes['NonEmptyString'], ParentType, ContextType>;
  name?: Resolver<ResolversTypes['NonEmptyString'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeProfileRelationshipTypeCollectionResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeProfileRelationshipTypeCollection'] = ResolversParentTypes['LiveLikeProfileRelationshipTypeCollection']> = ResolversObject<{
  edges?: Resolver<Maybe<Array<ResolversTypes['LiveLikeProfileRelationshipTypeEdge']>>, ParentType, ContextType>;
  page?: Resolver<ResolversTypes['LiveLikePage'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeProfileRelationshipTypeEdgeResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeProfileRelationshipTypeEdge'] = ResolversParentTypes['LiveLikeProfileRelationshipTypeEdge']> = ResolversObject<{
  cursor?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  node?: Resolver<ResolversTypes['LiveLikeProfileRelationshipType'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeProgramResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeProgram'] = ResolversParentTypes['LiveLikeProgram']> = ResolversObject<{
  clientId?: Resolver<ResolversTypes['NonEmptyString'], ParentType, ContextType>;
  createdAt?: Resolver<ResolversTypes['NonEmptyString'], ParentType, ContextType>;
  customId?: Resolver<Maybe<ResolversTypes['NonEmptyString']>, ParentType, ContextType>;
  id?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  scheduledAt?: Resolver<ResolversTypes['DateTimeISO'], ParentType, ContextType>;
  sponsorIds?: Resolver<Maybe<Array<ResolversTypes['UUID']>>, ParentType, ContextType>;
  startedAt?: Resolver<Maybe<ResolversTypes['DateTimeISO']>, ParentType, ContextType>;
  status?: Resolver<ResolversTypes['LiveLikeProgramStatusEnum'], ParentType, ContextType>;
  stoppedAt?: Resolver<Maybe<ResolversTypes['DateTimeISO']>, ParentType, ContextType>;
  title?: Resolver<ResolversTypes['NonEmptyString'], ParentType, ContextType>;
  widgets?: Resolver<Maybe<ResolversTypes['LiveLikeWidgetCollection']>, ParentType, ContextType, Partial<LiveLikeProgramWidgetsArgs>>;
  widgetsEnabled?: Resolver<ResolversTypes['Boolean'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeProgramBanResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeProgramBan'] = ResolversParentTypes['LiveLikeProgramBan']> = ResolversObject<{
  bannedByProfile?: Resolver<ResolversTypes['LiveLikeProfile'], ParentType, ContextType>;
  bannedProfile?: Resolver<ResolversTypes['LiveLikeProfile'], ParentType, ContextType>;
  clientId?: Resolver<ResolversTypes['NonEmptyString'], ParentType, ContextType>;
  comment?: Resolver<ResolversTypes['NonEmptyString'], ParentType, ContextType>;
  createdAt?: Resolver<ResolversTypes['DateTimeISO'], ParentType, ContextType>;
  expiringAt?: Resolver<Maybe<ResolversTypes['DateTimeISO']>, ParentType, ContextType>;
  id?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  programId?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeProgramBanCollectionResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeProgramBanCollection'] = ResolversParentTypes['LiveLikeProgramBanCollection']> = ResolversObject<{
  edges?: Resolver<Maybe<Array<ResolversTypes['LiveLikeProgramBanEdge']>>, ParentType, ContextType>;
  page?: Resolver<ResolversTypes['LiveLikePage'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeProgramBanEdgeResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeProgramBanEdge'] = ResolversParentTypes['LiveLikeProgramBanEdge']> = ResolversObject<{
  cursor?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  node?: Resolver<ResolversTypes['LiveLikeProgramBan'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeProgramConnectionResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeProgramConnection'] = ResolversParentTypes['LiveLikeProgramConnection']> = ResolversObject<{
  edges?: Resolver<Maybe<Array<Maybe<ResolversTypes['LiveLikeProgramEdge']>>>, ParentType, ContextType>;
  page?: Resolver<ResolversTypes['LiveLikePage'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeProgramEdgeResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeProgramEdge'] = ResolversParentTypes['LiveLikeProgramEdge']> = ResolversObject<{
  cursor?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  node?: Resolver<ResolversTypes['LiveLikeProgram'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeProgramScheduleResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeProgramSchedule'] = ResolversParentTypes['LiveLikeProgramSchedule']> = ResolversObject<{
  id?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  startedAt?: Resolver<Maybe<ResolversTypes['DateTimeISO']>, ParentType, ContextType>;
  status?: Resolver<ResolversTypes['LiveLikeProgramStatusEnum'], ParentType, ContextType>;
  stoppedAt?: Resolver<Maybe<ResolversTypes['DateTimeISO']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeQuestResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeQuest'] = ResolversParentTypes['LiveLikeQuest']> = ResolversObject<{
  attributes?: Resolver<Maybe<Array<ResolversTypes['LiveLikeKeyValuePair']>>, ParentType, ContextType>;
  clientId?: Resolver<ResolversTypes['NonEmptyString'], ParentType, ContextType>;
  createdAt?: Resolver<ResolversTypes['DateTimeISO'], ParentType, ContextType>;
  description?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  id?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  name?: Resolver<ResolversTypes['NonEmptyString'], ParentType, ContextType>;
  questRewards?: Resolver<Maybe<Array<ResolversTypes['LiveLikeQuestReward']>>, ParentType, ContextType>;
  questTasks?: Resolver<Maybe<Array<ResolversTypes['LiveLikeQuestTask']>>, ParentType, ContextType>;
  startedAt?: Resolver<Maybe<ResolversTypes['DateTimeISO']>, ParentType, ContextType>;
  status?: Resolver<ResolversTypes['LiveLikeQuestStatusEnum'], ParentType, ContextType>;
  stoppedAt?: Resolver<Maybe<ResolversTypes['DateTimeISO']>, ParentType, ContextType>;
  timeout?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeQuestCollectionResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeQuestCollection'] = ResolversParentTypes['LiveLikeQuestCollection']> = ResolversObject<{
  edges?: Resolver<Maybe<Array<ResolversTypes['LiveLikeQuestEdge']>>, ParentType, ContextType>;
  page?: Resolver<ResolversTypes['LiveLikePage'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeQuestEdgeResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeQuestEdge'] = ResolversParentTypes['LiveLikeQuestEdge']> = ResolversObject<{
  cursor?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  node?: Resolver<ResolversTypes['LiveLikeQuest'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeQuestRewardResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeQuestReward'] = ResolversParentTypes['LiveLikeQuestReward']> = ResolversObject<{
  id?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  questId?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  rewardItemAmount?: Resolver<ResolversTypes['PositiveInt'], ParentType, ContextType>;
  rewardItemId?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  rewardItemName?: Resolver<ResolversTypes['NonEmptyString'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeQuestTaskResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeQuestTask'] = ResolversParentTypes['LiveLikeQuestTask']> = ResolversObject<{
  attributes?: Resolver<Maybe<Array<ResolversTypes['LiveLikeKeyValuePair']>>, ParentType, ContextType>;
  createdAt?: Resolver<ResolversTypes['DateTimeISO'], ParentType, ContextType>;
  defaultProgressIncrement?: Resolver<ResolversTypes['NonNegativeInt'], ParentType, ContextType>;
  description?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  id?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  name?: Resolver<ResolversTypes['NonEmptyString'], ParentType, ContextType>;
  questId?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  targetValue?: Resolver<ResolversTypes['PositiveInt'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeReactionResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeReaction'] = ResolversParentTypes['LiveLikeReaction']> = ResolversObject<{
  count?: Resolver<ResolversTypes['NonNegativeInt'], ParentType, ContextType>;
  id?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  userReactionId?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeReactionPackResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeReactionPack'] = ResolversParentTypes['LiveLikeReactionPack']> = ResolversObject<{
  emojis?: Resolver<Maybe<Array<Maybe<ResolversTypes['LiveLikeEmoji']>>>, ParentType, ContextType>;
  id?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  name?: Resolver<ResolversTypes['NonEmptyString'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeReactionPackCollectionResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeReactionPackCollection'] = ResolversParentTypes['LiveLikeReactionPackCollection']> = ResolversObject<{
  edges?: Resolver<Maybe<Array<Maybe<ResolversTypes['LiveLikeReactionPackEdge']>>>, ParentType, ContextType>;
  page?: Resolver<ResolversTypes['LiveLikePage'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeReactionPackEdgeResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeReactionPackEdge'] = ResolversParentTypes['LiveLikeReactionPackEdge']> = ResolversObject<{
  cursor?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  node?: Resolver<ResolversTypes['LiveLikeReactionPack'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeReactionSpaceResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeReactionSpace'] = ResolversParentTypes['LiveLikeReactionSpace']> = ResolversObject<{
  clientId?: Resolver<ResolversTypes['NonEmptyString'], ParentType, ContextType>;
  createdBy?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  id?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  name?: Resolver<Maybe<ResolversTypes['NonEmptyString']>, ParentType, ContextType>;
  reactionPackIds?: Resolver<Maybe<Array<ResolversTypes['UUID']>>, ParentType, ContextType>;
  reactionSpaceChannel?: Resolver<Maybe<ResolversTypes['NonEmptyString']>, ParentType, ContextType>;
  targetGroupId?: Resolver<ResolversTypes['NonEmptyString'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeReactionSpaceCollectionResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeReactionSpaceCollection'] = ResolversParentTypes['LiveLikeReactionSpaceCollection']> = ResolversObject<{
  edges?: Resolver<Maybe<Array<Maybe<ResolversTypes['LiveLikeReactionSpaceEdge']>>>, ParentType, ContextType>;
  page?: Resolver<ResolversTypes['LiveLikePage'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeReactionSpaceCountResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeReactionSpaceCount'] = ResolversParentTypes['LiveLikeReactionSpaceCount']> = ResolversObject<{
  emojiCounts?: Resolver<Maybe<Array<ResolversTypes['LiveLikeEmojiCount']>>, ParentType, ContextType>;
  reactionSpaceId?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  reactionsCount?: Resolver<ResolversTypes['NonNegativeInt'], ParentType, ContextType>;
  targetGroupId?: Resolver<ResolversTypes['NonEmptyString'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeReactionSpaceEdgeResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeReactionSpaceEdge'] = ResolversParentTypes['LiveLikeReactionSpaceEdge']> = ResolversObject<{
  cursor?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  node?: Resolver<ResolversTypes['LiveLikeReactionSpace'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeReactionSpacePatchResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeReactionSpacePatch'] = ResolversParentTypes['LiveLikeReactionSpacePatch']> = ResolversObject<{
  name?: Resolver<Maybe<ResolversTypes['NonEmptyString']>, ParentType, ContextType>;
  reactionPackIds?: Resolver<Array<ResolversTypes['UUID']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeReactionsResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeReactions'] = ResolversParentTypes['LiveLikeReactions']> = ResolversObject<{
  reactions?: Resolver<Maybe<Array<ResolversTypes['LiveLikeReaction']>>, ParentType, ContextType>;
  targetId?: Resolver<ResolversTypes['NonEmptyString'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeResourceResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeResource'] = ResolversParentTypes['LiveLikeResource']> = ResolversObject<{
  createdAt?: Resolver<ResolversTypes['DateTimeISO'], ParentType, ContextType>;
  description?: Resolver<ResolversTypes['NonEmptyString'], ParentType, ContextType>;
  id?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  kind?: Resolver<ResolversTypes['LiveLikeResourceKindEnum'], ParentType, ContextType>;
  name?: Resolver<ResolversTypes['NonEmptyString'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeRewardResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeReward'] = ResolversParentTypes['LiveLikeReward']> = ResolversObject<{
  rewardAction?: Resolver<ResolversTypes['LiveLikeRewardActionEnum'], ParentType, ContextType>;
  rewardItemAmount?: Resolver<ResolversTypes['NonNegativeInt'], ParentType, ContextType>;
  rewardItemId?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  rewardItemName?: Resolver<ResolversTypes['NonEmptyString'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeRewardATableActionChoiceResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeRewardATableActionChoice'] = ResolversParentTypes['LiveLikeRewardATableActionChoice']> = ResolversObject<{
  action?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  actionDisplay?: Resolver<ResolversTypes['NonEmptyString'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeRewardActionResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeRewardAction'] = ResolversParentTypes['LiveLikeRewardAction']> = ResolversObject<{
  attributes?: Resolver<Maybe<Array<ResolversTypes['LiveLikeKeyValuePair']>>, ParentType, ContextType>;
  clientId?: Resolver<ResolversTypes['NonEmptyString'], ParentType, ContextType>;
  code?: Resolver<Maybe<ResolversTypes['NonEmptyString']>, ParentType, ContextType>;
  createdAt?: Resolver<ResolversTypes['NonEmptyString'], ParentType, ContextType>;
  id?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  profileId?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  profileNickname?: Resolver<ResolversTypes['NonEmptyString'], ParentType, ContextType>;
  programId?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  rewardActionKey?: Resolver<ResolversTypes['NonEmptyString'], ParentType, ContextType>;
  rewards?: Resolver<Maybe<Array<ResolversTypes['LiveLikeRewardActionItem']>>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeRewardActionItemResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeRewardActionItem'] = ResolversParentTypes['LiveLikeRewardActionItem']> = ResolversObject<{
  amount?: Resolver<ResolversTypes['NonNegativeInt'], ParentType, ContextType>;
  id?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  name?: Resolver<ResolversTypes['NonEmptyString'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeRewardItemResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeRewardItem'] = ResolversParentTypes['LiveLikeRewardItem']> = ResolversObject<{
  attributes?: Resolver<Maybe<Array<ResolversTypes['LiveLikeKeyValuePair']>>, ParentType, ContextType>;
  clientId?: Resolver<Maybe<ResolversTypes['NonEmptyString']>, ParentType, ContextType>;
  id?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  images?: Resolver<Maybe<Array<ResolversTypes['LiveLikeRewardItemImage']>>, ParentType, ContextType>;
  name?: Resolver<ResolversTypes['NonEmptyString'], ParentType, ContextType>;
  prizeoutConversionRate?: Resolver<Maybe<ResolversTypes['NonNegativeInt']>, ParentType, ContextType>;
  prizeoutPoints?: Resolver<Maybe<ResolversTypes['NonNegativeInt']>, ParentType, ContextType>;
  prizeoutStatus?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  rewardItemPoints?: Resolver<Maybe<ResolversTypes['NonNegativeInt']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeRewardItemBalanceResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeRewardItemBalance'] = ResolversParentTypes['LiveLikeRewardItemBalance']> = ResolversObject<{
  profileId?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  rewardItemBalance?: Resolver<ResolversTypes['NonNegativeInt'], ParentType, ContextType>;
  rewardItemId?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  rewardItemName?: Resolver<ResolversTypes['NonEmptyString'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeRewardItemBalanceCollectionResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeRewardItemBalanceCollection'] = ResolversParentTypes['LiveLikeRewardItemBalanceCollection']> = ResolversObject<{
  edges?: Resolver<Maybe<Array<ResolversTypes['LiveLikeRewardItemBalanceEdge']>>, ParentType, ContextType>;
  page?: Resolver<ResolversTypes['LiveLikePage'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeRewardItemBalanceEdgeResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeRewardItemBalanceEdge'] = ResolversParentTypes['LiveLikeRewardItemBalanceEdge']> = ResolversObject<{
  cursor?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  node?: Resolver<ResolversTypes['LiveLikeRewardItemBalance'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeRewardItemCollectionResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeRewardItemCollection'] = ResolversParentTypes['LiveLikeRewardItemCollection']> = ResolversObject<{
  edges?: Resolver<Maybe<Array<ResolversTypes['LiveLikeRewardItemEdge']>>, ParentType, ContextType>;
  page?: Resolver<ResolversTypes['LiveLikePage'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeRewardItemEdgeResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeRewardItemEdge'] = ResolversParentTypes['LiveLikeRewardItemEdge']> = ResolversObject<{
  cursor?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  node?: Resolver<ResolversTypes['LiveLikeRewardItem'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeRewardItemImageResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeRewardItemImage'] = ResolversParentTypes['LiveLikeRewardItemImage']> = ResolversObject<{
  id?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  imageUrl?: Resolver<ResolversTypes['URL'], ParentType, ContextType>;
  mimeType?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  name?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeRewardItemTransactionResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeRewardItemTransaction'] = ResolversParentTypes['LiveLikeRewardItemTransaction']> = ResolversObject<{
  attributes?: Resolver<Maybe<Array<ResolversTypes['LiveLikeKeyValuePair']>>, ParentType, ContextType>;
  createdAt?: Resolver<ResolversTypes['NonEmptyString'], ParentType, ContextType>;
  customData?: Resolver<Maybe<ResolversTypes['NonEmptyString']>, ParentType, ContextType>;
  description?: Resolver<Maybe<ResolversTypes['NonEmptyString']>, ParentType, ContextType>;
  id?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  newBalance?: Resolver<ResolversTypes['NonNegativeInt'], ParentType, ContextType>;
  prizeoutBalance?: Resolver<Maybe<ResolversTypes['NonNegativeInt']>, ParentType, ContextType>;
  reason?: Resolver<ResolversTypes['NonEmptyString'], ParentType, ContextType>;
  transactedById?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  transactedByNickname?: Resolver<ResolversTypes['NonEmptyString'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeRewardTableResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeRewardTable'] = ResolversParentTypes['LiveLikeRewardTable']> = ResolversObject<{
  actionChoices?: Resolver<Array<ResolversTypes['LiveLikeRewardATableActionChoice']>, ParentType, ContextType>;
  clientId?: Resolver<ResolversTypes['NonEmptyString'], ParentType, ContextType>;
  entries?: Resolver<Array<ResolversTypes['LiveLikeRewardTableEntry']>, ParentType, ContextType>;
  id?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  name?: Resolver<ResolversTypes['NonEmptyString'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeRewardTableCollectionResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeRewardTableCollection'] = ResolversParentTypes['LiveLikeRewardTableCollection']> = ResolversObject<{
  edges?: Resolver<Maybe<Array<ResolversTypes['LiveLikeRewardTableEdge']>>, ParentType, ContextType>;
  page?: Resolver<ResolversTypes['LiveLikePage'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeRewardTableEdgeResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeRewardTableEdge'] = ResolversParentTypes['LiveLikeRewardTableEdge']> = ResolversObject<{
  cursor?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  node?: Resolver<ResolversTypes['LiveLikeRewardTable'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeRewardTableEntryResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeRewardTableEntry'] = ResolversParentTypes['LiveLikeRewardTableEntry']> = ResolversObject<{
  action?: Resolver<ResolversTypes['NonEmptyString'], ParentType, ContextType>;
  actionDisplay?: Resolver<ResolversTypes['NonEmptyString'], ParentType, ContextType>;
  id?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  rewardItem?: Resolver<ResolversTypes['LiveLikeRewardItem'], ParentType, ContextType>;
  rewardItemAmount?: Resolver<ResolversTypes['PositiveInt'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeRichPostResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeRichPost'] = ResolversParentTypes['LiveLikeRichPost']> = ResolversObject<{
  clientId?: Resolver<ResolversTypes['NonEmptyString'], ParentType, ContextType>;
  content?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  contentFilter?: Resolver<Maybe<Array<ResolversTypes['String']>>, ParentType, ContextType>;
  createdAt?: Resolver<ResolversTypes['DateTimeISO'], ParentType, ContextType>;
  createdBy?: Resolver<ResolversTypes['LiveLikeWidgetCreator'], ParentType, ContextType>;
  customData?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  filteredContent?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  filteredTitle?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  id?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  interactiveUntil?: Resolver<Maybe<ResolversTypes['DateTimeISO']>, ParentType, ContextType>;
  kind?: Resolver<ResolversTypes['LiveLikeWidgetKindEnum'], ParentType, ContextType>;
  playbackTimeMs?: Resolver<Maybe<ResolversTypes['NonNegativeInt']>, ParentType, ContextType>;
  programDateTime?: Resolver<Maybe<ResolversTypes['DateTimeISO']>, ParentType, ContextType>;
  programId?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  publishDelay?: Resolver<ResolversTypes['Duration'], ParentType, ContextType>;
  publishedAt?: Resolver<Maybe<ResolversTypes['DateTimeISO']>, ParentType, ContextType>;
  pubnubEnabled?: Resolver<ResolversTypes['Boolean'], ParentType, ContextType>;
  reportCount?: Resolver<Maybe<ResolversTypes['LiveLikeWidgetReportCount']>, ParentType, ContextType>;
  scheduledAt?: Resolver<Maybe<ResolversTypes['DateTimeISO']>, ParentType, ContextType>;
  sponsorIds?: Resolver<Maybe<Array<ResolversTypes['UUID']>>, ParentType, ContextType>;
  status?: Resolver<ResolversTypes['LiveLikeWidgetStatusEnum'], ParentType, ContextType>;
  timeout?: Resolver<ResolversTypes['Duration'], ParentType, ContextType>;
  title?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  uniqueImpressionCount?: Resolver<Maybe<ResolversTypes['NonNegativeInt']>, ParentType, ContextType>;
  widgetAttributes?: Resolver<Maybe<Array<ResolversTypes['LiveLikeKeyValuePair']>>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeRoleResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeRole'] = ResolversParentTypes['LiveLikeRole']> = ResolversObject<{
  clientId?: Resolver<ResolversTypes['NonEmptyString'], ParentType, ContextType>;
  createdAt?: Resolver<ResolversTypes['DateTimeISO'], ParentType, ContextType>;
  description?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  id?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  isActive?: Resolver<ResolversTypes['Boolean'], ParentType, ContextType>;
  key?: Resolver<ResolversTypes['NonEmptyString'], ParentType, ContextType>;
  name?: Resolver<ResolversTypes['NonEmptyString'], ParentType, ContextType>;
  permissions?: Resolver<Array<ResolversTypes['LiveLikePermission']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeRoleAssignmentResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeRoleAssignment'] = ResolversParentTypes['LiveLikeRoleAssignment']> = ResolversObject<{
  createdAt?: Resolver<ResolversTypes['DateTimeISO'], ParentType, ContextType>;
  id?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  profile?: Resolver<Maybe<ResolversTypes['LiveLikeProfile']>, ParentType, ContextType>;
  role?: Resolver<Maybe<ResolversTypes['LiveLikeRole']>, ParentType, ContextType>;
  scope?: Resolver<Maybe<ResolversTypes['LiveLikeScope']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeRoleAssignmentConnectionResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeRoleAssignmentConnection'] = ResolversParentTypes['LiveLikeRoleAssignmentConnection']> = ResolversObject<{
  edges?: Resolver<Maybe<Array<ResolversTypes['LiveLikeRoleAssignmentEdge']>>, ParentType, ContextType>;
  page?: Resolver<ResolversTypes['LiveLikePage'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeRoleAssignmentEdgeResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeRoleAssignmentEdge'] = ResolversParentTypes['LiveLikeRoleAssignmentEdge']> = ResolversObject<{
  cursor?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  node?: Resolver<ResolversTypes['LiveLikeRoleAssignment'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeRoleConnectionResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeRoleConnection'] = ResolversParentTypes['LiveLikeRoleConnection']> = ResolversObject<{
  edges?: Resolver<Maybe<Array<ResolversTypes['LiveLikeRoleEdge']>>, ParentType, ContextType>;
  page?: Resolver<ResolversTypes['LiveLikePage'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeRoleEdgeResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeRoleEdge'] = ResolversParentTypes['LiveLikeRoleEdge']> = ResolversObject<{
  cursor?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  node?: Resolver<ResolversTypes['LiveLikeRole'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeScopeResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeScope'] = ResolversParentTypes['LiveLikeScope']> = ResolversObject<{
  clientId?: Resolver<ResolversTypes['NonEmptyString'], ParentType, ContextType>;
  createdAt?: Resolver<ResolversTypes['DateTimeISO'], ParentType, ContextType>;
  id?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  resource?: Resolver<ResolversTypes['LiveLikeResource'], ParentType, ContextType>;
  resourceKey?: Resolver<ResolversTypes['NonEmptyString'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeSocialEmbedResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeSocialEmbed'] = ResolversParentTypes['LiveLikeSocialEmbed']> = ResolversObject<{
  clientId?: Resolver<ResolversTypes['NonEmptyString'], ParentType, ContextType>;
  comment?: Resolver<Maybe<ResolversTypes['NonEmptyString']>, ParentType, ContextType>;
  createdAt?: Resolver<ResolversTypes['DateTimeISO'], ParentType, ContextType>;
  createdBy?: Resolver<ResolversTypes['LiveLikeWidgetCreator'], ParentType, ContextType>;
  customData?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  id?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  interactiveUntil?: Resolver<Maybe<ResolversTypes['DateTimeISO']>, ParentType, ContextType>;
  kind?: Resolver<ResolversTypes['LiveLikeWidgetKindEnum'], ParentType, ContextType>;
  oEmbedItem?: Resolver<Maybe<ResolversTypes['LiveLikeSocialEmbedItem']>, ParentType, ContextType>;
  playbackTimeMs?: Resolver<Maybe<ResolversTypes['NonNegativeInt']>, ParentType, ContextType>;
  programDateTime?: Resolver<Maybe<ResolversTypes['DateTimeISO']>, ParentType, ContextType>;
  programId?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  publishDelay?: Resolver<ResolversTypes['Duration'], ParentType, ContextType>;
  publishedAt?: Resolver<Maybe<ResolversTypes['DateTimeISO']>, ParentType, ContextType>;
  pubnubEnabled?: Resolver<ResolversTypes['Boolean'], ParentType, ContextType>;
  reportCount?: Resolver<Maybe<ResolversTypes['LiveLikeWidgetReportCount']>, ParentType, ContextType>;
  scheduledAt?: Resolver<Maybe<ResolversTypes['DateTimeISO']>, ParentType, ContextType>;
  sponsorIds?: Resolver<Maybe<Array<ResolversTypes['UUID']>>, ParentType, ContextType>;
  status?: Resolver<ResolversTypes['LiveLikeWidgetStatusEnum'], ParentType, ContextType>;
  timeout?: Resolver<ResolversTypes['Duration'], ParentType, ContextType>;
  uniqueImpressionCount?: Resolver<Maybe<ResolversTypes['NonNegativeInt']>, ParentType, ContextType>;
  widgetAttributes?: Resolver<Maybe<Array<ResolversTypes['LiveLikeKeyValuePair']>>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeSocialEmbedItemResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeSocialEmbedItem'] = ResolversParentTypes['LiveLikeSocialEmbedItem']> = ResolversObject<{
  id?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  oEmbedMeta?: Resolver<Maybe<ResolversTypes['JSONObject']>, ParentType, ContextType>;
  oEmbedUrl?: Resolver<Maybe<ResolversTypes['URL']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeTextPollResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeTextPoll'] = ResolversParentTypes['LiveLikeTextPoll']> = ResolversObject<{
  clientId?: Resolver<ResolversTypes['NonEmptyString'], ParentType, ContextType>;
  contentFilter?: Resolver<Maybe<Array<ResolversTypes['String']>>, ParentType, ContextType>;
  createdAt?: Resolver<ResolversTypes['DateTimeISO'], ParentType, ContextType>;
  createdBy?: Resolver<ResolversTypes['LiveLikeWidgetCreator'], ParentType, ContextType>;
  customData?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  filteredQuestion?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  id?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  interactiveUntil?: Resolver<Maybe<ResolversTypes['DateTimeISO']>, ParentType, ContextType>;
  kind?: Resolver<ResolversTypes['LiveLikeWidgetKindEnum'], ParentType, ContextType>;
  options?: Resolver<Array<ResolversTypes['LiveLikeTextPollOption']>, ParentType, ContextType>;
  playbackTimeMs?: Resolver<Maybe<ResolversTypes['NonNegativeInt']>, ParentType, ContextType>;
  programDateTime?: Resolver<Maybe<ResolversTypes['DateTimeISO']>, ParentType, ContextType>;
  programId?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  publishDelay?: Resolver<ResolversTypes['Duration'], ParentType, ContextType>;
  publishedAt?: Resolver<Maybe<ResolversTypes['DateTimeISO']>, ParentType, ContextType>;
  pubnubEnabled?: Resolver<ResolversTypes['Boolean'], ParentType, ContextType>;
  question?: Resolver<ResolversTypes['NonEmptyString'], ParentType, ContextType>;
  reportCount?: Resolver<Maybe<ResolversTypes['LiveLikeWidgetReportCount']>, ParentType, ContextType>;
  scheduledAt?: Resolver<Maybe<ResolversTypes['DateTimeISO']>, ParentType, ContextType>;
  sponsorIds?: Resolver<Maybe<Array<ResolversTypes['UUID']>>, ParentType, ContextType>;
  status?: Resolver<ResolversTypes['LiveLikeWidgetStatusEnum'], ParentType, ContextType>;
  timeout?: Resolver<ResolversTypes['Duration'], ParentType, ContextType>;
  uniqueImpressionCount?: Resolver<Maybe<ResolversTypes['NonNegativeInt']>, ParentType, ContextType>;
  userVote?: Resolver<Maybe<ResolversTypes['LiveLikeWidgetInteraction']>, ParentType, ContextType>;
  widgetAttributes?: Resolver<Maybe<Array<ResolversTypes['LiveLikeKeyValuePair']>>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeTextPollOptionResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeTextPollOption'] = ResolversParentTypes['LiveLikeTextPollOption']> = ResolversObject<{
  contentFilter?: Resolver<Maybe<Array<ResolversTypes['String']>>, ParentType, ContextType>;
  description?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  filteredDescription?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  id?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  translatableFields?: Resolver<Maybe<Array<ResolversTypes['String']>>, ParentType, ContextType>;
  voteCount?: Resolver<Maybe<ResolversTypes['Int']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeTextPollVoteResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeTextPollVote'] = ResolversParentTypes['LiveLikeTextPollVote']> = ResolversObject<{
  createdAt?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  id?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  leaderboardRewards?: Resolver<Maybe<Array<ResolversTypes['LiveLikeLeaderboardReward']>>, ParentType, ContextType>;
  optionId?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  profileId?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  rewards?: Resolver<Maybe<Array<ResolversTypes['LiveLikeReward']>>, ParentType, ContextType>;
  widget?: Resolver<ResolversTypes['LiveLikeTextPoll'], ParentType, ContextType>;
  widgetId?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  widgetKind?: Resolver<ResolversTypes['LiveLikeWidgetInteractionEnum'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeTextPredictionResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeTextPrediction'] = ResolversParentTypes['LiveLikeTextPrediction']> = ResolversObject<{
  clientId?: Resolver<ResolversTypes['NonEmptyString'], ParentType, ContextType>;
  confirmationMessage?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  createdAt?: Resolver<ResolversTypes['DateTimeISO'], ParentType, ContextType>;
  createdBy?: Resolver<ResolversTypes['LiveLikeWidgetCreator'], ParentType, ContextType>;
  customData?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  followUps?: Resolver<Array<ResolversTypes['LiveLikeTextPredictionFollowUp']>, ParentType, ContextType>;
  id?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  interactiveUntil?: Resolver<Maybe<ResolversTypes['DateTimeISO']>, ParentType, ContextType>;
  kind?: Resolver<ResolversTypes['LiveLikeWidgetKindEnum'], ParentType, ContextType>;
  options?: Resolver<Array<ResolversTypes['LiveLikeTextPredictionOption']>, ParentType, ContextType>;
  playbackTimeMs?: Resolver<Maybe<ResolversTypes['NonNegativeInt']>, ParentType, ContextType>;
  programDateTime?: Resolver<Maybe<ResolversTypes['DateTimeISO']>, ParentType, ContextType>;
  programId?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  publishDelay?: Resolver<ResolversTypes['Duration'], ParentType, ContextType>;
  publishedAt?: Resolver<Maybe<ResolversTypes['DateTimeISO']>, ParentType, ContextType>;
  pubnubEnabled?: Resolver<ResolversTypes['Boolean'], ParentType, ContextType>;
  question?: Resolver<ResolversTypes['NonEmptyString'], ParentType, ContextType>;
  reportCount?: Resolver<Maybe<ResolversTypes['LiveLikeWidgetReportCount']>, ParentType, ContextType>;
  scheduledAt?: Resolver<Maybe<ResolversTypes['DateTimeISO']>, ParentType, ContextType>;
  sponsorIds?: Resolver<Maybe<Array<ResolversTypes['UUID']>>, ParentType, ContextType>;
  status?: Resolver<ResolversTypes['LiveLikeWidgetStatusEnum'], ParentType, ContextType>;
  timeout?: Resolver<ResolversTypes['Duration'], ParentType, ContextType>;
  uniqueImpressionCount?: Resolver<Maybe<ResolversTypes['NonNegativeInt']>, ParentType, ContextType>;
  widgetAttributes?: Resolver<Maybe<Array<ResolversTypes['LiveLikeKeyValuePair']>>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeTextPredictionFollowUpResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeTextPredictionFollowUp'] = ResolversParentTypes['LiveLikeTextPredictionFollowUp']> = ResolversObject<{
  clientId?: Resolver<ResolversTypes['NonEmptyString'], ParentType, ContextType>;
  correctOptionId?: Resolver<Maybe<ResolversTypes['UUID']>, ParentType, ContextType>;
  createdAt?: Resolver<ResolversTypes['DateTimeISO'], ParentType, ContextType>;
  createdBy?: Resolver<ResolversTypes['LiveLikeWidgetCreator'], ParentType, ContextType>;
  customData?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  id?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  interactiveUntil?: Resolver<Maybe<ResolversTypes['DateTimeISO']>, ParentType, ContextType>;
  kind?: Resolver<ResolversTypes['LiveLikeWidgetKindEnum'], ParentType, ContextType>;
  options?: Resolver<Array<ResolversTypes['LiveLikeTextPredictionOption']>, ParentType, ContextType>;
  playbackTimeMs?: Resolver<Maybe<ResolversTypes['NonNegativeInt']>, ParentType, ContextType>;
  programDateTime?: Resolver<Maybe<ResolversTypes['DateTimeISO']>, ParentType, ContextType>;
  programId?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  publishDelay?: Resolver<ResolversTypes['Duration'], ParentType, ContextType>;
  publishedAt?: Resolver<Maybe<ResolversTypes['DateTimeISO']>, ParentType, ContextType>;
  pubnubEnabled?: Resolver<ResolversTypes['Boolean'], ParentType, ContextType>;
  question?: Resolver<ResolversTypes['NonEmptyString'], ParentType, ContextType>;
  reportCount?: Resolver<Maybe<ResolversTypes['LiveLikeWidgetReportCount']>, ParentType, ContextType>;
  scheduledAt?: Resolver<Maybe<ResolversTypes['DateTimeISO']>, ParentType, ContextType>;
  sponsorIds?: Resolver<Maybe<Array<ResolversTypes['UUID']>>, ParentType, ContextType>;
  status?: Resolver<ResolversTypes['LiveLikeWidgetStatusEnum'], ParentType, ContextType>;
  textPredictionId?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  timeout?: Resolver<ResolversTypes['Duration'], ParentType, ContextType>;
  uniqueImpressionCount?: Resolver<Maybe<ResolversTypes['NonNegativeInt']>, ParentType, ContextType>;
  widgetAttributes?: Resolver<Maybe<Array<ResolversTypes['LiveLikeKeyValuePair']>>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeTextPredictionOptionResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeTextPredictionOption'] = ResolversParentTypes['LiveLikeTextPredictionOption']> = ResolversObject<{
  description?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  earnableRewards?: Resolver<Maybe<Array<ResolversTypes['LiveLikeReward']>>, ParentType, ContextType>;
  id?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  isCorrect?: Resolver<ResolversTypes['Boolean'], ParentType, ContextType>;
  rewardItemAmount?: Resolver<Maybe<ResolversTypes['NonNegativeInt']>, ParentType, ContextType>;
  rewardItemId?: Resolver<Maybe<ResolversTypes['UUID']>, ParentType, ContextType>;
  translatableFields?: Resolver<Maybe<Array<ResolversTypes['String']>>, ParentType, ContextType>;
  voteCount?: Resolver<ResolversTypes['NonNegativeInt'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeTextPredictionVoteResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeTextPredictionVote'] = ResolversParentTypes['LiveLikeTextPredictionVote']> = ResolversObject<{
  claimToken?: Resolver<ResolversTypes['JWT'], ParentType, ContextType>;
  createdAt?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  id?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  leaderboardRewards?: Resolver<Maybe<Array<ResolversTypes['LiveLikeLeaderboardReward']>>, ParentType, ContextType>;
  optionId?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  profileId?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  rewards?: Resolver<Maybe<Array<ResolversTypes['LiveLikeReward']>>, ParentType, ContextType>;
  widget?: Resolver<ResolversTypes['LiveLikeTextPrediction'], ParentType, ContextType>;
  widgetId?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  widgetKind?: Resolver<ResolversTypes['LiveLikeWidgetInteractionEnum'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeTextQuizResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeTextQuiz'] = ResolversParentTypes['LiveLikeTextQuiz']> = ResolversObject<{
  choices?: Resolver<Array<ResolversTypes['LiveLikeTextQuizChoice']>, ParentType, ContextType>;
  clientId?: Resolver<ResolversTypes['NonEmptyString'], ParentType, ContextType>;
  createdAt?: Resolver<ResolversTypes['DateTimeISO'], ParentType, ContextType>;
  createdBy?: Resolver<ResolversTypes['LiveLikeWidgetCreator'], ParentType, ContextType>;
  customData?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  id?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  interactiveUntil?: Resolver<Maybe<ResolversTypes['DateTimeISO']>, ParentType, ContextType>;
  kind?: Resolver<ResolversTypes['LiveLikeWidgetKindEnum'], ParentType, ContextType>;
  playbackTimeMs?: Resolver<Maybe<ResolversTypes['NonNegativeInt']>, ParentType, ContextType>;
  programDateTime?: Resolver<Maybe<ResolversTypes['DateTimeISO']>, ParentType, ContextType>;
  programId?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  publishDelay?: Resolver<ResolversTypes['Duration'], ParentType, ContextType>;
  publishedAt?: Resolver<Maybe<ResolversTypes['DateTimeISO']>, ParentType, ContextType>;
  pubnubEnabled?: Resolver<ResolversTypes['Boolean'], ParentType, ContextType>;
  question?: Resolver<ResolversTypes['NonEmptyString'], ParentType, ContextType>;
  reportCount?: Resolver<Maybe<ResolversTypes['LiveLikeWidgetReportCount']>, ParentType, ContextType>;
  scheduledAt?: Resolver<Maybe<ResolversTypes['DateTimeISO']>, ParentType, ContextType>;
  sponsorIds?: Resolver<Maybe<Array<ResolversTypes['UUID']>>, ParentType, ContextType>;
  status?: Resolver<ResolversTypes['LiveLikeWidgetStatusEnum'], ParentType, ContextType>;
  timeout?: Resolver<ResolversTypes['Duration'], ParentType, ContextType>;
  uniqueImpressionCount?: Resolver<Maybe<ResolversTypes['NonNegativeInt']>, ParentType, ContextType>;
  widgetAttributes?: Resolver<Maybe<Array<ResolversTypes['LiveLikeKeyValuePair']>>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeTextQuizAnswerResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeTextQuizAnswer'] = ResolversParentTypes['LiveLikeTextQuizAnswer']> = ResolversObject<{
  choiceId?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  createdAt?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  id?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  leaderboardRewards?: Resolver<Maybe<Array<ResolversTypes['LiveLikeLeaderboardReward']>>, ParentType, ContextType>;
  profileId?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  rewards?: Resolver<Maybe<Array<ResolversTypes['LiveLikeReward']>>, ParentType, ContextType>;
  widget?: Resolver<ResolversTypes['LiveLikeTextQuiz'], ParentType, ContextType>;
  widgetId?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  widgetKind?: Resolver<ResolversTypes['LiveLikeWidgetInteractionEnum'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeTextQuizChoiceResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeTextQuizChoice'] = ResolversParentTypes['LiveLikeTextQuizChoice']> = ResolversObject<{
  answerCount?: Resolver<ResolversTypes['NonNegativeInt'], ParentType, ContextType>;
  description?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  id?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  isCorrect?: Resolver<ResolversTypes['Boolean'], ParentType, ContextType>;
  translatableFields?: Resolver<Maybe<Array<ResolversTypes['String']>>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeTokenGateResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeTokenGate'] = ResolversParentTypes['LiveLikeTokenGate']> = ResolversObject<{
  attributes?: Resolver<Maybe<Array<ResolversTypes['LiveLikeTokenGateAttribute']>>, ParentType, ContextType>;
  contractAddress?: Resolver<ResolversTypes['NonEmptyString'], ParentType, ContextType>;
  networkType?: Resolver<ResolversTypes['LiveLikeTokenGateNetworkTypeEnum'], ParentType, ContextType>;
  tokenType?: Resolver<ResolversTypes['LiveLikeTokenGateTokenTypeEnum'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeTokenGateAttributeResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeTokenGateAttribute'] = ResolversParentTypes['LiveLikeTokenGateAttribute']> = ResolversObject<{
  trainType?: Resolver<ResolversTypes['NonEmptyString'], ParentType, ContextType>;
  value?: Resolver<ResolversTypes['NonEmptyString'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeUserBadgeResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeUserBadge'] = ResolversParentTypes['LiveLikeUserBadge']> = ResolversObject<{
  awardedAt?: Resolver<ResolversTypes['DateTimeISO'], ParentType, ContextType>;
  badge?: Resolver<ResolversTypes['LiveLikeBadge'], ParentType, ContextType>;
  badgeId?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  id?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  profile?: Resolver<ResolversTypes['LiveLikeProfile'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeUserBadgeCollectionResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeUserBadgeCollection'] = ResolversParentTypes['LiveLikeUserBadgeCollection']> = ResolversObject<{
  edges?: Resolver<Maybe<Array<ResolversTypes['LiveLikeUserBadgeEdge']>>, ParentType, ContextType>;
  page?: Resolver<ResolversTypes['LiveLikePage'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeUserBadgeEdgeResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeUserBadgeEdge'] = ResolversParentTypes['LiveLikeUserBadgeEdge']> = ResolversObject<{
  cursor?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  node?: Resolver<ResolversTypes['LiveLikeUserBadge'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeUserQuestResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeUserQuest'] = ResolversParentTypes['LiveLikeUserQuest']> = ResolversObject<{
  activeUntil?: Resolver<Maybe<ResolversTypes['DateTimeISO']>, ParentType, ContextType>;
  completedAt?: Resolver<Maybe<ResolversTypes['NonEmptyString']>, ParentType, ContextType>;
  createdAt?: Resolver<ResolversTypes['NonEmptyString'], ParentType, ContextType>;
  id?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  profileId?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  quest?: Resolver<ResolversTypes['LiveLikeQuest'], ParentType, ContextType>;
  questId?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  rewardsClaimedAt?: Resolver<Maybe<ResolversTypes['NonEmptyString']>, ParentType, ContextType>;
  rewardsStatus?: Resolver<ResolversTypes['LiveLikeUserQuestRewardStatus'], ParentType, ContextType>;
  status?: Resolver<ResolversTypes['LiveLikeUserQuestStatusEnum'], ParentType, ContextType>;
  timerExpired?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  userQuestTasks?: Resolver<Maybe<Array<ResolversTypes['LiveLikeUserQuestTask']>>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeUserQuestCollectionResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeUserQuestCollection'] = ResolversParentTypes['LiveLikeUserQuestCollection']> = ResolversObject<{
  edges?: Resolver<Maybe<Array<ResolversTypes['LiveLikeUserQuestEdge']>>, ParentType, ContextType>;
  page?: Resolver<ResolversTypes['LiveLikePage'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeUserQuestEdgeResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeUserQuestEdge'] = ResolversParentTypes['LiveLikeUserQuestEdge']> = ResolversObject<{
  cursor?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  node?: Resolver<ResolversTypes['LiveLikeUserQuest'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeUserQuestRewardResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeUserQuestReward'] = ResolversParentTypes['LiveLikeUserQuestReward']> = ResolversObject<{
  id?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  questReward?: Resolver<ResolversTypes['LiveLikeQuestReward'], ParentType, ContextType>;
  rewardStatus?: Resolver<ResolversTypes['LiveLikeUserQuestRewardStatus'], ParentType, ContextType>;
  userQuestId?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeUserQuestRewardsConnectionResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeUserQuestRewardsConnection'] = ResolversParentTypes['LiveLikeUserQuestRewardsConnection']> = ResolversObject<{
  edges?: Resolver<Maybe<Array<Maybe<ResolversTypes['LiveLikeUserQuestRewardsEdge']>>>, ParentType, ContextType>;
  page?: Resolver<ResolversTypes['LiveLikePage'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeUserQuestRewardsEdgeResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeUserQuestRewardsEdge'] = ResolversParentTypes['LiveLikeUserQuestRewardsEdge']> = ResolversObject<{
  cursor?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  node?: Resolver<ResolversTypes['LiveLikeUserQuestReward'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeUserQuestTaskResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeUserQuestTask'] = ResolversParentTypes['LiveLikeUserQuestTask']> = ResolversObject<{
  completedAt?: Resolver<Maybe<ResolversTypes['DateTimeISO']>, ParentType, ContextType>;
  createdAt?: Resolver<ResolversTypes['NonEmptyString'], ParentType, ContextType>;
  id?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  progress?: Resolver<Maybe<ResolversTypes['NonNegativeInt']>, ParentType, ContextType>;
  questTask?: Resolver<ResolversTypes['LiveLikeQuestTask'], ParentType, ContextType>;
  status?: Resolver<ResolversTypes['LiveLikeUserQuestTaskStatusEnum'], ParentType, ContextType>;
  userQuestId?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeUserQuestTaskProgressResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeUserQuestTaskProgress'] = ResolversParentTypes['LiveLikeUserQuestTaskProgress']> = ResolversObject<{
  customIncrement?: Resolver<Maybe<ResolversTypes['NonNegativeInt']>, ParentType, ContextType>;
  customProgress?: Resolver<Maybe<ResolversTypes['NonNegativeInt']>, ParentType, ContextType>;
  id?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  userQuest?: Resolver<ResolversTypes['LiveLikeUserQuest'], ParentType, ContextType>;
  userQuestTaskId?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeUserReactionResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeUserReaction'] = ResolversParentTypes['LiveLikeUserReaction']> = ResolversObject<{
  clientId?: Resolver<ResolversTypes['NonEmptyString'], ParentType, ContextType>;
  createdAt?: Resolver<ResolversTypes['NonEmptyString'], ParentType, ContextType>;
  customData?: Resolver<Maybe<ResolversTypes['NonEmptyString']>, ParentType, ContextType>;
  id?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  reactedById?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  reactionId?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  reactionSpaceId?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  targetId?: Resolver<ResolversTypes['NonEmptyString'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeUserReactionCollectionResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeUserReactionCollection'] = ResolversParentTypes['LiveLikeUserReactionCollection']> = ResolversObject<{
  edges?: Resolver<Maybe<Array<ResolversTypes['LiveLikeUserReactionEdge']>>, ParentType, ContextType>;
  page?: Resolver<ResolversTypes['LiveLikePage'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeUserReactionCountCollectionResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeUserReactionCountCollection'] = ResolversParentTypes['LiveLikeUserReactionCountCollection']> = ResolversObject<{
  edges?: Resolver<Maybe<Array<ResolversTypes['LiveLikeUserReactionCountEdge']>>, ParentType, ContextType>;
  page?: Resolver<ResolversTypes['LiveLikePage'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeUserReactionCountEdgeResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeUserReactionCountEdge'] = ResolversParentTypes['LiveLikeUserReactionCountEdge']> = ResolversObject<{
  cursor?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  node?: Resolver<ResolversTypes['LiveLikeReactions'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeUserReactionEdgeResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeUserReactionEdge'] = ResolversParentTypes['LiveLikeUserReactionEdge']> = ResolversObject<{
  cursor?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  node?: Resolver<ResolversTypes['LiveLikeUserReaction'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeVideoAlertResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeVideoAlert'] = ResolversParentTypes['LiveLikeVideoAlert']> = ResolversObject<{
  clientId?: Resolver<ResolversTypes['NonEmptyString'], ParentType, ContextType>;
  createdAt?: Resolver<ResolversTypes['DateTimeISO'], ParentType, ContextType>;
  createdBy?: Resolver<ResolversTypes['LiveLikeWidgetCreator'], ParentType, ContextType>;
  customData?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  id?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  interactiveUntil?: Resolver<Maybe<ResolversTypes['DateTimeISO']>, ParentType, ContextType>;
  kind?: Resolver<ResolversTypes['LiveLikeWidgetKindEnum'], ParentType, ContextType>;
  linkLabel?: Resolver<Maybe<ResolversTypes['NonEmptyString']>, ParentType, ContextType>;
  linkUrl?: Resolver<Maybe<ResolversTypes['URL']>, ParentType, ContextType>;
  playbackTimeMs?: Resolver<Maybe<ResolversTypes['NonNegativeInt']>, ParentType, ContextType>;
  programDateTime?: Resolver<Maybe<ResolversTypes['DateTimeISO']>, ParentType, ContextType>;
  programId?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  publishDelay?: Resolver<ResolversTypes['Duration'], ParentType, ContextType>;
  publishedAt?: Resolver<Maybe<ResolversTypes['DateTimeISO']>, ParentType, ContextType>;
  pubnubEnabled?: Resolver<ResolversTypes['Boolean'], ParentType, ContextType>;
  reportCount?: Resolver<Maybe<ResolversTypes['LiveLikeWidgetReportCount']>, ParentType, ContextType>;
  scheduledAt?: Resolver<Maybe<ResolversTypes['DateTimeISO']>, ParentType, ContextType>;
  sponsorIds?: Resolver<Maybe<Array<ResolversTypes['UUID']>>, ParentType, ContextType>;
  status?: Resolver<ResolversTypes['LiveLikeWidgetStatusEnum'], ParentType, ContextType>;
  text?: Resolver<Maybe<ResolversTypes['NonEmptyString']>, ParentType, ContextType>;
  timeout?: Resolver<ResolversTypes['Duration'], ParentType, ContextType>;
  title?: Resolver<Maybe<ResolversTypes['NonEmptyString']>, ParentType, ContextType>;
  uniqueImpressionCount?: Resolver<Maybe<ResolversTypes['NonNegativeInt']>, ParentType, ContextType>;
  videoUrl?: Resolver<ResolversTypes['URL'], ParentType, ContextType>;
  widgetAttributes?: Resolver<Maybe<Array<ResolversTypes['LiveLikeKeyValuePair']>>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeWidgetResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeWidget'] = ResolversParentTypes['LiveLikeWidget']> = ResolversObject<{
  __resolveType: TypeResolveFn<'LiveLikeAlert' | 'LiveLikeImagePoll' | 'LiveLikeImagePrediction' | 'LiveLikeImagePredictionFollowUp' | 'LiveLikeImageQuiz' | 'LiveLikeRichPost' | 'LiveLikeSocialEmbed' | 'LiveLikeTextPoll' | 'LiveLikeTextPrediction' | 'LiveLikeTextPredictionFollowUp' | 'LiveLikeTextQuiz' | 'LiveLikeVideoAlert', ParentType, ContextType>;
}>;

export type LiveLikeWidgetBaseResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeWidgetBase'] = ResolversParentTypes['LiveLikeWidgetBase']> = ResolversObject<{
  __resolveType: TypeResolveFn<'LiveLikeAlert' | 'LiveLikeImagePoll' | 'LiveLikeImagePrediction' | 'LiveLikeImagePredictionFollowUp' | 'LiveLikeImageQuiz' | 'LiveLikeRichPost' | 'LiveLikeSocialEmbed' | 'LiveLikeTextPoll' | 'LiveLikeTextPrediction' | 'LiveLikeTextPredictionFollowUp' | 'LiveLikeTextQuiz' | 'LiveLikeVideoAlert', ParentType, ContextType>;
  clientId?: Resolver<ResolversTypes['NonEmptyString'], ParentType, ContextType>;
  createdAt?: Resolver<ResolversTypes['DateTimeISO'], ParentType, ContextType>;
  createdBy?: Resolver<ResolversTypes['LiveLikeWidgetCreator'], ParentType, ContextType>;
  customData?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  id?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  interactiveUntil?: Resolver<Maybe<ResolversTypes['DateTimeISO']>, ParentType, ContextType>;
  kind?: Resolver<ResolversTypes['LiveLikeWidgetKindEnum'], ParentType, ContextType>;
  playbackTimeMs?: Resolver<Maybe<ResolversTypes['NonNegativeInt']>, ParentType, ContextType>;
  programDateTime?: Resolver<Maybe<ResolversTypes['DateTimeISO']>, ParentType, ContextType>;
  programId?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  publishDelay?: Resolver<ResolversTypes['Duration'], ParentType, ContextType>;
  publishedAt?: Resolver<Maybe<ResolversTypes['DateTimeISO']>, ParentType, ContextType>;
  pubnubEnabled?: Resolver<ResolversTypes['Boolean'], ParentType, ContextType>;
  reportCount?: Resolver<Maybe<ResolversTypes['LiveLikeWidgetReportCount']>, ParentType, ContextType>;
  scheduledAt?: Resolver<Maybe<ResolversTypes['DateTimeISO']>, ParentType, ContextType>;
  sponsorIds?: Resolver<Maybe<Array<ResolversTypes['UUID']>>, ParentType, ContextType>;
  status?: Resolver<ResolversTypes['LiveLikeWidgetStatusEnum'], ParentType, ContextType>;
  timeout?: Resolver<ResolversTypes['Duration'], ParentType, ContextType>;
  uniqueImpressionCount?: Resolver<Maybe<ResolversTypes['NonNegativeInt']>, ParentType, ContextType>;
  widgetAttributes?: Resolver<Maybe<Array<ResolversTypes['LiveLikeKeyValuePair']>>, ParentType, ContextType>;
}>;

export type LiveLikeWidgetCollectionResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeWidgetCollection'] = ResolversParentTypes['LiveLikeWidgetCollection']> = ResolversObject<{
  edges?: Resolver<Maybe<Array<Maybe<ResolversTypes['LiveLikeWidgetEdge']>>>, ParentType, ContextType>;
  order?: Resolver<Maybe<ResolversTypes['LiveLikeWidgetOrder']>, ParentType, ContextType>;
  page?: Resolver<ResolversTypes['LiveLikePage'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeWidgetCreatorResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeWidgetCreator'] = ResolversParentTypes['LiveLikeWidgetCreator']> = ResolversObject<{
  avatar?: Resolver<Maybe<ResolversTypes['Avatar']>, ParentType, ContextType>;
  customId?: Resolver<Maybe<ResolversTypes['NonEmptyString']>, ParentType, ContextType>;
  id?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  name?: Resolver<ResolversTypes['NonEmptyString'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeWidgetEdgeResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeWidgetEdge'] = ResolversParentTypes['LiveLikeWidgetEdge']> = ResolversObject<{
  cursor?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  node?: Resolver<ResolversTypes['LiveLikeWidget'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeWidgetInteractionResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeWidgetInteraction'] = ResolversParentTypes['LiveLikeWidgetInteraction']> = ResolversObject<{
  createdAt?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  id?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  leaderboardRewards?: Resolver<Maybe<Array<ResolversTypes['LiveLikeLeaderboardReward']>>, ParentType, ContextType>;
  optionId?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  profileId?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  rewards?: Resolver<Maybe<Array<ResolversTypes['LiveLikeReward']>>, ParentType, ContextType>;
  widget?: Resolver<Maybe<ResolversTypes['LiveLikeWidget']>, ParentType, ContextType>;
  widgetId?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  widgetKind?: Resolver<ResolversTypes['LiveLikeWidgetInteractionEnum'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeWidgetInteractionBaseResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeWidgetInteractionBase'] = ResolversParentTypes['LiveLikeWidgetInteractionBase']> = ResolversObject<{
  __resolveType: TypeResolveFn<'LiveLikeImagePollVote' | 'LiveLikeImagePredictionVote' | 'LiveLikeImageQuizAnswer' | 'LiveLikeTextPollVote' | 'LiveLikeTextPredictionVote' | 'LiveLikeTextQuizAnswer', ParentType, ContextType>;
  createdAt?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  id?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  leaderboardRewards?: Resolver<Maybe<Array<ResolversTypes['LiveLikeLeaderboardReward']>>, ParentType, ContextType>;
  profileId?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  rewards?: Resolver<Maybe<Array<ResolversTypes['LiveLikeReward']>>, ParentType, ContextType>;
  widgetId?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  widgetKind?: Resolver<ResolversTypes['LiveLikeWidgetInteractionEnum'], ParentType, ContextType>;
}>;

export type LiveLikeWidgetInteractionBaseCreateInputResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeWidgetInteractionBaseCreateInput'] = ResolversParentTypes['LiveLikeWidgetInteractionBaseCreateInput']> = ResolversObject<{
  __resolveType: TypeResolveFn<null, ParentType, ContextType>;
  widgetId?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
}>;

export type LiveLikeWidgetInteractionUnionResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeWidgetInteractionUnion'] = ResolversParentTypes['LiveLikeWidgetInteractionUnion']> = ResolversObject<{
  __resolveType: TypeResolveFn<'LiveLikeImagePollVote' | 'LiveLikeImagePredictionVote' | 'LiveLikeImageQuizAnswer' | 'LiveLikeTextPollVote' | 'LiveLikeTextPredictionVote' | 'LiveLikeTextQuizAnswer', ParentType, ContextType>;
}>;

export type LiveLikeWidgetInteractionsResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeWidgetInteractions'] = ResolversParentTypes['LiveLikeWidgetInteractions']> = ResolversObject<{
  interactions?: Resolver<Maybe<Array<ResolversTypes['LiveLikeWidgetInteractionUnion']>>, ParentType, ContextType>;
  kind?: Resolver<ResolversTypes['LiveLikeWidgetInteractionEnum'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeWidgetOrderResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeWidgetOrder'] = ResolversParentTypes['LiveLikeWidgetOrder']> = ResolversObject<{
  field?: Resolver<Maybe<ResolversTypes['LiveLikeWidgetOrderField']>, ParentType, ContextType>;
  order?: Resolver<Maybe<ResolversTypes['LiveLikeOrderEnum']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeWidgetPublishResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeWidgetPublish'] = ResolversParentTypes['LiveLikeWidgetPublish']> = ResolversObject<{
  programDateTime?: Resolver<Maybe<ResolversTypes['DateTimeISO']>, ParentType, ContextType>;
  publishDelay?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  publishedAt?: Resolver<Maybe<ResolversTypes['DateTimeISO']>, ParentType, ContextType>;
  scheduledAt?: Resolver<Maybe<ResolversTypes['DateTimeISO']>, ParentType, ContextType>;
  status?: Resolver<ResolversTypes['LiveLikeWidgetStatusEnum'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeWidgetReportResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeWidgetReport'] = ResolversParentTypes['LiveLikeWidgetReport']> = ResolversObject<{
  clientId?: Resolver<ResolversTypes['NonEmptyString'], ParentType, ContextType>;
  comment?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  createdAt?: Resolver<ResolversTypes['DateTimeISO'], ParentType, ContextType>;
  id?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  moderatedAt?: Resolver<Maybe<ResolversTypes['DateTimeISO']>, ParentType, ContextType>;
  moderatedBy?: Resolver<Maybe<ResolversTypes['UUID']>, ParentType, ContextType>;
  moderatorComment?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  programId?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  status?: Resolver<ResolversTypes['LiveLikeWidgetReportStatusEnum'], ParentType, ContextType>;
  widgetId?: Resolver<ResolversTypes['UUID'], ParentType, ContextType>;
  widgetKind?: Resolver<ResolversTypes['LiveLikeWidgetKindEnum'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeWidgetReportCollectionResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeWidgetReportCollection'] = ResolversParentTypes['LiveLikeWidgetReportCollection']> = ResolversObject<{
  edges?: Resolver<Maybe<Array<Maybe<ResolversTypes['LiveLikeWidgetReportEdge']>>>, ParentType, ContextType>;
  page?: Resolver<ResolversTypes['LiveLikePage'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeWidgetReportCountResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeWidgetReportCount'] = ResolversParentTypes['LiveLikeWidgetReportCount']> = ResolversObject<{
  accepted?: Resolver<ResolversTypes['NonNegativeInt'], ParentType, ContextType>;
  dismissed?: Resolver<ResolversTypes['NonNegativeInt'], ParentType, ContextType>;
  pending?: Resolver<ResolversTypes['NonNegativeInt'], ParentType, ContextType>;
  total?: Resolver<ResolversTypes['NonNegativeInt'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type LiveLikeWidgetReportEdgeResolvers<ContextType = any, ParentType extends ResolversParentTypes['LiveLikeWidgetReportEdge'] = ResolversParentTypes['LiveLikeWidgetReportEdge']> = ResolversObject<{
  cursor?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  node?: Resolver<ResolversTypes['LiveLikeWidgetReport'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export interface LocaleScalarConfig extends GraphQLScalarTypeConfig<ResolversTypes['Locale'], any> {
  name: 'Locale';
}

export type LocalizationResolvers<ContextType = any, ParentType extends ResolversParentTypes['Localization'] = ResolversParentTypes['Localization']> = ResolversObject<{
  language?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  value?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type MediaResolvers<ContextType = any, ParentType extends ResolversParentTypes['Media'] = ResolversParentTypes['Media']> = ResolversObject<{
  _id?: Resolver<Maybe<ResolversTypes['MongoID']>, ParentType, ContextType>;
  clip?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  image?: Resolver<Maybe<ResolversTypes['Image']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type MenuResolvers<ContextType = any, ParentType extends ResolversParentTypes['Menu'] = ResolversParentTypes['Menu']> = ResolversObject<{
  _id?: Resolver<ResolversTypes['MongoID'], ParentType, ContextType>;
  cmsId?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  id?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  isPublished?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  language?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  links?: Resolver<Maybe<Array<Maybe<ResolversTypes['MenuLinks']>>>, ParentType, ContextType>;
  schemaVersion?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  tenant?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  title?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  uuid?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type MenuLinksResolvers<ContextType = any, ParentType extends ResolversParentTypes['MenuLinks'] = ResolversParentTypes['MenuLinks']> = ResolversObject<{
  _id?: Resolver<Maybe<ResolversTypes['MongoID']>, ParentType, ContextType>;
  children?: Resolver<Maybe<Array<Maybe<ResolversTypes['MenuLinks']>>>, ParentType, ContextType>;
  options?: Resolver<Maybe<ResolversTypes['MenuOptions']>, ParentType, ContextType>;
  tagGroups?: Resolver<Maybe<Array<Maybe<ResolversTypes['TagGroup']>>>, ParentType, ContextType>;
  tags?: Resolver<Maybe<Array<Maybe<ResolversTypes['TagV2']>>>, ParentType, ContextType>;
  text?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  url?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  weight?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type MenuOptionsResolvers<ContextType = any, ParentType extends ResolversParentTypes['MenuOptions'] = ResolversParentTypes['MenuOptions']> = ResolversObject<{
  _id?: Resolver<Maybe<ResolversTypes['MongoID']>, ParentType, ContextType>;
  attributes?: Resolver<Maybe<ResolversTypes['MenuOptionsAttributes']>, ParentType, ContextType>;
  expanded?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  images?: Resolver<Maybe<Array<Maybe<ResolversTypes['ImageWithStyle']>>>, ParentType, ContextType>;
  routes?: Resolver<Maybe<Array<Maybe<ResolversTypes['MenuRoutes']>>>, ParentType, ContextType>;
  target?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type MenuOptionsAttributesResolvers<ContextType = any, ParentType extends ResolversParentTypes['MenuOptionsAttributes'] = ResolversParentTypes['MenuOptionsAttributes']> = ResolversObject<{
  class?: Resolver<Maybe<Array<Maybe<ResolversTypes['String']>>>, ParentType, ContextType>;
  title?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type MenuRoutesResolvers<ContextType = any, ParentType extends ResolversParentTypes['MenuRoutes'] = ResolversParentTypes['MenuRoutes']> = ResolversObject<{
  _id?: Resolver<Maybe<ResolversTypes['MongoID']>, ParentType, ContextType>;
  id?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  path?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  title?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type MetadataResolvers<ContextType = any, ParentType extends ResolversParentTypes['Metadata'] = ResolversParentTypes['Metadata']> = ResolversObject<{
  cdn?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type ModuleMetaDataResolvers<ContextType = any, ParentType extends ResolversParentTypes['ModuleMetaData'] = ResolversParentTypes['ModuleMetaData']> = ResolversObject<{
  author?: Resolver<Maybe<ResolversTypes['TagV2']>, ParentType, ContextType>;
  brand?: Resolver<Maybe<ResolversTypes['ContentBrand']>, ParentType, ContextType>;
  communityTag?: Resolver<Maybe<ResolversTypes['TagV2']>, ParentType, ContextType>;
  hash?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  tenant?: Resolver<Maybe<ResolversTypes['Tenant']>, ParentType, ContextType>;
  videoContentId?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export interface MongoIdScalarConfig extends GraphQLScalarTypeConfig<ResolversTypes['MongoID'], any> {
  name: 'MongoID';
}

export type MutationResolvers<ContextType = any, ParentType extends ResolversParentTypes['Mutation'] = ResolversParentTypes['Mutation']> = ResolversObject<{
  addAlertRank?: Resolver<Maybe<ResolversTypes['AddAlertRankResponse']>, ParentType, ContextType, RequireFields<MutationAddAlertRankArgs, 'tenant'>>;
  addContentToPackage?: Resolver<ResolversTypes['ContentModule'], ParentType, ContextType, RequireFields<MutationAddContentToPackageArgs, 'description' | 'lastModifiedBy' | 'packageModuleId' | 'position' | 'thumbnail' | 'title'>>;
  addDevice?: Resolver<Maybe<ResolversTypes['Device']>, ParentType, ContextType, RequireFields<MutationAddDeviceArgs, 'device' | 'tenant'>>;
  addPushNotificationsAlertRank?: Resolver<Maybe<ResolversTypes['PushNotificationAlertRankResponse']>, ParentType, ContextType, RequireFields<MutationAddPushNotificationsAlertRankArgs, 'tenant'>>;
  addUserTags?: Resolver<Maybe<Array<Maybe<ResolversTypes['TagV2']>>>, ParentType, ContextType, RequireFields<MutationAddUserTagsArgs, 'inputs' | 'tenant'>>;
  awardLiveLikeBadge?: Resolver<Maybe<ResolversTypes['LiveLikeEarnedBadge']>, ParentType, ContextType, RequireFields<MutationAwardLiveLikeBadgeArgs, 'input'>>;
  blockLiveLikeProfile?: Resolver<Maybe<ResolversTypes['LiveLikeBlockProfile']>, ParentType, ContextType, RequireFields<MutationBlockLiveLikeProfileArgs, 'profileId'>>;
  blockProfile?: Resolver<Maybe<ResolversTypes['blockProfileResponse']>, ParentType, ContextType, RequireFields<MutationBlockProfileArgs, 'blockedProfileID'>>;
  claimLiveLikeUserQuestReward?: Resolver<Maybe<ResolversTypes['LiveLikeUserQuest']>, ParentType, ContextType, RequireFields<MutationClaimLiveLikeUserQuestRewardArgs, 'input'>>;
  createExternalArticle?: Resolver<ResolversTypes['ExternalArticle'], ParentType, ContextType, RequireFields<MutationCreateExternalArticleArgs, 'providerName' | 'source' | 'url'>>;
  createImagePollByTenant?: Resolver<Maybe<ResolversTypes['CreatePollResponse']>, ParentType, ContextType, RequireFields<MutationCreateImagePollByTenantArgs, 'poll' | 'tenant'>>;
  createLiveLikeAlert?: Resolver<Maybe<ResolversTypes['LiveLikeAlert']>, ParentType, ContextType, RequireFields<MutationCreateLiveLikeAlertArgs, 'input'>>;
  createLiveLikeChatRoom?: Resolver<Maybe<ResolversTypes['LiveLikeChatRoom']>, ParentType, ContextType, RequireFields<MutationCreateLiveLikeChatRoomArgs, 'input'>>;
  createLiveLikeComment?: Resolver<Maybe<ResolversTypes['LiveLikeComment']>, ParentType, ContextType, RequireFields<MutationCreateLiveLikeCommentArgs, 'input'>>;
  createLiveLikeCommentBoard?: Resolver<Maybe<ResolversTypes['LiveLikeCommentBoard']>, ParentType, ContextType, RequireFields<MutationCreateLiveLikeCommentBoardArgs, 'input'>>;
  createLiveLikeCommentBoardBan?: Resolver<Maybe<ResolversTypes['LiveLikeCommentBoardBan']>, ParentType, ContextType, RequireFields<MutationCreateLiveLikeCommentBoardBanArgs, 'input'>>;
  createLiveLikeCommentReply?: Resolver<Maybe<ResolversTypes['LiveLikeComment']>, ParentType, ContextType, RequireFields<MutationCreateLiveLikeCommentReplyArgs, 'input'>>;
  createLiveLikeCommentReport?: Resolver<Maybe<ResolversTypes['LiveLikeCommentReport']>, ParentType, ContextType, RequireFields<MutationCreateLiveLikeCommentReportArgs, 'input'>>;
  createLiveLikeImagePoll?: Resolver<Maybe<ResolversTypes['LiveLikeImagePoll']>, ParentType, ContextType, RequireFields<MutationCreateLiveLikeImagePollArgs, 'input'>>;
  createLiveLikeImagePollVote?: Resolver<Maybe<ResolversTypes['LiveLikeImagePollVote']>, ParentType, ContextType, RequireFields<MutationCreateLiveLikeImagePollVoteArgs, 'input'>>;
  createLiveLikeImagePrediction?: Resolver<Maybe<ResolversTypes['LiveLikeImagePrediction']>, ParentType, ContextType, RequireFields<MutationCreateLiveLikeImagePredictionArgs, 'input'>>;
  createLiveLikeImagePredictionFollowUp?: Resolver<Maybe<ResolversTypes['LiveLikeImagePredictionFollowUp']>, ParentType, ContextType, RequireFields<MutationCreateLiveLikeImagePredictionFollowUpArgs, 'input'>>;
  createLiveLikeImagePredictionVote?: Resolver<Maybe<ResolversTypes['LiveLikeImagePredictionVote']>, ParentType, ContextType, RequireFields<MutationCreateLiveLikeImagePredictionVoteArgs, 'input'>>;
  createLiveLikeImageQuiz?: Resolver<Maybe<ResolversTypes['LiveLikeImageQuiz']>, ParentType, ContextType, RequireFields<MutationCreateLiveLikeImageQuizArgs, 'input'>>;
  createLiveLikeImageQuizAnswer?: Resolver<Maybe<ResolversTypes['LiveLikeImageQuizAnswer']>, ParentType, ContextType, RequireFields<MutationCreateLiveLikeImageQuizAnswerArgs, 'input'>>;
  createLiveLikeLeaderboard?: Resolver<Maybe<ResolversTypes['LiveLikeLeaderboard']>, ParentType, ContextType, RequireFields<MutationCreateLiveLikeLeaderboardArgs, 'input'>>;
  createLiveLikePollVote?: Resolver<Maybe<ResolversTypes['LiveLikeWidgetInteraction']>, ParentType, ContextType, RequireFields<MutationCreateLiveLikePollVoteArgs, 'input'>>;
  createLiveLikeProfile?: Resolver<Maybe<ResolversTypes['LiveLikeProfileAuth']>, ParentType, ContextType, RequireFields<MutationCreateLiveLikeProfileArgs, 'input'>>;
  createLiveLikeProfileByCustomId?: Resolver<Maybe<ResolversTypes['LiveLikeProfileAuth']>, ParentType, ContextType, RequireFields<MutationCreateLiveLikeProfileByCustomIdArgs, 'input'>>;
  createLiveLikeProfileRelationship?: Resolver<Maybe<ResolversTypes['LiveLikeProfileRelationship']>, ParentType, ContextType, RequireFields<MutationCreateLiveLikeProfileRelationshipArgs, 'input'>>;
  createLiveLikeProfileRelationshipType?: Resolver<Maybe<ResolversTypes['LiveLikeProfileRelationshipType']>, ParentType, ContextType, RequireFields<MutationCreateLiveLikeProfileRelationshipTypeArgs, 'input'>>;
  createLiveLikeProgram?: Resolver<Maybe<ResolversTypes['LiveLikeProgram']>, ParentType, ContextType, RequireFields<MutationCreateLiveLikeProgramArgs, 'input'>>;
  createLiveLikeProgramBan?: Resolver<Maybe<ResolversTypes['LiveLikeProgramBan']>, ParentType, ContextType, RequireFields<MutationCreateLiveLikeProgramBanArgs, 'input'>>;
  createLiveLikeQuest?: Resolver<Maybe<ResolversTypes['LiveLikeQuest']>, ParentType, ContextType, RequireFields<MutationCreateLiveLikeQuestArgs, 'input'>>;
  createLiveLikeReactionSpace?: Resolver<Maybe<ResolversTypes['LiveLikeReactionSpace']>, ParentType, ContextType, RequireFields<MutationCreateLiveLikeReactionSpaceArgs, 'input'>>;
  createLiveLikeRewardItem?: Resolver<Maybe<ResolversTypes['LiveLikeRewardItem']>, ParentType, ContextType, RequireFields<MutationCreateLiveLikeRewardItemArgs, 'input'>>;
  createLiveLikeRewardTable?: Resolver<Maybe<ResolversTypes['LiveLikeRewardTable']>, ParentType, ContextType, RequireFields<MutationCreateLiveLikeRewardTableArgs, 'input'>>;
  createLiveLikeRewardTableEntry?: Resolver<Maybe<ResolversTypes['LiveLikeRewardTableEntry']>, ParentType, ContextType, RequireFields<MutationCreateLiveLikeRewardTableEntryArgs, 'input'>>;
  createLiveLikeRichPost?: Resolver<Maybe<ResolversTypes['LiveLikeRichPost']>, ParentType, ContextType, RequireFields<MutationCreateLiveLikeRichPostArgs, 'input'>>;
  createLiveLikeRole?: Resolver<Maybe<ResolversTypes['LiveLikeRole']>, ParentType, ContextType, RequireFields<MutationCreateLiveLikeRoleArgs, 'input'>>;
  createLiveLikeRoleAssignment?: Resolver<Maybe<ResolversTypes['LiveLikeRoleAssignment']>, ParentType, ContextType, RequireFields<MutationCreateLiveLikeRoleAssignmentArgs, 'input'>>;
  createLiveLikeSocialEmbed?: Resolver<Maybe<ResolversTypes['LiveLikeSocialEmbed']>, ParentType, ContextType, RequireFields<MutationCreateLiveLikeSocialEmbedArgs, 'input'>>;
  createLiveLikeTextPoll?: Resolver<Maybe<ResolversTypes['LiveLikeTextPoll']>, ParentType, ContextType, RequireFields<MutationCreateLiveLikeTextPollArgs, 'input'>>;
  createLiveLikeTextPollVote?: Resolver<Maybe<ResolversTypes['LiveLikeTextPollVote']>, ParentType, ContextType, RequireFields<MutationCreateLiveLikeTextPollVoteArgs, 'input'>>;
  createLiveLikeTextPrediction?: Resolver<Maybe<ResolversTypes['LiveLikeTextPrediction']>, ParentType, ContextType, RequireFields<MutationCreateLiveLikeTextPredictionArgs, 'input'>>;
  createLiveLikeTextPredictionFollowUp?: Resolver<Maybe<ResolversTypes['LiveLikeTextPredictionFollowUp']>, ParentType, ContextType, RequireFields<MutationCreateLiveLikeTextPredictionFollowUpArgs, 'input'>>;
  createLiveLikeTextPredictionVote?: Resolver<Maybe<ResolversTypes['LiveLikeTextPredictionVote']>, ParentType, ContextType, RequireFields<MutationCreateLiveLikeTextPredictionVoteArgs, 'input'>>;
  createLiveLikeTextQuiz?: Resolver<Maybe<ResolversTypes['LiveLikeTextQuiz']>, ParentType, ContextType, RequireFields<MutationCreateLiveLikeTextQuizArgs, 'input'>>;
  createLiveLikeTextQuizAnswer?: Resolver<Maybe<ResolversTypes['LiveLikeTextQuizAnswer']>, ParentType, ContextType, RequireFields<MutationCreateLiveLikeTextQuizAnswerArgs, 'input'>>;
  createLiveLikeUserQuest?: Resolver<Maybe<ResolversTypes['LiveLikeUserQuest']>, ParentType, ContextType, RequireFields<MutationCreateLiveLikeUserQuestArgs, 'input'>>;
  createLiveLikeUserReaction?: Resolver<Maybe<ResolversTypes['LiveLikeUserReaction']>, ParentType, ContextType, RequireFields<MutationCreateLiveLikeUserReactionArgs, 'input'>>;
  createLiveLikeVideoAlert?: Resolver<Maybe<ResolversTypes['LiveLikeVideoAlert']>, ParentType, ContextType, RequireFields<MutationCreateLiveLikeVideoAlertArgs, 'input'>>;
  createPackageContentModule?: Resolver<ResolversTypes['ContentModule'], ParentType, ContextType, RequireFields<MutationCreatePackageContentModuleArgs, 'channels' | 'contentType' | 'lastModifiedBy' | 'title'>>;
  createPostByTenant?: Resolver<Maybe<ResolversTypes['CreatePostResponse']>, ParentType, ContextType, RequireFields<MutationCreatePostByTenantArgs, 'post' | 'tenant'>>;
  createProgramForTaxonomy?: Resolver<Maybe<ResolversTypes['CreateProgramResponse']>, ParentType, ContextType, RequireFields<MutationCreateProgramForTaxonomyArgs, 'taxonomyId' | 'tenant'>>;
  createStandaloneContentModule?: Resolver<ResolversTypes['StandaloneContentModule'], ParentType, ContextType, RequireFields<MutationCreateStandaloneContentModuleArgs, 'channels' | 'contentId' | 'contentType' | 'description' | 'lastModifiedBy' | 'thumbnail' | 'title'>>;
  createStaticPackages?: Resolver<Array<Maybe<ResolversTypes['ContentModule']>>, ParentType, ContextType, RequireFields<MutationCreateStaticPackagesArgs, 'contentType' | 'lastModifiedBy' | 'packageTypes'>>;
  createTextPollByTenant?: Resolver<Maybe<ResolversTypes['CreatePollResponse']>, ParentType, ContextType, RequireFields<MutationCreateTextPollByTenantArgs, 'poll' | 'tenant'>>;
  createTweetById?: Resolver<ResolversTypes['Tweet'], ParentType, ContextType, RequireFields<MutationCreateTweetByIdArgs, 'id'>>;
  creditLiveLikeRewardItem?: Resolver<Maybe<ResolversTypes['LiveLikeRewardItemTransaction']>, ParentType, ContextType, RequireFields<MutationCreditLiveLikeRewardItemArgs, 'input'>>;
  debitLiveLikeRewardItem?: Resolver<Maybe<ResolversTypes['LiveLikeRewardItemTransaction']>, ParentType, ContextType, RequireFields<MutationDebitLiveLikeRewardItemArgs, 'input'>>;
  deleteContentFromPackage?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType, RequireFields<MutationDeleteContentFromPackageArgs, 'contentModuleId' | 'packageContentModuleId'>>;
  deleteContentModule?: Resolver<ResolversTypes['String'], ParentType, ContextType, RequireFields<MutationDeleteContentModuleArgs, 'id'>>;
  deleteContentModuleByContentId?: Resolver<ResolversTypes['DeleteVideoContentModulesResult'], ParentType, ContextType, RequireFields<MutationDeleteContentModuleByContentIdArgs, 'contentId'>>;
  deleteDuplicateScheduledHighlightsPackages?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  deleteLiveLikeAlert?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType, RequireFields<MutationDeleteLiveLikeAlertArgs, 'id'>>;
  deleteLiveLikeChatRoom?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType, RequireFields<MutationDeleteLiveLikeChatRoomArgs, 'id'>>;
  deleteLiveLikeComment?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType, RequireFields<MutationDeleteLiveLikeCommentArgs, 'id'>>;
  deleteLiveLikeCommentBoard?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType, RequireFields<MutationDeleteLiveLikeCommentBoardArgs, 'id'>>;
  deleteLiveLikeCommentBoardBan?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType, RequireFields<MutationDeleteLiveLikeCommentBoardBanArgs, 'id'>>;
  deleteLiveLikeImagePoll?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType, RequireFields<MutationDeleteLiveLikeImagePollArgs, 'id'>>;
  deleteLiveLikeImagePrediction?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType, RequireFields<MutationDeleteLiveLikeImagePredictionArgs, 'id'>>;
  deleteLiveLikeImagePredictionFollowUp?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType, RequireFields<MutationDeleteLiveLikeImagePredictionFollowUpArgs, 'id'>>;
  deleteLiveLikeImageQuiz?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType, RequireFields<MutationDeleteLiveLikeImageQuizArgs, 'id'>>;
  deleteLiveLikeLeaderboard?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType, RequireFields<MutationDeleteLiveLikeLeaderboardArgs, 'id'>>;
  deleteLiveLikeProfile?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType, RequireFields<MutationDeleteLiveLikeProfileArgs, 'id'>>;
  deleteLiveLikeProfileBlock?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType, RequireFields<MutationDeleteLiveLikeProfileBlockArgs, 'id'>>;
  deleteLiveLikeProfileRelationship?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType, RequireFields<MutationDeleteLiveLikeProfileRelationshipArgs, 'id'>>;
  deleteLiveLikeProfileRelationshipType?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType, RequireFields<MutationDeleteLiveLikeProfileRelationshipTypeArgs, 'id'>>;
  deleteLiveLikeProgram?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType, RequireFields<MutationDeleteLiveLikeProgramArgs, 'id'>>;
  deleteLiveLikeProgramBan?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType, RequireFields<MutationDeleteLiveLikeProgramBanArgs, 'id'>>;
  deleteLiveLikeProgramByCustomId?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType, RequireFields<MutationDeleteLiveLikeProgramByCustomIdArgs, 'input'>>;
  deleteLiveLikeReactionSpace?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType, RequireFields<MutationDeleteLiveLikeReactionSpaceArgs, 'input'>>;
  deleteLiveLikeRewardItem?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType, RequireFields<MutationDeleteLiveLikeRewardItemArgs, 'id'>>;
  deleteLiveLikeRewardTable?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType, RequireFields<MutationDeleteLiveLikeRewardTableArgs, 'id'>>;
  deleteLiveLikeRewardTableEntry?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType, RequireFields<MutationDeleteLiveLikeRewardTableEntryArgs, 'input'>>;
  deleteLiveLikeRichPost?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType, RequireFields<MutationDeleteLiveLikeRichPostArgs, 'id'>>;
  deleteLiveLikeSocialEmbed?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType, RequireFields<MutationDeleteLiveLikeSocialEmbedArgs, 'id'>>;
  deleteLiveLikeTextPoll?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType, RequireFields<MutationDeleteLiveLikeTextPollArgs, 'id'>>;
  deleteLiveLikeTextPrediction?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType, RequireFields<MutationDeleteLiveLikeTextPredictionArgs, 'id'>>;
  deleteLiveLikeTextPredictionFollowUp?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType, RequireFields<MutationDeleteLiveLikeTextPredictionFollowUpArgs, 'id'>>;
  deleteLiveLikeTextQuiz?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType, RequireFields<MutationDeleteLiveLikeTextQuizArgs, 'id'>>;
  deleteLiveLikeUserReaction?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType, RequireFields<MutationDeleteLiveLikeUserReactionArgs, 'id'>>;
  deleteLiveLikeVideoAlert?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType, RequireFields<MutationDeleteLiveLikeVideoAlertArgs, 'id'>>;
  deleteLiveLikeWidget?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType, RequireFields<MutationDeleteLiveLikeWidgetArgs, 'input'>>;
  dismissLiveLikeCommentReport?: Resolver<Maybe<ResolversTypes['LiveLikeCommentReport']>, ParentType, ContextType, RequireFields<MutationDismissLiveLikeCommentReportArgs, 'id'>>;
  expireContentModules?: Resolver<Array<ResolversTypes['Int']>, ParentType, ContextType>;
  flushAdRegistryCache?: Resolver<Maybe<ResolversTypes['Int']>, ParentType, ContextType, RequireFields<MutationFlushAdRegistryCacheArgs, 'operationName'>>;
  flushAdSiteCache?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType, Partial<MutationFlushAdSiteCacheArgs>>;
  invokeLiveLikeRewardAction?: Resolver<Maybe<ResolversTypes['LiveLikeRewardAction']>, ParentType, ContextType, RequireFields<MutationInvokeLiveLikeRewardActionArgs, 'input'>>;
  linkLiveLikeLeaderboardWithProgram?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType, RequireFields<MutationLinkLiveLikeLeaderboardWithProgramArgs, 'input'>>;
  linkLiveLikeRewardTableWithProgram?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType, RequireFields<MutationLinkLiveLikeRewardTableWithProgramArgs, 'input'>>;
  login?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType, RequireFields<MutationLoginArgs, 'email' | 'password'>>;
  prepareImage?: Resolver<Maybe<ResolversTypes['PrepareImageResponse']>, ParentType, ContextType, RequireFields<MutationPrepareImageArgs, 'imageCount' | 'imageTypes' | 'tenant'>>;
  publishLiveLikeAlert?: Resolver<Maybe<ResolversTypes['LiveLikeWidgetPublish']>, ParentType, ContextType, RequireFields<MutationPublishLiveLikeAlertArgs, 'input'>>;
  publishLiveLikeImagePoll?: Resolver<Maybe<ResolversTypes['LiveLikeWidgetPublish']>, ParentType, ContextType, RequireFields<MutationPublishLiveLikeImagePollArgs, 'input'>>;
  publishLiveLikeImagePrediction?: Resolver<Maybe<ResolversTypes['LiveLikeWidgetPublish']>, ParentType, ContextType, RequireFields<MutationPublishLiveLikeImagePredictionArgs, 'input'>>;
  publishLiveLikeImagePredictionFollowUp?: Resolver<Maybe<ResolversTypes['LiveLikeWidgetPublish']>, ParentType, ContextType, RequireFields<MutationPublishLiveLikeImagePredictionFollowUpArgs, 'input'>>;
  publishLiveLikeImageQuiz?: Resolver<Maybe<ResolversTypes['LiveLikeWidgetPublish']>, ParentType, ContextType, RequireFields<MutationPublishLiveLikeImageQuizArgs, 'input'>>;
  publishLiveLikeRichPost?: Resolver<Maybe<ResolversTypes['LiveLikeWidgetPublish']>, ParentType, ContextType, RequireFields<MutationPublishLiveLikeRichPostArgs, 'input'>>;
  publishLiveLikeSocialEmbed?: Resolver<Maybe<ResolversTypes['LiveLikeWidgetPublish']>, ParentType, ContextType, RequireFields<MutationPublishLiveLikeSocialEmbedArgs, 'input'>>;
  publishLiveLikeTextPoll?: Resolver<Maybe<ResolversTypes['LiveLikeWidgetPublish']>, ParentType, ContextType, RequireFields<MutationPublishLiveLikeTextPollArgs, 'input'>>;
  publishLiveLikeTextPrediction?: Resolver<Maybe<ResolversTypes['LiveLikeWidgetPublish']>, ParentType, ContextType, RequireFields<MutationPublishLiveLikeTextPredictionArgs, 'input'>>;
  publishLiveLikeTextPredictionFollowUp?: Resolver<Maybe<ResolversTypes['LiveLikeWidgetPublish']>, ParentType, ContextType, RequireFields<MutationPublishLiveLikeTextPredictionFollowUpArgs, 'input'>>;
  publishLiveLikeTextQuiz?: Resolver<Maybe<ResolversTypes['LiveLikeWidgetPublish']>, ParentType, ContextType, RequireFields<MutationPublishLiveLikeTextQuizArgs, 'input'>>;
  publishLiveLikeVideoAlert?: Resolver<Maybe<ResolversTypes['LiveLikeWidgetPublish']>, ParentType, ContextType, RequireFields<MutationPublishLiveLikeVideoAlertArgs, 'input'>>;
  publishLiveLikeWidget?: Resolver<Maybe<ResolversTypes['LiveLikeWidgetPublish']>, ParentType, ContextType, RequireFields<MutationPublishLiveLikeWidgetArgs, 'input' | 'kind'>>;
  removeUserTags?: Resolver<Maybe<Array<Maybe<ResolversTypes['TagV2']>>>, ParentType, ContextType, RequireFields<MutationRemoveUserTagsArgs, 'tagUUIDS' | 'tenant'>>;
  reportLiveLikeWidget?: Resolver<Maybe<ResolversTypes['LiveLikeWidgetReport']>, ParentType, ContextType, RequireFields<MutationReportLiveLikeWidgetArgs, 'input'>>;
  revokeLiveLikeEarnedBadge?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType, RequireFields<MutationRevokeLiveLikeEarnedBadgeArgs, 'earnedBadgeId'>>;
  sendPushNotification?: Resolver<Maybe<ResolversTypes['PushNotification']>, ParentType, ContextType, RequireFields<MutationSendPushNotificationArgs, 'notification' | 'tenant'>>;
  setGlobalAlerts?: Resolver<Maybe<ResolversTypes['Settings']>, ParentType, ContextType, RequireFields<MutationSetGlobalAlertsArgs, 'input'>>;
  setGlobalSpoilerSettings?: Resolver<Maybe<ResolversTypes['Settings']>, ParentType, ContextType, RequireFields<MutationSetGlobalSpoilerSettingsArgs, 'spoilersEnabled'>>;
  setUserFavoriteTeams?: Resolver<Maybe<ResolversTypes['User']>, ParentType, ContextType, RequireFields<MutationSetUserFavoriteTeamsArgs, 'tagUUIDS' | 'tenant'>>;
  setUserSpoilers?: Resolver<Maybe<ResolversTypes['TagV2']>, ParentType, ContextType, RequireFields<MutationSetUserSpoilersArgs, 'spoilers' | 'tagUUID' | 'tenant'>>;
  startLiveLikeProgram?: Resolver<Maybe<ResolversTypes['LiveLikeProgramSchedule']>, ParentType, ContextType, RequireFields<MutationStartLiveLikeProgramArgs, 'id'>>;
  stopLiveLikeProgram?: Resolver<Maybe<ResolversTypes['LiveLikeProgramSchedule']>, ParentType, ContextType, RequireFields<MutationStopLiveLikeProgramArgs, 'id'>>;
  unblockProfile?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType, RequireFields<MutationUnblockProfileArgs, 'blockedProfileID'>>;
  unlinkLiveLikeLeaderboardFromProgram?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType, RequireFields<MutationUnlinkLiveLikeLeaderboardFromProgramArgs, 'input'>>;
  unlinkLiveLikeRewardTableWithProgram?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType, RequireFields<MutationUnlinkLiveLikeRewardTableWithProgramArgs, 'input'>>;
  updateLiveLikeChatRoom?: Resolver<Maybe<ResolversTypes['LiveLikeChatRoom']>, ParentType, ContextType, RequireFields<MutationUpdateLiveLikeChatRoomArgs, 'input'>>;
  updateLiveLikeCommentBoard?: Resolver<Maybe<ResolversTypes['LiveLikeCommentBoard']>, ParentType, ContextType, RequireFields<MutationUpdateLiveLikeCommentBoardArgs, 'input'>>;
  updateLiveLikeImagePollVote?: Resolver<Maybe<ResolversTypes['LiveLikeImagePollVote']>, ParentType, ContextType, RequireFields<MutationUpdateLiveLikeImagePollVoteArgs, 'input'>>;
  updateLiveLikeImagePredictionVote?: Resolver<Maybe<ResolversTypes['LiveLikeImagePredictionVote']>, ParentType, ContextType, RequireFields<MutationUpdateLiveLikeImagePredictionVoteArgs, 'input'>>;
  updateLiveLikeImageQuizAnswer?: Resolver<Maybe<ResolversTypes['LiveLikeImageQuizAnswer']>, ParentType, ContextType, RequireFields<MutationUpdateLiveLikeImageQuizAnswerArgs, 'input'>>;
  updateLiveLikeLeaderboard?: Resolver<Maybe<ResolversTypes['LiveLikeLeaderboard']>, ParentType, ContextType, RequireFields<MutationUpdateLiveLikeLeaderboardArgs, 'input'>>;
  updateLiveLikePollVote?: Resolver<Maybe<ResolversTypes['LiveLikeWidgetInteraction']>, ParentType, ContextType, RequireFields<MutationUpdateLiveLikePollVoteArgs, 'input'>>;
  updateLiveLikeProfile?: Resolver<Maybe<ResolversTypes['LiveLikeProfile']>, ParentType, ContextType, RequireFields<MutationUpdateLiveLikeProfileArgs, 'input'>>;
  updateLiveLikeProgram?: Resolver<Maybe<ResolversTypes['LiveLikeProgram']>, ParentType, ContextType, RequireFields<MutationUpdateLiveLikeProgramArgs, 'input'>>;
  updateLiveLikeProgramByCustomId?: Resolver<Maybe<ResolversTypes['LiveLikeProgram']>, ParentType, ContextType, RequireFields<MutationUpdateLiveLikeProgramByCustomIdArgs, 'input'>>;
  updateLiveLikeReactionSpace?: Resolver<Maybe<ResolversTypes['LiveLikeReactionSpacePatch']>, ParentType, ContextType, RequireFields<MutationUpdateLiveLikeReactionSpaceArgs, 'input'>>;
  updateLiveLikeRewardTable?: Resolver<Maybe<ResolversTypes['LiveLikeRewardTable']>, ParentType, ContextType, RequireFields<MutationUpdateLiveLikeRewardTableArgs, 'input'>>;
  updateLiveLikeTextPollVote?: Resolver<Maybe<ResolversTypes['LiveLikeTextPollVote']>, ParentType, ContextType, RequireFields<MutationUpdateLiveLikeTextPollVoteArgs, 'input'>>;
  updateLiveLikeTextPredictionVote?: Resolver<Maybe<ResolversTypes['LiveLikeTextPredictionVote']>, ParentType, ContextType, RequireFields<MutationUpdateLiveLikeTextPredictionVoteArgs, 'input'>>;
  updateLiveLikeTextQuizAnswer?: Resolver<Maybe<ResolversTypes['LiveLikeTextQuizAnswer']>, ParentType, ContextType, RequireFields<MutationUpdateLiveLikeTextQuizAnswerArgs, 'input'>>;
  updateLiveLikeUserQuestTaskProgress?: Resolver<Maybe<ResolversTypes['LiveLikeUserQuestTaskProgress']>, ParentType, ContextType, RequireFields<MutationUpdateLiveLikeUserQuestTaskProgressArgs, 'input'>>;
  updatePackageContentModule?: Resolver<ResolversTypes['ContentModule'], ParentType, ContextType, RequireFields<MutationUpdatePackageContentModuleArgs, 'contentModuleId'>>;
  updatePostByTenant?: Resolver<Maybe<ResolversTypes['CreatePostResponse']>, ParentType, ContextType, RequireFields<MutationUpdatePostByTenantArgs, 'post' | 'tenant'>>;
  updateStandaloneContentModule?: Resolver<ResolversTypes['ContentModule'], ParentType, ContextType, RequireFields<MutationUpdateStandaloneContentModuleArgs, 'id'>>;
  updateTextPollByTenant?: Resolver<Maybe<ResolversTypes['CreatePollResponse']>, ParentType, ContextType, RequireFields<MutationUpdateTextPollByTenantArgs, 'poll' | 'tenant'>>;
  updateUserTags?: Resolver<Maybe<Array<Maybe<ResolversTypes['TagV2']>>>, ParentType, ContextType, RequireFields<MutationUpdateUserTagsArgs, 'inputs' | 'tenant'>>;
  upsertPackageContentModules?: Resolver<Maybe<Array<Maybe<ResolversTypes['PackageContentModule']>>>, ParentType, ContextType, Partial<MutationUpsertPackageContentModulesArgs>>;
  upsertStandaloneContentModules?: Resolver<Array<ResolversTypes['ContentModule']>, ParentType, ContextType, RequireFields<MutationUpsertStandaloneContentModulesArgs, 'data'>>;
  upsertVideoState?: Resolver<Maybe<ResolversTypes['VideoV2Metadata']>, ParentType, ContextType, RequireFields<MutationUpsertVideoStateArgs, 'data'>>;
}>;

export type NameResolvers<ContextType = any, ParentType extends ResolversParentTypes['Name'] = ResolversParentTypes['Name']> = ResolversObject<{
  display_name?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  first?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  last?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type NavigationElementResolvers<ContextType = any, ParentType extends ResolversParentTypes['NavigationElement'] = ResolversParentTypes['NavigationElement']> = ResolversObject<{
  href?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  name?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  queryParameters?: Resolver<Maybe<ResolversTypes['NavigationQueryParameters']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type NavigationQueryParametersResolvers<ContextType = any, ParentType extends ResolversParentTypes['NavigationQueryParameters'] = ResolversParentTypes['NavigationQueryParameters']> = ResolversObject<{
  date?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  league?: Resolver<Maybe<ResolversTypes['StatsLeagues']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export interface NonEmptyStringScalarConfig extends GraphQLScalarTypeConfig<ResolversTypes['NonEmptyString'], any> {
  name: 'NonEmptyString';
}

export interface NonNegativeFloatScalarConfig extends GraphQLScalarTypeConfig<ResolversTypes['NonNegativeFloat'], any> {
  name: 'NonNegativeFloat';
}

export interface NonNegativeIntScalarConfig extends GraphQLScalarTypeConfig<ResolversTypes['NonNegativeInt'], any> {
  name: 'NonNegativeInt';
}

export type NotificationMethodResolvers<ContextType = any, ParentType extends ResolversParentTypes['NotificationMethod'] = ResolversParentTypes['NotificationMethod']> = ResolversObject<{
  enabled?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  type?: Resolver<Maybe<ResolversTypes['CategoryType']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type NotificationsResolvers<ContextType = any, ParentType extends ResolversParentTypes['Notifications'] = ResolversParentTypes['Notifications']> = ResolversObject<{
  enabled?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  id?: Resolver<Maybe<ResolversTypes['Category']>, ParentType, ContextType>;
  notificationMethods?: Resolver<Maybe<Array<Maybe<ResolversTypes['NotificationMethod']>>>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type OfferingResolvers<ContextType = any, ParentType extends ResolversParentTypes['Offering'] = ResolversParentTypes['Offering']> = ResolversObject<{
  actions?: Resolver<Maybe<ResolversTypes['Action']>, ParentType, ContextType>;
  alternateIds?: Resolver<Maybe<Array<Maybe<ResolversTypes['Identifier']>>>, ParentType, ContextType>;
  appNames?: Resolver<Maybe<ResolversTypes['VideoAppName']>, ParentType, ContextType>;
  brands?: Resolver<Maybe<Array<Maybe<ResolversTypes['Brand']>>>, ParentType, ContextType>;
  contentClass?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  contentId?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  createdDateTime?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  editId?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  endDate?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  firstAvailableDate?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  id?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  lastModifiedDateTime?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  limitations?: Resolver<Maybe<ResolversTypes['Limitation']>, ParentType, ContextType>;
  packages?: Resolver<Maybe<Array<Maybe<ResolversTypes['String']>>>, ParentType, ContextType>;
  platforms?: Resolver<Maybe<ResolversTypes['AllowAll']>, ParentType, ContextType>;
  productLines?: Resolver<Maybe<Array<Maybe<ResolversTypes['ProductLine']>>>, ParentType, ContextType>;
  startDate?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  territories?: Resolver<Maybe<Array<Maybe<ResolversTypes['String']>>>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type PackageContentModuleResolvers<ContextType = any, ParentType extends ResolversParentTypes['PackageContentModule'] = ResolversParentTypes['PackageContentModule']> = ResolversObject<{
  adsConfig?: Resolver<Maybe<ResolversTypes['AdsConfiguration']>, ParentType, ContextType>;
  alertRanks?: Resolver<Array<Maybe<ResolversTypes['AlertRank']>>, ParentType, ContextType, RequireFields<PackageContentModuleAlertRanksArgs, 'limit'>>;
  alertedChannelTagUUID?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  allowedCountries?: Resolver<Maybe<Array<Maybe<ResolversTypes['String']>>>, ParentType, ContextType>;
  commentsEnabled?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  components?: Resolver<Maybe<Array<Maybe<ResolversTypes['ComponentModule']>>>, ParentType, ContextType>;
  contentType?: Resolver<Maybe<ResolversTypes['ContentModuleType']>, ParentType, ContextType>;
  contents?: Resolver<Maybe<Array<Maybe<ResolversTypes['StandaloneContentModule']>>>, ParentType, ContextType>;
  description?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  expiresAt?: Resolver<Maybe<ResolversTypes['Date']>, ParentType, ContextType>;
  hidden?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  hiddenExpiresAt?: Resolver<Maybe<ResolversTypes['Date']>, ParentType, ContextType>;
  id?: Resolver<ResolversTypes['ID'], ParentType, ContextType>;
  insertedAt?: Resolver<Maybe<ResolversTypes['Date']>, ParentType, ContextType>;
  isAlerted?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  metaData?: Resolver<Maybe<ResolversTypes['ModuleMetaData']>, ParentType, ContextType>;
  orientation?: Resolver<ResolversTypes['ModuleOrientation'], ParentType, ContextType>;
  packageHeadline?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  packageTag?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  packageType?: Resolver<Maybe<ResolversTypes['PackageType']>, ParentType, ContextType>;
  scheduledDate?: Resolver<Maybe<ResolversTypes['Date']>, ParentType, ContextType>;
  state?: Resolver<Maybe<ResolversTypes['ModuleState']>, ParentType, ContextType>;
  title?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  uniqueTitle?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  updatedAt?: Resolver<Maybe<ResolversTypes['Date']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type PageResolvers<ContextType = any, ParentType extends ResolversParentTypes['Page'] = ResolversParentTypes['Page']> = ResolversObject<{
  _id?: Resolver<ResolversTypes['MongoID'], ParentType, ContextType>;
  adsConfig?: Resolver<Maybe<ResolversTypes['AdsConfiguration']>, ParentType, ContextType>;
  body?: Resolver<Maybe<ResolversTypes['PageBody']>, ParentType, ContextType>;
  changed?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  cmsId?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  components?: Resolver<Maybe<Array<Maybe<ResolversTypes['Component']>>>, ParentType, ContextType>;
  componentsConnection?: Resolver<ResolversTypes['ComponentsConnection'], ParentType, ContextType, Partial<PageComponentsConnectionArgs>>;
  created?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  headline?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  isPublished?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  language?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  metatags?: Resolver<Maybe<Array<Maybe<ResolversTypes['PageMetatags']>>>, ParentType, ContextType>;
  schemaVersion?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  tenant?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  title?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  type?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  uri?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  uuid?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type PageBodyResolvers<ContextType = any, ParentType extends ResolversParentTypes['PageBody'] = ResolversParentTypes['PageBody']> = ResolversObject<{
  _id?: Resolver<Maybe<ResolversTypes['MongoID']>, ParentType, ContextType>;
  format?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  summary?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  value?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type PageInfoResolvers<ContextType = any, ParentType extends ResolversParentTypes['PageInfo'] = ResolversParentTypes['PageInfo']> = ResolversObject<{
  endCursor?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  hasNextPage?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  hasPreviousPage?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  startCursor?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type PageMetatagsResolvers<ContextType = any, ParentType extends ResolversParentTypes['PageMetatags'] = ResolversParentTypes['PageMetatags']> = ResolversObject<{
  _id?: Resolver<Maybe<ResolversTypes['MongoID']>, ParentType, ContextType>;
  content?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  key?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  type?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type PeriodScoreResolvers<ContextType = any, ParentType extends ResolversParentTypes['PeriodScore'] = ResolversParentTypes['PeriodScore']> = ResolversObject<{
  number?: Resolver<Maybe<ResolversTypes['Int']>, ParentType, ContextType>;
  score?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  subscore?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  type?: Resolver<Maybe<ResolversTypes['PeriodScoreType']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type PlaylistResolvers<ContextType = any, ParentType extends ResolversParentTypes['Playlist'] = ResolversParentTypes['Playlist']> = ResolversObject<{
  _id?: Resolver<ResolversTypes['MongoID'], ParentType, ContextType>;
  changed?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  cmsId?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  created?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  headline?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  isPublished?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  language?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  media?: Resolver<Maybe<Array<Maybe<ResolversTypes['Media']>>>, ParentType, ContextType>;
  schemaVersion?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  tagging?: Resolver<Maybe<ResolversTypes['Tagging']>, ParentType, ContextType>;
  tenant?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  title?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  type?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  uuid?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type PollResolvers<ContextType = any, ParentType extends ResolversParentTypes['Poll'] = ResolversParentTypes['Poll']> = ResolversObject<{
  contentId?: Resolver<ResolversTypes['ID'], ParentType, ContextType>;
  id?: Resolver<ResolversTypes['ID'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export interface PositiveIntScalarConfig extends GraphQLScalarTypeConfig<ResolversTypes['PositiveInt'], any> {
  name: 'PositiveInt';
}

export type PostResolvers<ContextType = any, ParentType extends ResolversParentTypes['Post'] = ResolversParentTypes['Post']> = ResolversObject<{
  content?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  contentId?: Resolver<Maybe<ResolversTypes['ID']>, ParentType, ContextType>;
  id?: Resolver<ResolversTypes['ID'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type PrepareImageResponseResolvers<ContextType = any, ParentType extends ResolversParentTypes['PrepareImageResponse'] = ResolversParentTypes['PrepareImageResponse']> = ResolversObject<{
  errorMsg?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  uploadId?: Resolver<ResolversTypes['ID'], ParentType, ContextType>;
  urlMappings?: Resolver<Array<ResolversTypes['UrlMapping']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type ProductResolvers<ContextType = any, ParentType extends ResolversParentTypes['Product'] = ResolversParentTypes['Product']> = ResolversObject<{
  _id?: Resolver<Maybe<ResolversTypes['MongoID']>, ParentType, ContextType>;
  cta?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  disclaimer?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  headline?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  isPayPalEnabled?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  price?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  productId?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  subHeadline?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  weight?: Resolver<Maybe<ResolversTypes['Float']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type ProductLineResolvers<ContextType = any, ParentType extends ResolversParentTypes['ProductLine'] = ResolversParentTypes['ProductLine']> = ResolversObject<{
  id?: Resolver<Maybe<ResolversTypes['Identifier']>, ParentType, ContextType>;
  label?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type ProgramResolvers<ContextType = any, ParentType extends ResolversParentTypes['Program'] = ResolversParentTypes['Program']> = ResolversObject<{
  alternateIds?: Resolver<Maybe<Array<Maybe<ResolversTypes['Identifier']>>>, ParentType, ContextType>;
  createdDateTime?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  credits?: Resolver<Maybe<Array<Maybe<ResolversTypes['Credit']>>>, ParentType, ContextType>;
  entityClass?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  entityType?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  id?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  lastModifiedDateTime?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  ratings?: Resolver<Maybe<Array<Maybe<ResolversTypes['Rating']>>>, ParentType, ContextType>;
  taxonomyReferenceGroups?: Resolver<Maybe<Array<Maybe<ResolversTypes['TaxonomyReferenceGroup']>>>, ParentType, ContextType>;
  titles?: Resolver<Maybe<Array<Maybe<ResolversTypes['VideoTitle']>>>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type ProgrammedContentResolvers<ContextType = any, ParentType extends ResolversParentTypes['ProgrammedContent'] = ResolversParentTypes['ProgrammedContent']> = ResolversObject<{
  __resolveType: TypeResolveFn<'Article' | 'ExternalArticle' | 'StatsBetting' | 'StatsGamecast' | 'Tweet' | 'UGCImagePoll' | 'UGCPost' | 'UGCTextPoll' | 'VideoV2', ParentType, ContextType>;
}>;

export type PushNotificationResolvers<ContextType = any, ParentType extends ResolversParentTypes['PushNotification'] = ResolversParentTypes['PushNotification']> = ResolversObject<{
  adParameters?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  alertCategories?: Resolver<Array<ResolversTypes['AlertCategory']>, ParentType, ContextType>;
  allowInRegions?: Resolver<Array<ResolversTypes['AlertRegion']>, ParentType, ContextType>;
  analytics?: Resolver<Maybe<ResolversTypes['AlertAnalytics']>, ParentType, ContextType>;
  attachments?: Resolver<Array<ResolversTypes['AlertMediaAttachment']>, ParentType, ContextType>;
  createdAt?: Resolver<ResolversTypes['DateTime'], ParentType, ContextType>;
  createdBy?: Resolver<ResolversTypes['ID'], ParentType, ContextType>;
  destinationOverride?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  destinations?: Resolver<Array<ResolversTypes['AlertDestination']>, ParentType, ContextType>;
  id?: Resolver<ResolversTypes['ID'], ParentType, ContextType>;
  showAlertCard?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  spoiler?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  tags?: Resolver<Array<ResolversTypes['TagV2']>, ParentType, ContextType>;
  text?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  title?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  url?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  userDestination?: Resolver<Maybe<ResolversTypes['UserDestination']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type PushNotificationAlertRankResponseResolvers<ContextType = any, ParentType extends ResolversParentTypes['PushNotificationAlertRankResponse'] = ResolversParentTypes['PushNotificationAlertRankResponse']> = ResolversObject<{
  message?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  status?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type QueryResolvers<ContextType = any, ParentType extends ResolversParentTypes['Query'] = ResolversParentTypes['Query']> = ResolversObject<{
  a2a?: Resolver<Array<ResolversTypes['A2AResult']>, ParentType, ContextType, RequireFields<QueryA2aArgs, 'articleUuid' | 'limit' | 'primaryPrioritizedTag' | 'secondaryPrioritizedTags' | 'version'>>;
  a2v?: Resolver<Array<ResolversTypes['A2VResult']>, ParentType, ContextType, RequireFields<QueryA2vArgs, 'articleUuid' | 'aspectRatio' | 'limit' | 'primaryPrioritizedTag' | 'secondaryPrioritizedTags' | 'version'>>;
  alertRanks?: Resolver<Array<ResolversTypes['AlertRank']>, ParentType, ContextType, RequireFields<QueryAlertRanksArgs, 'limit' | 'offset'>>;
  articleBlocklist?: Resolver<Array<ResolversTypes['BlockedContent']>, ParentType, ContextType, RequireFields<QueryArticleBlocklistArgs, 'limit'>>;
  contentModules?: Resolver<Maybe<Array<Maybe<ResolversTypes['ContentModule']>>>, ParentType, ContextType>;
  dsModel?: Resolver<Maybe<ResolversTypes['DsModel']>, ParentType, ContextType, RequireFields<QueryDsModelArgs, 'model'>>;
  fetchContentModuleByContentIdAndContentType?: Resolver<Array<Maybe<ResolversTypes['ContentModule']>>, ParentType, ContextType, RequireFields<QueryFetchContentModuleByContentIdAndContentTypeArgs, 'contentId' | 'contentType' | 'state'>>;
  fetchContentModuleById?: Resolver<Maybe<ResolversTypes['ContentModule']>, ParentType, ContextType, RequireFields<QueryFetchContentModuleByIdArgs, 'id'>>;
  fetchPackageByTypeAndTag?: Resolver<Maybe<Array<Maybe<ResolversTypes['PackageContentModule']>>>, ParentType, ContextType, RequireFields<QueryFetchPackageByTypeAndTagArgs, 'packageType' | 'state' | 'tagUUID'>>;
  fetchScheduledModules?: Resolver<Maybe<Array<Maybe<ResolversTypes['ContentModule']>>>, ParentType, ContextType, Partial<QueryFetchScheduledModulesArgs>>;
  findContentBrandBySourceUrl?: Resolver<Maybe<ResolversTypes['ContentBrand']>, ParentType, ContextType, RequireFields<QueryFindContentBrandBySourceUrlArgs, 'publishedOnly' | 'source' | 'tenant'>>;
  findContentModulesBySemanticIdAndTag?: Resolver<Maybe<Array<Maybe<ResolversTypes['ContentModule']>>>, ParentType, ContextType, RequireFields<QueryFindContentModulesBySemanticIdAndTagArgs, 'limit' | 'state'>>;
  findPackageByTitle?: Resolver<Maybe<Array<Maybe<ResolversTypes['PackageContentModule']>>>, ParentType, ContextType, RequireFields<QueryFindPackageByTitleArgs, 'state'>>;
  findTagByMatchTerm?: Resolver<Array<ResolversTypes['Tag']>, ParentType, ContextType, RequireFields<QueryFindTagByMatchTermArgs, 'tenant' | 'term'>>;
  getAllArticles?: Resolver<Maybe<ResolversTypes['ArticleConnection']>, ParentType, ContextType, RequireFields<QueryGetAllArticlesArgs, 'publishedOnly' | 'tenant'>>;
  getAllCompetitors?: Resolver<Maybe<Array<Maybe<ResolversTypes['Competitor']>>>, ParentType, ContextType, RequireFields<QueryGetAllCompetitorsArgs, 'tenant'>>;
  getAllConferences?: Resolver<Maybe<Array<Maybe<ResolversTypes['Conference']>>>, ParentType, ContextType, RequireFields<QueryGetAllConferencesArgs, 'tenant'>>;
  getAllDivisions?: Resolver<Maybe<Array<Maybe<ResolversTypes['Division']>>>, ParentType, ContextType, RequireFields<QueryGetAllDivisionsArgs, 'tenant'>>;
  getAllEvents?: Resolver<Maybe<Array<Maybe<ResolversTypes['Event']>>>, ParentType, ContextType, RequireFields<QueryGetAllEventsArgs, 'tenant'>>;
  getAllLeagues?: Resolver<Maybe<Array<Maybe<ResolversTypes['League']>>>, ParentType, ContextType, RequireFields<QueryGetAllLeaguesArgs, 'tenant'>>;
  getAllMenus?: Resolver<Maybe<Array<Maybe<ResolversTypes['Menu']>>>, ParentType, ContextType, RequireFields<QueryGetAllMenusArgs, 'publishedOnly' | 'tenant'>>;
  getAllNotifications?: Resolver<Array<ResolversTypes['PushNotification']>, ParentType, ContextType, RequireFields<QueryGetAllNotificationsArgs, 'limit' | 'tenant'>>;
  getAllPlaylists?: Resolver<Maybe<Array<Maybe<ResolversTypes['Playlist']>>>, ParentType, ContextType, RequireFields<QueryGetAllPlaylistsArgs, 'publishedOnly' | 'tenant'>>;
  getAllSeries?: Resolver<Maybe<Array<Maybe<ResolversTypes['Series']>>>, ParentType, ContextType, RequireFields<QueryGetAllSeriesArgs, 'tenant'>>;
  getAllSports?: Resolver<Maybe<Array<Maybe<ResolversTypes['Sport']>>>, ParentType, ContextType, RequireFields<QueryGetAllSportsArgs, 'tenant'>>;
  getAllTeamsByPermalink?: Resolver<Array<ResolversTypes['Tag']>, ParentType, ContextType, RequireFields<QueryGetAllTeamsByPermalinkArgs, 'permalink' | 'tenant'>>;
  getAllTournaments?: Resolver<Maybe<Array<Maybe<ResolversTypes['Tournament']>>>, ParentType, ContextType, RequireFields<QueryGetAllTournamentsArgs, 'tenant'>>;
  getAllVenues?: Resolver<Maybe<Array<Maybe<ResolversTypes['Venue']>>>, ParentType, ContextType, RequireFields<QueryGetAllVenuesArgs, 'tenant'>>;
  getAllVideos?: Resolver<Maybe<Array<Maybe<ResolversTypes['Video']>>>, ParentType, ContextType, RequireFields<QueryGetAllVideosArgs, 'limit' | 'order' | 'publishedOnly' | 'skip' | 'tenant'>>;
  getAllVideosV2?: Resolver<Maybe<Array<Maybe<ResolversTypes['VideoV2']>>>, ParentType, ContextType, RequireFields<QueryGetAllVideosV2Args, 'publishedOnly' | 'tenant'>>;
  getArticleByCmsId?: Resolver<Maybe<ResolversTypes['Article']>, ParentType, ContextType, RequireFields<QueryGetArticleByCmsIdArgs, 'publishedOnly' | 'tenant'>>;
  getArticleByDisplayId?: Resolver<Maybe<ResolversTypes['Article']>, ParentType, ContextType, RequireFields<QueryGetArticleByDisplayIdArgs, 'displayId' | 'publishedOnly' | 'tenant'>>;
  getArticleBySlug?: Resolver<Maybe<ResolversTypes['Article']>, ParentType, ContextType, RequireFields<QueryGetArticleBySlugArgs, 'publishedOnly' | 'tenant'>>;
  getArticleByUUID?: Resolver<Maybe<ResolversTypes['Article']>, ParentType, ContextType, RequireFields<QueryGetArticleByUuidArgs, 'publishedOnly' | 'tenant'>>;
  getBlockedUsers?: Resolver<Maybe<Array<Maybe<ResolversTypes['User']>>>, ParentType, ContextType>;
  getChannelByCmsId?: Resolver<Maybe<ResolversTypes['Channel']>, ParentType, ContextType, RequireFields<QueryGetChannelByCmsIdArgs, 'publishedOnly' | 'tenant'>>;
  getChannelBySlug?: Resolver<Maybe<ResolversTypes['Channel']>, ParentType, ContextType, RequireFields<QueryGetChannelBySlugArgs, 'publishedOnly' | 'slug' | 'tenant'>>;
  getChannelByTagUUID?: Resolver<Maybe<ResolversTypes['Channel']>, ParentType, ContextType, RequireFields<QueryGetChannelByTagUuidArgs, 'publishedOnly' | 'tagUUID' | 'tenant'>>;
  getChannelByUUID?: Resolver<Maybe<ResolversTypes['Channel']>, ParentType, ContextType, RequireFields<QueryGetChannelByUuidArgs, 'publishedOnly' | 'tenant' | 'uuid'>>;
  getCompetitorById?: Resolver<Maybe<ResolversTypes['Competitor']>, ParentType, ContextType, RequireFields<QueryGetCompetitorByIdArgs, 'id' | 'tenant'>>;
  getCompetitorList?: Resolver<Maybe<ResolversTypes['Competitors']>, ParentType, ContextType, RequireFields<QueryGetCompetitorListArgs, 'tenant'>>;
  getConferenceById?: Resolver<Maybe<ResolversTypes['Conference']>, ParentType, ContextType, RequireFields<QueryGetConferenceByIdArgs, 'id' | 'tenant'>>;
  getConferenceList?: Resolver<Maybe<ResolversTypes['Conferences']>, ParentType, ContextType, RequireFields<QueryGetConferenceListArgs, 'tenant'>>;
  getConfigJsonByUri?: Resolver<Maybe<ResolversTypes['ConfigJson']>, ParentType, ContextType, RequireFields<QueryGetConfigJsonByUriArgs, 'publishedOnly' | 'tenant' | 'uri'>>;
  getContentModuleIdsWithPushNotificationIds?: Resolver<Maybe<Array<ResolversTypes['Int']>>, ParentType, ContextType, RequireFields<QueryGetContentModuleIdsWithPushNotificationIdsArgs, 'contentModuleIds' | 'tenant'>>;
  getDivisionById?: Resolver<Maybe<ResolversTypes['Division']>, ParentType, ContextType, RequireFields<QueryGetDivisionByIdArgs, 'id' | 'tenant'>>;
  getDivisionList?: Resolver<Maybe<ResolversTypes['Divisions']>, ParentType, ContextType, RequireFields<QueryGetDivisionListArgs, 'tenant'>>;
  getEventById?: Resolver<Maybe<ResolversTypes['Event']>, ParentType, ContextType, RequireFields<QueryGetEventByIdArgs, 'id' | 'isSportRadar' | 'tenant'>>;
  getEventList?: Resolver<Maybe<ResolversTypes['Events']>, ParentType, ContextType, RequireFields<QueryGetEventListArgs, 'tenant'>>;
  getGameCastByTagUUID?: Resolver<Maybe<ResolversTypes['StatsGamecast']>, ParentType, ContextType, RequireFields<QueryGetGameCastByTagUuidArgs, 'uuid'>>;
  getGamecastBySlug?: Resolver<Maybe<ResolversTypes['StatsGamecast']>, ParentType, ContextType, RequireFields<QueryGetGamecastBySlugArgs, 'slug'>>;
  getGamesByGameDate?: Resolver<Maybe<Array<Maybe<ResolversTypes['Game']>>>, ParentType, ContextType, RequireFields<QueryGetGamesByGameDateArgs, 'endDate' | 'startDate' | 'timezone'>>;
  getGamesByGameIds?: Resolver<Maybe<Array<Maybe<ResolversTypes['Game']>>>, ParentType, ContextType, RequireFields<QueryGetGamesByGameIdsArgs, 'gameIds'>>;
  getGamesBySportRadarIds?: Resolver<Maybe<Array<Maybe<ResolversTypes['Game']>>>, ParentType, ContextType, RequireFields<QueryGetGamesBySportRadarIdsArgs, 'gameIds'>>;
  getHelloWorld?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  getLeagueById?: Resolver<Maybe<ResolversTypes['League']>, ParentType, ContextType, RequireFields<QueryGetLeagueByIdArgs, 'id' | 'tenant'>>;
  getLeagueList?: Resolver<Maybe<ResolversTypes['Leagues']>, ParentType, ContextType, RequireFields<QueryGetLeagueListArgs, 'tenant'>>;
  getMediaId?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType, Partial<QueryGetMediaIdArgs>>;
  getMenuById?: Resolver<Maybe<ResolversTypes['Menu']>, ParentType, ContextType, RequireFields<QueryGetMenuByIdArgs, 'publishedOnly' | 'tenant'>>;
  getMetadata?: Resolver<Maybe<ResolversTypes['Metadata']>, ParentType, ContextType>;
  getPageByUri?: Resolver<Maybe<ResolversTypes['Page']>, ParentType, ContextType, RequireFields<QueryGetPageByUriArgs, 'publishedOnly' | 'tenant' | 'uri'>>;
  getPlaylistByCmsId?: Resolver<Maybe<ResolversTypes['Playlist']>, ParentType, ContextType, RequireFields<QueryGetPlaylistByCmsIdArgs, 'publishedOnly' | 'tenant'>>;
  getPlaylistByEventId?: Resolver<Maybe<ResolversTypes['Playlist']>, ParentType, ContextType, RequireFields<QueryGetPlaylistByEventIdArgs, 'publishedOnly' | 'tenant'>>;
  getPlaylistById?: Resolver<Maybe<ResolversTypes['Playlist']>, ParentType, ContextType, RequireFields<QueryGetPlaylistByIdArgs, 'publishedOnly' | 'tenant'>>;
  getPushNotificationById?: Resolver<Maybe<ResolversTypes['PushNotification']>, ParentType, ContextType, RequireFields<QueryGetPushNotificationByIdArgs, 'id' | 'tenant'>>;
  getReferenceStreamByComponentId?: Resolver<Maybe<ResolversTypes['ReferenceStream']>, ParentType, ContextType, RequireFields<QueryGetReferenceStreamByComponentIdArgs, 'componentID'>>;
  getReferenceStreamByName?: Resolver<Maybe<Array<ResolversTypes['Reference']>>, ParentType, ContextType, RequireFields<QueryGetReferenceStreamByNameArgs, 'referenceStreamName'>>;
  getSchedule?: Resolver<Maybe<ResolversTypes['StatsSchedule']>, ParentType, ContextType, RequireFields<QueryGetScheduleArgs, 'slug'>>;
  getScheduleByFeeds?: Resolver<Maybe<ResolversTypes['Schedule']>, ParentType, ContextType, RequireFields<QueryGetScheduleByFeedsArgs, 'feed'>>;
  getScores?: Resolver<Maybe<ResolversTypes['Scores']>, ParentType, ContextType, RequireFields<QueryGetScoresArgs, 'timezone'>>;
  getSeriesById?: Resolver<Maybe<ResolversTypes['Series']>, ParentType, ContextType, RequireFields<QueryGetSeriesByIdArgs, 'id' | 'tenant'>>;
  getSeriesList?: Resolver<Maybe<ResolversTypes['Serieses']>, ParentType, ContextType, RequireFields<QueryGetSeriesListArgs, 'tenant'>>;
  getSiteMap?: Resolver<ResolversTypes['Tag'], ParentType, ContextType, RequireFields<QueryGetSiteMapArgs, 'client' | 'permalink' | 'tenant'>>;
  getSportById?: Resolver<Maybe<ResolversTypes['Sport']>, ParentType, ContextType, RequireFields<QueryGetSportByIdArgs, 'id' | 'tenant'>>;
  getSportList?: Resolver<Maybe<ResolversTypes['Sports']>, ParentType, ContextType, RequireFields<QueryGetSportListArgs, 'tenant'>>;
  getStandings?: Resolver<Maybe<ResolversTypes['StatsStanding']>, ParentType, ContextType, RequireFields<QueryGetStandingsArgs, 'permalink'>>;
  getTagByForeignId?: Resolver<Maybe<ResolversTypes['TagV2']>, ParentType, ContextType, RequireFields<QueryGetTagByForeignIdArgs, 'foreignId' | 'publishedOnly' | 'tenant'>>;
  getTagByForeignIds?: Resolver<Maybe<Array<Maybe<ResolversTypes['TagV2']>>>, ParentType, ContextType, RequireFields<QueryGetTagByForeignIdsArgs, 'foreignIds' | 'publishedOnly' | 'tenant'>>;
  getTagById?: Resolver<ResolversTypes['Tag'], ParentType, ContextType, RequireFields<QueryGetTagByIdArgs, 'id' | 'tenant'>>;
  getTagBySlugs?: Resolver<Maybe<Array<Maybe<ResolversTypes['TagV2']>>>, ParentType, ContextType, RequireFields<QueryGetTagBySlugsArgs, 'publishedOnly' | 'slugs' | 'tenant'>>;
  getTagByUUID?: Resolver<Maybe<ResolversTypes['TagV2']>, ParentType, ContextType, RequireFields<QueryGetTagByUuidArgs, 'publishedOnly' | 'tenant' | 'uuid'>>;
  getTagGroupByUUID?: Resolver<Maybe<ResolversTypes['TagGroup']>, ParentType, ContextType, RequireFields<QueryGetTagGroupByUuidArgs, 'publishedOnly' | 'tenant' | 'uuid'>>;
  getTagGroupsBySlugs?: Resolver<Maybe<Array<Maybe<ResolversTypes['TagGroup']>>>, ParentType, ContextType, RequireFields<QueryGetTagGroupsBySlugsArgs, 'publishedOnly' | 'slugs' | 'tenant'>>;
  getTagsByPermalinks?: Resolver<Maybe<Array<Maybe<ResolversTypes['Tag']>>>, ParentType, ContextType, RequireFields<QueryGetTagsByPermalinksArgs, 'permalinks' | 'tenant'>>;
  getTaxonomyByIdAndType?: Resolver<Maybe<ResolversTypes['TaxonomyTerm']>, ParentType, ContextType, RequireFields<QueryGetTaxonomyByIdAndTypeArgs, 'id' | 'publishedOnly' | 'tenant' | 'type'>>;
  getTournamentById?: Resolver<Maybe<ResolversTypes['Tournament']>, ParentType, ContextType, RequireFields<QueryGetTournamentByIdArgs, 'id' | 'tenant'>>;
  getTournamentList?: Resolver<Maybe<ResolversTypes['Tournaments']>, ParentType, ContextType, RequireFields<QueryGetTournamentListArgs, 'tenant'>>;
  getTweetsByIds?: Resolver<Array<ResolversTypes['Tweet']>, ParentType, ContextType, RequireFields<QueryGetTweetsByIdsArgs, 'ids'>>;
  getUser?: Resolver<Maybe<ResolversTypes['User']>, ParentType, ContextType, RequireFields<QueryGetUserArgs, 'tenant'>>;
  getUserPushNotifications?: Resolver<Array<ResolversTypes['PushNotification']>, ParentType, ContextType, RequireFields<QueryGetUserPushNotificationsArgs, 'limit' | 'tenant'>>;
  getVenueById?: Resolver<Maybe<ResolversTypes['Venue']>, ParentType, ContextType, RequireFields<QueryGetVenueByIdArgs, 'id' | 'tenant'>>;
  getVenueList?: Resolver<Maybe<ResolversTypes['Venues']>, ParentType, ContextType, RequireFields<QueryGetVenueListArgs, 'tenant'>>;
  getVideoByCmsId?: Resolver<Maybe<ResolversTypes['Video']>, ParentType, ContextType, RequireFields<QueryGetVideoByCmsIdArgs, 'limit' | 'publishedOnly' | 'skip' | 'tenant'>>;
  getVideoById?: Resolver<Maybe<ResolversTypes['Video']>, ParentType, ContextType, RequireFields<QueryGetVideoByIdArgs, 'publishedOnly' | 'tenant'>>;
  getVideoV2ByCmsId?: Resolver<Maybe<ResolversTypes['VideoV2']>, ParentType, ContextType, RequireFields<QueryGetVideoV2ByCmsIdArgs, 'publishedOnly' | 'tenant'>>;
  getVideoV2ByEditId?: Resolver<Maybe<ResolversTypes['VideoV2']>, ParentType, ContextType, RequireFields<QueryGetVideoV2ByEditIdArgs, 'editId' | 'publishedOnly' | 'tenant'>>;
  getVideoV2ById?: Resolver<Maybe<ResolversTypes['VideoV2']>, ParentType, ContextType, RequireFields<QueryGetVideoV2ByIdArgs, 'eventId' | 'publishedOnly' | 'tenant'>>;
  getVideoV2TagIdsFromEventIds?: Resolver<Maybe<Array<ResolversTypes['VideoV2TagIds']>>, ParentType, ContextType, RequireFields<QueryGetVideoV2TagIdsFromEventIdsArgs, 'eventIds' | 'publishedOnly' | 'tenant'>>;
  getVideosByEventId?: Resolver<Maybe<Array<Maybe<ResolversTypes['Video']>>>, ParentType, ContextType, RequireFields<QueryGetVideosByEventIdArgs, 'limit' | 'order' | 'publishedOnly' | 'skip' | 'tenant'>>;
  getVideosByTeamId?: Resolver<Maybe<Array<Maybe<ResolversTypes['Video']>>>, ParentType, ContextType, RequireFields<QueryGetVideosByTeamIdArgs, 'limit' | 'order' | 'publishedOnly' | 'skip' | 'tenant'>>;
  getWbdContext?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  liveLikeAlert?: Resolver<Maybe<ResolversTypes['LiveLikeAlert']>, ParentType, ContextType, RequireFields<QueryLiveLikeAlertArgs, 'id'>>;
  liveLikeApplication?: Resolver<Maybe<ResolversTypes['LiveLikeApplication']>, ParentType, ContextType, RequireFields<QueryLiveLikeApplicationArgs, 'clientId'>>;
  liveLikeBadge?: Resolver<Maybe<ResolversTypes['LiveLikeBadge']>, ParentType, ContextType, RequireFields<QueryLiveLikeBadgeArgs, 'id'>>;
  liveLikeBadgeProfiles?: Resolver<Maybe<ResolversTypes['LiveLikeBadgeProfileCollection']>, ParentType, ContextType, RequireFields<QueryLiveLikeBadgeProfilesArgs, 'badgeId'>>;
  liveLikeBadgeProgress?: Resolver<Maybe<Array<ResolversTypes['LiveLikeBadgeRewardProgressCollection']>>, ParentType, ContextType, RequireFields<QueryLiveLikeBadgeProgressArgs, 'badgeId' | 'profileId'>>;
  liveLikeBadges?: Resolver<Maybe<ResolversTypes['LiveLikeBadgeCollection']>, ParentType, ContextType, RequireFields<QueryLiveLikeBadgesArgs, 'clientId'>>;
  liveLikeBlockedProfileIds?: Resolver<Maybe<Array<ResolversTypes['UUID']>>, ParentType, ContextType>;
  liveLikeChatRoom?: Resolver<Maybe<ResolversTypes['LiveLikeChatRoom']>, ParentType, ContextType, RequireFields<QueryLiveLikeChatRoomArgs, 'id'>>;
  liveLikeChatRooms?: Resolver<Maybe<ResolversTypes['LiveLikeChatRoomCollection']>, ParentType, ContextType, RequireFields<QueryLiveLikeChatRoomsArgs, 'input'>>;
  liveLikeComment?: Resolver<Maybe<ResolversTypes['LiveLikeComment']>, ParentType, ContextType, RequireFields<QueryLiveLikeCommentArgs, 'id'>>;
  liveLikeCommentBoard?: Resolver<Maybe<ResolversTypes['LiveLikeCommentBoard']>, ParentType, ContextType, RequireFields<QueryLiveLikeCommentBoardArgs, 'id'>>;
  liveLikeCommentBoardBan?: Resolver<Maybe<ResolversTypes['LiveLikeCommentBoardBan']>, ParentType, ContextType, RequireFields<QueryLiveLikeCommentBoardBanArgs, 'id'>>;
  liveLikeCommentBoardBans?: Resolver<Maybe<ResolversTypes['LiveLikeCommentBoardBanCollection']>, ParentType, ContextType, Partial<QueryLiveLikeCommentBoardBansArgs>>;
  liveLikeCommentBoards?: Resolver<Maybe<ResolversTypes['LiveLikeCommentBoardCollection']>, ParentType, ContextType, RequireFields<QueryLiveLikeCommentBoardsArgs, 'input'>>;
  liveLikeCommentBoardsCount?: Resolver<Maybe<Array<ResolversTypes['LiveLikeCommentBoardCount']>>, ParentType, ContextType, RequireFields<QueryLiveLikeCommentBoardsCountArgs, 'input'>>;
  liveLikeCommentReplies?: Resolver<Maybe<ResolversTypes['LiveLikeCommentCollection']>, ParentType, ContextType, RequireFields<QueryLiveLikeCommentRepliesArgs, 'input'>>;
  liveLikeCommentReport?: Resolver<Maybe<ResolversTypes['LiveLikeCommentReport']>, ParentType, ContextType, RequireFields<QueryLiveLikeCommentReportArgs, 'id'>>;
  liveLikeComments?: Resolver<Maybe<ResolversTypes['LiveLikeCommentCollection']>, ParentType, ContextType, RequireFields<QueryLiveLikeCommentsArgs, 'input'>>;
  liveLikeCommentsReports?: Resolver<Maybe<ResolversTypes['LiveLikeCommentReportCollection']>, ParentType, ContextType, RequireFields<QueryLiveLikeCommentsReportsArgs, 'input'>>;
  liveLikeEarnedBadges?: Resolver<Maybe<ResolversTypes['LiveLikeEarnedBadgeCollection']>, ParentType, ContextType, RequireFields<QueryLiveLikeEarnedBadgesArgs, 'profileId'>>;
  liveLikeImagePoll?: Resolver<Maybe<ResolversTypes['LiveLikeImagePoll']>, ParentType, ContextType, RequireFields<QueryLiveLikeImagePollArgs, 'id'>>;
  liveLikeImagePrediction?: Resolver<Maybe<ResolversTypes['LiveLikeImagePrediction']>, ParentType, ContextType, RequireFields<QueryLiveLikeImagePredictionArgs, 'id'>>;
  liveLikeImagePredictionFollowUp?: Resolver<Maybe<ResolversTypes['LiveLikeImagePredictionFollowUp']>, ParentType, ContextType, RequireFields<QueryLiveLikeImagePredictionFollowUpArgs, 'id'>>;
  liveLikeImageQuiz?: Resolver<Maybe<ResolversTypes['LiveLikeImageQuiz']>, ParentType, ContextType, RequireFields<QueryLiveLikeImageQuizArgs, 'id'>>;
  liveLikeLeaderboard?: Resolver<Maybe<ResolversTypes['LiveLikeLeaderboard']>, ParentType, ContextType, RequireFields<QueryLiveLikeLeaderboardArgs, 'id'>>;
  liveLikeLeaderboardEntries?: Resolver<Maybe<ResolversTypes['LiveLikeLeaderboardEntryCollection']>, ParentType, ContextType, RequireFields<QueryLiveLikeLeaderboardEntriesArgs, 'input'>>;
  liveLikeLeaderboardEntry?: Resolver<Maybe<ResolversTypes['LiveLikeLeaderboardEntry']>, ParentType, ContextType, RequireFields<QueryLiveLikeLeaderboardEntryArgs, 'input'>>;
  liveLikeLeaderboards?: Resolver<Maybe<ResolversTypes['LiveLikeLeaderboardCollection']>, ParentType, ContextType, RequireFields<QueryLiveLikeLeaderboardsArgs, 'input'>>;
  liveLikeMe?: Resolver<Maybe<ResolversTypes['LiveLikeProfile']>, ParentType, ContextType>;
  liveLikePermissions?: Resolver<Maybe<ResolversTypes['LiveLikePermissions']>, ParentType, ContextType, Partial<QueryLiveLikePermissionsArgs>>;
  liveLikeProfile?: Resolver<Maybe<ResolversTypes['LiveLikeProfile']>, ParentType, ContextType, RequireFields<QueryLiveLikeProfileArgs, 'id'>>;
  liveLikeProfileByCustomId?: Resolver<Maybe<ResolversTypes['LiveLikeProfile']>, ParentType, ContextType, RequireFields<QueryLiveLikeProfileByCustomIdArgs, 'input'>>;
  liveLikeProfileRelationshipType?: Resolver<Maybe<ResolversTypes['LiveLikeProfileRelationshipType']>, ParentType, ContextType, RequireFields<QueryLiveLikeProfileRelationshipTypeArgs, 'id'>>;
  liveLikeProfileRelationshipTypes?: Resolver<Maybe<ResolversTypes['LiveLikeProfileRelationshipTypeCollection']>, ParentType, ContextType, RequireFields<QueryLiveLikeProfileRelationshipTypesArgs, 'input'>>;
  liveLikeProfileRelationships?: Resolver<Maybe<ResolversTypes['LiveLikeProfileRelationshipCollection']>, ParentType, ContextType, RequireFields<QueryLiveLikeProfileRelationshipsArgs, 'input'>>;
  liveLikeProgram?: Resolver<Maybe<ResolversTypes['LiveLikeProgram']>, ParentType, ContextType, RequireFields<QueryLiveLikeProgramArgs, 'id'>>;
  liveLikeProgramBans?: Resolver<Maybe<ResolversTypes['LiveLikeProgramBanCollection']>, ParentType, ContextType, Partial<QueryLiveLikeProgramBansArgs>>;
  liveLikeProgramByCustomId?: Resolver<Maybe<ResolversTypes['LiveLikeProgram']>, ParentType, ContextType, RequireFields<QueryLiveLikeProgramByCustomIdArgs, 'input'>>;
  liveLikePrograms?: Resolver<Maybe<ResolversTypes['LiveLikeProgramConnection']>, ParentType, ContextType, RequireFields<QueryLiveLikeProgramsArgs, 'input'>>;
  liveLikeQuests?: Resolver<Maybe<ResolversTypes['LiveLikeQuestCollection']>, ParentType, ContextType, RequireFields<QueryLiveLikeQuestsArgs, 'clientId'>>;
  liveLikeReactionPack?: Resolver<Maybe<ResolversTypes['LiveLikeReactionPack']>, ParentType, ContextType, RequireFields<QueryLiveLikeReactionPackArgs, 'id'>>;
  liveLikeReactionPacks?: Resolver<Maybe<ResolversTypes['LiveLikeReactionPackCollection']>, ParentType, ContextType, RequireFields<QueryLiveLikeReactionPacksArgs, 'input'>>;
  liveLikeReactionSpace?: Resolver<Maybe<ResolversTypes['LiveLikeReactionSpace']>, ParentType, ContextType, RequireFields<QueryLiveLikeReactionSpaceArgs, 'id'>>;
  liveLikeReactionSpaces?: Resolver<Maybe<ResolversTypes['LiveLikeReactionSpaceCollection']>, ParentType, ContextType, RequireFields<QueryLiveLikeReactionSpacesArgs, 'input'>>;
  liveLikeReactionSpacesCount?: Resolver<Maybe<Array<ResolversTypes['LiveLikeReactionSpaceCount']>>, ParentType, ContextType, RequireFields<QueryLiveLikeReactionSpacesCountArgs, 'input'>>;
  liveLikeRewardBalance?: Resolver<Maybe<ResolversTypes['LiveLikeRewardItemBalance']>, ParentType, ContextType, RequireFields<QueryLiveLikeRewardBalanceArgs, 'input' | 'profileId'>>;
  liveLikeRewardBalances?: Resolver<Maybe<ResolversTypes['LiveLikeRewardItemBalanceCollection']>, ParentType, ContextType, RequireFields<QueryLiveLikeRewardBalancesArgs, 'profileId'>>;
  liveLikeRewardItem?: Resolver<Maybe<ResolversTypes['LiveLikeRewardItem']>, ParentType, ContextType, RequireFields<QueryLiveLikeRewardItemArgs, 'id'>>;
  liveLikeRewardItems?: Resolver<Maybe<ResolversTypes['LiveLikeRewardItemCollection']>, ParentType, ContextType, RequireFields<QueryLiveLikeRewardItemsArgs, 'clientId'>>;
  liveLikeRewardTable?: Resolver<Maybe<ResolversTypes['LiveLikeRewardTable']>, ParentType, ContextType, RequireFields<QueryLiveLikeRewardTableArgs, 'id'>>;
  liveLikeRewardTableEntry?: Resolver<Maybe<ResolversTypes['LiveLikeRewardTableEntry']>, ParentType, ContextType, RequireFields<QueryLiveLikeRewardTableEntryArgs, 'input'>>;
  liveLikeRewardTables?: Resolver<Maybe<ResolversTypes['LiveLikeRewardTableCollection']>, ParentType, ContextType, RequireFields<QueryLiveLikeRewardTablesArgs, 'input'>>;
  liveLikeRichPost?: Resolver<Maybe<ResolversTypes['LiveLikeRichPost']>, ParentType, ContextType, RequireFields<QueryLiveLikeRichPostArgs, 'id'>>;
  liveLikeRoles?: Resolver<Maybe<ResolversTypes['LiveLikeRoleConnection']>, ParentType, ContextType, RequireFields<QueryLiveLikeRolesArgs, 'input'>>;
  liveLikeRolesAssignment?: Resolver<Maybe<ResolversTypes['LiveLikeRoleAssignmentConnection']>, ParentType, ContextType, RequireFields<QueryLiveLikeRolesAssignmentArgs, 'input'>>;
  liveLikeSocialEmbed?: Resolver<Maybe<ResolversTypes['LiveLikeSocialEmbed']>, ParentType, ContextType, RequireFields<QueryLiveLikeSocialEmbedArgs, 'id'>>;
  liveLikeTextPoll?: Resolver<Maybe<ResolversTypes['LiveLikeTextPoll']>, ParentType, ContextType, RequireFields<QueryLiveLikeTextPollArgs, 'id'>>;
  liveLikeTextPrediction?: Resolver<Maybe<ResolversTypes['LiveLikeTextPrediction']>, ParentType, ContextType, RequireFields<QueryLiveLikeTextPredictionArgs, 'id'>>;
  liveLikeTextPredictionFollowUp?: Resolver<Maybe<ResolversTypes['LiveLikeTextPredictionFollowUp']>, ParentType, ContextType, RequireFields<QueryLiveLikeTextPredictionFollowUpArgs, 'id'>>;
  liveLikeTextQuiz?: Resolver<Maybe<ResolversTypes['LiveLikeTextQuiz']>, ParentType, ContextType, RequireFields<QueryLiveLikeTextQuizArgs, 'id'>>;
  liveLikeUserBadges?: Resolver<Maybe<ResolversTypes['LiveLikeUserBadgeCollection']>, ParentType, ContextType, Partial<QueryLiveLikeUserBadgesArgs>>;
  liveLikeUserQuestRewards?: Resolver<Maybe<ResolversTypes['LiveLikeUserQuestRewardsConnection']>, ParentType, ContextType, RequireFields<QueryLiveLikeUserQuestRewardsArgs, 'input'>>;
  liveLikeUserQuests?: Resolver<Maybe<ResolversTypes['LiveLikeUserQuestCollection']>, ParentType, ContextType, RequireFields<QueryLiveLikeUserQuestsArgs, 'profileId'>>;
  liveLikeUserReactionCounts?: Resolver<Maybe<ResolversTypes['LiveLikeUserReactionCountCollection']>, ParentType, ContextType, RequireFields<QueryLiveLikeUserReactionCountsArgs, 'input'>>;
  liveLikeUserReactions?: Resolver<Maybe<ResolversTypes['LiveLikeUserReactionCollection']>, ParentType, ContextType, RequireFields<QueryLiveLikeUserReactionsArgs, 'input'>>;
  liveLikeVideoAlert?: Resolver<Maybe<ResolversTypes['LiveLikeVideoAlert']>, ParentType, ContextType, RequireFields<QueryLiveLikeVideoAlertArgs, 'id'>>;
  liveLikeWidgetReports?: Resolver<Maybe<ResolversTypes['LiveLikeWidgetReportCollection']>, ParentType, ContextType, Partial<QueryLiveLikeWidgetReportsArgs>>;
  liveLikeWidgets?: Resolver<Maybe<ResolversTypes['LiveLikeWidgetCollection']>, ParentType, ContextType, RequireFields<QueryLiveLikeWidgetsArgs, 'programId'>>;
  liveLikeWidgetsInteractions?: Resolver<Maybe<Array<ResolversTypes['LiveLikeWidgetInteractions']>>, ParentType, ContextType, RequireFields<QueryLiveLikeWidgetsInteractionsArgs, 'input' | 'profileId'>>;
  paginatedFindContentModulesBySemanticIdAndTag?: Resolver<Maybe<ResolversTypes['ContentsConnection']>, ParentType, ContextType, RequireFields<QueryPaginatedFindContentModulesBySemanticIdAndTagArgs, 'state'>>;
  popularSearches?: Resolver<ResolversTypes['QueryAssistResponse'], ParentType, ContextType, RequireFields<QueryPopularSearchesArgs, 'tenant'>>;
  search?: Resolver<ResolversTypes['SearchResults'], ParentType, ContextType, RequireFields<QuerySearchArgs, 'contentTypes' | 'tenant'>>;
  searchContentLibrary?: Resolver<Maybe<Array<Maybe<ResolversTypes['ContentLibrarySearchResult']>>>, ParentType, ContextType, RequireFields<QuerySearchContentLibraryArgs, 'publishedOnly' | 'tenant'>>;
  searchTagByMatchTerm?: Resolver<Array<ResolversTypes['TagV2']>, ParentType, ContextType, RequireFields<QuerySearchTagByMatchTermArgs, 'publishedOnly' | 'tenant'>>;
  tags?: Resolver<Maybe<ResolversTypes['TagV2Connection']>, ParentType, ContextType, RequireFields<QueryTagsArgs, 'publishedOnly' | 'tagParams' | 'tenant'>>;
  test?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  trendingArticles?: Resolver<Array<ResolversTypes['TrendingResult']>, ParentType, ContextType, RequireFields<QueryTrendingArticlesArgs, 'primaryPrioritizedTag' | 'secondaryPrioritizedTags' | 'topN'>>;
  trendingChannels?: Resolver<Array<ResolversTypes['TrendingChannelResult']>, ParentType, ContextType, RequireFields<QueryTrendingChannelsArgs, 'topN'>>;
  trendingVideos?: Resolver<Array<ResolversTypes['TrendingResult']>, ParentType, ContextType, RequireFields<QueryTrendingVideosArgs, 'aspectRatio' | 'primaryPrioritizedTag' | 'secondaryPrioritizedTags' | 'topN'>>;
  typeAhead?: Resolver<ResolversTypes['QueryAssistResponse'], ParentType, ContextType, RequireFields<QueryTypeAheadArgs, 'tenant'>>;
  v2v?: Resolver<Array<ResolversTypes['V2VResult']>, ParentType, ContextType, RequireFields<QueryV2vArgs, 'aspectRatio' | 'limit' | 'primaryPrioritizedTag' | 'secondaryPrioritizedTags' | 'version' | 'videoEventId'>>;
  videoBlocklist?: Resolver<Array<ResolversTypes['BlockedContent']>, ParentType, ContextType, RequireFields<QueryVideoBlocklistArgs, 'limit'>>;
}>;

export type QueryAssistResponseResolvers<ContextType = any, ParentType extends ResolversParentTypes['QueryAssistResponse'] = ResolversParentTypes['QueryAssistResponse']> = ResolversObject<{
  results?: Resolver<Maybe<Array<ResolversTypes['QueryAssistResult']>>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type QueryAssistResultResolvers<ContextType = any, ParentType extends ResolversParentTypes['QueryAssistResult'] = ResolversParentTypes['QueryAssistResult']> = ResolversObject<{
  term?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type RatingResolvers<ContextType = any, ParentType extends ResolversParentTypes['Rating'] = ResolversParentTypes['Rating']> = ResolversObject<{
  classifier?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  contentDescriptors?: Resolver<Maybe<Array<Maybe<ResolversTypes['String']>>>, ParentType, ContextType>;
  ratingAuthority?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type ReferenceResolvers<ContextType = any, ParentType extends ResolversParentTypes['Reference'] = ResolversParentTypes['Reference']> = ResolversObject<{
  author?: Resolver<Maybe<ResolversTypes['Author']>, ParentType, ContextType>;
  createdAt?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  description?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  id?: Resolver<ResolversTypes['ID'], ParentType, ContextType>;
  metadata?: Resolver<Maybe<ResolversTypes['ReferenceMetadata']>, ParentType, ContextType>;
  permalink?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  tag?: Resolver<ResolversTypes['Tag'], ParentType, ContextType>;
  thumbnailUrl?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  title?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  type?: Resolver<Maybe<ResolversTypes['ReferenceType']>, ParentType, ContextType>;
  updatedAt?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  url?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type ReferenceMetadataResolvers<ContextType = any, ParentType extends ResolversParentTypes['ReferenceMetadata'] = ResolversParentTypes['ReferenceMetadata']> = ResolversObject<{
  gamecast?: Resolver<Maybe<ResolversTypes['GamecastMetadata']>, ParentType, ContextType>;
  genres?: Resolver<Maybe<Array<ResolversTypes['String']>>, ParentType, ContextType>;
  labels?: Resolver<Array<ResolversTypes['Tag']>, ParentType, ContextType>;
  photoCredit?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  providerName?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  shareUrl?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  video?: Resolver<Maybe<ResolversTypes['VideoMetadata']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type ReferenceStreamResolvers<ContextType = any, ParentType extends ResolversParentTypes['ReferenceStream'] = ResolversParentTypes['ReferenceStream']> = ResolversObject<{
  id?: Resolver<ResolversTypes['ID'], ParentType, ContextType>;
  name?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  references?: Resolver<Maybe<Array<ResolversTypes['Reference']>>, ParentType, ContextType, Partial<ReferenceStreamReferencesArgs>>;
  tag?: Resolver<ResolversTypes['Tag'], ParentType, ContextType>;
  type?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type ScheduleResolvers<ContextType = any, ParentType extends ResolversParentTypes['Schedule'] = ResolversParentTypes['Schedule']> = ResolversObject<{
  dateFrom?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  dateTo?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  feeds?: Resolver<Maybe<Array<Maybe<ResolversTypes['Feed']>>>, ParentType, ContextType>;
  offset?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type ScoreResolvers<ContextType = any, ParentType extends ResolversParentTypes['Score'] = ResolversParentTypes['Score']> = ResolversObject<{
  away?: Resolver<Maybe<ResolversTypes['Int']>, ParentType, ContextType>;
  home?: Resolver<Maybe<ResolversTypes['Int']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type ScoresResolvers<ContextType = any, ParentType extends ResolversParentTypes['Scores'] = ResolversParentTypes['Scores']> = ResolversObject<{
  bettingLink?: Resolver<Maybe<ResolversTypes['ScoresBettingLink']>, ParentType, ContextType>;
  calendarNavigation?: Resolver<Maybe<ResolversTypes['ScoresCalendarNavigation']>, ParentType, ContextType>;
  gameGroups?: Resolver<Maybe<Array<Maybe<ResolversTypes['GameGroup']>>>, ParentType, ContextType>;
  leagues?: Resolver<Maybe<Array<Maybe<ResolversTypes['ScoresLeague']>>>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type ScoresBettingLinkResolvers<ContextType = any, ParentType extends ResolversParentTypes['ScoresBettingLink'] = ResolversParentTypes['ScoresBettingLink']> = ResolversObject<{
  attributionText?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  betting?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  clickUrl?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  ctaText?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  disclaimerText?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  disclaimerUrl?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  id?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  logo?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  logoNight?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  partner?: Resolver<Maybe<ResolversTypes['ScoresOddsSportsbook']>, ParentType, ContextType>;
  showLinkout?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  success?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type ScoresCalendarNavigationResolvers<ContextType = any, ParentType extends ResolversParentTypes['ScoresCalendarNavigation'] = ResolversParentTypes['ScoresCalendarNavigation']> = ResolversObject<{
  current?: Resolver<Maybe<Array<Maybe<ResolversTypes['NavigationElement']>>>, ParentType, ContextType>;
  next?: Resolver<Maybe<Array<Maybe<ResolversTypes['NavigationElement']>>>, ParentType, ContextType>;
  previous?: Resolver<Maybe<Array<Maybe<ResolversTypes['NavigationElement']>>>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type ScoresDescriptionResolvers<ContextType = any, ParentType extends ResolversParentTypes['ScoresDescription'] = ResolversParentTypes['ScoresDescription']> = ResolversObject<{
  text?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type ScoresEventResolvers<ContextType = any, ParentType extends ResolversParentTypes['ScoresEvent'] = ResolversParentTypes['ScoresEvent']> = ResolversObject<{
  boxScore?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  current?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  descriptions?: Resolver<Maybe<Array<Maybe<ResolversTypes['ScoresDescription']>>>, ParentType, ContextType>;
  gameDate?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  gameEndDate?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  gameState?: Resolver<Maybe<ResolversTypes['ScoresState']>, ParentType, ContextType>;
  gamecast?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  gamecastInformation?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  gamecastTag?: Resolver<Maybe<ResolversTypes['TagV2']>, ParentType, ContextType, RequireFields<ScoresEventGamecastTagArgs, 'tenant'>>;
  id?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  league?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  metadata?: Resolver<Maybe<ResolversTypes['ScoresMetadata']>, ParentType, ContextType>;
  name?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  nameLabels?: Resolver<Maybe<Array<Maybe<ResolversTypes['ScoresEventNameLabel']>>>, ParentType, ContextType>;
  odds?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  participants?: Resolver<Maybe<ResolversTypes['ScoresEventParticipant']>, ParentType, ContextType>;
  progress?: Resolver<Maybe<ResolversTypes['ScoresProgress']>, ParentType, ContextType>;
  site?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  sport?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  status?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  stream?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  subName?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  type?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type ScoresEventNameLabelResolvers<ContextType = any, ParentType extends ResolversParentTypes['ScoresEventNameLabel'] = ResolversParentTypes['ScoresEventNameLabel']> = ResolversObject<{
  text?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type ScoresEventParticipantResolvers<ContextType = any, ParentType extends ResolversParentTypes['ScoresEventParticipant'] = ResolversParentTypes['ScoresEventParticipant']> = ResolversObject<{
  entries?: Resolver<Maybe<Array<Maybe<ResolversTypes['ScoresEventParticipantEntry']>>>, ParentType, ContextType>;
  headers?: Resolver<Maybe<ResolversTypes['ScoresEventParticipantHeader']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type ScoresEventParticipantEntryResolvers<ContextType = any, ParentType extends ResolversParentTypes['ScoresEventParticipantEntry'] = ResolversParentTypes['ScoresEventParticipantEntry']> = ResolversObject<{
  abbrev?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  isWinner?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  logo?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  name?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  number?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  values?: Resolver<Maybe<Array<Maybe<ResolversTypes['ScoresEventParticipantEntryValue']>>>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type ScoresEventParticipantEntryFontFormattingResolvers<ContextType = any, ParentType extends ResolversParentTypes['ScoresEventParticipantEntryFontFormatting'] = ResolversParentTypes['ScoresEventParticipantEntryFontFormatting']> = ResolversObject<{
  fontColor?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  fontColorNight?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  fontIsBold?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type ScoresEventParticipantEntryValueResolvers<ContextType = any, ParentType extends ResolversParentTypes['ScoresEventParticipantEntryValue'] = ResolversParentTypes['ScoresEventParticipantEntryValue']> = ResolversObject<{
  fontFormatting?: Resolver<Maybe<ResolversTypes['ScoresEventParticipantEntryFontFormatting']>, ParentType, ContextType>;
  value?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type ScoresEventParticipantHeaderResolvers<ContextType = any, ParentType extends ResolversParentTypes['ScoresEventParticipantHeader'] = ResolversParentTypes['ScoresEventParticipantHeader']> = ResolversObject<{
  value?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type ScoresGameResolvers<ContextType = any, ParentType extends ResolversParentTypes['ScoresGame'] = ResolversParentTypes['ScoresGame']> = ResolversObject<{
  boxScore?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  current?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  descriptions?: Resolver<Maybe<Array<Maybe<ResolversTypes['ScoresDescription']>>>, ParentType, ContextType>;
  gameDate?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  gameEndDate?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  gameState?: Resolver<Maybe<ResolversTypes['ScoresState']>, ParentType, ContextType>;
  gamecast?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  gamecastInformation?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  gamecastTag?: Resolver<Maybe<ResolversTypes['TagV2']>, ParentType, ContextType, RequireFields<ScoresGameGamecastTagArgs, 'tenant'>>;
  id?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  league?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  maxPeriodScores?: Resolver<Maybe<ResolversTypes['Int']>, ParentType, ContextType>;
  metadata?: Resolver<Maybe<ResolversTypes['ScoresMetadata']>, ParentType, ContextType>;
  name?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  odds?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  progress?: Resolver<Maybe<ResolversTypes['ScoresProgress']>, ParentType, ContextType>;
  site?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  sport?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  squadRide?: Resolver<Maybe<ResolversTypes['SquadRide']>, ParentType, ContextType>;
  status?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  teamOne?: Resolver<Maybe<ResolversTypes['ScoresGameTeam']>, ParentType, ContextType>;
  teamTwo?: Resolver<Maybe<ResolversTypes['ScoresGameTeam']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type ScoresGameTeamResolvers<ContextType = any, ParentType extends ResolversParentTypes['ScoresGameTeam'] = ResolversParentTypes['ScoresGameTeam']> = ResolversObject<{
  abbrev?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  colors?: Resolver<Maybe<Array<Maybe<ResolversTypes['String']>>>, ParentType, ContextType>;
  competitors?: Resolver<Maybe<Array<Maybe<ResolversTypes['ScoresTeamCompetitor']>>>, ParentType, ContextType>;
  hasPossession?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  isWinner?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  logo?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  mainScore?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  name?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  odds?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  periodScores?: Resolver<Maybe<Array<Maybe<ResolversTypes['PeriodScore']>>>, ParentType, ContextType>;
  permalink?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  rank?: Resolver<Maybe<ResolversTypes['Int']>, ParentType, ContextType>;
  record?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  score?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  secondaryScore?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  shortName?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  virtual?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type ScoresLeagueResolvers<ContextType = any, ParentType extends ResolversParentTypes['ScoresLeague'] = ResolversParentTypes['ScoresLeague']> = ResolversObject<{
  children?: Resolver<Maybe<Array<Maybe<ResolversTypes['ScoresLeague']>>>, ParentType, ContextType>;
  current?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  href?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  id?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  league?: Resolver<Maybe<ResolversTypes['Int']>, ParentType, ContextType>;
  name?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  queryParameters?: Resolver<Maybe<ResolversTypes['ScoresLeagueQueryParameters']>, ParentType, ContextType>;
  slug?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  tag?: Resolver<Maybe<ResolversTypes['Tag']>, ParentType, ContextType>;
  tagV2?: Resolver<Maybe<ResolversTypes['TagV2']>, ParentType, ContextType, RequireFields<ScoresLeagueTagV2Args, 'tenant'>>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type ScoresLeagueQueryParametersResolvers<ContextType = any, ParentType extends ResolversParentTypes['ScoresLeagueQueryParameters'] = ResolversParentTypes['ScoresLeagueQueryParameters']> = ResolversObject<{
  context?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  date?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  league?: Resolver<Maybe<ResolversTypes['StatsLeagues']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type ScoresMetadataResolvers<ContextType = any, ParentType extends ResolversParentTypes['ScoresMetadata'] = ResolversParentTypes['ScoresMetadata']> = ResolversObject<{
  about?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  endDate?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  location?: Resolver<Maybe<ResolversTypes['ScoresMetadataLocation']>, ParentType, ContextType>;
  name?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  startDate?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  status?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type ScoresMetadataLocationResolvers<ContextType = any, ParentType extends ResolversParentTypes['ScoresMetadataLocation'] = ResolversParentTypes['ScoresMetadataLocation']> = ResolversObject<{
  city?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  country?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  name?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  state?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  zip?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type ScoresProgressResolvers<ContextType = any, ParentType extends ResolversParentTypes['ScoresProgress'] = ResolversParentTypes['ScoresProgress']> = ResolversObject<{
  clock?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  inningPhase?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  network?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  playPeriod?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  playPeriodCondensed?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  round?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  venue?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type ScoresStateResolvers<ContextType = any, ParentType extends ResolversParentTypes['ScoresState'] = ResolversParentTypes['ScoresState']> = ResolversObject<{
  balls?: Resolver<Maybe<ResolversTypes['Int']>, ParentType, ContextType>;
  isRedZone?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  outs?: Resolver<Maybe<ResolversTypes['Int']>, ParentType, ContextType>;
  runners?: Resolver<Maybe<ResolversTypes['ScoresStateRunners']>, ParentType, ContextType>;
  strikes?: Resolver<Maybe<ResolversTypes['Int']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type ScoresStateRunnersResolvers<ContextType = any, ParentType extends ResolversParentTypes['ScoresStateRunners'] = ResolversParentTypes['ScoresStateRunners']> = ResolversObject<{
  first?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  second?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  third?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type ScoresTeamCompetitorResolvers<ContextType = any, ParentType extends ResolversParentTypes['ScoresTeamCompetitor'] = ResolversParentTypes['ScoresTeamCompetitor']> = ResolversObject<{
  abbrev?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  logo?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  name?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  rank?: Resolver<Maybe<ResolversTypes['Int']>, ParentType, ContextType>;
  slug?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  team?: Resolver<Maybe<ResolversTypes['Int']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type SearchAssetResolvers<ContextType = any, ParentType extends ResolversParentTypes['SearchAsset'] = ResolversParentTypes['SearchAsset']> = ResolversObject<{
  __resolveType: TypeResolveFn<'Article' | 'Channel' | 'ExternalArticle' | 'User' | 'VideoV2', ParentType, ContextType>;
}>;

export type SearchResultResolvers<ContextType = any, ParentType extends ResolversParentTypes['SearchResult'] = ResolversParentTypes['SearchResult']> = ResolversObject<{
  contentModule?: Resolver<Maybe<ResolversTypes['StandaloneContentModule']>, ParentType, ContextType>;
  searchAsset?: Resolver<Maybe<ResolversTypes['SearchAsset']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type SearchResultsResolvers<ContextType = any, ParentType extends ResolversParentTypes['SearchResults'] = ResolversParentTypes['SearchResults']> = ResolversObject<{
  connection?: Resolver<Maybe<ResolversTypes['AssetConnection']>, ParentType, ContextType>;
  didYouMeanResponse?: Resolver<Maybe<ResolversTypes['QueryAssistResponse']>, ParentType, ContextType>;
  errors?: Resolver<Maybe<Array<Maybe<ResolversTypes['String']>>>, ParentType, ContextType>;
  facetResponse?: Resolver<Maybe<Array<ResolversTypes['FacetResponse']>>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type SeasonResolvers<ContextType = any, ParentType extends ResolversParentTypes['Season'] = ResolversParentTypes['Season']> = ResolversObject<{
  current?: Resolver<Maybe<ResolversTypes['Int']>, ParentType, ContextType>;
  end?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  id?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  name?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  start?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  type?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type SeriesResolvers<ContextType = any, ParentType extends ResolversParentTypes['Series'] = ResolversParentTypes['Series']> = ResolversObject<{
  events?: Resolver<Maybe<Array<Maybe<ResolversTypes['Event']>>>, ParentType, ContextType, Partial<SeriesEventsArgs>>;
  hash?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  id?: Resolver<Maybe<ResolversTypes['ID']>, ParentType, ContextType>;
  season?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  series_name?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  start_date?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  taxonomy?: Resolver<Maybe<ResolversTypes['TaxonomyTerm']>, ParentType, ContextType>;
  territories_available?: Resolver<Maybe<Array<Maybe<ResolversTypes['Territories']>>>, ParentType, ContextType>;
  tournament?: Resolver<Maybe<ResolversTypes['Tournament']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type SeriesesResolvers<ContextType = any, ParentType extends ResolversParentTypes['Serieses'] = ResolversParentTypes['Serieses']> = ResolversObject<{
  index_end?: Resolver<Maybe<ResolversTypes['Int']>, ParentType, ContextType>;
  index_start?: Resolver<Maybe<ResolversTypes['Int']>, ParentType, ContextType>;
  series?: Resolver<Maybe<Array<Maybe<ResolversTypes['Series']>>>, ParentType, ContextType>;
  total?: Resolver<Maybe<ResolversTypes['Int']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type SettingsResolvers<ContextType = any, ParentType extends ResolversParentTypes['Settings'] = ResolversParentTypes['Settings']> = ResolversObject<{
  alerts?: Resolver<Maybe<Array<ResolversTypes['AlertPreference']>>, ParentType, ContextType>;
  social?: Resolver<Maybe<Array<ResolversTypes['SocialPreference']>>, ParentType, ContextType>;
  spoilers_enabled?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type ShowResolvers<ContextType = any, ParentType extends ResolversParentTypes['Show'] = ResolversParentTypes['Show']> = ResolversObject<{
  airDateTime?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  begin?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  end?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  episode?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  franchiseId?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  franchiseName?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  genreList?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  hash?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  highlightList?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  id?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  lang?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  length?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  offset?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  originalTitle?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  rate?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  ratingArgentina?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  ratingBrasil?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  ratingMexico?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  season?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  serie?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  status?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  storyline?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  summary?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  taxonomy?: Resolver<Maybe<ResolversTypes['TaxonomyTerm']>, ParentType, ContextType, RequireFields<ShowTaxonomyArgs, 'tenant'>>;
  title?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  titleId?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type SlideResolvers<ContextType = any, ParentType extends ResolversParentTypes['Slide'] = ResolversParentTypes['Slide']> = ResolversObject<{
  elements?: Resolver<Maybe<Array<Maybe<ResolversTypes['Element']>>>, ParentType, ContextType>;
  featuredMedia?: Resolver<ResolversTypes['Element'], ParentType, ContextType>;
  id?: Resolver<Maybe<ResolversTypes['Int']>, ParentType, ContextType>;
  slideNumber?: Resolver<Maybe<ResolversTypes['Int']>, ParentType, ContextType>;
  title?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type SocialLinksResolvers<ContextType = any, ParentType extends ResolversParentTypes['SocialLinks'] = ResolversParentTypes['SocialLinks']> = ResolversObject<{
  instagram?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  tiktok?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  twitch?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  twitter?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  youtube?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type SocialMediaHandleResolvers<ContextType = any, ParentType extends ResolversParentTypes['SocialMediaHandle'] = ResolversParentTypes['SocialMediaHandle']> = ResolversObject<{
  handle?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  platform?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type SocialPreferenceResolvers<ContextType = any, ParentType extends ResolversParentTypes['SocialPreference'] = ResolversParentTypes['SocialPreference']> = ResolversObject<{
  enabled?: Resolver<ResolversTypes['Boolean'], ParentType, ContextType>;
  type?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type SocialWidgetResolvers<ContextType = any, ParentType extends ResolversParentTypes['SocialWidget'] = ResolversParentTypes['SocialWidget']> = ResolversObject<{
  clientId?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  commentBoardReactionSpaceId?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  count?: Resolver<Maybe<ResolversTypes['Int']>, ParentType, ContextType>;
  fireReactionId?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  liveLikeUserReaction?: Resolver<Maybe<ResolversTypes['CustomLiveLikeUserReaction']>, ParentType, ContextType>;
  targetGroupId?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  type?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  widgetId?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type SportResolvers<ContextType = any, ParentType extends ResolversParentTypes['Sport'] = ResolversParentTypes['Sport']> = ResolversObject<{
  event_image?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  gracenote_id?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  has_media?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  icon_dark?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  icon_light?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  id?: Resolver<Maybe<ResolversTypes['ID']>, ParentType, ContextType>;
  leagues?: Resolver<Maybe<Array<Maybe<ResolversTypes['League']>>>, ParentType, ContextType, Partial<SportLeaguesArgs>>;
  name?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  sportradar_id?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  territories_available?: Resolver<Maybe<Array<Maybe<ResolversTypes['Territories']>>>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type SportMetaDataResolvers<ContextType = any, ParentType extends ResolversParentTypes['SportMetaData'] = ResolversParentTypes['SportMetaData']> = ResolversObject<{
  league?: Resolver<Maybe<ResolversTypes['StatsLeagues']>, ParentType, ContextType>;
  sport?: Resolver<Maybe<ResolversTypes['StatsSport']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type SportsResolvers<ContextType = any, ParentType extends ResolversParentTypes['Sports'] = ResolversParentTypes['Sports']> = ResolversObject<{
  index_end?: Resolver<Maybe<ResolversTypes['Int']>, ParentType, ContextType>;
  index_start?: Resolver<Maybe<ResolversTypes['Int']>, ParentType, ContextType>;
  sports?: Resolver<Maybe<Array<Maybe<ResolversTypes['Sport']>>>, ParentType, ContextType>;
  total?: Resolver<Maybe<ResolversTypes['Int']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type SquadRideResolvers<ContextType = any, ParentType extends ResolversParentTypes['SquadRide'] = ResolversParentTypes['SquadRide']> = ResolversObject<{
  id?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  outcome?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type StandaloneContentModuleResolvers<ContextType = any, ParentType extends ResolversParentTypes['StandaloneContentModule'] = ResolversParentTypes['StandaloneContentModule']> = ResolversObject<{
  adsConfig?: Resolver<Maybe<ResolversTypes['AdsConfiguration']>, ParentType, ContextType>;
  alertRanks?: Resolver<Array<Maybe<ResolversTypes['AlertRank']>>, ParentType, ContextType, RequireFields<StandaloneContentModuleAlertRanksArgs, 'limit'>>;
  alertedChannelTagUUID?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  allowedCountries?: Resolver<Maybe<Array<Maybe<ResolversTypes['String']>>>, ParentType, ContextType>;
  commentsEnabled?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  components?: Resolver<Maybe<Array<Maybe<ResolversTypes['ComponentModule']>>>, ParentType, ContextType>;
  composites?: Resolver<Maybe<Array<Maybe<ResolversTypes['PackageContentModule']>>>, ParentType, ContextType>;
  content?: Resolver<ResolversTypes['ProgrammedContent'], ParentType, ContextType>;
  contentID?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  contentMetadata?: Resolver<Maybe<ResolversTypes['ContentMetadata']>, ParentType, ContextType>;
  description?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  expiresAt?: Resolver<Maybe<ResolversTypes['Date']>, ParentType, ContextType>;
  hidden?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  hiddenExpiresAt?: Resolver<Maybe<ResolversTypes['Date']>, ParentType, ContextType>;
  id?: Resolver<ResolversTypes['ID'], ParentType, ContextType>;
  insertedAt?: Resolver<Maybe<ResolversTypes['Date']>, ParentType, ContextType>;
  isAlerted?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  isPositionLocked?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  lastModifiedBy?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  metaData?: Resolver<Maybe<ResolversTypes['ModuleMetaData']>, ParentType, ContextType>;
  orientation?: Resolver<ResolversTypes['ModuleOrientation'], ParentType, ContextType>;
  position?: Resolver<Maybe<ResolversTypes['Int']>, ParentType, ContextType>;
  positionLockExpiresAt?: Resolver<Maybe<ResolversTypes['Date']>, ParentType, ContextType>;
  programmingUpdatedAt?: Resolver<Maybe<ResolversTypes['Date']>, ParentType, ContextType>;
  scheduledDate?: Resolver<Maybe<ResolversTypes['Date']>, ParentType, ContextType>;
  socialWidgets?: Resolver<Maybe<Array<Maybe<ResolversTypes['SocialWidget']>>>, ParentType, ContextType>;
  state?: Resolver<Maybe<ResolversTypes['ModuleState']>, ParentType, ContextType>;
  thumbnail?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  thumbnailAccreditation?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  thumbnailCopyright?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  title?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  type?: Resolver<ResolversTypes['ContentModuleType'], ParentType, ContextType>;
  updatedAt?: Resolver<Maybe<ResolversTypes['Date']>, ParentType, ContextType>;
  wrapperContentModuleId?: Resolver<Maybe<ResolversTypes['ID']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type StatsBetOfferResolvers<ContextType = any, ParentType extends ResolversParentTypes['StatsBetOffer'] = ResolversParentTypes['StatsBetOffer']> = ResolversObject<{
  jsonResponse?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type StatsBettingResolvers<ContextType = any, ParentType extends ResolversParentTypes['StatsBetting'] = ResolversParentTypes['StatsBetting']> = ResolversObject<{
  id?: Resolver<ResolversTypes['ID'], ParentType, ContextType>;
  jsonResponse?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type StatsGamecastResolvers<ContextType = any, ParentType extends ResolversParentTypes['StatsGamecast'] = ResolversParentTypes['StatsGamecast']> = ResolversObject<{
  gameDate?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  jsonResponse?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  linescore?: Resolver<Maybe<ResolversTypes['StatsLinescore']>, ParentType, ContextType>;
  pbp?: Resolver<Maybe<ResolversTypes['StatsPbp']>, ParentType, ContextType>;
  podium?: Resolver<Maybe<ResolversTypes['StatsPodium']>, ParentType, ContextType>;
  raceInfo?: Resolver<Maybe<ResolversTypes['StatsRaceInfo']>, ParentType, ContextType>;
  scoreLeaderboard?: Resolver<Maybe<ResolversTypes['ScoresEvent']>, ParentType, ContextType>;
  scoreboard?: Resolver<Maybe<ResolversTypes['StatsScoreboard']>, ParentType, ContextType>;
  slug?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  sport?: Resolver<Maybe<ResolversTypes['StatsSport']>, ParentType, ContextType>;
  status?: Resolver<Maybe<ResolversTypes['StatsGameStatus']>, ParentType, ContextType>;
  tag?: Resolver<Maybe<ResolversTypes['TagV2']>, ParentType, ContextType, Partial<StatsGamecastTagArgs>>;
  venue?: Resolver<Maybe<ResolversTypes['StatsVenue']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type StatsLinescoreResolvers<ContextType = any, ParentType extends ResolversParentTypes['StatsLinescore'] = ResolversParentTypes['StatsLinescore']> = ResolversObject<{
  gameState?: Resolver<Maybe<ResolversTypes['StatsLinescoreGameState']>, ParentType, ContextType>;
  headers?: Resolver<Maybe<Array<Maybe<ResolversTypes['StatsLinescoreValue']>>>, ParentType, ContextType>;
  summaryHeaders?: Resolver<Maybe<Array<Maybe<ResolversTypes['StatsLinescoreValue']>>>, ParentType, ContextType>;
  teamOne?: Resolver<Maybe<ResolversTypes['StatsLinescoreTeam']>, ParentType, ContextType>;
  teamTwo?: Resolver<Maybe<ResolversTypes['StatsLinescoreTeam']>, ParentType, ContextType>;
  title?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type StatsLinescoreBatterResolvers<ContextType = any, ParentType extends ResolversParentTypes['StatsLinescoreBatter'] = ResolversParentTypes['StatsLinescoreBatter']> = ResolversObject<{
  atBats?: Resolver<Maybe<ResolversTypes['Int']>, ParentType, ContextType>;
  average?: Resolver<Maybe<ResolversTypes['Float']>, ParentType, ContextType>;
  player?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  totalHits?: Resolver<Maybe<ResolversTypes['Int']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type StatsLinescoreDiamondResolvers<ContextType = any, ParentType extends ResolversParentTypes['StatsLinescoreDiamond'] = ResolversParentTypes['StatsLinescoreDiamond']> = ResolversObject<{
  first?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  second?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  third?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type StatsLinescoreGameStateResolvers<ContextType = any, ParentType extends ResolversParentTypes['StatsLinescoreGameState'] = ResolversParentTypes['StatsLinescoreGameState']> = ResolversObject<{
  balls?: Resolver<Maybe<ResolversTypes['Int']>, ParentType, ContextType>;
  batter?: Resolver<Maybe<ResolversTypes['StatsLinescoreBatter']>, ParentType, ContextType>;
  outs?: Resolver<Maybe<ResolversTypes['Int']>, ParentType, ContextType>;
  pitcher?: Resolver<Maybe<ResolversTypes['StatsLinescorePitcher']>, ParentType, ContextType>;
  runners?: Resolver<Maybe<ResolversTypes['StatsLinescoreDiamond']>, ParentType, ContextType>;
  strikes?: Resolver<Maybe<ResolversTypes['Int']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type StatsLinescorePitcherResolvers<ContextType = any, ParentType extends ResolversParentTypes['StatsLinescorePitcher'] = ResolversParentTypes['StatsLinescorePitcher']> = ResolversObject<{
  player?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  totalPitches?: Resolver<Maybe<ResolversTypes['Int']>, ParentType, ContextType>;
  totalStrikeouts?: Resolver<Maybe<ResolversTypes['Int']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type StatsLinescoreTeamResolvers<ContextType = any, ParentType extends ResolversParentTypes['StatsLinescoreTeam'] = ResolversParentTypes['StatsLinescoreTeam']> = ResolversObject<{
  colors?: Resolver<Maybe<Array<Maybe<ResolversTypes['String']>>>, ParentType, ContextType>;
  logo?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  name?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  record?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  summaryValues?: Resolver<Maybe<Array<Maybe<ResolversTypes['StatsLinescoreValue']>>>, ParentType, ContextType>;
  values?: Resolver<Maybe<Array<Maybe<ResolversTypes['StatsLinescoreValue']>>>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type StatsLinescoreValueResolvers<ContextType = any, ParentType extends ResolversParentTypes['StatsLinescoreValue'] = ResolversParentTypes['StatsLinescoreValue']> = ResolversObject<{
  value?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type StatsPbpResolvers<ContextType = any, ParentType extends ResolversParentTypes['StatsPbp'] = ResolversParentTypes['StatsPbp']> = ResolversObject<{
  pbpPreview?: Resolver<Maybe<ResolversTypes['StatsPbpPreview']>, ParentType, ContextType>;
  plays?: Resolver<Maybe<Array<ResolversTypes['StatsPbpPlay']>>, ParentType, ContextType>;
  scoringSummary?: Resolver<Maybe<ResolversTypes['StatsPbpTabGrouping']>, ParentType, ContextType>;
  tabs?: Resolver<Maybe<ResolversTypes['StatsPbpTabs']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type StatsPbpDriveChartResolvers<ContextType = any, ParentType extends ResolversParentTypes['StatsPbpDriveChart'] = ResolversParentTypes['StatsPbpDriveChart']> = ResolversObject<{
  currentPosition?: Resolver<Maybe<ResolversTypes['Float']>, ParentType, ContextType>;
  direction?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  firstDownPosition?: Resolver<Maybe<ResolversTypes['Float']>, ParentType, ContextType>;
  startingPosition?: Resolver<Maybe<ResolversTypes['Float']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type StatsPbpDriveSummaryResolvers<ContextType = any, ParentType extends ResolversParentTypes['StatsPbpDriveSummary'] = ResolversParentTypes['StatsPbpDriveSummary']> = ResolversObject<{
  isRedzone?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  logo?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  primaryDescription?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  secondaryDescription?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type StatsPbpPeriodGroupingResolvers<ContextType = any, ParentType extends ResolversParentTypes['StatsPbpPeriodGrouping'] = ResolversParentTypes['StatsPbpPeriodGrouping']> = ResolversObject<{
  collapsable?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  collapsed?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  description?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  plays?: Resolver<Maybe<Array<ResolversTypes['Int']>>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type StatsPbpPlayResolvers<ContextType = any, ParentType extends ResolversParentTypes['StatsPbpPlay'] = ResolversParentTypes['StatsPbpPlay']> = ResolversObject<{
  boldPenalty?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  gameProgress?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  gameProgressPrimary?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  gameProgressSecondary?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  logo?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  playStoppage?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  scoreTeamOne?: Resolver<Maybe<ResolversTypes['Int']>, ParentType, ContextType>;
  scoreTeamTwo?: Resolver<Maybe<ResolversTypes['Int']>, ParentType, ContextType>;
  sequence?: Resolver<Maybe<ResolversTypes['Int']>, ParentType, ContextType>;
  summary?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  teamName?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  teamOneScoringPlay?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  teamTwoScoringPlay?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type StatsPbpPreviewResolvers<ContextType = any, ParentType extends ResolversParentTypes['StatsPbpPreview'] = ResolversParentTypes['StatsPbpPreview']> = ResolversObject<{
  description?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  driveChart?: Resolver<Maybe<ResolversTypes['StatsPbpDriveChart']>, ParentType, ContextType>;
  driveSummary?: Resolver<Maybe<ResolversTypes['StatsPbpDriveSummary']>, ParentType, ContextType>;
  formatting?: Resolver<Maybe<ResolversTypes['StatsPbpTextFormatting']>, ParentType, ContextType>;
  gameStateDescription?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  groupings?: Resolver<Maybe<Array<ResolversTypes['StatsPbpPeriodGrouping']>>, ParentType, ContextType>;
  id?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  useGameProgressSecondary?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type StatsPbpTabGroupingResolvers<ContextType = any, ParentType extends ResolversParentTypes['StatsPbpTabGrouping'] = ResolversParentTypes['StatsPbpTabGrouping']> = ResolversObject<{
  description?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  groupings?: Resolver<Array<ResolversTypes['StatsPbpPeriodGrouping']>, ParentType, ContextType>;
  id?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  useGameProgressSecondary?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type StatsPbpTabsResolvers<ContextType = any, ParentType extends ResolversParentTypes['StatsPbpTabs'] = ResolversParentTypes['StatsPbpTabs']> = ResolversObject<{
  byPeriod?: Resolver<Maybe<ResolversTypes['StatsPbpTabGrouping']>, ParentType, ContextType>;
  penalties?: Resolver<Maybe<ResolversTypes['StatsPbpTabGrouping']>, ParentType, ContextType>;
  scoringSummary?: Resolver<Maybe<ResolversTypes['StatsPbpTabGrouping']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type StatsPbpTextFormattingResolvers<ContextType = any, ParentType extends ResolversParentTypes['StatsPbpTextFormatting'] = ResolversParentTypes['StatsPbpTextFormatting']> = ResolversObject<{
  fontColor?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  fontColorNight?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  fontIsBold?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  fontIsItalic?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  textClass?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type StatsPodiumResolvers<ContextType = any, ParentType extends ResolversParentTypes['StatsPodium'] = ResolversParentTypes['StatsPodium']> = ResolversObject<{
  entries?: Resolver<Maybe<Array<Maybe<ResolversTypes['StatsPodiumEntry']>>>, ParentType, ContextType>;
  title?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type StatsPodiumEntryResolvers<ContextType = any, ParentType extends ResolversParentTypes['StatsPodiumEntry'] = ResolversParentTypes['StatsPodiumEntry']> = ResolversObject<{
  logo?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  name?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  place?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  result?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  subResult?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type StatsRaceInfoResolvers<ContextType = any, ParentType extends ResolversParentTypes['StatsRaceInfo'] = ResolversParentTypes['StatsRaceInfo']> = ResolversObject<{
  distance?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  distanceUnit?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  laps?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  name?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  status?: Resolver<Maybe<ResolversTypes['StatsGameStatus']>, ParentType, ContextType>;
  type?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type StatsScheduleResolvers<ContextType = any, ParentType extends ResolversParentTypes['StatsSchedule'] = ResolversParentTypes['StatsSchedule']> = ResolversObject<{
  adPlacement?: Resolver<Maybe<Array<Maybe<ResolversTypes['StatsScheduleAdPlacement']>>>, ParentType, ContextType>;
  league?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  name?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  scheduleGroupings?: Resolver<Maybe<Array<Maybe<ResolversTypes['StatsScheduleGrouping']>>>, ParentType, ContextType>;
  slug?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type StatsScheduleAdPlacementResolvers<ContextType = any, ParentType extends ResolversParentTypes['StatsScheduleAdPlacement'] = ResolversParentTypes['StatsScheduleAdPlacement']> = ResolversObject<{
  adId?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  gameRowIndex?: Resolver<Maybe<ResolversTypes['Int']>, ParentType, ContextType>;
  groupIndex?: Resolver<Maybe<ResolversTypes['Int']>, ParentType, ContextType>;
  repeatOffset?: Resolver<Maybe<ResolversTypes['Int']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type StatsScheduleEntryResolvers<ContextType = any, ParentType extends ResolversParentTypes['StatsScheduleEntry'] = ResolversParentTypes['StatsScheduleEntry']> = ResolversObject<{
  current?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  date?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  group?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  homeAway?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  isoUtcDatetime?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  location?: Resolver<Maybe<ResolversTypes['ScoresMetadataLocation']>, ParentType, ContextType>;
  opponent?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  opponentLogo?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  resultCode?: Resolver<Maybe<ResolversTypes['StatsScheduleResultCode']>, ParentType, ContextType>;
  resultDescription?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  slug?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  startTimeTbd?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  status?: Resolver<Maybe<ResolversTypes['StatsGameStatus']>, ParentType, ContextType>;
  ticketInfo?: Resolver<Maybe<ResolversTypes['StatsScheduleTickets']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type StatsScheduleGroupingResolvers<ContextType = any, ParentType extends ResolversParentTypes['StatsScheduleGrouping'] = ResolversParentTypes['StatsScheduleGrouping']> = ResolversObject<{
  current?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  entries?: Resolver<Maybe<Array<Maybe<ResolversTypes['StatsScheduleEntry']>>>, ParentType, ContextType>;
  key?: Resolver<Maybe<Array<Maybe<ResolversTypes['StatsScheduleKey']>>>, ParentType, ContextType>;
  link?: Resolver<Maybe<ResolversTypes['StatsScheduleLink']>, ParentType, ContextType>;
  title?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type StatsScheduleKeyResolvers<ContextType = any, ParentType extends ResolversParentTypes['StatsScheduleKey'] = ResolversParentTypes['StatsScheduleKey']> = ResolversObject<{
  color?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  returnColor?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  value?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type StatsScheduleLinkResolvers<ContextType = any, ParentType extends ResolversParentTypes['StatsScheduleLink'] = ResolversParentTypes['StatsScheduleLink']> = ResolversObject<{
  title?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  type?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  value?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type StatsScheduleResultCodeResolvers<ContextType = any, ParentType extends ResolversParentTypes['StatsScheduleResultCode'] = ResolversParentTypes['StatsScheduleResultCode']> = ResolversObject<{
  color?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  colorNight?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  value?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type StatsScheduleTicketsResolvers<ContextType = any, ParentType extends ResolversParentTypes['StatsScheduleTickets'] = ResolversParentTypes['StatsScheduleTickets']> = ResolversObject<{
  minPrice?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  url?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type StatsScoreboardResolvers<ContextType = any, ParentType extends ResolversParentTypes['StatsScoreboard'] = ResolversParentTypes['StatsScoreboard']> = ResolversObject<{
  gameDate?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  progress?: Resolver<Maybe<ResolversTypes['ScoresProgress']>, ParentType, ContextType>;
  teamOne?: Resolver<Maybe<ResolversTypes['ScoresGameTeam']>, ParentType, ContextType>;
  teamTwo?: Resolver<Maybe<ResolversTypes['ScoresGameTeam']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type StatsScoreboardTeamResolvers<ContextType = any, ParentType extends ResolversParentTypes['StatsScoreboardTeam'] = ResolversParentTypes['StatsScoreboardTeam']> = ResolversObject<{
  abbrev?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  bonus?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  colors?: Resolver<Maybe<Array<Maybe<ResolversTypes['String']>>>, ParentType, ContextType>;
  competitors?: Resolver<Maybe<Array<Maybe<ResolversTypes['ScoresTeamCompetitor']>>>, ParentType, ContextType>;
  doubleBonus?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  hasPossession?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  hasPowerPlay?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  isRedZone?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  isWinner?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  logo?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  name?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  odds?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  periodScores?: Resolver<Maybe<Array<Maybe<ResolversTypes['PeriodScore']>>>, ParentType, ContextType>;
  permalink?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  rank?: Resolver<Maybe<ResolversTypes['Int']>, ParentType, ContextType>;
  record?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  score?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  shortName?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  timeoutsRemaining?: Resolver<Maybe<ResolversTypes['Int']>, ParentType, ContextType>;
  totalTimeouts?: Resolver<Maybe<ResolversTypes['Int']>, ParentType, ContextType>;
  virtual?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type StatsStandingResolvers<ContextType = any, ParentType extends ResolversParentTypes['StatsStanding'] = ResolversParentTypes['StatsStanding']> = ResolversObject<{
  name?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  season?: Resolver<Maybe<ResolversTypes['Int']>, ParentType, ContextType>;
  slug?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  standingGroupings?: Resolver<Maybe<Array<Maybe<ResolversTypes['StatsStandingGrouping']>>>, ParentType, ContextType>;
  tag?: Resolver<Maybe<ResolversTypes['Tag']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type StatsStandingAdPlacementResolvers<ContextType = any, ParentType extends ResolversParentTypes['StatsStandingAdPlacement'] = ResolversParentTypes['StatsStandingAdPlacement']> = ResolversObject<{
  adId?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  index?: Resolver<Maybe<ResolversTypes['Int']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type StatsStandingEntryResolvers<ContextType = any, ParentType extends ResolversParentTypes['StatsStandingEntry'] = ResolversParentTypes['StatsStandingEntry']> = ResolversObject<{
  current?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  headers?: Resolver<Maybe<Array<Maybe<ResolversTypes['StatsStandingHeader']>>>, ParentType, ContextType>;
  keys?: Resolver<Maybe<Array<Maybe<ResolversTypes['StatsStandingKey']>>>, ParentType, ContextType>;
  separator?: Resolver<Maybe<ResolversTypes['StatsStandingSeparator']>, ParentType, ContextType>;
  teams?: Resolver<Maybe<Array<Maybe<ResolversTypes['StatsStandingTeam']>>>, ParentType, ContextType>;
  title?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type StatsStandingGroupingResolvers<ContextType = any, ParentType extends ResolversParentTypes['StatsStandingGrouping'] = ResolversParentTypes['StatsStandingGrouping']> = ResolversObject<{
  adPlacement?: Resolver<Maybe<Array<Maybe<ResolversTypes['StatsStandingAdPlacement']>>>, ParentType, ContextType>;
  entries?: Resolver<Maybe<Array<Maybe<ResolversTypes['StatsStandingEntry']>>>, ParentType, ContextType>;
  title?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type StatsStandingHeaderResolvers<ContextType = any, ParentType extends ResolversParentTypes['StatsStandingHeader'] = ResolversParentTypes['StatsStandingHeader']> = ResolversObject<{
  title?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type StatsStandingKeyResolvers<ContextType = any, ParentType extends ResolversParentTypes['StatsStandingKey'] = ResolversParentTypes['StatsStandingKey']> = ResolversObject<{
  color?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  returnColor?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  value?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type StatsStandingSeparatorResolvers<ContextType = any, ParentType extends ResolversParentTypes['StatsStandingSeparator'] = ResolversParentTypes['StatsStandingSeparator']> = ResolversObject<{
  color?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  index?: Resolver<Maybe<ResolversTypes['Int']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type StatsStandingTeamResolvers<ContextType = any, ParentType extends ResolversParentTypes['StatsStandingTeam'] = ResolversParentTypes['StatsStandingTeam']> = ResolversObject<{
  color?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  current?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  logo?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  name?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  number?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  prefixSuperscript?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  returnColor?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  slug?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  superscript?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  tag?: Resolver<Maybe<ResolversTypes['Tag']>, ParentType, ContextType>;
  values?: Resolver<Maybe<Array<Maybe<ResolversTypes['StatsStandingValue']>>>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type StatsStandingValueResolvers<ContextType = any, ParentType extends ResolversParentTypes['StatsStandingValue'] = ResolversParentTypes['StatsStandingValue']> = ResolversObject<{
  value?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type StatsVenueResolvers<ContextType = any, ParentType extends ResolversParentTypes['StatsVenue'] = ResolversParentTypes['StatsVenue']> = ResolversObject<{
  location?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  stadium?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  weatherEmoji?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  weatherPrimary?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  weatherSecondary?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type StreamMetaDataResolvers<ContextType = any, ParentType extends ResolversParentTypes['StreamMetaData'] = ResolversParentTypes['StreamMetaData']> = ResolversObject<{
  _id?: Resolver<Maybe<ResolversTypes['MongoID']>, ParentType, ContextType>;
  headline?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  id?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  referenceStream?: Resolver<Maybe<ResolversTypes['ReferenceStream']>, ParentType, ContextType>;
  subtype?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  weight?: Resolver<Maybe<ResolversTypes['Float']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type TagResolvers<ContextType = any, ParentType extends ResolversParentTypes['Tag'] = ResolversParentTypes['Tag']> = ResolversObject<{
  abbreviation?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  active?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  children?: Resolver<Array<ResolversTypes['Tag']>, ParentType, ContextType>;
  color1?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  color2?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  displayLogo?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  expiresAt?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  href?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  id?: Resolver<ResolversTypes['ID'], ParentType, ContextType>;
  logoFileName?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  menu?: Resolver<Maybe<ResolversTypes['Menu']>, ParentType, ContextType, RequireFields<TagMenuArgs, 'tenant'>>;
  name?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  newsletterEnabled?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  parent?: Resolver<Maybe<ResolversTypes['Tag']>, ParentType, ContextType>;
  parents?: Resolver<Array<ResolversTypes['Tag']>, ParentType, ContextType>;
  permalink?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  position?: Resolver<Maybe<ResolversTypes['Int']>, ParentType, ContextType>;
  root?: Resolver<Maybe<ResolversTypes['Tag']>, ParentType, ContextType>;
  shopUrl?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  shortName?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  site?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  teamColor?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  ticketsLink?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  type?: Resolver<Maybe<ResolversTypes['TagType']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type TagGroupResolvers<ContextType = any, ParentType extends ResolversParentTypes['TagGroup'] = ResolversParentTypes['TagGroup']> = ResolversObject<{
  _id?: Resolver<ResolversTypes['MongoID'], ParentType, ContextType>;
  children?: Resolver<Maybe<Array<Maybe<ResolversTypes['TagV2']>>>, ParentType, ContextType>;
  cmsId?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  displayName?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  isPublished?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  language?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  schemaVersion?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  slug?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  tenant?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  type?: Resolver<ResolversTypes['EnumTagGroupType'], ParentType, ContextType>;
  uuid?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type TagV2Resolvers<ContextType = any, ParentType extends ResolversParentTypes['TagV2'] = ResolversParentTypes['TagV2']> = ResolversObject<{
  _id?: Resolver<ResolversTypes['MongoID'], ParentType, ContextType>;
  abbreviation?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  changed?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  channelState?: Resolver<Maybe<ResolversTypes['EnumTagV2ChannelState']>, ParentType, ContextType>;
  children?: Resolver<Maybe<Array<Maybe<ResolversTypes['TagV2']>>>, ParentType, ContextType>;
  cmsId?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  colorPrimary?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  colorSecondary?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  creatorTier?: Resolver<Maybe<ResolversTypes['CreatorTier']>, ParentType, ContextType>;
  description?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  displayName?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  endTime?: Resolver<Maybe<ResolversTypes['Date']>, ParentType, ContextType>;
  eyebrow?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  followers?: Resolver<Maybe<Array<Maybe<ResolversTypes['User']>>>, ParentType, ContextType, RequireFields<TagV2FollowersArgs, 'limit' | 'tenant'>>;
  followersCount?: Resolver<ResolversTypes['Int'], ParentType, ContextType, Partial<TagV2FollowersCountArgs>>;
  following?: Resolver<Maybe<Array<Maybe<ResolversTypes['TagV2']>>>, ParentType, ContextType, RequireFields<TagV2FollowingArgs, 'limit' | 'tenant'>>;
  followingMetadata?: Resolver<Maybe<ResolversTypes['FollowingMetadata']>, ParentType, ContextType>;
  foreignId?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  gameStatus?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  isChannel?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  isFeatured?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  isPublished?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  isVisibleContentTool?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  isVisibleProgrammingTool?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  language?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  locationRelatedTags?: Resolver<Maybe<Array<Maybe<ResolversTypes['TagV2']>>>, ParentType, ContextType>;
  logo?: Resolver<Maybe<ResolversTypes['Image']>, ParentType, ContextType>;
  menu?: Resolver<Maybe<ResolversTypes['Menu']>, ParentType, ContextType>;
  notifications?: Resolver<Maybe<Array<Maybe<ResolversTypes['Notifications']>>>, ParentType, ContextType>;
  parent?: Resolver<Maybe<ResolversTypes['TagV2']>, ParentType, ContextType>;
  parents?: Resolver<Maybe<Array<Maybe<ResolversTypes['TagV2']>>>, ParentType, ContextType>;
  recommendedArticles?: Resolver<Array<ResolversTypes['DsContentModelResult']>, ParentType, ContextType, RequireFields<TagV2RecommendedArticlesArgs, 'limit'>>;
  recommendedTags?: Resolver<Array<ResolversTypes['ChannelRecommenderResult']>, ParentType, ContextType, RequireFields<TagV2RecommendedTagsArgs, 'limit'>>;
  root?: Resolver<Maybe<ResolversTypes['TagV2']>, ParentType, ContextType>;
  schemaVersion?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  settings?: Resolver<Maybe<ResolversTypes['Settings']>, ParentType, ContextType>;
  shortName?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  slug?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  startTime?: Resolver<Maybe<ResolversTypes['Date']>, ParentType, ContextType>;
  tagUUID?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  tenant?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  ticketLink?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  type?: Resolver<Maybe<ResolversTypes['TagTypeV2']>, ParentType, ContextType>;
  updatedAt?: Resolver<Maybe<ResolversTypes['Date']>, ParentType, ContextType>;
  user?: Resolver<Maybe<ResolversTypes['User']>, ParentType, ContextType>;
  uuid?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  watchInfo?: Resolver<Maybe<Array<Maybe<ResolversTypes['WatchInfo']>>>, ParentType, ContextType, Partial<TagV2WatchInfoArgs>>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type TagV2ConnectionResolvers<ContextType = any, ParentType extends ResolversParentTypes['TagV2Connection'] = ResolversParentTypes['TagV2Connection']> = ResolversObject<{
  edges?: Resolver<Array<ResolversTypes['TagV2Edge']>, ParentType, ContextType>;
  pageInfo?: Resolver<ResolversTypes['PageInfo'], ParentType, ContextType>;
  totalCount?: Resolver<ResolversTypes['Int'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type TagV2EdgeResolvers<ContextType = any, ParentType extends ResolversParentTypes['TagV2Edge'] = ResolversParentTypes['TagV2Edge']> = ResolversObject<{
  cursor?: Resolver<ResolversTypes['ComponentCursor'], ParentType, ContextType>;
  node?: Resolver<ResolversTypes['TagV2'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type TaggingResolvers<ContextType = any, ParentType extends ResolversParentTypes['Tagging'] = ResolversParentTypes['Tagging']> = ResolversObject<{
  _id?: Resolver<Maybe<ResolversTypes['MongoID']>, ParentType, ContextType>;
  competitors?: Resolver<Maybe<Array<Maybe<ResolversTypes['Competitor']>>>, ParentType, ContextType>;
  events?: Resolver<Maybe<Array<Maybe<ResolversTypes['Event']>>>, ParentType, ContextType>;
  shows?: Resolver<Maybe<Array<Maybe<ResolversTypes['String']>>>, ParentType, ContextType>;
  tags?: Resolver<Maybe<Array<Maybe<ResolversTypes['String']>>>, ParentType, ContextType>;
  tournaments?: Resolver<Maybe<Array<Maybe<ResolversTypes['Tournament']>>>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type TaxonomyReferenceResolvers<ContextType = any, ParentType extends ResolversParentTypes['TaxonomyReference'] = ResolversParentTypes['TaxonomyReference']> = ResolversObject<{
  taxonomyId?: Resolver<Maybe<ResolversTypes['Identifier']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type TaxonomyReferenceGroupResolvers<ContextType = any, ParentType extends ResolversParentTypes['TaxonomyReferenceGroup'] = ResolversParentTypes['TaxonomyReferenceGroup']> = ResolversObject<{
  kind?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  taxonomyReferences?: Resolver<Maybe<Array<Maybe<ResolversTypes['TaxonomyReference']>>>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type TaxonomyTermResolvers<ContextType = any, ParentType extends ResolversParentTypes['TaxonomyTerm'] = ResolversParentTypes['TaxonomyTerm']> = ResolversObject<{
  _id?: Resolver<ResolversTypes['MongoID'], ParentType, ContextType>;
  changed?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  cmsId?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  created?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  description?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  id?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  image?: Resolver<Maybe<ResolversTypes['Image']>, ParentType, ContextType>;
  isPublished?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  language?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  name?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  parentId?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  schemaVersion?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  sportsRadarId?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  tenant?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  tournamentId?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  type?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  uuid?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  year?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type TeamResolvers<ContextType = any, ParentType extends ResolversParentTypes['Team'] = ResolversParentTypes['Team']> = ResolversObject<{
  abbreviation?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  draws?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  logo?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  losses?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  market?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  mascot?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  name?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  wins?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type TournamentResolvers<ContextType = any, ParentType extends ResolversParentTypes['Tournament'] = ResolversParentTypes['Tournament']> = ResolversObject<{
  display_name?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  display_name_short?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  has_media?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  hash?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  id?: Resolver<Maybe<ResolversTypes['ID']>, ParentType, ContextType>;
  is_featured?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  is_popular?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  league?: Resolver<Maybe<ResolversTypes['League']>, ParentType, ContextType>;
  name?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  sport?: Resolver<Maybe<ResolversTypes['Sport']>, ParentType, ContextType>;
  team_tournament?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  territories_available?: Resolver<Maybe<Array<Maybe<ResolversTypes['Territories']>>>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type TournamentsResolvers<ContextType = any, ParentType extends ResolversParentTypes['Tournaments'] = ResolversParentTypes['Tournaments']> = ResolversObject<{
  index_end?: Resolver<Maybe<ResolversTypes['Int']>, ParentType, ContextType>;
  index_start?: Resolver<Maybe<ResolversTypes['Int']>, ParentType, ContextType>;
  total?: Resolver<Maybe<ResolversTypes['Int']>, ParentType, ContextType>;
  tournaments?: Resolver<Maybe<Array<Maybe<ResolversTypes['Tournament']>>>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type TrendingChannelResultResolvers<ContextType = any, ParentType extends ResolversParentTypes['TrendingChannelResult'] = ResolversParentTypes['TrendingChannelResult']> = ResolversObject<{
  rank?: Resolver<ResolversTypes['Int'], ParentType, ContextType>;
  tagV2?: Resolver<ResolversTypes['TagV2'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type TrendingResultResolvers<ContextType = any, ParentType extends ResolversParentTypes['TrendingResult'] = ResolversParentTypes['TrendingResult']> = ResolversObject<{
  contentID?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  contentModule?: Resolver<Maybe<ResolversTypes['StandaloneContentModule']>, ParentType, ContextType>;
  rank?: Resolver<ResolversTypes['Int'], ParentType, ContextType>;
  type?: Resolver<ResolversTypes['ContentModuleType'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type TweetResolvers<ContextType = any, ParentType extends ResolversParentTypes['Tweet'] = ResolversParentTypes['Tweet']> = ResolversObject<{
  author?: Resolver<Maybe<ResolversTypes['TwitterUser']>, ParentType, ContextType>;
  data?: Resolver<Maybe<ResolversTypes['TweetData']>, ParentType, ContextType>;
  id?: Resolver<ResolversTypes['ID'], ParentType, ContextType>;
  media?: Resolver<Maybe<Array<Maybe<ResolversTypes['TweetMedia']>>>, ParentType, ContextType>;
  referencedTweet?: Resolver<Maybe<ResolversTypes['Tweet']>, ParentType, ContextType>;
  type?: Resolver<ResolversTypes['TweetType'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type TweetAttachmentsResolvers<ContextType = any, ParentType extends ResolversParentTypes['TweetAttachments'] = ResolversParentTypes['TweetAttachments']> = ResolversObject<{
  mediaKeys?: Resolver<Maybe<Array<Maybe<ResolversTypes['String']>>>, ParentType, ContextType>;
  pollIds?: Resolver<Maybe<Array<Maybe<ResolversTypes['String']>>>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type TweetDataResolvers<ContextType = any, ParentType extends ResolversParentTypes['TweetData'] = ResolversParentTypes['TweetData']> = ResolversObject<{
  attachments?: Resolver<Maybe<ResolversTypes['TweetAttachments']>, ParentType, ContextType>;
  authorId?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  createdAt?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  entities?: Resolver<Maybe<ResolversTypes['TweetEntities']>, ParentType, ContextType>;
  publicMetrics?: Resolver<ResolversTypes['TweetMetrics'], ParentType, ContextType>;
  referencedTweets?: Resolver<Maybe<Array<Maybe<ResolversTypes['TweetReference']>>>, ParentType, ContextType>;
  text?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type TweetEntitiesResolvers<ContextType = any, ParentType extends ResolversParentTypes['TweetEntities'] = ResolversParentTypes['TweetEntities']> = ResolversObject<{
  hashTags?: Resolver<Maybe<Array<Maybe<ResolversTypes['TweetHashtag']>>>, ParentType, ContextType>;
  mentions?: Resolver<Maybe<Array<Maybe<ResolversTypes['TweetMention']>>>, ParentType, ContextType>;
  urls?: Resolver<Maybe<Array<Maybe<ResolversTypes['TweetUrl']>>>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type TweetHashtagResolvers<ContextType = any, ParentType extends ResolversParentTypes['TweetHashtag'] = ResolversParentTypes['TweetHashtag']> = ResolversObject<{
  end?: Resolver<ResolversTypes['Int'], ParentType, ContextType>;
  start?: Resolver<ResolversTypes['Int'], ParentType, ContextType>;
  tag?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type TweetMediaResolvers<ContextType = any, ParentType extends ResolversParentTypes['TweetMedia'] = ResolversParentTypes['TweetMedia']> = ResolversObject<{
  height?: Resolver<ResolversTypes['Int'], ParentType, ContextType>;
  mediaKey?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  previewImageUrl?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  type?: Resolver<ResolversTypes['TweetMediaType'], ParentType, ContextType>;
  url?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  variants?: Resolver<Maybe<Array<Maybe<ResolversTypes['TweetVariant']>>>, ParentType, ContextType>;
  width?: Resolver<ResolversTypes['Int'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type TweetMentionResolvers<ContextType = any, ParentType extends ResolversParentTypes['TweetMention'] = ResolversParentTypes['TweetMention']> = ResolversObject<{
  end?: Resolver<ResolversTypes['Int'], ParentType, ContextType>;
  start?: Resolver<ResolversTypes['Int'], ParentType, ContextType>;
  username?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type TweetMetricsResolvers<ContextType = any, ParentType extends ResolversParentTypes['TweetMetrics'] = ResolversParentTypes['TweetMetrics']> = ResolversObject<{
  bookmarkCount?: Resolver<ResolversTypes['Int'], ParentType, ContextType>;
  impressionCount?: Resolver<ResolversTypes['Int'], ParentType, ContextType>;
  likeCount?: Resolver<ResolversTypes['Int'], ParentType, ContextType>;
  quoteCount?: Resolver<ResolversTypes['Int'], ParentType, ContextType>;
  replyCount?: Resolver<ResolversTypes['Int'], ParentType, ContextType>;
  retweetCount?: Resolver<ResolversTypes['Int'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type TweetReferenceResolvers<ContextType = any, ParentType extends ResolversParentTypes['TweetReference'] = ResolversParentTypes['TweetReference']> = ResolversObject<{
  id?: Resolver<ResolversTypes['ID'], ParentType, ContextType>;
  referenceType?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type TweetUrlResolvers<ContextType = any, ParentType extends ResolversParentTypes['TweetUrl'] = ResolversParentTypes['TweetUrl']> = ResolversObject<{
  displayUrl?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  end?: Resolver<ResolversTypes['Int'], ParentType, ContextType>;
  expandedUrl?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  start?: Resolver<ResolversTypes['Int'], ParentType, ContextType>;
  url?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type TweetVariantResolvers<ContextType = any, ParentType extends ResolversParentTypes['TweetVariant'] = ResolversParentTypes['TweetVariant']> = ResolversObject<{
  bitRate?: Resolver<Maybe<ResolversTypes['Int']>, ParentType, ContextType>;
  contentType?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  url?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type TwitterUserResolvers<ContextType = any, ParentType extends ResolversParentTypes['TwitterUser'] = ResolversParentTypes['TwitterUser']> = ResolversObject<{
  id?: Resolver<ResolversTypes['ID'], ParentType, ContextType>;
  name?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  profileImageUrl?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  username?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  verified?: Resolver<ResolversTypes['Boolean'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type UgcImagePollResolvers<ContextType = any, ParentType extends ResolversParentTypes['UGCImagePoll'] = ResolversParentTypes['UGCImagePoll']> = ResolversObject<{
  id?: Resolver<ResolversTypes['ID'], ParentType, ContextType>;
  liveLikeImagePoll?: Resolver<Maybe<ResolversTypes['LiveLikeImagePoll']>, ParentType, ContextType>;
  liveLikeUserVote?: Resolver<Maybe<ResolversTypes['LiveLikeImagePollVote']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type UgcPostResolvers<ContextType = any, ParentType extends ResolversParentTypes['UGCPost'] = ResolversParentTypes['UGCPost']> = ResolversObject<{
  id?: Resolver<ResolversTypes['ID'], ParentType, ContextType>;
  liveLikeRichPost?: Resolver<Maybe<ResolversTypes['LiveLikeRichPost']>, ParentType, ContextType>;
  uploadId?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type UgcTextPollResolvers<ContextType = any, ParentType extends ResolversParentTypes['UGCTextPoll'] = ResolversParentTypes['UGCTextPoll']> = ResolversObject<{
  id?: Resolver<ResolversTypes['ID'], ParentType, ContextType>;
  liveLikeTextPoll?: Resolver<Maybe<ResolversTypes['LiveLikeTextPoll']>, ParentType, ContextType>;
  liveLikeUserVote?: Resolver<Maybe<ResolversTypes['LiveLikeTextPollVote']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type UgcWidgetResolvers<ContextType = any, ParentType extends ResolversParentTypes['UGCWidget'] = ResolversParentTypes['UGCWidget']> = ResolversObject<{
  clientId?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  count?: Resolver<Maybe<ResolversTypes['Int']>, ParentType, ContextType>;
  fireReactionId?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  liveLikeUserReaction?: Resolver<Maybe<ResolversTypes['LiveLikeUserReaction']>, ParentType, ContextType>;
  targetGroupId?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  type?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  widgetId?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export interface UrlScalarConfig extends GraphQLScalarTypeConfig<ResolversTypes['URL'], any> {
  name: 'URL';
}

export interface UuidScalarConfig extends GraphQLScalarTypeConfig<ResolversTypes['UUID'], any> {
  name: 'UUID';
}

export type UrlMappingResolvers<ContextType = any, ParentType extends ResolversParentTypes['UrlMapping'] = ResolversParentTypes['UrlMapping']> = ResolversObject<{
  mediaId?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  status?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  uploadUrl?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type UserResolvers<ContextType = any, ParentType extends ResolversParentTypes['User'] = ResolversParentTypes['User']> = ResolversObject<{
  avatar?: Resolver<Maybe<ResolversTypes['Avatar']>, ParentType, ContextType>;
  badges?: Resolver<Maybe<Array<Maybe<ResolversTypes['BadgeComponent']>>>, ParentType, ContextType>;
  creatorId?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  creatorTag?: Resolver<Maybe<ResolversTypes['TagV2']>, ParentType, ContextType>;
  favoriteTeams?: Resolver<Maybe<Array<Maybe<ResolversTypes['TagV2']>>>, ParentType, ContextType>;
  followers?: Resolver<Maybe<ResolversTypes['Int']>, ParentType, ContextType, Partial<UserFollowersArgs>>;
  following?: Resolver<Maybe<ResolversTypes['Int']>, ParentType, ContextType, Partial<UserFollowingArgs>>;
  globalBan?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  id?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  liveLikeProfileId?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  liveLikeToken?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  name?: Resolver<Maybe<ResolversTypes['Name']>, ParentType, ContextType>;
  profileDescription?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  profileId?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  recommendedLeagues?: Resolver<Maybe<Array<ResolversTypes['TrendingChannelResult']>>, ParentType, ContextType>;
  recommendedTeams?: Resolver<Maybe<Array<ResolversTypes['TrendingChannelResult']>>, ParentType, ContextType>;
  recommendedVideos?: Resolver<Maybe<Array<ResolversTypes['TrendingResult']>>, ParentType, ContextType>;
  scores?: Resolver<Maybe<ResolversTypes['Scores']>, ParentType, ContextType, Partial<UserScoresArgs>>;
  settings?: Resolver<Maybe<ResolversTypes['Settings']>, ParentType, ContextType>;
  socialLinks?: Resolver<Maybe<ResolversTypes['SocialLinks']>, ParentType, ContextType>;
  tags?: Resolver<Maybe<Array<Maybe<ResolversTypes['TagV2']>>>, ParentType, ContextType>;
  type?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type UserDestinationResolvers<ContextType = any, ParentType extends ResolversParentTypes['UserDestination'] = ResolversParentTypes['UserDestination']> = ResolversObject<{
  contentModule?: Resolver<Maybe<ResolversTypes['StandaloneContentModule']>, ParentType, ContextType>;
  contentModuleId?: Resolver<Maybe<ResolversTypes['ID']>, ParentType, ContextType>;
  tag?: Resolver<ResolversTypes['TagV2'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type UserSocialAlertResolvers<ContextType = any, ParentType extends ResolversParentTypes['UserSocialAlert'] = ResolversParentTypes['UserSocialAlert']> = ResolversObject<{
  activityType?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  adParameters?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  attachments?: Resolver<Maybe<Array<ResolversTypes['AlertMediaAttachment']>>, ParentType, ContextType>;
  commentId?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  createdAt?: Resolver<Maybe<ResolversTypes['DateTime']>, ParentType, ContextType>;
  id?: Resolver<ResolversTypes['ID'], ParentType, ContextType>;
  postId?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  showActivityCard?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  showAlertCard?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  sourceUserId?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  targetUserId?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  text?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  textHtml?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  title?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  titleHtml?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  userDestination?: Resolver<Maybe<ResolversTypes['UserDestination']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type V2VResultResolvers<ContextType = any, ParentType extends ResolversParentTypes['V2VResult'] = ResolversParentTypes['V2VResult']> = ResolversObject<{
  contentID?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  score?: Resolver<ResolversTypes['Float'], ParentType, ContextType>;
  type?: Resolver<ResolversTypes['ContentModuleType'], ParentType, ContextType>;
  video?: Resolver<Maybe<ResolversTypes['StandaloneContentModule']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type VenueResolvers<ContextType = any, ParentType extends ResolversParentTypes['Venue'] = ResolversParentTypes['Venue']> = ResolversObject<{
  address?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  capacity?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  city?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  country?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  id?: Resolver<Maybe<ResolversTypes['ID']>, ParentType, ContextType>;
  name?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  state?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  time_zone?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  zip?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type VenuesResolvers<ContextType = any, ParentType extends ResolversParentTypes['Venues'] = ResolversParentTypes['Venues']> = ResolversObject<{
  index_end?: Resolver<Maybe<ResolversTypes['Int']>, ParentType, ContextType>;
  index_start?: Resolver<Maybe<ResolversTypes['Int']>, ParentType, ContextType>;
  total?: Resolver<Maybe<ResolversTypes['Int']>, ParentType, ContextType>;
  venues?: Resolver<Maybe<Array<Maybe<ResolversTypes['Venue']>>>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type VideoResolvers<ContextType = any, ParentType extends ResolversParentTypes['Video'] = ResolversParentTypes['Video']> = ResolversObject<{
  _id?: Resolver<ResolversTypes['MongoID'], ParentType, ContextType>;
  cardLabel?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  changed?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  cmsId?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  collectionName?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  created?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  duration?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  episodeNumber?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  events?: Resolver<Maybe<Array<Maybe<ResolversTypes['Event']>>>, ParentType, ContextType>;
  headline?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  isPublished?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  language?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  mediaId?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  schemaVersion?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  sortDate?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  subHeadline?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  tagging?: Resolver<Maybe<ResolversTypes['Tagging']>, ParentType, ContextType>;
  tenant?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  thumbnail?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  title?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  uuid?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type VideoAnalyticsResolvers<ContextType = any, ParentType extends ResolversParentTypes['VideoAnalytics'] = ResolversParentTypes['VideoAnalytics']> = ResolversObject<{
  creationTimePeriod?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  id?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  league?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  publishMethod?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  publishedAt?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  rating?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  ruleId?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  ruleName?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  stream?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  team?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  title?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  videoId?: Resolver<Maybe<ResolversTypes['Int']>, ParentType, ContextType>;
  videoType?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type VideoAppNameResolvers<ContextType = any, ParentType extends ResolversParentTypes['VideoAppName'] = ResolversParentTypes['VideoAppName']> = ResolversObject<{
  allowValues?: Resolver<Maybe<Array<Maybe<ResolversTypes['String']>>>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type VideoImpressionTrackingResolvers<ContextType = any, ParentType extends ResolversParentTypes['VideoImpressionTracking'] = ResolversParentTypes['VideoImpressionTracking']> = ResolversObject<{
  name?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  url?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type VideoMetadataResolvers<ContextType = any, ParentType extends ResolversParentTypes['VideoMetadata'] = ResolversParentTypes['VideoMetadata']> = ResolversObject<{
  analytics?: Resolver<Maybe<ResolversTypes['VideoAnalytics']>, ParentType, ContextType>;
  duration?: Resolver<Maybe<ResolversTypes['Int']>, ParentType, ContextType>;
  height?: Resolver<Maybe<ResolversTypes['Int']>, ParentType, ContextType>;
  hlsUrl?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  impressionTracking?: Resolver<Maybe<Array<Maybe<ResolversTypes['VideoImpressionTracking']>>>, ParentType, ContextType>;
  mp4Url?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  state?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  videoId?: Resolver<Maybe<ResolversTypes['Int']>, ParentType, ContextType>;
  videoUrl?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  width?: Resolver<Maybe<ResolversTypes['Int']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type VideoTitleResolvers<ContextType = any, ParentType extends ResolversParentTypes['VideoTitle'] = ResolversParentTypes['VideoTitle']> = ResolversObject<{
  localizations?: Resolver<Maybe<Array<Maybe<ResolversTypes['Localization']>>>, ParentType, ContextType>;
  scope?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  type?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type VideoV2Resolvers<ContextType = any, ParentType extends ResolversParentTypes['VideoV2'] = ResolversParentTypes['VideoV2']> = ResolversObject<{
  _id?: Resolver<ResolversTypes['MongoID'], ParentType, ContextType>;
  cmsId?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  contentType?: Resolver<Maybe<ResolversTypes['VideoContentType']>, ParentType, ContextType>;
  createdAt?: Resolver<Maybe<ResolversTypes['Date']>, ParentType, ContextType>;
  createdDateTime?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  deliverableImage?: Resolver<Maybe<ResolversTypes['Image']>, ParentType, ContextType>;
  description?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  durationSeconds?: Resolver<Maybe<ResolversTypes['Float']>, ParentType, ContextType>;
  eventId?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  headline?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  height?: Resolver<Maybe<ResolversTypes['Int']>, ParentType, ContextType>;
  isPtScheduled?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  isPublished?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  lastModifiedDateTime?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  offering?: Resolver<Maybe<ResolversTypes['Offering']>, ParentType, ContextType>;
  playable?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  program?: Resolver<Maybe<ResolversTypes['Program']>, ParentType, ContextType>;
  recommendedVideos?: Resolver<Array<ResolversTypes['V2VResult']>, ParentType, ContextType, RequireFields<VideoV2RecommendedVideosArgs, 'aspectRatio' | 'limit' | 'version'>>;
  schemaVersion?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  subHeadline?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  tags?: Resolver<Maybe<Array<Maybe<ResolversTypes['TagV2']>>>, ParentType, ContextType>;
  tenant?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  title?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  trendingRank?: Resolver<Maybe<ResolversTypes['Int']>, ParentType, ContextType>;
  updatedAt?: Resolver<Maybe<ResolversTypes['Date']>, ParentType, ContextType>;
  uuid?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  videoSource?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  videoState?: Resolver<Maybe<ResolversTypes['VideoState']>, ParentType, ContextType>;
  videoType?: Resolver<Maybe<ResolversTypes['VideoType']>, ParentType, ContextType>;
  width?: Resolver<Maybe<ResolversTypes['Int']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type VideoV2MetadataResolvers<ContextType = any, ParentType extends ResolversParentTypes['VideoV2Metadata'] = ResolversParentTypes['VideoV2Metadata']> = ResolversObject<{
  state?: Resolver<Maybe<ResolversTypes['VideoState']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type VideoV2TagDataResolvers<ContextType = any, ParentType extends ResolversParentTypes['VideoV2TagData'] = ResolversParentTypes['VideoV2TagData']> = ResolversObject<{
  type?: Resolver<ResolversTypes['TagTypeV2'], ParentType, ContextType>;
  uuid?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type VideoV2TagIdsResolvers<ContextType = any, ParentType extends ResolversParentTypes['VideoV2TagIds'] = ResolversParentTypes['VideoV2TagIds']> = ResolversObject<{
  eventId?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  tagData?: Resolver<Maybe<Array<Maybe<ResolversTypes['VideoV2TagData']>>>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type WatchInfoResolvers<ContextType = any, ParentType extends ResolversParentTypes['WatchInfo'] = ResolversParentTypes['WatchInfo']> = ResolversObject<{
  logoUrl?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  name?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  text?: Resolver<Maybe<Array<Maybe<ResolversTypes['String']>>>, ParentType, ContextType>;
  url?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type BlockProfileResponseResolvers<ContextType = any, ParentType extends ResolversParentTypes['blockProfileResponse'] = ResolversParentTypes['blockProfileResponse']> = ResolversObject<{
  id?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  nickname?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type Resolvers<ContextType = any> = ResolversObject<{
  A2AResult?: A2AResultResolvers<ContextType>;
  A2VResult?: A2VResultResolvers<ContextType>;
  Action?: ActionResolvers<ContextType>;
  AddAlertRankResponse?: AddAlertRankResponseResolvers<ContextType>;
  AdsAdSize?: AdsAdSizeResolvers<ContextType>;
  AdsChannelConfiguration?: AdsChannelConfigurationResolvers<ContextType>;
  AdsChannelGroupingConfiguration?: AdsChannelGroupingConfigurationResolvers<ContextType>;
  AdsConfiguration?: AdsConfigurationResolvers<ContextType>;
  AdsDeployedState?: AdsDeployedStateResolvers<ContextType>;
  AdsHistory?: AdsHistoryResolvers<ContextType>;
  AdsModuleConfiguration?: AdsModuleConfigurationResolvers<ContextType>;
  AdsRegistryDetailItem?: AdsRegistryDetailItemResolvers<ContextType>;
  AdsSlot?: AdsSlotResolvers<ContextType>;
  AdsTargeting?: AdsTargetingResolvers<ContextType>;
  AdsViewport?: AdsViewportResolvers<ContextType>;
  AlertAnalytics?: AlertAnalyticsResolvers<ContextType>;
  AlertDestination?: AlertDestinationResolvers<ContextType>;
  AlertMediaAttachment?: AlertMediaAttachmentResolvers<ContextType>;
  AlertPreference?: AlertPreferenceResolvers<ContextType>;
  AlertRank?: AlertRankResolvers<ContextType>;
  AllowAll?: AllowAllResolvers<ContextType>;
  Allowed?: AllowedResolvers<ContextType>;
  Article?: ArticleResolvers<ContextType>;
  ArticleAuthor?: ArticleAuthorResolvers<ContextType>;
  ArticleConnection?: ArticleConnectionResolvers<ContextType>;
  ArticleEdge?: ArticleEdgeResolvers<ContextType>;
  AssetConnection?: AssetConnectionResolvers<ContextType>;
  AssetEdge?: AssetEdgeResolvers<ContextType>;
  Author?: AuthorResolvers<ContextType>;
  Avatar?: AvatarResolvers<ContextType>;
  Badge?: BadgeResolvers<ContextType>;
  BadgeComponent?: BadgeComponentResolvers<ContextType>;
  BillingOrder?: BillingOrderResolvers<ContextType>;
  BlockedContent?: BlockedContentResolvers<ContextType>;
  Brand?: BrandResolvers<ContextType>;
  Channel?: ChannelResolvers<ContextType>;
  ChannelComponent?: ChannelComponentResolvers<ContextType>;
  ChannelRecommenderResult?: ChannelRecommenderResultResolvers<ContextType>;
  ChannelStreamMetaData?: ChannelStreamMetaDataResolvers<ContextType>;
  ChatModule?: ChatModuleResolvers<ContextType>;
  Clock?: ClockResolvers<ContextType>;
  Competitor?: CompetitorResolvers<ContextType>;
  Competitors?: CompetitorsResolvers<ContextType>;
  Component?: ComponentResolvers<ContextType>;
  ComponentCursor?: GraphQLScalarType;
  ComponentEdge?: ComponentEdgeResolvers<ContextType>;
  ComponentModule?: ComponentModuleResolvers<ContextType>;
  ComponentsConnection?: ComponentsConnectionResolvers<ContextType>;
  Conference?: ConferenceResolvers<ContextType>;
  Conferences?: ConferencesResolvers<ContextType>;
  ConfigJson?: ConfigJsonResolvers<ContextType>;
  Content?: ContentResolvers<ContextType>;
  ContentBrand?: ContentBrandResolvers<ContextType>;
  ContentCursor?: GraphQLScalarType;
  ContentEdge?: ContentEdgeResolvers<ContextType>;
  ContentFilters?: ContentFiltersResolvers<ContextType>;
  ContentForm?: ContentFormResolvers<ContextType>;
  ContentLibrarySearchResult?: ContentLibrarySearchResultResolvers<ContextType>;
  ContentMetadata?: ContentMetadataResolvers<ContextType>;
  ContentModule?: ContentModuleResolvers<ContextType>;
  ContentShow?: ContentShowResolvers<ContextType>;
  ContentSort?: ContentSortResolvers<ContextType>;
  ContentsConnection?: ContentsConnectionResolvers<ContextType>;
  ContextFieldValue?: GraphQLScalarType;
  CreatePollResponse?: CreatePollResponseResolvers<ContextType>;
  CreatePostResponse?: CreatePostResponseResolvers<ContextType>;
  CreateProgramResponse?: CreateProgramResponseResolvers<ContextType>;
  Credit?: CreditResolvers<ContextType>;
  CustomLiveLikeUserReaction?: CustomLiveLikeUserReactionResolvers<ContextType>;
  Date?: GraphQLScalarType;
  DateTime?: GraphQLScalarType;
  DateTimeISO?: GraphQLScalarType;
  DeleteVideoContentModulesResult?: DeleteVideoContentModulesResultResolvers<ContextType>;
  Device?: DeviceResolvers<ContextType>;
  Division?: DivisionResolvers<ContextType>;
  Divisions?: DivisionsResolvers<ContextType>;
  DsContentModelResult?: DsContentModelResultResolvers<ContextType>;
  DsModel?: DsModelResolvers<ContextType>;
  Duration?: GraphQLScalarType;
  Element?: ElementResolvers<ContextType>;
  ElementContent?: ElementContentResolvers<ContextType>;
  Event?: EventResolvers<ContextType>;
  Events?: EventsResolvers<ContextType>;
  ExternalArticle?: ExternalArticleResolvers<ContextType>;
  FacetResponse?: FacetResponseResolvers<ContextType>;
  FacetResult?: FacetResultResolvers<ContextType>;
  Feed?: FeedResolvers<ContextType>;
  FollowingMetadata?: FollowingMetadataResolvers<ContextType>;
  FormElement?: FormElementResolvers<ContextType>;
  Game?: GameResolvers<ContextType>;
  GameDate?: GameDateResolvers<ContextType>;
  GameGroup?: GameGroupResolvers<ContextType>;
  GameProgress?: GameProgressResolvers<ContextType>;
  GamecastAnalytics?: GamecastAnalyticsResolvers<ContextType>;
  GamecastMetadata?: GamecastMetadataResolvers<ContextType>;
  GamecastProgress?: GamecastProgressResolvers<ContextType>;
  GamecastScoreboard?: GamecastScoreboardResolvers<ContextType>;
  GamecastTeam?: GamecastTeamResolvers<ContextType>;
  Grouping?: GroupingResolvers<ContextType>;
  GroupingHeader?: GroupingHeaderResolvers<ContextType>;
  Identifier?: IdentifierResolvers<ContextType>;
  Image?: ImageResolvers<ContextType>;
  ImageWithStyle?: ImageWithStyleResolvers<ContextType>;
  Item?: ItemResolvers<ContextType>;
  JSON?: GraphQLScalarType;
  JSONObject?: GraphQLScalarType;
  JWT?: GraphQLScalarType;
  League?: LeagueResolvers<ContextType>;
  Leagues?: LeaguesResolvers<ContextType>;
  Legacy?: LegacyResolvers<ContextType>;
  Limitation?: LimitationResolvers<ContextType>;
  Link?: LinkResolvers<ContextType>;
  LiveLikeAlert?: LiveLikeAlertResolvers<ContextType>;
  LiveLikeApplication?: LiveLikeApplicationResolvers<ContextType>;
  LiveLikeBadge?: LiveLikeBadgeResolvers<ContextType>;
  LiveLikeBadgeCollection?: LiveLikeBadgeCollectionResolvers<ContextType>;
  LiveLikeBadgeEdge?: LiveLikeBadgeEdgeResolvers<ContextType>;
  LiveLikeBadgeProfile?: LiveLikeBadgeProfileResolvers<ContextType>;
  LiveLikeBadgeProfileCollection?: LiveLikeBadgeProfileCollectionResolvers<ContextType>;
  LiveLikeBadgeProfileEdge?: LiveLikeBadgeProfileEdgeResolvers<ContextType>;
  LiveLikeBadgeRewardProgress?: LiveLikeBadgeRewardProgressResolvers<ContextType>;
  LiveLikeBadgeRewardProgressCollection?: LiveLikeBadgeRewardProgressCollectionResolvers<ContextType>;
  LiveLikeBlockProfile?: LiveLikeBlockProfileResolvers<ContextType>;
  LiveLikeChatRoom?: LiveLikeChatRoomResolvers<ContextType>;
  LiveLikeChatRoomChannel?: LiveLikeChatRoomChannelResolvers<ContextType>;
  LiveLikeChatRoomCollection?: LiveLikeChatRoomCollectionResolvers<ContextType>;
  LiveLikeChatRoomEdge?: LiveLikeChatRoomEdgeResolvers<ContextType>;
  LiveLikeComment?: LiveLikeCommentResolvers<ContextType>;
  LiveLikeCommentBoard?: LiveLikeCommentBoardResolvers<ContextType>;
  LiveLikeCommentBoardBan?: LiveLikeCommentBoardBanResolvers<ContextType>;
  LiveLikeCommentBoardBanCollection?: LiveLikeCommentBoardBanCollectionResolvers<ContextType>;
  LiveLikeCommentBoardBanEdge?: LiveLikeCommentBoardBanEdgeResolvers<ContextType>;
  LiveLikeCommentBoardCollection?: LiveLikeCommentBoardCollectionResolvers<ContextType>;
  LiveLikeCommentBoardCount?: LiveLikeCommentBoardCountResolvers<ContextType>;
  LiveLikeCommentBoardEdge?: LiveLikeCommentBoardEdgeResolvers<ContextType>;
  LiveLikeCommentCollection?: LiveLikeCommentCollectionResolvers<ContextType>;
  LiveLikeCommentEdge?: LiveLikeCommentEdgeResolvers<ContextType>;
  LiveLikeCommentReport?: LiveLikeCommentReportResolvers<ContextType>;
  LiveLikeCommentReportCollection?: LiveLikeCommentReportCollectionResolvers<ContextType>;
  LiveLikeCommentReportEdge?: LiveLikeCommentReportEdgeResolvers<ContextType>;
  LiveLikeConnection?: LiveLikeConnectionResolvers<ContextType>;
  LiveLikeEarnedBadge?: LiveLikeEarnedBadgeResolvers<ContextType>;
  LiveLikeEarnedBadgeCollection?: LiveLikeEarnedBadgeCollectionResolvers<ContextType>;
  LiveLikeEarnedBadgeEdge?: LiveLikeEarnedBadgeEdgeResolvers<ContextType>;
  LiveLikeEdge?: LiveLikeEdgeResolvers<ContextType>;
  LiveLikeEmoji?: LiveLikeEmojiResolvers<ContextType>;
  LiveLikeEmojiCount?: LiveLikeEmojiCountResolvers<ContextType>;
  LiveLikeImagePoll?: LiveLikeImagePollResolvers<ContextType>;
  LiveLikeImagePollOption?: LiveLikeImagePollOptionResolvers<ContextType>;
  LiveLikeImagePollVote?: LiveLikeImagePollVoteResolvers<ContextType>;
  LiveLikeImagePrediction?: LiveLikeImagePredictionResolvers<ContextType>;
  LiveLikeImagePredictionFollowUp?: LiveLikeImagePredictionFollowUpResolvers<ContextType>;
  LiveLikeImagePredictionOption?: LiveLikeImagePredictionOptionResolvers<ContextType>;
  LiveLikeImagePredictionVote?: LiveLikeImagePredictionVoteResolvers<ContextType>;
  LiveLikeImageQuiz?: LiveLikeImageQuizResolvers<ContextType>;
  LiveLikeImageQuizAnswer?: LiveLikeImageQuizAnswerResolvers<ContextType>;
  LiveLikeImageQuizChoice?: LiveLikeImageQuizChoiceResolvers<ContextType>;
  LiveLikeKeyValuePair?: LiveLikeKeyValuePairResolvers<ContextType>;
  LiveLikeLeaderboard?: LiveLikeLeaderboardResolvers<ContextType>;
  LiveLikeLeaderboardCollection?: LiveLikeLeaderboardCollectionResolvers<ContextType>;
  LiveLikeLeaderboardEdge?: LiveLikeLeaderboardEdgeResolvers<ContextType>;
  LiveLikeLeaderboardEntry?: LiveLikeLeaderboardEntryResolvers<ContextType>;
  LiveLikeLeaderboardEntryCollection?: LiveLikeLeaderboardEntryCollectionResolvers<ContextType>;
  LiveLikeLeaderboardEntryEdge?: LiveLikeLeaderboardEntryEdgeResolvers<ContextType>;
  LiveLikeLeaderboardReward?: LiveLikeLeaderboardRewardResolvers<ContextType>;
  LiveLikeNode?: LiveLikeNodeResolvers<ContextType>;
  LiveLikePage?: LiveLikePageResolvers<ContextType>;
  LiveLikePageOffset?: LiveLikePageOffsetResolvers<ContextType>;
  LiveLikePaginationOffset?: LiveLikePaginationOffsetResolvers<ContextType>;
  LiveLikePermission?: LiveLikePermissionResolvers<ContextType>;
  LiveLikePermissionEdge?: LiveLikePermissionEdgeResolvers<ContextType>;
  LiveLikePermissions?: LiveLikePermissionsResolvers<ContextType>;
  LiveLikeProfile?: LiveLikeProfileResolvers<ContextType>;
  LiveLikeProfileAuth?: LiveLikeProfileAuthResolvers<ContextType>;
  LiveLikeProfileRelationship?: LiveLikeProfileRelationshipResolvers<ContextType>;
  LiveLikeProfileRelationshipCollection?: LiveLikeProfileRelationshipCollectionResolvers<ContextType>;
  LiveLikeProfileRelationshipEdge?: LiveLikeProfileRelationshipEdgeResolvers<ContextType>;
  LiveLikeProfileRelationshipType?: LiveLikeProfileRelationshipTypeResolvers<ContextType>;
  LiveLikeProfileRelationshipTypeCollection?: LiveLikeProfileRelationshipTypeCollectionResolvers<ContextType>;
  LiveLikeProfileRelationshipTypeEdge?: LiveLikeProfileRelationshipTypeEdgeResolvers<ContextType>;
  LiveLikeProgram?: LiveLikeProgramResolvers<ContextType>;
  LiveLikeProgramBan?: LiveLikeProgramBanResolvers<ContextType>;
  LiveLikeProgramBanCollection?: LiveLikeProgramBanCollectionResolvers<ContextType>;
  LiveLikeProgramBanEdge?: LiveLikeProgramBanEdgeResolvers<ContextType>;
  LiveLikeProgramConnection?: LiveLikeProgramConnectionResolvers<ContextType>;
  LiveLikeProgramEdge?: LiveLikeProgramEdgeResolvers<ContextType>;
  LiveLikeProgramSchedule?: LiveLikeProgramScheduleResolvers<ContextType>;
  LiveLikeQuest?: LiveLikeQuestResolvers<ContextType>;
  LiveLikeQuestCollection?: LiveLikeQuestCollectionResolvers<ContextType>;
  LiveLikeQuestEdge?: LiveLikeQuestEdgeResolvers<ContextType>;
  LiveLikeQuestReward?: LiveLikeQuestRewardResolvers<ContextType>;
  LiveLikeQuestTask?: LiveLikeQuestTaskResolvers<ContextType>;
  LiveLikeReaction?: LiveLikeReactionResolvers<ContextType>;
  LiveLikeReactionPack?: LiveLikeReactionPackResolvers<ContextType>;
  LiveLikeReactionPackCollection?: LiveLikeReactionPackCollectionResolvers<ContextType>;
  LiveLikeReactionPackEdge?: LiveLikeReactionPackEdgeResolvers<ContextType>;
  LiveLikeReactionSpace?: LiveLikeReactionSpaceResolvers<ContextType>;
  LiveLikeReactionSpaceCollection?: LiveLikeReactionSpaceCollectionResolvers<ContextType>;
  LiveLikeReactionSpaceCount?: LiveLikeReactionSpaceCountResolvers<ContextType>;
  LiveLikeReactionSpaceEdge?: LiveLikeReactionSpaceEdgeResolvers<ContextType>;
  LiveLikeReactionSpacePatch?: LiveLikeReactionSpacePatchResolvers<ContextType>;
  LiveLikeReactions?: LiveLikeReactionsResolvers<ContextType>;
  LiveLikeResource?: LiveLikeResourceResolvers<ContextType>;
  LiveLikeReward?: LiveLikeRewardResolvers<ContextType>;
  LiveLikeRewardATableActionChoice?: LiveLikeRewardATableActionChoiceResolvers<ContextType>;
  LiveLikeRewardAction?: LiveLikeRewardActionResolvers<ContextType>;
  LiveLikeRewardActionItem?: LiveLikeRewardActionItemResolvers<ContextType>;
  LiveLikeRewardItem?: LiveLikeRewardItemResolvers<ContextType>;
  LiveLikeRewardItemBalance?: LiveLikeRewardItemBalanceResolvers<ContextType>;
  LiveLikeRewardItemBalanceCollection?: LiveLikeRewardItemBalanceCollectionResolvers<ContextType>;
  LiveLikeRewardItemBalanceEdge?: LiveLikeRewardItemBalanceEdgeResolvers<ContextType>;
  LiveLikeRewardItemCollection?: LiveLikeRewardItemCollectionResolvers<ContextType>;
  LiveLikeRewardItemEdge?: LiveLikeRewardItemEdgeResolvers<ContextType>;
  LiveLikeRewardItemImage?: LiveLikeRewardItemImageResolvers<ContextType>;
  LiveLikeRewardItemTransaction?: LiveLikeRewardItemTransactionResolvers<ContextType>;
  LiveLikeRewardTable?: LiveLikeRewardTableResolvers<ContextType>;
  LiveLikeRewardTableCollection?: LiveLikeRewardTableCollectionResolvers<ContextType>;
  LiveLikeRewardTableEdge?: LiveLikeRewardTableEdgeResolvers<ContextType>;
  LiveLikeRewardTableEntry?: LiveLikeRewardTableEntryResolvers<ContextType>;
  LiveLikeRichPost?: LiveLikeRichPostResolvers<ContextType>;
  LiveLikeRole?: LiveLikeRoleResolvers<ContextType>;
  LiveLikeRoleAssignment?: LiveLikeRoleAssignmentResolvers<ContextType>;
  LiveLikeRoleAssignmentConnection?: LiveLikeRoleAssignmentConnectionResolvers<ContextType>;
  LiveLikeRoleAssignmentEdge?: LiveLikeRoleAssignmentEdgeResolvers<ContextType>;
  LiveLikeRoleConnection?: LiveLikeRoleConnectionResolvers<ContextType>;
  LiveLikeRoleEdge?: LiveLikeRoleEdgeResolvers<ContextType>;
  LiveLikeScope?: LiveLikeScopeResolvers<ContextType>;
  LiveLikeSocialEmbed?: LiveLikeSocialEmbedResolvers<ContextType>;
  LiveLikeSocialEmbedItem?: LiveLikeSocialEmbedItemResolvers<ContextType>;
  LiveLikeTextPoll?: LiveLikeTextPollResolvers<ContextType>;
  LiveLikeTextPollOption?: LiveLikeTextPollOptionResolvers<ContextType>;
  LiveLikeTextPollVote?: LiveLikeTextPollVoteResolvers<ContextType>;
  LiveLikeTextPrediction?: LiveLikeTextPredictionResolvers<ContextType>;
  LiveLikeTextPredictionFollowUp?: LiveLikeTextPredictionFollowUpResolvers<ContextType>;
  LiveLikeTextPredictionOption?: LiveLikeTextPredictionOptionResolvers<ContextType>;
  LiveLikeTextPredictionVote?: LiveLikeTextPredictionVoteResolvers<ContextType>;
  LiveLikeTextQuiz?: LiveLikeTextQuizResolvers<ContextType>;
  LiveLikeTextQuizAnswer?: LiveLikeTextQuizAnswerResolvers<ContextType>;
  LiveLikeTextQuizChoice?: LiveLikeTextQuizChoiceResolvers<ContextType>;
  LiveLikeTokenGate?: LiveLikeTokenGateResolvers<ContextType>;
  LiveLikeTokenGateAttribute?: LiveLikeTokenGateAttributeResolvers<ContextType>;
  LiveLikeUserBadge?: LiveLikeUserBadgeResolvers<ContextType>;
  LiveLikeUserBadgeCollection?: LiveLikeUserBadgeCollectionResolvers<ContextType>;
  LiveLikeUserBadgeEdge?: LiveLikeUserBadgeEdgeResolvers<ContextType>;
  LiveLikeUserQuest?: LiveLikeUserQuestResolvers<ContextType>;
  LiveLikeUserQuestCollection?: LiveLikeUserQuestCollectionResolvers<ContextType>;
  LiveLikeUserQuestEdge?: LiveLikeUserQuestEdgeResolvers<ContextType>;
  LiveLikeUserQuestReward?: LiveLikeUserQuestRewardResolvers<ContextType>;
  LiveLikeUserQuestRewardsConnection?: LiveLikeUserQuestRewardsConnectionResolvers<ContextType>;
  LiveLikeUserQuestRewardsEdge?: LiveLikeUserQuestRewardsEdgeResolvers<ContextType>;
  LiveLikeUserQuestTask?: LiveLikeUserQuestTaskResolvers<ContextType>;
  LiveLikeUserQuestTaskProgress?: LiveLikeUserQuestTaskProgressResolvers<ContextType>;
  LiveLikeUserReaction?: LiveLikeUserReactionResolvers<ContextType>;
  LiveLikeUserReactionCollection?: LiveLikeUserReactionCollectionResolvers<ContextType>;
  LiveLikeUserReactionCountCollection?: LiveLikeUserReactionCountCollectionResolvers<ContextType>;
  LiveLikeUserReactionCountEdge?: LiveLikeUserReactionCountEdgeResolvers<ContextType>;
  LiveLikeUserReactionEdge?: LiveLikeUserReactionEdgeResolvers<ContextType>;
  LiveLikeVideoAlert?: LiveLikeVideoAlertResolvers<ContextType>;
  LiveLikeWidget?: LiveLikeWidgetResolvers<ContextType>;
  LiveLikeWidgetBase?: LiveLikeWidgetBaseResolvers<ContextType>;
  LiveLikeWidgetCollection?: LiveLikeWidgetCollectionResolvers<ContextType>;
  LiveLikeWidgetCreator?: LiveLikeWidgetCreatorResolvers<ContextType>;
  LiveLikeWidgetEdge?: LiveLikeWidgetEdgeResolvers<ContextType>;
  LiveLikeWidgetInteraction?: LiveLikeWidgetInteractionResolvers<ContextType>;
  LiveLikeWidgetInteractionBase?: LiveLikeWidgetInteractionBaseResolvers<ContextType>;
  LiveLikeWidgetInteractionBaseCreateInput?: LiveLikeWidgetInteractionBaseCreateInputResolvers<ContextType>;
  LiveLikeWidgetInteractionUnion?: LiveLikeWidgetInteractionUnionResolvers<ContextType>;
  LiveLikeWidgetInteractions?: LiveLikeWidgetInteractionsResolvers<ContextType>;
  LiveLikeWidgetOrder?: LiveLikeWidgetOrderResolvers<ContextType>;
  LiveLikeWidgetPublish?: LiveLikeWidgetPublishResolvers<ContextType>;
  LiveLikeWidgetReport?: LiveLikeWidgetReportResolvers<ContextType>;
  LiveLikeWidgetReportCollection?: LiveLikeWidgetReportCollectionResolvers<ContextType>;
  LiveLikeWidgetReportCount?: LiveLikeWidgetReportCountResolvers<ContextType>;
  LiveLikeWidgetReportEdge?: LiveLikeWidgetReportEdgeResolvers<ContextType>;
  Locale?: GraphQLScalarType;
  Localization?: LocalizationResolvers<ContextType>;
  Media?: MediaResolvers<ContextType>;
  Menu?: MenuResolvers<ContextType>;
  MenuLinks?: MenuLinksResolvers<ContextType>;
  MenuOptions?: MenuOptionsResolvers<ContextType>;
  MenuOptionsAttributes?: MenuOptionsAttributesResolvers<ContextType>;
  MenuRoutes?: MenuRoutesResolvers<ContextType>;
  Metadata?: MetadataResolvers<ContextType>;
  ModuleMetaData?: ModuleMetaDataResolvers<ContextType>;
  MongoID?: GraphQLScalarType;
  Mutation?: MutationResolvers<ContextType>;
  Name?: NameResolvers<ContextType>;
  NavigationElement?: NavigationElementResolvers<ContextType>;
  NavigationQueryParameters?: NavigationQueryParametersResolvers<ContextType>;
  NonEmptyString?: GraphQLScalarType;
  NonNegativeFloat?: GraphQLScalarType;
  NonNegativeInt?: GraphQLScalarType;
  NotificationMethod?: NotificationMethodResolvers<ContextType>;
  Notifications?: NotificationsResolvers<ContextType>;
  Offering?: OfferingResolvers<ContextType>;
  PackageContentModule?: PackageContentModuleResolvers<ContextType>;
  Page?: PageResolvers<ContextType>;
  PageBody?: PageBodyResolvers<ContextType>;
  PageInfo?: PageInfoResolvers<ContextType>;
  PageMetatags?: PageMetatagsResolvers<ContextType>;
  PeriodScore?: PeriodScoreResolvers<ContextType>;
  Playlist?: PlaylistResolvers<ContextType>;
  Poll?: PollResolvers<ContextType>;
  PositiveInt?: GraphQLScalarType;
  Post?: PostResolvers<ContextType>;
  PrepareImageResponse?: PrepareImageResponseResolvers<ContextType>;
  Product?: ProductResolvers<ContextType>;
  ProductLine?: ProductLineResolvers<ContextType>;
  Program?: ProgramResolvers<ContextType>;
  ProgrammedContent?: ProgrammedContentResolvers<ContextType>;
  PushNotification?: PushNotificationResolvers<ContextType>;
  PushNotificationAlertRankResponse?: PushNotificationAlertRankResponseResolvers<ContextType>;
  Query?: QueryResolvers<ContextType>;
  QueryAssistResponse?: QueryAssistResponseResolvers<ContextType>;
  QueryAssistResult?: QueryAssistResultResolvers<ContextType>;
  Rating?: RatingResolvers<ContextType>;
  Reference?: ReferenceResolvers<ContextType>;
  ReferenceMetadata?: ReferenceMetadataResolvers<ContextType>;
  ReferenceStream?: ReferenceStreamResolvers<ContextType>;
  Schedule?: ScheduleResolvers<ContextType>;
  Score?: ScoreResolvers<ContextType>;
  Scores?: ScoresResolvers<ContextType>;
  ScoresBettingLink?: ScoresBettingLinkResolvers<ContextType>;
  ScoresCalendarNavigation?: ScoresCalendarNavigationResolvers<ContextType>;
  ScoresDescription?: ScoresDescriptionResolvers<ContextType>;
  ScoresEvent?: ScoresEventResolvers<ContextType>;
  ScoresEventNameLabel?: ScoresEventNameLabelResolvers<ContextType>;
  ScoresEventParticipant?: ScoresEventParticipantResolvers<ContextType>;
  ScoresEventParticipantEntry?: ScoresEventParticipantEntryResolvers<ContextType>;
  ScoresEventParticipantEntryFontFormatting?: ScoresEventParticipantEntryFontFormattingResolvers<ContextType>;
  ScoresEventParticipantEntryValue?: ScoresEventParticipantEntryValueResolvers<ContextType>;
  ScoresEventParticipantHeader?: ScoresEventParticipantHeaderResolvers<ContextType>;
  ScoresGame?: ScoresGameResolvers<ContextType>;
  ScoresGameTeam?: ScoresGameTeamResolvers<ContextType>;
  ScoresLeague?: ScoresLeagueResolvers<ContextType>;
  ScoresLeagueQueryParameters?: ScoresLeagueQueryParametersResolvers<ContextType>;
  ScoresMetadata?: ScoresMetadataResolvers<ContextType>;
  ScoresMetadataLocation?: ScoresMetadataLocationResolvers<ContextType>;
  ScoresProgress?: ScoresProgressResolvers<ContextType>;
  ScoresState?: ScoresStateResolvers<ContextType>;
  ScoresStateRunners?: ScoresStateRunnersResolvers<ContextType>;
  ScoresTeamCompetitor?: ScoresTeamCompetitorResolvers<ContextType>;
  SearchAsset?: SearchAssetResolvers<ContextType>;
  SearchResult?: SearchResultResolvers<ContextType>;
  SearchResults?: SearchResultsResolvers<ContextType>;
  Season?: SeasonResolvers<ContextType>;
  Series?: SeriesResolvers<ContextType>;
  Serieses?: SeriesesResolvers<ContextType>;
  Settings?: SettingsResolvers<ContextType>;
  Show?: ShowResolvers<ContextType>;
  Slide?: SlideResolvers<ContextType>;
  SocialLinks?: SocialLinksResolvers<ContextType>;
  SocialMediaHandle?: SocialMediaHandleResolvers<ContextType>;
  SocialPreference?: SocialPreferenceResolvers<ContextType>;
  SocialWidget?: SocialWidgetResolvers<ContextType>;
  Sport?: SportResolvers<ContextType>;
  SportMetaData?: SportMetaDataResolvers<ContextType>;
  Sports?: SportsResolvers<ContextType>;
  SquadRide?: SquadRideResolvers<ContextType>;
  StandaloneContentModule?: StandaloneContentModuleResolvers<ContextType>;
  StatsBetOffer?: StatsBetOfferResolvers<ContextType>;
  StatsBetting?: StatsBettingResolvers<ContextType>;
  StatsGamecast?: StatsGamecastResolvers<ContextType>;
  StatsLinescore?: StatsLinescoreResolvers<ContextType>;
  StatsLinescoreBatter?: StatsLinescoreBatterResolvers<ContextType>;
  StatsLinescoreDiamond?: StatsLinescoreDiamondResolvers<ContextType>;
  StatsLinescoreGameState?: StatsLinescoreGameStateResolvers<ContextType>;
  StatsLinescorePitcher?: StatsLinescorePitcherResolvers<ContextType>;
  StatsLinescoreTeam?: StatsLinescoreTeamResolvers<ContextType>;
  StatsLinescoreValue?: StatsLinescoreValueResolvers<ContextType>;
  StatsPbp?: StatsPbpResolvers<ContextType>;
  StatsPbpDriveChart?: StatsPbpDriveChartResolvers<ContextType>;
  StatsPbpDriveSummary?: StatsPbpDriveSummaryResolvers<ContextType>;
  StatsPbpPeriodGrouping?: StatsPbpPeriodGroupingResolvers<ContextType>;
  StatsPbpPlay?: StatsPbpPlayResolvers<ContextType>;
  StatsPbpPreview?: StatsPbpPreviewResolvers<ContextType>;
  StatsPbpTabGrouping?: StatsPbpTabGroupingResolvers<ContextType>;
  StatsPbpTabs?: StatsPbpTabsResolvers<ContextType>;
  StatsPbpTextFormatting?: StatsPbpTextFormattingResolvers<ContextType>;
  StatsPodium?: StatsPodiumResolvers<ContextType>;
  StatsPodiumEntry?: StatsPodiumEntryResolvers<ContextType>;
  StatsRaceInfo?: StatsRaceInfoResolvers<ContextType>;
  StatsSchedule?: StatsScheduleResolvers<ContextType>;
  StatsScheduleAdPlacement?: StatsScheduleAdPlacementResolvers<ContextType>;
  StatsScheduleEntry?: StatsScheduleEntryResolvers<ContextType>;
  StatsScheduleGrouping?: StatsScheduleGroupingResolvers<ContextType>;
  StatsScheduleKey?: StatsScheduleKeyResolvers<ContextType>;
  StatsScheduleLink?: StatsScheduleLinkResolvers<ContextType>;
  StatsScheduleResultCode?: StatsScheduleResultCodeResolvers<ContextType>;
  StatsScheduleTickets?: StatsScheduleTicketsResolvers<ContextType>;
  StatsScoreboard?: StatsScoreboardResolvers<ContextType>;
  StatsScoreboardTeam?: StatsScoreboardTeamResolvers<ContextType>;
  StatsStanding?: StatsStandingResolvers<ContextType>;
  StatsStandingAdPlacement?: StatsStandingAdPlacementResolvers<ContextType>;
  StatsStandingEntry?: StatsStandingEntryResolvers<ContextType>;
  StatsStandingGrouping?: StatsStandingGroupingResolvers<ContextType>;
  StatsStandingHeader?: StatsStandingHeaderResolvers<ContextType>;
  StatsStandingKey?: StatsStandingKeyResolvers<ContextType>;
  StatsStandingSeparator?: StatsStandingSeparatorResolvers<ContextType>;
  StatsStandingTeam?: StatsStandingTeamResolvers<ContextType>;
  StatsStandingValue?: StatsStandingValueResolvers<ContextType>;
  StatsVenue?: StatsVenueResolvers<ContextType>;
  StreamMetaData?: StreamMetaDataResolvers<ContextType>;
  Tag?: TagResolvers<ContextType>;
  TagGroup?: TagGroupResolvers<ContextType>;
  TagV2?: TagV2Resolvers<ContextType>;
  TagV2Connection?: TagV2ConnectionResolvers<ContextType>;
  TagV2Edge?: TagV2EdgeResolvers<ContextType>;
  Tagging?: TaggingResolvers<ContextType>;
  TaxonomyReference?: TaxonomyReferenceResolvers<ContextType>;
  TaxonomyReferenceGroup?: TaxonomyReferenceGroupResolvers<ContextType>;
  TaxonomyTerm?: TaxonomyTermResolvers<ContextType>;
  Team?: TeamResolvers<ContextType>;
  Tournament?: TournamentResolvers<ContextType>;
  Tournaments?: TournamentsResolvers<ContextType>;
  TrendingChannelResult?: TrendingChannelResultResolvers<ContextType>;
  TrendingResult?: TrendingResultResolvers<ContextType>;
  Tweet?: TweetResolvers<ContextType>;
  TweetAttachments?: TweetAttachmentsResolvers<ContextType>;
  TweetData?: TweetDataResolvers<ContextType>;
  TweetEntities?: TweetEntitiesResolvers<ContextType>;
  TweetHashtag?: TweetHashtagResolvers<ContextType>;
  TweetMedia?: TweetMediaResolvers<ContextType>;
  TweetMention?: TweetMentionResolvers<ContextType>;
  TweetMetrics?: TweetMetricsResolvers<ContextType>;
  TweetReference?: TweetReferenceResolvers<ContextType>;
  TweetUrl?: TweetUrlResolvers<ContextType>;
  TweetVariant?: TweetVariantResolvers<ContextType>;
  TwitterUser?: TwitterUserResolvers<ContextType>;
  UGCImagePoll?: UgcImagePollResolvers<ContextType>;
  UGCPost?: UgcPostResolvers<ContextType>;
  UGCTextPoll?: UgcTextPollResolvers<ContextType>;
  UGCWidget?: UgcWidgetResolvers<ContextType>;
  URL?: GraphQLScalarType;
  UUID?: GraphQLScalarType;
  UrlMapping?: UrlMappingResolvers<ContextType>;
  User?: UserResolvers<ContextType>;
  UserDestination?: UserDestinationResolvers<ContextType>;
  UserSocialAlert?: UserSocialAlertResolvers<ContextType>;
  V2VResult?: V2VResultResolvers<ContextType>;
  Venue?: VenueResolvers<ContextType>;
  Venues?: VenuesResolvers<ContextType>;
  Video?: VideoResolvers<ContextType>;
  VideoAnalytics?: VideoAnalyticsResolvers<ContextType>;
  VideoAppName?: VideoAppNameResolvers<ContextType>;
  VideoImpressionTracking?: VideoImpressionTrackingResolvers<ContextType>;
  VideoMetadata?: VideoMetadataResolvers<ContextType>;
  VideoTitle?: VideoTitleResolvers<ContextType>;
  VideoV2?: VideoV2Resolvers<ContextType>;
  VideoV2Metadata?: VideoV2MetadataResolvers<ContextType>;
  VideoV2TagData?: VideoV2TagDataResolvers<ContextType>;
  VideoV2TagIds?: VideoV2TagIdsResolvers<ContextType>;
  WatchInfo?: WatchInfoResolvers<ContextType>;
  blockProfileResponse?: BlockProfileResponseResolvers<ContextType>;
}>;

